// Records a captioned tour of the real app (real KARMAX + wacli) to recordings/. Assigns real tasks.
//   node scripts/record-demo.mjs        (close the running app first; this launches its own copy)
import { _electron as electron } from 'playwright'
import { spawn, spawnSync } from 'node:child_process'
import { readFileSync, readdirSync, mkdirSync, existsSync, statSync } from 'node:fs'
import { join } from 'node:path'

const OUT = 'recordings'
mkdirSync(OUT, { recursive: true })
const HOME = process.env.USERPROFILE
const token = readFileSync(join(HOME, '.karmax', '.env'), 'utf8').match(/^KARMAX_API_TOKEN=(.+)$/m)[1].trim()
const setup = JSON.parse(readFileSync(join(process.env.APPDATA, 'KARMAX', 'setup.json'), 'utf8'))
const api = (path, body) =>
  fetch('http://127.0.0.1:9091' + path, { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' }, body: JSON.stringify(body ?? {}) }).then((r) => r.json())
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const log = (...a) => console.log(new Date().toLocaleTimeString(), ...a)

const app = await electron.launch({ args: ['.'] })
const w = await app.firstWindow()
await sleep(6000)
const geo = await app.evaluate(({ BrowserWindow, screen }) => {
  const b = BrowserWindow.getAllWindows()[0]
  b.unmaximize()
  b.setBounds({ x: 20, y: 10, width: 1200, height: 740 })
  b.setAlwaysOnTop(true, 'screen-saver')
  b.show()
  b.focus()
  const bounds = b.getBounds()
  return { bounds, sf: screen.getDisplayMatching(bounds).scaleFactor }
})
await sleep(2500)
// The app can restore its own saved window size after launch; force ours again and check what we actually got.
for (let i = 0; i < 4; i++) {
  await app.evaluate(({ BrowserWindow }) => {
    const b = BrowserWindow.getAllWindows()[0]
    b.setFullScreen(true)
  })
  await sleep(1500)
}
await sleep(3000) // let the fullscreen transition finish before measuring
{
  const g2 = await app.evaluate(({ BrowserWindow, screen }) => {
    const b = BrowserWindow.getAllWindows()[0]
    const bounds = b.getBounds()
    const d = screen.getDisplayMatching(bounds)
    return { bounds, sf: d.scaleFactor, screenW: Math.round(d.size.width * d.scaleFactor), screenH: Math.round(d.size.height * d.scaleFactor) }
  })
  geo.bounds = g2.bounds
  geo.sf = g2.sf
  geo.screenW = g2.screenW
  geo.screenH = g2.screenH
}
const even = (n) => Math.floor(n / 2) * 2
// Clamp to the visible screen (a maximized window reports negative offsets; ffmpeg rejects those).
const rx0 = Math.max(0, Math.round(geo.bounds.x * geo.sf))
const ry0 = Math.max(0, Math.round(geo.bounds.y * geo.sf))
const rx1 = Math.min(geo.screenW, Math.round((geo.bounds.x + geo.bounds.width) * geo.sf))
const ry1 = Math.min(geo.screenH, Math.round((geo.bounds.y + geo.bounds.height) * geo.sf))
const R = { x: rx0, y: ry0, w: even(rx1 - rx0), h: even(ry1 - ry0) }
log('capture region', JSON.stringify(R), 'scale', geo.sf)
const FFMPEG = (() => {
  const pk = join(process.env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Packages')
  const d = readdirSync(pk).find((n) => n.startsWith('Gyan.FFmpeg'))
  const inner = readdirSync(join(pk, d)).find((n) => n.startsWith('ffmpeg-'))
  return join(pk, d, inner, 'bin', 'ffmpeg.exe')
})()
const OUTFILE = join(OUT, 'karmax-demo.mp4')
const region = ['-f', 'gdigrab', '-framerate', '25', '-draw_mouse', '0', '-offset_x', String(R.x), '-offset_y', String(R.y), '-video_size', `${R.w}x${R.h}`, '-i', 'desktop']
mkdirSync('shots', { recursive: true })
spawnSync(FFMPEG, ['-y', ...region, '-frames:v', '1', 'shots/regiontest.png'], { stdio: 'ignore' })
const testSize = existsSync('shots/regiontest.png') ? statSync('shots/regiontest.png').size : 0
log('region self-test png bytes:', testSize)
if (testSize < 30000) {
  log('SELFTEST FAILED: capture is blank. Aborting.')
  await app.close()
  process.exit(2)
}
const ff = spawn(FFMPEG, ['-y', ...region, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-pix_fmt', 'yuv420p', OUTFILE], { stdio: ['pipe', 'ignore', 'ignore'] })
const ffDone = new Promise((r) => ff.on('exit', r))
await sleep(3500)
if (!existsSync(OUTFILE) || ff.exitCode !== null) {
  log('RECORDER FAILED: ffmpeg is not writing the video. Aborting.')
  ff.kill()
  await app.close()
  process.exit(3)
}
log('recording started ->', OUTFILE)

/* ── on-screen furniture: cursor, captions, title cards ───────────────── */
await w.evaluate(() => {
  const css = document.createElement('style')
  css.textContent = `
  #km-cursor{position:fixed;z-index:99999;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;border:2px solid #fff;background:rgba(57,135,229,.55);box-shadow:0 0 0 2px rgba(0,0,0,.5),0 0 18px rgba(57,135,229,.9);pointer-events:none;transition:transform .12s}
  #km-cursor.down{transform:scale(.6)}
  #km-cap{position:fixed;z-index:99998;left:50%;bottom:34px;transform:translateX(-50%) translateY(14px);opacity:0;max-width:1100px;padding:14px 26px;border-radius:16px;background:rgba(9,10,14,.88);border:1px solid rgba(255,255,255,.16);color:#fff;font:600 21px/1.35 "Segoe UI Variable Display","Segoe UI",sans-serif;text-align:center;box-shadow:0 18px 50px rgba(0,0,0,.6);transition:opacity .35s,transform .35s;pointer-events:none}
  #km-cap small{display:block;margin-top:4px;font:400 15px/1.4 "Segoe UI",sans-serif;color:#b9c6da}
  #km-cap.on{opacity:1;transform:translateX(-50%) translateY(0)}
  #km-card{position:fixed;inset:0;z-index:99997;display:grid;place-items:center;background:radial-gradient(900px 500px at 50% 30%,#16233d,#08090c 70%);color:#fff;font-family:"Segoe UI Variable Display","Segoe UI",sans-serif;text-align:center;opacity:0;pointer-events:none;transition:opacity .6s}
  #km-card.on{opacity:1}
  #km-card h1{font-size:68px;letter-spacing:.14em;margin:0 0 10px;font-weight:700}
  #km-card h2{font-size:26px;font-weight:400;color:#b9c6da;margin:0 0 34px}
  #km-card ul{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 40px;text-align:left;font-size:21px;color:#e8eefb}
  #km-card li::before{content:"";display:inline-block;width:9px;height:9px;border-radius:50%;background:#3987e5;margin-right:12px;box-shadow:0 0 10px #3987e5}`
  document.head.appendChild(css)
  const cur = document.createElement('div')
  cur.id = 'km-cursor'
  cur.style.left = '-50px'
  document.body.append(cur)
  addEventListener('mousemove', (e) => { cur.style.left = e.clientX + 'px'; cur.style.top = e.clientY + 'px' }, true)
  addEventListener('mousedown', () => cur.classList.add('down'), true)
  addEventListener('mouseup', () => cur.classList.remove('down'), true)
  const cap = document.createElement('div')
  cap.id = 'km-cap'
  document.body.append(cap)
  const card = document.createElement('div')
  card.id = 'km-card'
  document.body.append(card)
})
const cap = (t, sub = '') => w.evaluate(([t, sub]) => { const c = document.getElementById('km-cap'); c.innerHTML = t + (sub ? `<small>${sub}</small>` : ''); c.classList.add('on') }, [t, sub])
const uncap = () => w.evaluate(() => document.getElementById('km-cap').classList.remove('on'))
const card = (html) => w.evaluate((h) => { const c = document.getElementById('km-card'); c.innerHTML = h; c.classList.add('on') }, html)
const uncard = () => w.evaluate(() => document.getElementById('km-card').classList.remove('on'))

const glide = async (loc) => {
  try {
    await loc.scrollIntoViewIfNeeded({ timeout: 4000 })
    const b = await loc.boundingBox()
    if (!b) return
    await w.mouse.move(b.x + b.width / 2, b.y + b.height / 2, { steps: 28 })
    await sleep(350)
  } catch (e) {
    log('glide skipped:', String(e).split('\n')[0])
  }
}
const click = async (loc) => {
  await glide(loc)
  try {
    await loc.click({ timeout: 5000 })
  } catch (e) {
    log('click skipped:', String(e).split('\n')[0])
  }
}
const nav = (name) => click(w.getByRole('link', { name, exact: true }).first())
const typeSlow = async (loc, text, delay = 28) => {
  await click(loc)
  await w.keyboard.type(text, { delay })
}
const scrollChat = () =>
  w.evaluate(() => {
    const h = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /Recent operator conversation/.test(e.textContent || ''))
    for (let n = h; n; n = n.parentElement) {
      if (n.scrollHeight > n.clientHeight + 20 && /(auto|scroll)/.test(getComputedStyle(n).overflowY)) { n.scrollTo({ top: n.scrollHeight, behavior: 'smooth' }); break }
    }
  })
const waitReply = async (max = 170000) => {
  await sleep(2500)
  const stop = w.getByRole('button', { name: 'Stop the reply' })
  const t0 = Date.now()
  while (Date.now() - t0 < max && (await stop.isVisible().catch(() => false))) await sleep(800)
}

// Privacy: nothing but the operator chat may be unlocked, and the recording must never show other people's chats.
await sleep(3000)
{
  const WA = 'http://127.0.0.1:8765'
  try {
    const un = (await (await fetch(`${WA}/chats?filter=unlocked&limit=500`)).json()).chats ?? []
    for (const c of un) if (c.jid !== setup.operatorJid) await fetch(`${WA}/chats/${encodeURIComponent(c.jid)}`, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: '{"locked":true}' })
    log('unlocked chats before:', un.length, '(now only the operator chat)')
  } catch (e) {
    log('could not re-lock:', String(e).slice(0, 80))
  }
}
// Hide the old "brain is DOWN" alert bubble (a slow moment during testing) from the conversation panel.
await w.evaluate(() => {
  // Strictly bounded: only small elements (short text) are ever hidden, never a page container.
  let pending = false
  const hide = () => {
    pending = false
    for (const el of document.querySelectorAll('p,span,div')) {
      const t = el.textContent || ''
      if (el.children.length > 1 || t.length > 200 || !/brain is DOWN/.test(t) || el.dataset.kmHid) continue
      let bubble = el.closest('[class*="rounded"]') || el
      if ((bubble.textContent || '').length > 300) bubble = el
      let wrap = bubble
      const par = bubble.parentElement
      if (par && (par.textContent || '').length < 320 && /^KARMAX/.test((par.textContent || '').trim())) wrap = par
      if ((wrap.textContent || '').length < 400 && wrap.id !== 'root') {
        wrap.style.display = 'none'
        el.dataset.kmHid = '1'
      }
    }
  }
  new MutationObserver(() => { if (!pending) { pending = true; setTimeout(hide, 250) } }).observe(document.body, { childList: true, subtree: true })
  hide()
  // Safety net: the app root must never stay hidden.
  setInterval(() => { const r = document.getElementById('root'); if (r && r.style.display === 'none') r.style.display = '' }, 300)
})

/* ── 0. intro ─────────────────────────────────────────────────────────── */
await sleep(3500) // let both daemons come up
await w.evaluate(() => { location.hash = '#/chat' })
await card(`<div><h1>KARMAX</h1><h2>Your AI chief of staff. Give it work from WhatsApp or the desktop. It plans, does it, and reports back.</h2>
<ul><li>Conversation and task assignment</li><li>Live loops constellation</li><li>Task board with status and logs</li><li>Approvals before anything risky</li><li>WhatsApp operator channel</li><li>Long-term memory</li><li>Runs on your own Claude Code, no API key</li><li>Local first: your data stays on your PC</li></ul></div>`)
await sleep(7500)
await uncard()
await sleep(900)

for (const [content, category] of [
  ['KARMAX Desktop is an Electron cockpit for KARMAX and wacli: chat, task assignment, a live loops overview, approvals, a WhatsApp operator channel and memory.', 'project'],
  ['The operator prefers short, plain WhatsApp replies and a quick acknowledgement before long work.', 'preference'],
  ['The KARMAX demo video was recorded on 2026-09-20.', 'fact']
]) await api('/api/tools/memory.ingest', { content, category, importance: 0.7 }).catch(() => {})

/* ── 1. conversation ──────────────────────────────────────────────────── */
log('scene: conversation')
await cap('Conversation', 'Ask anything. KARMAX answers live, powered by your own Claude Code.')
await sleep(2500)
const box = w.getByPlaceholder(/Ask KARMAX anything/)
await typeSlow(box, 'Hi KARMAX! In two short sentences, what can you do for me?')
await sleep(600)
await w.keyboard.press('Enter')
await cap('Live streaming reply', 'Real KARMAX, real Claude. Nothing here is mocked.')
await waitReply()
await sleep(2500)

log('scene: memory chat')
await cap('It remembers', 'Facts you tell KARMAX go into long-term memory.')
await typeSlow(box, 'Remember this: our project is KARMAX Desktop and the demo is being recorded today.')
await sleep(500)
await w.keyboard.press('Enter')
await waitReply()
await sleep(2000)

/* ── 2. assign a task ─────────────────────────────────────────────────── */
log('scene: assign task')
await cap('Assign a task', 'Hand over work. It keeps going after you close the window.')
await click(w.getByRole('tab', { name: 'Assign task' }))
await sleep(1200)
await typeSlow(
  w.getByLabel('Task goal'),
  'Create a file named KARMAX-demo-report.md in the working directory with a short report of five bullet points on what KARMAX Desktop does: chat, task assignment, live loops overview, approvals, WhatsApp operator channel and memory. Keep it concise, then finish.',
  12
)
await sleep(700)
await w.getByPlaceholder('Defaults to the first line of the goal').fill('Write the KARMAX demo report', { timeout: 3000 }).catch(() => {})
await w.getByPlaceholder(/projects.repo/).fill('C:/Users/NISSI JESSE/.karmax/work/demo', { timeout: 3000 }).catch(() => {})
await click(w.getByRole('button', { name: 'Assign task' }).last())
await cap('Task assigned', 'KARMAX takes ownership and works in its own session.')
await sleep(4000)

// A second task that reports back on WhatsApp, created through KARMAX's own task tool.
const t2 = await api('/api/tools/task.create', {
  title: 'Report to WhatsApp',
  goal: 'Create a file named whatsapp-note.txt in the working directory with one friendly sentence saying the KARMAX demo task finished. Then finish.',
  workdir: 'C:/Users/NISSI JESSE/.karmax/work/demo',
  channel_id: 'whatsapp-main',
  target: setup.operatorJid
})
log('task 2 created:', t2.ok)

/* ── 3. task board ────────────────────────────────────────────────────── */
log('scene: tasks')
await nav('Tasks')
await cap('Task board', 'Queued, Running, Needs you, Done. Every task, live.')
await sleep(6000)

/* ── 4. loops constellation ───────────────────────────────────────────── */
log('scene: loops')
await nav('Loops')
await cap('Loops constellation', 'Every automation KARMAX runs, as glowing nodes on orbit rings by cadence.')
await sleep(6000)
const node = w.getByText('webhook-health').first()
await glide(node)
await cap('Hover for details', 'Status, schedule and last run at a glance.')
await sleep(3500)
await node.click().catch(() => {})
await cap('Open any loop', 'Run it, enable it or disable it from the side panel.')
await sleep(5000)
await w.keyboard.press('Escape')
await click(w.getByRole('tab', { name: 'Grid' }))
await cap('Grid view', 'The same loops as cards.')
await sleep(3500)
await click(w.getByRole('tab', { name: 'Timeline' }))
await cap('Timeline view', 'When each loop last ran and what is next.')
await sleep(3500)
await click(w.getByRole('tab', { name: 'Constellation' }))
await sleep(1500)

/* ── 5. logs ──────────────────────────────────────────────────────────── */
// (Logs screen intentionally not filmed: raw log lines can contain other people's chat IDs.)

/* ── 6. approvals ─────────────────────────────────────────────────────── */
log('scene: approvals')
await nav('Approvals')
await cap('Approvals', 'Anything risky waits for your OK: approve, edit, or reject.')
await sleep(5500)

/* ── 7. whatsapp ──────────────────────────────────────────────────────── */
log('scene: whatsapp')
await nav('WhatsApp')
await cap('WhatsApp operator channel', 'Message KARMAX from your phone. Only your number can give orders.')
await sleep(6500)
await cap('Locked by default', 'Every other chat stays locked. KARMAX only ever hears you.')
await sleep(6500)

/* ── 8. memory ────────────────────────────────────────────────────────── */
log('scene: memory')
await nav('Memory')
await cap('Memory', 'Search what KARMAX knows, browse it as a tree, and clean it up.')
await sleep(6000)
await click(w.getByRole('tab', { name: 'Tree' }))
await sleep(4000)
await click(w.getByRole('tab', { name: 'Entries' }))
await sleep(1500)

/* ── 9. wait for tasks, then show results ─────────────────────────────── */
log('waiting for tasks')
const t0 = Date.now()
await nav('Tasks')
await cap('Tasks are running in the background', 'Watch them move across the board.')
const files = [join(HOME, '.karmax', 'work', 'demo', 'whatsapp-note.txt')]
while (Date.now() - t0 < 6 * 60_000) {
  const r = await api('/api/tools/task.list')
  const open = (r.output?.tasks ?? []).filter((t) => ['open', 'working'].includes(t.status)).length
  if (open === 0) break
  await sleep(6000)
}
await sleep(3000)
await cap('Done', 'KARMAX finished the work and reported back.')
await sleep(6000)
await nav('WhatsApp')
await cap('And it messaged you', 'The task report arrives in WhatsApp too.')
await sleep(7000)

/* ── 10. theme + settings ─────────────────────────────────────────────── */
log('scene: theme')
await cap('Dark and light themes', 'Built for long sessions and bright rooms.')
const themeBtn = w.getByRole('button', { name: /Theme:/ })
await click(themeBtn)
await sleep(2500)
await click(themeBtn)
await sleep(2500)
await click(themeBtn)
await sleep(1500)
await uncap()

await w.mouse.move(1190, 730, { steps: 10 })
/* ── outro ────────────────────────────────────────────────────────────── */
await card(`<div><h1>KARMAX</h1><h2>Give it work. Get results. Right from WhatsApp.</h2>
<ul><li>Real Claude Code brain, no API key</li><li>Live loops and task board</li><li>Approvals and safe by default</li><li>Your data stays on your PC</li></ul></div>`)
await sleep(7500)

ff.stdin.write('q')
await ffDone
await app.close()
log('saved', OUTFILE, existsSync(OUTFILE))
