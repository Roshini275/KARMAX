// One-command demo: fake KARMAX (:9091) + wacli (:8765), then the real Electron app in demo mode.
//   npm run demo
// Uses throw-away data folders, so it never touches a real ~/.karmax or the app's saved settings.
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync } from 'node:fs'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const require = createRequire(import.meta.url)
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm'

if (!existsSync('out/main/index.js')) {
  console.log('Building the app first (one time)...')
  const r = spawnSync(npm, ['run', 'build'], { stdio: 'inherit', shell: process.platform === 'win32' })
  if (r.status !== 0) process.exit(r.status ?? 1)
}

const electronExe = require('electron')
if (typeof electronExe !== 'string' || !existsSync(electronExe)) {
  console.error('The Electron binary is missing. Run: node node_modules/electron/install.js')
  process.exit(1)
}

const base = join(tmpdir(), 'karmax-desktop-demo')
mkdirSync(base, { recursive: true })

const mock = spawn(process.execPath, ['fixtures/mock-daemon/server.mjs'], { stdio: 'inherit' })
await new Promise((r) => setTimeout(r, 1200))

const app = spawn(electronExe, ['.'], {
  stdio: 'inherit',
  env: { ...process.env, KARMAX_DEMO: '1', KARMAX_USER_DATA: join(base, 'userData'), KARMAX_HOME: join(base, 'home') }
})

const stop = () => {
  mock.kill()
  app.kill()
}
app.on('exit', (code) => {
  mock.kill()
  process.exit(code ?? 0)
})
process.on('SIGINT', stop)
process.on('SIGTERM', stop)
