// The real thing: the desktop app (starts KARMAX + wacli itself) plus the instant-ack relay.
//   npm run live
import { spawn, spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
if (!existsSync('out/main/index.js')) {
  const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build'], { stdio: 'inherit', shell: process.platform === 'win32' })
  if (r.status !== 0) process.exit(r.status ?? 1)
}
const relay = spawn(process.execPath, ['scripts/ack-relay.mjs'], { stdio: 'inherit' })
const app = spawn(require('electron'), ['.'], { stdio: 'inherit' })
const stop = () => {
  relay.kill()
  app.kill()
}
app.on('exit', (code) => {
  relay.kill()
  process.exit(code ?? 0)
})
process.on('SIGINT', stop)
process.on('SIGTERM', stop)
