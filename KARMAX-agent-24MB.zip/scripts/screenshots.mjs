// Screenshot the renderer (browser build) against the mock daemon.
//   node scripts/screenshots.mjs                      -> every route, dark
//   node scripts/screenshots.mjs /loops /tasks        -> just these
//   THEME=light node scripts/screenshots.mjs /loops   -> light theme
//   SETUP=1 node scripts/screenshots.mjs /setup       -> first-run wizard state
//   QUERY='daemon=http://127.0.0.1:9103&wacli=http://127.0.0.1:8803'  -> use a private mock instance (MOCK_KARMAX_PORT=9103 MOCK_WACLI_PORT=8803 node fixtures/mock-daemon/server.mjs)
//   SETTLE=2500 to wait longer for polling data / animations
// Requires: mock daemon (npm run mock) and renderer dev server (npm run dev:web) running.
import { chromium } from 'playwright'
import { mkdirSync, existsSync } from 'node:fs'
import { readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const OUT = process.env.OUT || 'shots'
const THEME = process.env.THEME || 'dark'
const SETTLE = Number(process.env.SETTLE || 1800)
const W = Number(process.env.W || 1440)
const H = Number(process.env.H || 900)
const ALL = ['/chat', '/loops', '/tasks', '/logs', '/approvals', '/whatsapp', '/memory', '/settings']
const routes = process.argv.slice(2).length ? process.argv.slice(2) : ALL

function chromePath() {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}

mkdirSync(OUT, { recursive: true })
const exe = chromePath()
const browser = await chromium.launch(exe ? { executablePath: exe, args: ['--no-sandbox'] } : { channel: process.env.CHANNEL || 'msedge' })
const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1, colorScheme: THEME === 'light' ? 'light' : 'dark' })
await ctx.addInitScript((theme) => {
  try {
    localStorage.setItem('km.theme', theme)
  } catch {}
}, THEME)
const page = await ctx.newPage()
const errors = []
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
page.on('console', (m) => m.type() === 'error' && errors.push(`console.error: ${m.text()}`))

for (const r of routes) {
  const qs = [process.env.SETUP === '1' ? 'setup=1' : '', process.env.QUERY || ''].filter(Boolean).join('&')
  await page.goto(`${BASE}/${qs ? '?' + qs : ''}#${r}`, { waitUntil: 'networkidle' }).catch(() => {})
  await page.waitForTimeout(SETTLE)
  const name = `${r.replace(/[^a-z0-9]+/gi, '_').replace(/^_|_$/g, '') || 'home'}-${THEME}.png`
  await page.screenshot({ path: `${OUT}/${name}` })
  console.log('saved', `${OUT}/${name}`)
}
if (errors.length) {
  console.log('\nBROWSER ERRORS:')
  for (const e of [...new Set(errors)]) console.log(' -', e)
}
await browser.close()
