// Instant acknowledgement for the operator chat.
// KARMAX's real answer takes 10-90 s (a new Claude Code process per turn). This relay registers a second wacli webhook for the
// operator chat only and replies "Got it" within a second, so the sender sees KARMAX react immediately.
//   node scripts/ack-relay.mjs         (or `npm run live`, which also starts the app)
import { createServer } from 'node:http'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { randomBytes } from 'node:crypto'

const WACLI = process.env.WACLI_URL || 'http://127.0.0.1:8765'
const PORT = Number(process.env.ACK_PORT || 9095)
const TEXT = process.env.ACK_TEXT || 'Got it. Working on it...'
const URL_ = `http://127.0.0.1:${PORT}/ack`

const operatorJid =
  process.env.OPERATOR_JID ||
  (() => {
    const f = join(process.env.APPDATA || '', 'KARMAX', 'setup.json')
    return JSON.parse(readFileSync(f, 'utf8')).operatorJid
  })()
if (!operatorJid) {
  console.error('ack-relay: no operator chat known yet. Finish the setup wizard first.')
  process.exit(1)
}

const wa = async (method, path, body) => {
  const r = await fetch(WACLI + path, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
  if (!r.ok) throw new Error(`${method} ${path} -> ${r.status} ${await r.text()}`)
  return r.json().catch(() => ({}))
}

let lastAck = 0
createServer((req, res) => {
  let raw = ''
  req.on('data', (c) => (raw += c))
  req.on('end', () => {
    res.writeHead(200).end('ok')
    try {
      const ev = JSON.parse(raw)
      const m = ev?.payload?.message
      const chat = ev?.payload?.chat?.jid
      if (ev.event !== 'incoming_message' || !m || m.is_from_me || chat !== operatorJid || !String(m.content || '').trim()) return
      if (Date.now() - lastAck < 2000) return // a burst of messages gets one ack
      lastAck = Date.now()
      const t0 = Date.now()
      wa('POST', '/send', { to: operatorJid, text: TEXT }).then(
        () => console.log(`acked in ${Date.now() - t0} ms`),
        (e) => console.error('ack failed:', e.message)
      )
    } catch {
      /* not JSON */
    }
  })
}).listen(PORT, '127.0.0.1')

let hookId
const register = async () => {
  for (;;) {
    try {
      await wa('GET', '/status')
      const { webhooks = [] } = await wa('GET', '/webhooks')
      for (const w of webhooks) if (w.url === URL_) await wa('DELETE', `/webhooks/${w.id}`)
      const out = await wa('POST', '/webhooks', { url: URL_, secret: randomBytes(16).toString('hex'), events: ['incoming_message'], scope: 'selected_chats', chat_jids: [operatorJid] })
      hookId = out?.webhook?.id
      console.log(`ack relay ready (webhook #${hookId}); replying "${TEXT}" to the operator chat`)
      return
    } catch (e) {
      console.log('waiting for wacli...', e.message.slice(0, 80))
      await new Promise((r) => setTimeout(r, 3000))
    }
  }
}
void register()

const bye = async () => {
  if (hookId) await wa('DELETE', `/webhooks/${hookId}`).catch(() => {})
  process.exit(0)
}
process.on('SIGINT', bye)
process.on('SIGTERM', bye)
