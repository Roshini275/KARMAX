/**
 * Preload: exposes `window.karmax` (the `KarmaxBridge` from src/shared/ipc.ts) via contextBridge.
 *
 * Runs in a sandboxed renderer, so it must be a CommonJS bundle and may only `require('electron')`. Nothing raw from
 * `ipcRenderer` is exposed: every method below wraps one specific channel, event objects never reach the page, and
 * subscriptions hand back an Unsubscribe.
 */
import { contextBridge, ipcRenderer, type IpcRendererEvent } from 'electron'
import {
  IPC,
  type ConnectionState,
  type DaemonRequest,
  type KarmaxBridge,
  type LogLine,
  type ProcName,
  type ProcStatus,
  type SetupState,
  type StreamHandle,
  type Unsubscribe
} from '../../src/shared/ipc'

/** Electron prefixes rejected invoke() messages with "Error invoking remote method 'x': Error: "; show the real message. */
function cleanError(e: unknown): Error {
  const msg = e instanceof Error ? e.message : String(e)
  return new Error(msg.replace(/^Error invoking remote method '[^']*':\s*(?:Error:\s*)?/, ''))
}

async function invoke<T>(channel: string, ...args: unknown[]): Promise<T> {
  try {
    return (await ipcRenderer.invoke(channel, ...args)) as T
  } catch (e) {
    throw cleanError(e)
  }
}

function subscribe<T>(channel: string, cb: (payload: T) => void): Unsubscribe {
  const listener = (_e: IpcRendererEvent, payload: T): void => cb(payload)
  ipcRenderer.on(channel, listener)
  return () => {
    ipcRenderer.removeListener(channel, listener)
  }
}

function randomId(): string {
  const c = globalThis.crypto as Crypto | undefined
  if (c?.randomUUID) return c.randomUUID()
  const bytes = new Uint8Array(16)
  if (c?.getRandomValues) c.getRandomValues(bytes)
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256)
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')
}

// One shared listener for all streams (a listener per stream would trip Node's MaxListeners warning at 11 concurrent streams).
interface StreamMsg {
  id: string
  line?: unknown
  end?: true
  error?: string
}
const streamHandlers = new Map<string, (m: StreamMsg) => void>()
let streamListening = false
function ensureStreamListener(): void {
  if (streamListening) return
  streamListening = true
  ipcRenderer.on(IPC.daemonStreamEvent, (_e, m: StreamMsg) => streamHandlers.get(m?.id)?.(m))
}

function stream(req: DaemonRequest, onLine: (line: unknown) => void): StreamHandle {
  ensureStreamListener()
  const id = randomId()
  let settled = false
  let resolveDone!: () => void
  let rejectDone!: (e: Error) => void
  const done = new Promise<void>((res, rej) => {
    resolveDone = res
    rejectDone = rej
  })
  const settle = (err?: Error): void => {
    if (settled) return
    settled = true
    streamHandlers.delete(id)
    if (err) rejectDone(err)
    else resolveDone()
  }
  streamHandlers.set(id, (m) => {
    if (settled) return
    if ('line' in m) {
      try {
        onLine(m.line)
      } catch {
        /* a throwing consumer must not kill the stream */
      }
    } else if (m.error !== undefined) settle(new Error(m.error))
    else if (m.end) settle()
  })
  invoke(IPC.daemonStreamStart, { id, req }).catch((e: unknown) => settle(e instanceof Error ? e : new Error(String(e))))
  return {
    done,
    abort: () => {
      ipcRenderer.send(IPC.daemonStreamAbort, id)
      settle() // resolve immediately; main also sends a final `end`
    }
  }
}

const setupCall =
  <T>(method: string) =>
  (...args: unknown[]): Promise<T> =>
    invoke<T>(IPC.setupInvoke, { method, args })

const bridge: KarmaxBridge = {
  app: {
    version: () => invoke<string>(IPC.appVersion),
    platform: process.platform,
    openExternal: (url) => invoke<void>(IPC.openExternal, url),
    window: {
      minimize: () => ipcRenderer.send(IPC.winMinimize),
      toggleMaximize: () => ipcRenderer.send(IPC.winToggleMax),
      close: () => ipcRenderer.send(IPC.winClose)
    }
  },
  daemon: {
    request: (req) => invoke(IPC.daemonRequest, req),
    stream
  },
  connection: {
    get: () => invoke<ConnectionState>(IPC.connectionGet),
    onChange: (cb) => subscribe<ConnectionState>(IPC.connectionChanged, cb)
  },
  supervisor: {
    status: () => invoke<ProcStatus[]>(IPC.supervisorStatus),
    start: (name: ProcName) => invoke<void>(IPC.supervisorStart, name),
    stop: (name: ProcName) => invoke<void>(IPC.supervisorStop, name),
    restart: (name: ProcName) => invoke<void>(IPC.supervisorRestart, name),
    onStatus: (cb) => subscribe<ProcStatus[]>(IPC.supervisorChanged, cb)
  },
  logs: {
    history: (q) => invoke<LogLine[]>(IPC.logsHistory, q ?? {}),
    // Main batches lines into arrays; deliver them one by one as the contract says.
    onLine: (cb) =>
      subscribe<LogLine | LogLine[]>(IPC.logsLine, (p) => {
        if (Array.isArray(p)) for (const l of p) cb(l)
        else cb(p)
      })
  },
  setup: {
    state: setupCall<SetupState>('state') as () => Promise<SetupState>,
    checkPrereqs: setupCall('checkPrereqs') as KarmaxBridge['setup']['checkPrereqs'],
    saveModelKey: (apiKey) => setupCall<void>('saveModelKey')(apiKey),
    saveModelClaudeCode: () => setupCall<void>('saveModelClaudeCode')(),
    installBinaries: () => setupCall<void>('installBinaries')(),
    writeConfig: (input) => setupCall<void>('writeConfig')(input),
    startServices: () => setupCall<void>('startServices')(),
    startPairing: (input) => setupCall<void>('startPairing')(input),
    cancelPairing: () => setupCall<void>('cancelPairing')(),
    applyOperatorLockdown: () => setupCall<void>('applyOperatorLockdown')(),
    sendTestMessage: () => setupCall<void>('sendTestMessage')(),
    reset: () => setupCall<void>('reset')(),
    onChange: (cb) => subscribe<SetupState>(IPC.setupChanged, cb)
  },
  startup: {
    get: () => invoke(IPC.startupGet),
    set: (patch) => invoke(IPC.startupSet, patch)
  }
}

contextBridge.exposeInMainWorld('karmax', bridge)
