/**
 * Log pipeline: child-process output -> lines -> {level, loop, message} -> ring buffer + rotating files + renderer.
 *
 * Which formats exist (verified in upstream source):
 *  - KARMAX (Go, zap). cmd/karmax/runtime_cmd.go `newStartCmd`: `log_format: pretty` (the default, config.go)
 *    => zap.NewDevelopment(), anything else => zap.NewProduction(). Both write to STDERR.
 *      development: tab-separated console encoder
 *        `2026-09-19T12:00:00.000+0530\tINFO\truntime/x.go:12\tmessage\t{"loop":"x"}`
 *        (ISO8601 time has NO colon in the offset: layout 2006-01-02T15:04:05.000Z0700). At Warn and above
 *        zap appends a multi-line stack trace after the entry.
 *      production: JSON `{"level":"info","ts":1758268800.123,"caller":"…","msg":"…","loop":"x"}` (ts = epoch seconds).
 *    Loops log through the same logger with a `loop` field (zap.String("loop", name), internal/runtime/loophost.go)
 *    and loopkit guest logs are prefixed `[loop:<name>] ` (loophost.go ~L1133).
 *  - wacli (Go). wa/service.go NewService: `waLog.Stdout("wacli", level, true)` (whatsmeow's logger, ANSI colour
 *    always on) => `15:04:05.000 [wacli WARN] message`; the call-media stack uses zerolog's ConsoleWriter on
 *    stderr => `15:04:05.000 INF message key=value`. Fatal start-up errors are bare `fmt.Fprintf(os.Stderr, …)`.
 *  - Anything else is treated as a plain line (info, unless it very obviously says error/warn).
 *
 * Secrets never reach the buffer, the files or the renderer: see `redact`.
 */
import { appendFileSync, existsSync, mkdirSync, renameSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'
import type { LogLevel, LogLine, LogQuery, LogSource } from '../../src/shared/ipc'
import type { LogSink } from './contracts'

// ── pure helpers (unit-tested) ───────────────────────────────────────────────

// eslint-disable-next-line no-control-regex
const ANSI_RE = /\u001b\[[0-9;?]*[ -/]*[@-~]|\u001b\][^\u0007\u001b]*(?:\u0007|\u001b\\)|\u001b[@-Z\\-_]/g
export function stripAnsi(s: string): string {
  return s.replace(ANSI_RE, '')
}

const REDACTED = '[redacted]'
const SECRET_PATTERNS: RegExp[] = [
  /(Bearer\s+)[A-Za-z0-9._~+/=-]{8,}/gi,
  /\bsk-ant-[A-Za-z0-9_-]{8,}/g,
  /\bsk-[A-Za-z0-9_-]{20,}/g,
  // KEY=value / "key":"value" for anything that smells like a credential
  /((?:api[_-]?key|api[_-]?token|access[_-]?token|refresh[_-]?token|auth[_-]?token|token|secret|password|passwd|authorization)["']?\s*[:=]\s*["']?)[^\s"',;}]{4,}/gi
]

/** Remove credentials from a log message. `extra` are exact secret strings known to the app (e.g. the API token). */
export function redact(message: string, extra: readonly string[] = []): string {
  let out = message
  for (const s of extra) if (s && s.length >= 6 && out.includes(s)) out = out.split(s).join(REDACTED)
  for (const re of SECRET_PATTERNS) {
    out = out.replace(re, (_m, prefix?: string) => (typeof prefix === 'string' ? `${prefix}${REDACTED}` : REDACTED))
  }
  return out
}

/** Splits a stream of chunks into complete lines. Partial trailing data is held until the next chunk / `flush()`. */
export class LineBuffer {
  private buf = ''
  constructor(private readonly maxPartial = 64 * 1024) {}

  push(chunk: string): string[] {
    this.buf += chunk
    const out: string[] = []
    let nl: number
    while ((nl = this.buf.indexOf('\n')) >= 0) {
      out.push(this.buf.slice(0, nl).replace(/\r+$/, ''))
      this.buf = this.buf.slice(nl + 1)
    }
    if (this.buf.length > this.maxPartial) {
      out.push(this.buf)
      this.buf = ''
    }
    return out
  }

  /** Returns and clears any partial line. */
  flush(): string | undefined {
    const rest = this.buf.replace(/\r+$/, '')
    this.buf = ''
    return rest ? rest : undefined
  }

  get pending(): boolean {
    return this.buf.length > 0
  }
}

export interface ParsedLine {
  level: LogLevel
  loop?: string
  message: string
  /** ISO 8601, only when the line carried a full timestamp we could parse. */
  ts?: string
  /** True for zap development-console / JSON entries: the following unstructured lines may be a stack trace. */
  structured: boolean
}

const LEVEL_WORDS: Record<string, LogLevel> = {
  debug: 'debug',
  dbg: 'debug',
  trace: 'debug',
  trc: 'debug',
  info: 'info',
  inf: 'info',
  notice: 'info',
  warn: 'warn',
  warning: 'warn',
  wrn: 'warn',
  error: 'error',
  err: 'error',
  fatal: 'error',
  ftl: 'error',
  panic: 'error',
  pnc: 'error',
  dpanic: 'error'
}

export function toLevel(word: string | undefined): LogLevel | undefined {
  return word ? LEVEL_WORDS[word.trim().toLowerCase()] : undefined
}

/** zap's ISO8601 encoder emits `+0530` (no colon), which `Date.parse` does not accept everywhere. */
export function parseZapTime(raw: string): string | undefined {
  const fixed = raw.replace(/([+-]\d{2})(\d{2})$/, '$1:$2')
  const t = Date.parse(fixed)
  return Number.isNaN(t) ? undefined : new Date(t).toISOString()
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v)
}

function stringifyField(v: unknown): string {
  return typeof v === 'string' ? v : JSON.stringify(v)
}

const LOOP_PREFIX_RE = /^\s*\[loop:([^\]\s]+)\]\s?/
const LOOP_KV_RE = /(?:^|[\s,{(])loop[=:]"?([A-Za-z0-9][\w.-]*)"?/

/** Pull `loop` out of a message (prefix `[loop:x] ` wins, then a `loop=x` token) and return the cleaned message. */
function extractLoopFromText(message: string): { loop?: string; message: string } {
  const pre = LOOP_PREFIX_RE.exec(message)
  if (pre) return { loop: pre[1], message: message.slice(pre[0].length) }
  const kv = LOOP_KV_RE.exec(message)
  if (kv) return { loop: kv[1], message }
  return { message }
}

function foldFields(message: string, fields: Record<string, unknown>): { loop?: string; message: string } {
  let loop: string | undefined
  if (typeof fields.loop === 'string' && fields.loop) loop = fields.loop
  const rest: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(fields)) if (k !== 'loop') rest[k] = v
  const restKeys = Object.keys(rest)
  const msg = restKeys.length ? `${message} ${JSON.stringify(rest)}` : message
  return { loop, message: msg }
}

const ZAP_CONSOLE_RE =
  /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\t([A-Za-z]+)\t(.*)$/
const WHATSMEOW_RE = /^\d{2}:\d{2}:\d{2}(?:\.\d+)?\s+\[([^\]\s]+)\s+([A-Za-z]+)\]\s?(.*)$/
const ZEROLOG_RE = /^\d{2}:\d{2}:\d{2}(?:\.\d+)?\s+(TRC|DBG|INF|WRN|ERR|FTL|PNC)\s(.*)$/
const LEADING_LEVEL_RE = /^\s*(?:\[(error|err|fatal|panic|warn|warning)\]|(error|fatal|panic|warn|warning|err)\s*[:\]])\s*/i
const LOGFMT_LEVEL_RE = /(?:^|\s)level=(debug|info|warn|warning|error|fatal)\b/i

/** Parse one already-ANSI-stripped, non-empty line. Never throws. */
export function parseLine(raw: string): ParsedLine {
  const line = raw.trimEnd()

  // (b) zap JSON (production encoder)
  if (line.startsWith('{') && line.endsWith('}')) {
    try {
      const obj: unknown = JSON.parse(line)
      if (isPlainObject(obj) && (typeof obj.level === 'string' || typeof obj.msg === 'string' || typeof obj.message === 'string')) {
        const level = toLevel(typeof obj.level === 'string' ? obj.level : undefined) ?? 'info'
        const text = typeof obj.msg === 'string' ? obj.msg : typeof obj.message === 'string' ? obj.message : ''
        let ts: string | undefined
        if (typeof obj.ts === 'number') ts = new Date(obj.ts > 1e12 ? obj.ts : obj.ts * 1000).toISOString()
        else if (typeof obj.ts === 'string') ts = parseZapTime(obj.ts)
        else if (typeof obj.time === 'string') ts = parseZapTime(obj.time)
        const drop = new Set(['level', 'ts', 'time', 'msg', 'message', 'caller', 'logger'])
        const fields: Record<string, unknown> = {}
        for (const [k, v] of Object.entries(obj)) if (!drop.has(k)) fields[k] = v
        const folded = foldFields(text, fields)
        const viaText = folded.loop ? { loop: folded.loop, message: folded.message } : extractLoopFromText(folded.message)
        return { level, loop: viaText.loop, message: viaText.message, ts: ts, structured: true }
      }
    } catch {
      /* fall through: not JSON after all */
    }
  }

  // (a) zap development console: time \t LEVEL \t [name \t] caller \t message [\t {fields}]
  const zc = ZAP_CONSOLE_RE.exec(line)
  if (zc) {
    const level = toLevel(zc[2])
    if (level) {
      const parts = zc[3].split('\t')
      let fields: Record<string, unknown> | undefined
      const last = parts[parts.length - 1]
      if (parts.length > 1 && last.startsWith('{') && last.endsWith('}')) {
        try {
          const parsed: unknown = JSON.parse(last)
          if (isPlainObject(parsed)) {
            fields = parsed
            parts.pop()
          }
        } catch {
          /* keep as text */
        }
      }
      // What remains is [logger-name] caller message: the caller looks like `pkg/file.go:123`.
      let idx = 0
      while (idx < parts.length - 1 && !/\.go:\d+$/.test(parts[idx])) idx++
      const hasCaller = idx < parts.length - 1 && /\.go:\d+$/.test(parts[idx])
      const messageParts = hasCaller ? parts.slice(idx + 1) : parts
      const text = messageParts.join(' ').trim()
      const folded = fields ? foldFields(text, fields) : { loop: undefined, message: text }
      const viaText = folded.loop ? { loop: folded.loop, message: folded.message } : extractLoopFromText(folded.message)
      return { level, loop: viaText.loop, message: viaText.message, ts: parseZapTime(zc[1]), structured: true }
    }
  }

  // wacli: whatsmeow logger `12:00:00.000 [wacli WARN] message`
  const wm = WHATSMEOW_RE.exec(line)
  if (wm) {
    const level = toLevel(wm[2])
    if (level) return { level, message: wm[3].trim() || line, structured: true }
  }
  // wacli: zerolog console `12:00:00.000 INF message key=value`
  const zl = ZEROLOG_RE.exec(line)
  if (zl) {
    return { level: toLevel(zl[1]) ?? 'info', message: zl[2].trim(), structured: true }
  }

  // (c) plain text. Conservative level detection.
  let level: LogLevel = 'info'
  const lf = LOGFMT_LEVEL_RE.exec(line)
  if (lf) level = toLevel(lf[1]) ?? 'info'
  else {
    const lead = LEADING_LEVEL_RE.exec(line)
    if (lead) level = toLevel(lead[1] ?? lead[2]) ?? 'info'
    else if (/^(panic:|fatal error:|runtime: |goroutine \d+ \[)/.test(line)) level = 'error'
  }
  const loopBits = extractLoopFromText(line)
  return { level, loop: loopBits.loop, message: loopBits.message, structured: false }
}

/** A stack-trace-ish continuation line (zap appends stacks after Warn+ entries in development mode). */
export function looksLikeContinuation(line: string): boolean {
  return (
    /^\s/.test(line) ||
    /^goroutine \d+/.test(line) ||
    /^[A-Za-z0-9_./-]+(?:\.\(\*?[A-Za-z0-9_]+\))?(?:\.[A-Za-z0-9_]+)+(?:\.func\d+)*(?:\(.*\))?$/.test(line)
  )
}

const LEVEL_RANK: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 }
const MAX_MESSAGE = 8 * 1024

// ── the sink ─────────────────────────────────────────────────────────────────

export interface LogSinkOptions {
  /** Directory for karmax.log / wacli.log / app.log. When omitted nothing is persisted (tests). */
  dir?: string
  ringSize?: number
  maxFileBytes?: number
  maxFiles?: number
  /** Exact secret strings to scrub (the API token…). Evaluated per line so late-set secrets are covered. */
  secrets?: () => readonly string[]
  now?: () => Date
  /** How often buffered file writes hit the disk. */
  flushMs?: number
}

export interface LogSinkImpl extends LogSink {
  history(q?: LogQuery): LogLine[]
  /** Main-process subscription (ipc.ts batches these to the renderer). */
  subscribe(cb: (l: LogLine) => void): () => void
  /** Flush partial lines + pending file writes. */
  close(): void
}

interface FileState {
  path: string
  size: number
  pending: string[]
  failed: boolean
}

export function createLogSink(opts: LogSinkOptions = {}): LogSinkImpl {
  const ringSize = opts.ringSize ?? 5000
  const maxFileBytes = opts.maxFileBytes ?? 2 * 1024 * 1024
  const maxFiles = opts.maxFiles ?? 5
  const now = opts.now ?? (() => new Date())
  const flushMs = opts.flushMs ?? 250

  const ring: LogLine[] = []
  let seq = 0
  const subs = new Set<(l: LogLine) => void>()
  const buffers = new Map<LogSource, LineBuffer>()
  const lastStructured = new Map<LogSource, ParsedLine>()
  const files = new Map<LogSource, FileState>()
  let flushTimer: ReturnType<typeof setTimeout> | undefined
  const partialTimers = new Map<LogSource, ReturnType<typeof setTimeout>>()

  const fileFor = (source: LogSource): FileState | undefined => {
    if (!opts.dir) return undefined
    let f = files.get(source)
    if (!f) {
      const path = join(opts.dir, `${source}.log`)
      let size = 0
      try {
        mkdirSync(opts.dir, { recursive: true })
        size = existsSync(path) ? statSync(path).size : 0
      } catch {
        /* handled at write time */
      }
      f = { path, size, pending: [], failed: false }
      files.set(source, f)
    }
    return f
  }

  const rotate = (f: FileState): void => {
    // karmax.log -> karmax.log.1 -> … -> karmax.log.<maxFiles-1>; the oldest is dropped.
    const last = `${f.path}.${maxFiles - 1}`
    try {
      if (existsSync(last)) rmSync(last, { force: true })
      for (let i = maxFiles - 2; i >= 1; i--) {
        const from = `${f.path}.${i}`
        if (existsSync(from)) renameSync(from, `${f.path}.${i + 1}`)
      }
      if (existsSync(f.path)) renameSync(f.path, `${f.path}.1`)
    } catch {
      /* rotation is best effort */
    }
    f.size = 0
  }

  const flushFiles = (): void => {
    flushTimer = undefined
    for (const f of files.values()) {
      if (!f.pending.length) continue
      const data = f.pending.join('')
      f.pending = []
      try {
        if (f.size + Buffer.byteLength(data) > maxFileBytes && f.size > 0) rotate(f)
        appendFileSync(f.path, data, { encoding: 'utf8' })
        f.size += Buffer.byteLength(data)
        f.failed = false
      } catch {
        f.failed = true // never let logging take the app down
      }
    }
  }

  const scheduleFlush = (): void => {
    if (flushTimer || !opts.dir) return
    flushTimer = setTimeout(flushFiles, flushMs)
    flushTimer.unref?.()
  }

  const publish = (source: LogSource, level: LogLevel, message: string, loop: string | undefined, ts: string | undefined): void => {
    let msg = redact(message, opts.secrets?.() ?? [])
    if (msg.length > MAX_MESSAGE) msg = `${msg.slice(0, MAX_MESSAGE)}… [truncated]`
    const line: LogLine = { seq: ++seq, ts: ts ?? now().toISOString(), source, level, message: msg }
    if (loop) line.loop = loop
    ring.push(line)
    if (ring.length > ringSize) ring.splice(0, ring.length - ringSize)

    const f = fileFor(source)
    if (f && !f.failed) {
      f.pending.push(`${line.ts} ${level.toUpperCase().padEnd(5)} ${loop ? `[loop:${loop}] ` : ''}${msg.replace(/\r?\n/g, '\\n')}\n`)
      scheduleFlush()
    }
    for (const cb of subs) {
      try {
        cb(line)
      } catch {
        /* a subscriber must not break logging */
      }
    }
  }

  const handleLine = (source: Exclude<LogSource, 'app'>, rawLine: string): void => {
    const cleaned = stripAnsi(rawLine)
    if (!cleaned.trim()) return
    const parsed = parseLine(cleaned)
    const prev = lastStructured.get(source)
    if (parsed.structured) {
      lastStructured.set(source, parsed)
    } else if (prev && LEVEL_RANK[prev.level] >= LEVEL_RANK.warn && looksLikeContinuation(cleaned)) {
      // A stack trace under a warn/error entry keeps that entry's level (and loop) so filters don't orphan it.
      publish(source, prev.level, cleaned.trimEnd(), prev.loop, undefined)
      return
    } else {
      lastStructured.delete(source)
    }
    publish(source, parsed.level, parsed.message, parsed.loop, parsed.ts)
  }

  const bufferFor = (source: Exclude<LogSource, 'app'>): LineBuffer => {
    let b = buffers.get(source)
    if (!b) {
      b = new LineBuffer()
      buffers.set(source, b)
    }
    return b
  }

  const flushPartial = (source: Exclude<LogSource, 'app'>): void => {
    partialTimers.delete(source)
    const rest = buffers.get(source)?.flush()
    if (rest) handleLine(source, rest)
  }

  return {
    app(level, message) {
      const cleaned = stripAnsi(message)
      for (const l of cleaned.split(/\r?\n/)) if (l.trim()) publish('app', level, l, undefined, undefined)
    },

    ingest(source, chunk) {
      const b = bufferFor(source)
      for (const l of b.push(chunk)) handleLine(source, l)
      const t = partialTimers.get(source)
      if (t) clearTimeout(t)
      if (b.pending) {
        // A prompt or a line whose newline never comes must still show up.
        const timer = setTimeout(() => flushPartial(source), 1000)
        timer.unref?.()
        partialTimers.set(source, timer)
      } else partialTimers.delete(source)
    },

    history(q = {}) {
      const limit = Math.max(1, Math.min(q.limit ?? 500, ringSize))
      const since = q.sinceSeq ?? 0
      const out = ring.filter((l) => l.seq > since && (!q.source || l.source === q.source) && (!q.level || l.level === q.level))
      // Same contract as the mock daemon: with a cursor return the *next* `limit` lines, otherwise the newest `limit`.
      return since ? out.slice(0, limit) : out.slice(-limit)
    },

    subscribe(cb) {
      subs.add(cb)
      return () => void subs.delete(cb)
    },

    close() {
      for (const s of ['karmax', 'wacli'] as const) {
        const t = partialTimers.get(s)
        if (t) clearTimeout(t)
        flushPartial(s)
      }
      if (flushTimer) clearTimeout(flushTimer)
      flushFiles()
    }
  }
}
