/**
 * Every filesystem location the main process cares about (implements `Paths` from ./contracts).
 *
 * Deliberately free of any `electron` import: everything Electron-specific (userData, app path,
 * packaged-ness) is injected by index.ts so the resolution logic can be unit-tested on any OS.
 * Windows-first, but every function has a sane POSIX answer so tests run on Linux/macOS CI.
 *
 * Verified against upstream:
 *  - KARMAX data dir is `~/.karmax` (KARMAX/internal/config/config.go applyDefaults); the daemon itself
 *    honours KARMAX_DATA_DIR, while KARMAX_HOME is *this app's* test/override knob (see supervisor.ts, which
 *    forwards it to the daemon as KARMAX_DATA_DIR).
 *  - wacli data dir is `~/.wacli` unless WACLI_HOME is set (wacli/wa/app.go init()).
 */
import { homedir } from 'node:os'
import { win32, posix } from 'node:path'
import type { Paths } from './contracts'

export interface AppPaths extends Paths {
  /** userData/logs — the persisted karmax.log / wacli.log / app.log (see logs.ts). */
  logsDir(): string
  /** userData/prefs.json — window/startup prefs (see prefs.ts). */
  prefsFile(): string
  /** userData/secrets — safeStorage blobs (see daemon.ts). */
  secretsDir(): string
  /** Tray/window icon (icon.ico on Windows, icon.png elsewhere). */
  iconFile(): string
  /** out/renderer/index.html (only meaningful for the file:// production load). */
  rendererIndex(): string
  /** Directory holding the built preload bundle (out/preload). */
  preloadDir(): string
}

export interface PathsOptions {
  platform?: NodeJS.Platform
  env?: NodeJS.ProcessEnv
  /** Defaults to os.homedir() (USERPROFILE on Windows — the same source Go's os.UserHomeDir uses). */
  home?: string
  /** Electron `app.getPath('userData')`. Required for a real app; tests may omit (falls back under home). */
  userData?: string
  /** Electron `app.isPackaged`. */
  isPackaged?: boolean
  /** Electron `process.resourcesPath` (packaged builds). */
  resourcesPath?: string
  /** Electron `app.getAppPath()` — the repo root in dev, the asar root when packaged. */
  appPath?: string
}

export function createPaths(opts: PathsOptions = {}): AppPaths {
  const platform = opts.platform ?? process.platform
  const env = opts.env ?? process.env
  const home = opts.home ?? homedir()
  const isWin = platform === 'win32'
  // Use the flavour of `path` that matches the *target* platform, so resolution is testable from any host.
  const p = isWin ? win32 : posix
  const j = (...parts: string[]): string => p.join(...parts)

  const nonEmpty = (v: string | undefined): string | undefined => {
    const t = v?.trim()
    return t ? t : undefined
  }

  const dataDir = nonEmpty(env.KARMAX_HOME) ?? j(home, '.karmax')
  const wacliHome = nonEmpty(env.WACLI_HOME) ?? j(home, '.wacli')
  const installDir = (): string => {
    const override = nonEmpty(env.KARMAX_INSTALL_DIR)
    if (override) return override
    if (isWin) return j(nonEmpty(env.LOCALAPPDATA) ?? j(home, 'AppData', 'Local'), 'KARMAX')
    return j(nonEmpty(env.XDG_DATA_HOME) ?? j(home, '.local', 'share'), 'KARMAX')
  }
  const exe = (name: string): string => (isWin ? `${name}.exe` : name)
  const userData = opts.userData ?? nonEmpty(env.KARMAX_USER_DATA) ?? j(home, '.karmax-desktop')
  const appPath = opts.appPath ?? process.cwd()
  // Packaged: <install>/resources/bin (electron-builder extraResources). Dev: <repo>/resources/bin.
  const resourcesRoot = opts.isPackaged ? (opts.resourcesPath ?? process.resourcesPath ?? appPath) : appPath
  const resourcesBin = opts.isPackaged ? j(resourcesRoot, 'bin') : j(appPath, 'resources', 'bin')
  const iconDir = opts.isPackaged ? resourcesRoot : j(appPath, 'build')

  return {
    dataDir: () => dataDir,
    envFile: () => j(dataDir, '.env'),
    yamlFile: () => j(dataDir, 'karmax.yaml'),
    installDir,
    karmaxExe: () => j(installDir(), exe('karmax')),
    wacliExe: () => j(installDir(), exe('wacli')),
    wacliHome: () => wacliHome,
    userData: () => userData,
    resourcesBin: () => resourcesBin,
    logsDir: () => j(userData, 'logs'),
    prefsFile: () => j(userData, 'prefs.json'),
    secretsDir: () => j(userData, 'secrets'),
    iconFile: () => j(iconDir, isWin ? 'icon.ico' : 'icon.png'),
    // electron-vite emits to <appPath>/out/{main,preload,renderer}; inside the asar for packaged builds.
    rendererIndex: () => j(appPath, 'out', 'renderer', 'index.html'),
    preloadDir: () => j(appPath, 'out', 'preload')
  }
}
