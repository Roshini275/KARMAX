/**
 * Persistent app preferences (`StartupPrefs`), stored as JSON in <userData>/prefs.json.
 *
 * Defaults: `openAtLogin` is FALSE until the user opts in (the wizard/settings can enable it); `minimizeToTray` is TRUE, because
 * the point of the app is to keep the daemons running and the tray menu is where Quit lives.
 */
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import type { StartupPrefs } from '../../src/shared/ipc'

export const DEFAULT_PREFS: StartupPrefs = { openAtLogin: false, minimizeToTray: true }

/** Coerce arbitrary JSON into valid prefs (unknown keys dropped, wrong types fall back to defaults). */
export function sanitizePrefs(input: unknown, base: StartupPrefs = DEFAULT_PREFS): StartupPrefs {
  const src = input && typeof input === 'object' ? (input as Record<string, unknown>) : {}
  return {
    openAtLogin: typeof src.openAtLogin === 'boolean' ? src.openAtLogin : base.openAtLogin,
    minimizeToTray: typeof src.minimizeToTray === 'boolean' ? src.minimizeToTray : base.minimizeToTray
  }
}

export interface PrefsStore {
  get(): StartupPrefs
  set(patch: Partial<StartupPrefs>): StartupPrefs
  onChange(cb: (p: StartupPrefs) => void): () => void
}

export function createPrefs(file: string): PrefsStore {
  let current: StartupPrefs = DEFAULT_PREFS
  try {
    current = sanitizePrefs(JSON.parse(readFileSync(file, 'utf8')))
  } catch {
    current = { ...DEFAULT_PREFS }
  }
  const listeners = new Set<(p: StartupPrefs) => void>()

  const persist = (): void => {
    try {
      mkdirSync(dirname(file), { recursive: true })
      const tmp = `${file}.tmp`
      writeFileSync(tmp, JSON.stringify(current, null, 2), 'utf8')
      renameSync(tmp, file)
    } catch {
      /* prefs are a convenience; failing to save must not break the app */
    }
  }

  return {
    get: () => ({ ...current }),
    set(patch) {
      const next = sanitizePrefs(patch, current)
      const changed = next.openAtLogin !== current.openAtLogin || next.minimizeToTray !== current.minimizeToTray
      current = next
      if (changed) {
        persist()
        for (const cb of listeners) cb({ ...current })
      }
      return { ...current }
    },
    onChange(cb) {
      listeners.add(cb)
      return () => void listeners.delete(cb)
    }
  }
}
