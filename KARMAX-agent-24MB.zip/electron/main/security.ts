/**
 * Renderer hardening: CSP, permission denial, navigation/new-window blocking, and IPC sender validation.
 */
import { BrowserWindow, session, shell, type IpcMainEvent, type IpcMainInvokeEvent, type WebContents } from 'electron'

/** Content-Security-Policy for packaged builds. The renderer makes no network calls of its own: everything goes over IPC. */
export const PACKAGED_CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "frame-src 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'"
].join('; ')

/** Only http(s) URLs may be handed to the OS. Everything else (file:, javascript:, ms-msdt:, custom protocols) is refused. */
export function isSafeExternalUrl(raw: unknown): raw is string {
  if (typeof raw !== 'string' || raw.length > 4096) return false
  try {
    const u = new URL(raw)
    return (u.protocol === 'https:' || u.protocol === 'http:') && !u.username && !u.password
  } catch {
    return false
  }
}

export async function openExternalSafe(raw: unknown): Promise<void> {
  if (!isSafeExternalUrl(raw)) throw new Error('Only http(s) URLs can be opened')
  await shell.openExternal(raw)
}

/**
 * True when `url` is a page of this app: the dev-server origin in development, the packaged index.html (file://) otherwise.
 * Query/hash are ignored (the renderer uses a HashRouter).
 */
export function isAppUrl(url: string, appOrigin: { devOrigin?: string; fileUrlPrefix?: string }): boolean {
  try {
    const u = new URL(url)
    if (appOrigin.devOrigin && u.origin === new URL(appOrigin.devOrigin).origin) return true
    if (appOrigin.fileUrlPrefix && u.protocol === 'file:') {
      const base = new URL(appOrigin.fileUrlPrefix)
      return decodeURIComponent(u.pathname).toLowerCase() === decodeURIComponent(base.pathname).toLowerCase()
    }
    return false
  } catch {
    return false
  }
}

export interface SecurityOptions {
  isPackaged: boolean
  devOrigin?: string
  /** file:// URL of the packaged index.html. */
  fileUrl?: string
}

export interface Security {
  /** IPC handlers must reject events whose frame is not our own page. */
  isTrustedSender(e: IpcMainEvent | IpcMainInvokeEvent): boolean
  guardWebContents(wc: WebContents): void
}

export function installSecurity(opts: SecurityOptions): Security {
  const origin = { devOrigin: opts.isPackaged ? undefined : opts.devOrigin, fileUrlPrefix: opts.fileUrl }

  const ses = session.defaultSession
  // No camera, mic, geolocation, notifications, clipboard-read... The app needs none of them.
  ses.setPermissionRequestHandler((_wc, _permission, cb) => cb(false))
  ses.setPermissionCheckHandler(() => false)

  if (opts.isPackaged) {
    // NOTE: whether webRequest observes file:// loads is not verifiable off-device; index.html also carries a <meta> CSP as a backstop.
    ses.webRequest.onHeadersReceived((details, cb) => {
      cb({ responseHeaders: { ...details.responseHeaders, 'Content-Security-Policy': [PACKAGED_CSP] } })
    })
  }

  const guardWebContents = (wc: WebContents): void => {
    wc.setWindowOpenHandler(({ url }) => {
      if (isSafeExternalUrl(url)) void shell.openExternal(url)
      return { action: 'deny' }
    })
    const block = (e: { preventDefault(): void }, url: string): void => {
      if (isAppUrl(url, origin)) return
      e.preventDefault()
      if (isSafeExternalUrl(url)) void shell.openExternal(url)
    }
    wc.on('will-navigate', (e, url) => block(e, url))
    wc.on('will-redirect', (e, url) => block(e, url))
    wc.on('will-attach-webview', (e) => e.preventDefault())
  }

  return {
    guardWebContents,
    isTrustedSender(e) {
      const frame = e.senderFrame
      if (!frame) return false
      // Only the top-level frame of a window we created may use the bridge.
      if (frame.parent) return false
      return isAppUrl(frame.url, origin) && BrowserWindow.fromWebContents(e.sender) !== null
    }
  }
}
