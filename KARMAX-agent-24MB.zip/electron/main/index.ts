/**
 * KARMAX Desktop — Electron main process entry.
 *
 * Lifecycle:  single-instance lock -> ready -> paths/logs/daemon/supervisor/prefs -> security + IPC + setup backend
 *             -> window + tray -> (only if the wizard has completed) start wacli then karmax.
 * Quit:       before-quit is intercepted once to stop the supervised children (5s cap), then quit for real.
 */
import { app, BrowserWindow, Menu, nativeImage, safeStorage } from 'electron'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createDaemon, type DaemonService } from './daemon'
import { broadcast, registerIpc } from './ipc'
import { createLogSink, type LogSinkImpl } from './logs'
import { createPaths, type AppPaths } from './paths'
import { createPrefs, type PrefsStore } from './prefs'
import { installSecurity, type Security } from './security'
import { registerSetup } from './setup'
import { createSupervisor, type Supervisor } from './supervisor'
import { createTray, type TrayHandle } from './tray'
import type { SetupApi, SetupState } from '../../src/shared/ipc'

const APP_ID = 'com.karmax.desktop'
const QUIT_STOP_CAP_MS = 5_000
/** Passed by the login item so an auto-launch starts in the tray instead of popping a window. */
const START_HIDDEN = process.argv.includes('--hidden')

let mainWindow: BrowserWindow | null = null
let tray: TrayHandle | undefined
let quitState: 'running' | 'stopping' | 'done' = 'running'

// Assigned in boot(); module-level so window/tray callbacks can reach them.
let paths: AppPaths
let logs: LogSinkImpl
let daemon: DaemonService
let supervisor: Supervisor
let prefs: PrefsStore
let security: Security
let setup: { api: SetupApi; getState(): SetupState } | undefined

if (process.platform === 'win32') app.setAppUserModelId(APP_ID)

function resolvePreload(): string {
  // electron-vite emits CJS (index.js) unless package.json says "type": "module"; a sandboxed preload cannot be ESM.
  for (const f of ['index.js', 'index.cjs', 'index.mjs']) {
    const p = join(paths.preloadDir(), f)
    if (existsSync(p)) return p
  }
  return join(paths.preloadDir(), 'index.js')
}

function rendererTarget(): { devUrl?: string; fileUrl: string } {
  const devUrl = !app.isPackaged ? process.env.ELECTRON_RENDERER_URL : undefined
  return { devUrl, fileUrl: pathToFileURL(paths.rendererIndex()).toString() }
}

function showWindow(): void {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow(false)
    return
  }
  if (mainWindow.isMinimized()) mainWindow.restore()
  mainWindow.show()
  mainWindow.focus()
}

function createWindow(hidden: boolean): BrowserWindow {
  const isWin = process.platform === 'win32'
  const icon = nativeImage.createFromPath(paths.iconFile())
  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1000,
    minHeight: 640,
    show: false,
    title: 'KARMAX',
    backgroundColor: '#0d0d0d',
    autoHideMenuBar: true,
    ...(icon.isEmpty() ? {} : { icon }),
    ...(isWin
      ? {
          titleBarStyle: 'hidden' as const,
          titleBarOverlay: { color: '#141413', symbolColor: '#c3c2b7', height: 40 }
        }
      : {}),
    webPreferences: {
      preload: resolvePreload(),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: false,
      devTools: !app.isPackaged || process.env.KARMAX_DEVTOOLS === '1'
    }
  })
  mainWindow = win

  let shown = false
  const reveal = (): void => {
    if (shown || win.isDestroyed()) return
    shown = true
    if (!hidden) win.show()
  }
  win.once('ready-to-show', reveal)
  // If the renderer never reports ready (a load error), still surface the window so the user is not left with a ghost process.
  const fallback = setTimeout(reveal, 8_000)
  win.once('closed', () => clearTimeout(fallback))

  win.webContents.on('did-fail-load', (_e, code, desc, url, isMainFrame) => {
    if (isMainFrame) logs.app('error', `Renderer failed to load ${url}: ${desc} (${code})`)
  })
  win.webContents.on('render-process-gone', (_e, details) => {
    logs.app('error', `Renderer process gone: ${details.reason} (exit ${details.exitCode})`)
  })

  // Close-to-tray: keep daemons running unless the user is really quitting or opted out.
  win.on('close', (e) => {
    if (quitState === 'running' && prefs.get().minimizeToTray) {
      e.preventDefault()
      win.hide()
    }
  })
  // Windows logoff/shutdown: there is no time for a graceful stop; do not leave orphans behind.
  win.on('session-end', () => {
    quitState = 'stopping'
    supervisor.killAllSync()
  })
  win.on('closed', () => {
    if (mainWindow === win) mainWindow = null
  })

  const { devUrl } = rendererTarget()
  const load = devUrl ? win.loadURL(devUrl) : win.loadFile(paths.rendererIndex())
  load.catch((err: unknown) => logs.app('error', `Could not load the renderer: ${String(err)}`))
  return win
}

function applyLoginItem(openAtLogin: boolean): void {
  // In dev this would register electron.exe itself; only touch the OS login items for the packaged app.
  if (!app.isPackaged) return
  try {
    app.setLoginItemSettings({ openAtLogin, args: openAtLogin ? ['--hidden'] : [] })
  } catch (e) {
    logs.app('warn', `Could not update the login item: ${String(e)}`)
  }
}

async function restartDaemons(): Promise<void> {
  try {
    await supervisor.restartAll()
  } catch (e) {
    logs.app('error', `Restarting the daemons failed: ${String(e)}`)
  }
}

// KARMAX_DEMO=1: present the app as already set up so it can attach to daemons that are already
// running on the usual ports (e.g. `npm run mock`). Never spawns anything and never writes setup state.
const DEMO = process.env.KARMAX_DEMO === '1'

function setupCompleted(): boolean {
  if (DEMO) return true
  try {
    return setup?.getState().completed === true
  } catch {
    return false
  }
}

function requestQuit(): void {
  app.quit()
}

async function boot(): Promise<void> {
  paths = createPaths({
    userData: app.getPath('userData'),
    isPackaged: app.isPackaged,
    resourcesPath: process.resourcesPath,
    appPath: app.getAppPath()
  })
  logs = createLogSink({ dir: paths.logsDir(), secrets: () => [daemon?.getToken() ?? ''] })
  daemon = createDaemon({ paths, log: logs, safeStorage })
  supervisor = createSupervisor({
    paths,
    ports: () => {
      const p = daemon.ports()
      return { karmax: p.karmax, wacli: p.wacli }
    },
    log: logs,
    setupCompleted
  })
  prefs = createPrefs(paths.prefsFile())

  const { devUrl, fileUrl } = rendererTarget()
  security = installSecurity({ isPackaged: app.isPackaged, devOrigin: devUrl, fileUrl })
  app.on('web-contents-created', (_e, wc) => security.guardWebContents(wc))
  if (app.isPackaged) Menu.setApplicationMenu(null)

  registerIpc({
    daemon,
    supervisor,
    logs,
    prefs,
    security,
    setup: () => setup,
    onPrefsChanged: (p) => applyLoginItem(p.openAtLogin)
  })
  setup = registerSetup({ paths, supervisor, daemon, log: logs, emit: broadcast })
  if (DEMO) {
    const real = setup
    const done = (s: SetupState): SetupState => ({ ...s, completed: true })
    setup = { api: { ...real.api, state: async () => done(await real.api.state()) }, getState: () => done(real.getState()) }
    logs.app('info', 'Demo mode (KARMAX_DEMO=1): setup wizard skipped; attaching to daemons already running.')
  }

  logs.app('info', `KARMAX Desktop ${app.getVersion()} starting (${process.platform} ${process.arch}, electron ${process.versions.electron})`)
  const p = daemon.ports()
  logs.app('info', `karmax API :${p.karmax}, webhooks :${p.webhooks}, wacli API :${p.wacli}; API token ${daemon.hasToken() ? `present (${daemon.storageKind()})` : 'not set yet'}`)

  createWindow(START_HIDDEN)
  try {
    tray = createTray({
      iconFiles: [paths.iconFile(), join(paths.iconFile(), '..', 'icon.png')],
      onShow: showWindow,
      onRestartDaemons: () => void restartDaemons(),
      onQuit: requestQuit
    })
    tray.update(supervisor.status())
    supervisor.onChange((s) => tray?.update(s))
  } catch (e) {
    logs.app('warn', `Tray unavailable: ${String(e)}`)
  }

  applyLoginItem(prefs.get().openAtLogin)

  // The saved wizard state loads asynchronously; reading it before then always says "not completed".
  await setup?.api.state().catch(() => undefined)
  supervisor.startMonitor()
  if (setupCompleted()) {
    void supervisor.startAll().catch((e: unknown) => logs.app('error', `Auto-start failed: ${String(e)}`))
  } else {
    logs.app('info', 'First-run setup has not completed: daemons are not auto-started.')
  }
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (app.isReady()) showWindow()
  })

  app.on('window-all-closed', () => {
    // With minimize-to-tray the close handler hides instead of closing, so reaching here means we are quitting or the user opted out.
    app.quit()
  })

  app.on('before-quit', (e) => {
    if (quitState === 'done') return
    e.preventDefault()
    if (quitState === 'stopping') return
    quitState = 'stopping'
    const stop = supervisor ? supervisor.stopAll().catch(() => undefined) : Promise.resolve()
    let capTimer: ReturnType<typeof setTimeout> | undefined
    const cap = new Promise<void>((res) => {
      capTimer = setTimeout(res, QUIT_STOP_CAP_MS)
    })
    void Promise.race([stop, cap]).finally(() => {
      if (capTimer) clearTimeout(capTimer)
      supervisor?.killAllSync() // anything that ignored the polite stop
      supervisor?.dispose()
      tray?.destroy()
      logs?.close()
      quitState = 'done'
      app.quit()
    })
  })

  process.on('exit', () => supervisor?.killAllSync())
  process.on('uncaughtException', (err) => logs?.app('error', `Uncaught exception: ${err.stack ?? err.message}`))
  process.on('unhandledRejection', (reason) => logs?.app('error', `Unhandled rejection: ${String(reason)}`))

  void app.whenReady().then(boot).catch((err: unknown) => {
    console.error('KARMAX Desktop failed to start', err)
    app.exit(1)
  })
}
