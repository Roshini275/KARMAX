/**
 * Internal contracts between the Electron main-process modules, so they can be built in parallel:
 *   A1 (window/preload/daemon/supervisor/logs/paths)  implements Paths, SupervisorApi, DaemonApi, LogSink
 *   A2 (setup backend)                                consumes them and exports registerSetup()
 * Renderer-facing types live in src/shared/ipc.ts and are NOT duplicated here.
 */
import type { DaemonRequest, DaemonResponse, LogLevel, LogSource, ProcName, ProcStatus, SetupApi, SetupState } from '../../src/shared/ipc'

/** Every filesystem location the main process cares about. Implemented in paths.ts (Windows-first, works on POSIX for tests). */
export interface Paths {
  /** ~/.karmax (KARMAX data dir; karmax.yaml and .env live here). Override: KARMAX_HOME (tests). */
  dataDir(): string
  envFile(): string
  yamlFile(): string
  /** %LOCALAPPDATA%\KARMAX on Windows (karmax.exe, wacli.exe are installed here). */
  installDir(): string
  karmaxExe(): string
  wacliExe(): string
  /** ~/.wacli, overridable with WACLI_HOME. Contains the WhatsApp session, sqlite db and qr.png. */
  wacliHome(): string
  /** Electron userData (setup.json, logs, safeStorage blobs). */
  userData(): string
  /** Bundled resources dir (resources/bin/{karmax.exe,wacli.exe,manifest.json}); different in dev vs packaged. */
  resourcesBin(): string
}

export interface SupervisorApi {
  status(): ProcStatus[]
  start(name: ProcName): Promise<void>
  stop(name: ProcName): Promise<void>
  restart(name: ProcName): Promise<void>
  /** Resolves true when the process reports healthy within timeoutMs. */
  waitHealthy(name: ProcName, timeoutMs: number): Promise<boolean>
  onChange(cb: (s: ProcStatus[]) => void): () => void
}

export interface DaemonApi {
  request(req: DaemonRequest): Promise<DaemonResponse>
  /** Called by setup after it generates KARMAX_API_TOKEN; persisted encrypted (safeStorage). */
  setToken(token: string): void
  getToken(): string | undefined
  /** karmax API port (default 9091) / wacli API port (default 8765). */
  setPorts(p: { karmax?: number; wacli?: number }): void
}

export interface LogSink {
  /** Append an app-originated line (source 'app'), e.g. setup progress. */
  app(level: LogLevel, message: string): void
  /** Feed raw child-process output; the sink splits lines, parses level/loop, assigns seq, persists, broadcasts. */
  ingest(source: Exclude<LogSource, 'app'>, chunk: string): void
}

export interface SetupDeps {
  paths: Paths
  supervisor: SupervisorApi
  daemon: DaemonApi
  log: LogSink
  /** Push a renderer event (IPC.setupChanged etc.). */
  emit(channel: string, payload: unknown): void
}

/** What A2's electron/main/setup/index.ts must export. */
export type RegisterSetup = (deps: SetupDeps) => { api: SetupApi; getState(): SetupState }
