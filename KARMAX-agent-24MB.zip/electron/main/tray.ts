/**
 * System tray: Show / daemon status / Restart daemons / Quit.
 */
import { Menu, Tray, nativeImage, type NativeImage } from 'electron'
import type { ProcStatus } from '../../src/shared/ipc'

export interface TrayOptions {
  /** Candidate icon files, first that loads wins (icon.ico on Windows, then icon.png). */
  iconFiles: string[]
  onShow(): void
  onRestartDaemons(): void
  onQuit(): void
}

export interface TrayHandle {
  update(status: ProcStatus[]): void
  destroy(): void
}

/** Human label for the tray menu / tooltip. */
export function describeStatus(s: ProcStatus): string {
  const detail = s.state === 'running' && !s.healthy ? 'running (not answering)' : s.state === 'external' ? 'external (not managed)' : s.state
  return `${s.name}: ${detail}`
}

function loadIcon(files: string[]): NativeImage {
  for (const f of files) {
    const img = nativeImage.createFromPath(f)
    if (!img.isEmpty()) return img
  }
  return nativeImage.createEmpty()
}

export function createTray(opts: TrayOptions): TrayHandle {
  const tray = new Tray(loadIcon(opts.iconFiles))
  let status: ProcStatus[] = []

  const render = (): void => {
    tray.setToolTip(['KARMAX', ...status.map(describeStatus)].join('\n'))
    tray.setContextMenu(
      Menu.buildFromTemplate([
        { label: 'Show KARMAX', click: opts.onShow },
        { type: 'separator' },
        ...status.map((s) => ({ label: describeStatus(s), enabled: false })),
        ...(status.length ? [{ type: 'separator' as const }] : []),
        { label: 'Restart daemons', click: opts.onRestartDaemons },
        { type: 'separator' },
        { label: 'Quit KARMAX', click: opts.onQuit }
      ])
    )
  }
  tray.on('click', opts.onShow)
  tray.on('double-click', opts.onShow)
  render()

  return {
    update(s) {
      status = s
      if (!tray.isDestroyed()) render()
    },
    destroy() {
      if (!tray.isDestroyed()) tray.destroy()
    }
  }
}
