/**
 * Bundled-binary manifest + verification. The installer ships `resources/bin/{karmax.exe,wacli.exe,manifest.json}`
 * (see README.md in this folder for the schema CI must produce). Setup verifies sha256 before copying anything
 * into %LOCALAPPDATA%\KARMAX, and again after the copy, so a truncated or tampered file is never executed.
 */
import { createHash } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { chmod, copyFile, mkdir, readFile, rename, rm, stat } from 'node:fs/promises'
import { basename, dirname, join } from 'node:path'
import { z } from 'zod'

const entry = z.object({
  version: z.string().min(1),
  /** File name inside resources/bin — a bare name, never a path. */
  file: z
    .string()
    .min(1)
    .refine((f) => f === basename(f) && !/[\\/]/.test(f) && f !== '..' && f !== '.', 'file must be a bare file name'),
  sha256: z.string().regex(/^[a-fA-F0-9]{64}$/, 'sha256 must be 64 hex characters')
})

export const manifestSchema = z.object({
  schema: z.literal(1),
  karmax: entry,
  wacli: entry
})

export type Manifest = z.infer<typeof manifestSchema>
export type ManifestEntry = z.infer<typeof entry>
export type BinaryName = 'karmax' | 'wacli'

export class ManifestError extends Error {}

export function parseManifest(json: string): Manifest {
  let raw: unknown
  try {
    raw = JSON.parse(json)
  } catch (e) {
    throw new ManifestError(`manifest.json is not valid JSON (${e instanceof Error ? e.message : String(e)})`)
  }
  const r = manifestSchema.safeParse(raw)
  if (!r.success) {
    const first = r.error.issues[0]
    throw new ManifestError(`manifest.json is invalid: ${first.path.join('.') || '(root)'} ${first.message}`)
  }
  return r.data
}

export async function readManifest(dir: string): Promise<Manifest | null> {
  let text: string
  try {
    text = await readFile(join(dir, 'manifest.json'), 'utf8')
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw e
  }
  return parseManifest(text)
}

export function sha256File(path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const h = createHash('sha256')
    const s = createReadStream(path)
    s.on('error', reject)
    s.on('data', (c) => h.update(c))
    s.on('end', () => resolve(h.digest('hex')))
  })
}

export async function exists(path: string): Promise<boolean> {
  try {
    await stat(path)
    return true
  } catch {
    return false
  }
}

export type InstallOutcome = 'installed' | 'already-current'

/**
 * Copy `src` to `dest` after verifying its digest. Idempotent: when `dest` already has the expected digest nothing is
 * written (so re-running never touches a binary that is currently running and locked by Windows). The copy goes to a
 * temp name first and is verified again before the atomic rename.
 */
export async function installVerified(src: string, dest: string, expectedSha256: string): Promise<InstallOutcome> {
  const want = expectedSha256.toLowerCase()
  if (await exists(dest)) {
    if ((await sha256File(dest)) === want) return 'already-current'
  }
  if (!(await exists(src))) throw new ManifestError(`${basename(src)} is listed in the manifest but missing from the installer`)
  const got = await sha256File(src)
  if (got !== want) throw new ManifestError(`${basename(src)} failed its integrity check (expected ${want.slice(0, 12)}…, got ${got.slice(0, 12)}…)`)

  await mkdir(dirname(dest), { recursive: true })
  const tmp = `${dest}.part`
  await copyFile(src, tmp)
  if (process.platform !== 'win32') await chmod(tmp, 0o755) // dev machines only; Windows has no exec bit
  const copied = await sha256File(tmp)
  if (copied !== want) {
    await rm(tmp, { force: true })
    throw new ManifestError(`${basename(dest)} was corrupted while copying`)
  }
  try {
    await rename(tmp, dest)
  } catch (e) {
    await rm(tmp, { force: true })
    const code = (e as NodeJS.ErrnoException).code
    if (code === 'EBUSY' || code === 'EPERM' || code === 'EACCES') {
      throw new ManifestError(`${basename(dest)} is in use. Stop KARMAX and try again.`)
    }
    throw e
  }
  return 'installed'
}

/** Parse a `sha256sum` style checksums.txt ("<hex>  ./name") into name -> hex. */
export function parseChecksums(text: string): Map<string, string> {
  const out = new Map<string, string>()
  for (const line of text.split(/\r?\n/)) {
    const m = /^([a-fA-F0-9]{64})\s+\*?(?:\.\/)?(.+?)\s*$/.exec(line)
    if (m) out.set(m[2], m[1].toLowerCase())
  }
  return out
}
