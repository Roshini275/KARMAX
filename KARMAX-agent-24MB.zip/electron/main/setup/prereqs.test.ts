import { createServer, type Server } from 'node:net'
import { createServer as createHttp } from 'node:http'
import { afterEach, describe, expect, it } from 'vitest'
import { checkClaude, checkPorts, claudeCandidates, describeOs, identifyOccupant, probePort } from './prereqs'
import type { CaptureResult } from './proc'

const ok = (stdout: string): CaptureResult => ({ code: 0, stdout, stderr: '', timedOut: false })
const missing: CaptureResult = { code: null, stdout: '', stderr: '', timedOut: false, spawnError: 'spawn claude ENOENT' }

describe('checkClaude', () => {
  it('reports not found with an install hint', async () => {
    const r = await checkClaude({ run: async () => missing, fileExists: async () => false, home: '/h', platform: 'linux' })
    expect(r.found).toBe(false)
    expect(r.hint).toMatch(/Install Claude Code/)
  })

  it('parses the version and reads structured auth status', async () => {
    const run = async (_c: string, a: string[]) => (a[0] === '--version' ? ok('2.1.3 (Claude Code)\n') : ok('{"loggedIn":true,"authMethod":"claude.ai"}'))
    const r = await checkClaude({ run, fileExists: async () => false, home: '/h', platform: 'linux' })
    expect(r).toMatchObject({ found: true, version: '2.1.3', loggedIn: true })
    expect(r.hint).toBeUndefined()
  })

  it('treats unknown sign-in state as a warning (loggedIn undefined), not a failure', async () => {
    const run = async (_c: string, a: string[]) => (a[0] === '--version' ? ok('1.0.90') : { ...missing, spawnError: 'unknown command' })
    const r = await checkClaude({ run, fileExists: async () => false, home: '/h', platform: 'linux' })
    expect(r.found).toBe(true)
    expect(r.loggedIn).toBeUndefined()
    expect(r.hint).toMatch(/Could not verify/)
  })

  it('falls back to the credentials file when `auth status` is unavailable', async () => {
    const run = async (_c: string, a: string[]) => (a[0] === '--version' ? ok('1.0.90') : { code: 1, stdout: '', stderr: 'unknown command "auth"', timedOut: false })
    const r = await checkClaude({ run, fileExists: async (p) => p.endsWith('.credentials.json'), home: '/h', platform: 'linux' })
    expect(r.loggedIn).toBe(true)
  })

  it('detects an explicit "not logged in"', async () => {
    const run = async (_c: string, a: string[]) => (a[0] === '--version' ? ok('2.0.0') : { code: 1, stdout: 'Not logged in', stderr: '', timedOut: false })
    const r = await checkClaude({ run, fileExists: async () => false, home: '/h', platform: 'linux' })
    expect(r.loggedIn).toBe(false)
    expect(r.hint).toMatch(/not signed in/)
  })

  it('finds claude in a well-known location when it is not on PATH', async () => {
    const seen: string[] = []
    const run = async (c: string, a: string[]) => {
      seen.push(c)
      if (c === 'claude') return missing
      return a[0] === '--version' ? ok('2.0.1') : ok('{"loggedIn":true}')
    }
    const home = '/home/u'
    const r = await checkClaude({ run, fileExists: async (p) => p === claudeCandidates('linux', home)[0], home, platform: 'linux' })
    expect(r.found).toBe(true)
    expect(seen).toContain(claudeCandidates('linux', home)[0])
  })
})

describe('describeOs', () => {
  it('names Windows 10 vs 11 by build number', () => {
    expect(describeOs('win32', '10.0.22631', 'x64')).toMatch(/Windows 11 \(build 22631, x64\)/)
    expect(describeOs('win32', '10.0.19045', 'x64')).toMatch(/Windows 10/)
    expect(describeOs('linux', '6.1.0', 'x64', 'Linux')).toMatch(/development machine/)
  })
})

describe('ports', () => {
  const servers: Server[] = []
  afterEach(() => {
    servers.splice(0).forEach((s) => s.close())
  })
  const listen = (s: Server, port = 0) => new Promise<number>((res) => s.listen(port, '127.0.0.1', () => res((s.address() as { port: number }).port)))

  it('probePort: free vs busy', async () => {
    const s = createServer()
    servers.push(s)
    const port = await listen(s)
    expect(await probePort(port)).toBe('busy')
    await new Promise((r) => s.close(r))
    expect(await probePort(port)).toBe('free')
  })

  it('adopts a running KARMAX (identified by /api/ping) and reports the webhook port as held by it', async () => {
    const api = createHttp((req, res) => {
      res.setHeader('content-type', 'application/json')
      res.end(req.url === '/api/ping' ? '{"service":"karmax","version":"0.2.0"}' : '{}')
    })
    const hook = createServer()
    servers.push(api as unknown as Server, hook)
    const apiPort = await listen(api as unknown as Server)
    const hookPort = await listen(hook)
    const { report, adopted } = await checkPorts({ karmax: apiPort, wacli: 1, webhooks: hookPort })
    expect(adopted.karmax).toBe(true)
    expect(report.free).toBe(true)
    expect(report.busyBy).toMatch(/adopted/)
  })

  it('flags an unknown program on a port as not free', async () => {
    const s = createServer()
    servers.push(s)
    const port = await listen(s)
    const { report } = await checkPorts({ karmax: port, wacli: 1, webhooks: 2 })
    expect(report.free).toBe(false)
    expect(report.busyBy).toMatch(/another program/)
    expect(await identifyOccupant('karmax', port)).toBeUndefined()
  })

  it('identifies wacli by its /status shape', async () => {
    const w = createHttp((_req, res) => {
      res.setHeader('content-type', 'application/json')
      res.end('{"connected":true,"dnd_mode":false}')
    })
    servers.push(w as unknown as Server)
    const port = await listen(w as unknown as Server)
    expect(await identifyOccupant('wacli', port)).toBe('wacli')
  })
})
