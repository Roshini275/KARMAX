import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import type { SetupState } from '../../../src/shared/ipc'
import { STEP_ORDER, SetupStore } from './state'

let dir: string
let file: string
let events: SetupState[]
const stores: SetupStore[] = []
const make = () => {
  const s = new SetupStore(file, (x) => events.push(x))
  stores.push(s)
  return s
}

beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), 'km-state-'))
  file = join(dir, 'nested', 'setup.json')
  events = []
})
afterEach(async () => {
  await Promise.all(stores.splice(0).map((s) => s.flush()))
  await rm(dir, { recursive: true, force: true })
})

describe('SetupStore', () => {
  it('starts with all nine steps todo, not completed', async () => {
    const s = make()
    await s.load()
    const snap = s.snapshot()
    expect(snap.steps.map((x) => x.id)).toEqual(STEP_ORDER)
    expect(snap.steps.every((x) => x.status === 'todo')).toBe(true)
    expect(snap.completed).toBe(false)
  })

  it('enforces step order: a step is blocked until every earlier step is done or skipped', () => {
    const s = make()
    expect(s.blocker('prereqs')).toBeNull()
    expect(s.blocker('model')).toMatch(/Prerequisites/)
    s.skip('prereqs', 'claude missing') // skipped == passed with a warning
    expect(s.blocker('model')).toBeNull()
    expect(s.blocker('binaries')).toMatch(/Model access/)
    s.done('model')
    expect(s.blocker('binaries')).toBeNull()
    expect(s.blocker('config')).toMatch(/Install KARMAX/)
  })

  it('an error blocks later steps and keeps the human message until retried', () => {
    const s = make()
    s.done('prereqs')
    s.fail('model', 'That key looks too short.')
    expect(s.blocker('binaries')).toMatch(/Model access/)
    expect(s.step('model')).toEqual({ id: 'model', status: 'error', error: 'That key looks too short.' })
    s.begin('model')
    expect(s.step('model').error).toBeUndefined()
    s.done('model', 'key saved')
    expect(s.step('model')).toEqual({ id: 'model', status: 'done', detail: 'key saved' })
  })

  it('completed only when verify is done and nothing is left todo/error', () => {
    const s = make()
    for (const id of STEP_ORDER) s.done(id)
    expect(s.snapshot().completed).toBe(true)
    s.fail('lockdown', 'x')
    expect(s.snapshot().completed).toBe(false)
  })

  it('persists across instances and demotes a crashed `active` step to todo', async () => {
    const a = make()
    a.done('prereqs')
    a.done('model')
    a.begin('binaries', 'copying')
    a.setMeta({ operatorNumber: '919876543210', waMode: 'dedicated', operatorJid: '919876543210@s.whatsapp.net' })
    await a.flush()

    const b = make()
    await b.load()
    const snap = b.snapshot()
    expect(snap.steps.find((x) => x.id === 'model')?.status).toBe('done')
    expect(snap.steps.find((x) => x.id === 'binaries')?.status).toBe('todo')
    expect(snap.operatorNumber).toBe('919876543210')
    expect(snap.waMode).toBe('dedicated')
    expect(b.meta().operatorJid).toBe('919876543210@s.whatsapp.net')
  })

  it('tolerates a corrupt or foreign setup.json', async () => {
    await writeFile(join(dir, 'setup.json'), '{not json')
    file = join(dir, 'setup.json')
    const s = make()
    await s.load()
    expect(s.snapshot().steps.every((x) => x.status === 'todo')).toBe(true)
  })

  it('emits a snapshot on every change, including pairing updates and api-key presence', () => {
    const s = make()
    s.begin('whatsapp')
    s.setPairing({ running: true, method: 'code', code: 'K4Q7-9XPM', lines: ['Pairing code: K4Q7-9XPM'] })
    s.setApiKeyPresent(true)
    const last = events.at(-1)!
    expect(last.hasApiKey).toBe(true)
    expect(last.pairing?.code).toBe('K4Q7-9XPM')
    expect(events.length).toBeGreaterThanOrEqual(3)
  })

  it('reset clears only setup.json state', async () => {
    const s = make()
    s.done('prereqs')
    s.setMeta({ operatorNumber: '1234567890' })
    await s.flush()
    await s.reset()
    expect(s.snapshot().steps.every((x) => x.status === 'todo')).toBe(true)
    expect(s.snapshot().operatorNumber).toBeUndefined()
    expect(JSON.parse(await readFile(file, 'utf8'))).toEqual({ version: 1, steps: {} })
  })
})
