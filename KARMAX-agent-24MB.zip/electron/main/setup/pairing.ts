/**
 * `wacli login` output handling. Facts verified in wacli/main.go cmdLogin:
 *   pairing-code mode  ->  "Pairing code: XXXX-XXXX" then "Open WhatsApp on your phone -> Linked Devices -> Link with phone number."
 *   success            ->  "Login successful." then post-login sync ("Syncing chats, messages, and contacts..." ... "Sync complete. ...")
 *   existing session   ->  "Existing session found, verifying..." then "Session valid."  (or "Existing session is stale...")
 *   QR mode            ->  optional "QR code written to <path>" (only when `qrencode` is installed) plus terminal half-blocks
 *   timeout / failure  ->  process exits non-zero with "login timed out; run `wacli login` again" / "pair phone: ..." on stderr
 */

// eslint-disable-next-line no-control-regex
const ANSI_RE = /\u001b\[[0-9;?]*[ -/]*[@-~]|\u001b\][^\u0007]*\u0007/g

export function stripAnsi(s: string): string {
  return s.replace(ANSI_RE, '')
}

/** Extract the pairing code from a line, normalised to "ABCD-EFGH". WhatsApp codes are 8 chars from [A-Z0-9]. */
export function parsePairingCode(line: string): string | undefined {
  const m = /Pairing code:\s*([A-Z0-9]{4})-?([A-Z0-9]{4})\b/i.exec(stripAnsi(line))
  return m ? `${m[1]}-${m[2]}`.toUpperCase() : undefined
}

/** Terminal-QR rows are made of half-block glyphs; they are useless in a log panel. */
export function isQrBlockLine(line: string): boolean {
  return /[▀-▟]{6,}/.test(line)
}

/**
 * Turn wacli's terminal QR (half-block glyphs) into an SVG data URI, so QR pairing works without `qrencode`.
 * Each glyph is two vertical modules: "█" light/light, " " dark/dark, "▀" light over dark, "▄" dark over light.
 * The output ends with a row of "▀" that pads the bottom edge; its lower half is off the canvas, not a dark module.
 * Returns undefined for anything that is not a rectangular QR-sized block.
 */
export function qrRowsToSvgDataUri(rows: string[]): string | undefined {
  if (rows.length < 12) return undefined
  const width = rows[0].length
  if (width < 21 || rows.some((r) => r.length !== width || /[^ █▀▄]/.test(r))) return undefined
  const trailingPad = /^▀+$/.test(rows[rows.length - 1])
  const height = rows.length * 2 - (trailingPad ? 1 : 0)
  const dark = (y: number, x: number): boolean => {
    const ch = rows[y >> 1][x]
    if (y & 1) return ch === ' ' || ch === '▀'
    return ch === ' ' || ch === '▄'
  }
  let d = ''
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; ) {
      if (!dark(y, x)) {
        x++
        continue
      }
      let run = 1
      while (x + run < width && dark(y, x + run)) run++
      d += `M${x} ${y}h${run}v1h-${run}z`
      x += run
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" shape-rendering="crispEdges"><rect width="${width}" height="${height}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`
}

/** A row of wacli's terminal QR: only "█▀▄" and spaces, wide, and framed by the light quiet zone. */
export function isQrRowLine(line: string): boolean {
  return /^[█▀▄][ █▀▄]{19,}[█▀▄]$/.test(line)
}

export type LoginEvent =
  | { kind: 'code'; code: string }
  | { kind: 'success' } // "Login successful."
  | { kind: 'valid' } // "Session valid." (existing session verified)
  | { kind: 'stale' } // existing session cleared, starting fresh
  | { kind: 'qr'; path: string }
  | { kind: 'syncing' }
  | { kind: 'synced' }
  | { kind: 'timeout' }
  | { kind: 'other' }

export function classifyLoginLine(rawLine: string): LoginEvent {
  const line = stripAnsi(rawLine).trim()
  const code = parsePairingCode(line)
  if (code) return { kind: 'code', code }
  if (/^Login successful\.?$/i.test(line)) return { kind: 'success' }
  if (/^Session valid\.?$/i.test(line)) return { kind: 'valid' }
  if (/existing session is stale/i.test(line)) return { kind: 'stale' }
  const qr = /^QR code written to\s+(.+)$/i.exec(line)
  if (qr) return { kind: 'qr', path: qr[1].trim() }
  if (/^Syncing chats/i.test(line)) return { kind: 'syncing' }
  if (/^Sync complete/i.test(line)) return { kind: 'synced' }
  if (/login timed out|timeout/i.test(line) && /login/i.test(line)) return { kind: 'timeout' }
  return { kind: 'other' }
}

/** Splits arbitrary chunks into complete lines (handles \r, \r\n, \n and a partial trailing line). */
export class LineSplitter {
  private buf = ''
  push(chunk: string): string[] {
    this.buf += chunk
    const parts = this.buf.split(/\r\n|\n|\r/)
    this.buf = parts.pop() ?? ''
    return parts.map((l) => stripAnsi(l).trimEnd()).filter((l) => l.trim() !== '')
  }
  flush(): string[] {
    const rest = stripAnsi(this.buf).trim()
    this.buf = ''
    return rest ? [rest] : []
  }
}

export interface LoginProgress {
  code?: string
  linked: boolean // success or valid session seen
  existingSession: boolean
  syncing: boolean
  synced: boolean
  timedOut: boolean
  qrPath?: string
}

/** Fold login output lines into a progress summary. Pure so it can be unit-tested with real transcripts. */
export function foldLoginLines(lines: string[], initial?: LoginProgress): LoginProgress {
  const p: LoginProgress = initial ?? { linked: false, existingSession: false, syncing: false, synced: false, timedOut: false }
  for (const l of lines) {
    const ev = classifyLoginLine(l)
    switch (ev.kind) {
      case 'code':
        p.code = ev.code
        break
      case 'success':
        p.linked = true
        break
      case 'valid':
        p.linked = true
        p.existingSession = true
        break
      case 'qr':
        p.qrPath = ev.path
        break
      case 'syncing':
        p.syncing = true
        break
      case 'synced':
        p.synced = true
        break
      case 'timeout':
        p.timedOut = true
        break
    }
  }
  return p
}

/** Human message for the most common failure lines wacli prints before exiting non-zero. */
export function explainLoginFailure(lines: string[], code: number | null): string {
  const text = lines.join('\n')
  if (/WACLI_PHONE env var is required/i.test(text)) return 'wacli did not receive the phone number to link. Enter it and try again.'
  if (/login timed out|timed out/i.test(text)) return 'The pairing code expired before it was entered. Start again to get a fresh code.'
  if (/pair phone:/i.test(text)) return 'WhatsApp rejected the pairing request. Check the number (country code, no +) and that this device can reach WhatsApp, then try again.'
  if (/database is locked|unable to open database|locked/i.test(text)) return 'The WhatsApp session store is in use by another wacli process. Stop any running wacli and try again.'
  if (/connect:/i.test(text)) return 'Could not connect to WhatsApp. Check your internet connection and try again.'
  return `wacli login stopped unexpectedly${code != null ? ` (exit ${code})` : ''}. See the activity log for details.`
}
