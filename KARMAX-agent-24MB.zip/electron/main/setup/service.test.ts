/**
 * End-to-end tests of the setup state machine against fake karmax/wacli executables (shell scripts) and an in-memory
 * fake of the two daemon APIs. POSIX only: the fakes are #! scripts.
 */
import { createHash } from 'node:crypto'
import { chmod, mkdir, mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import type { DaemonRequest, DaemonResponse, LogLevel, ProcName, ProcStatus, SetupState, SetupStepId } from '../../../src/shared/ipc'
import type { Paths, SetupDeps } from '../contracts'
import { readEnvValue } from './env'
import { createSetup } from './service'

const OPERATOR = '919876543210'
const KARMAX_NUMBER = '15551230000'
const API_KEY = 'sk-ant-api03-abcdefghijklmnopqrstuvwxyz0123456789'

const KARMAX_SCRIPT = `#!/bin/sh
case "$1" in
  --version) echo "karmax version 0.2.0" ;;
  init)
    mkdir -p "$HOME/.karmax"
    cat > "$HOME/.karmax/karmax.yaml" <<'YAML'
karmax:
    version: "1"
    data_dir: ~/.karmax
webhooks:
    enabled: true
    port: 9090
    host: 0.0.0.0
api:
    enabled: false
    port: 0
    host: ""
comms:
    channels: []
agents:
    - id: hello-world
      name: Hello World Agent
harness:
    enabled: false
YAML
    echo "created" ;;
  --config)
    if [ "$FAKE_KARMAX_INVALID" = "1" ]; then echo "error: config validation FAILED: boom" >&2; exit 1; fi
    echo "config validation OK" ;;
esac
`

const WACLI_SCRIPT = `#!/bin/sh
if [ "$1" = "login" ]; then
  case "$FAKE_WA_MODE" in
    fail) echo "pair phone: not on whatsapp" >&2; exit 1 ;;
    hang) echo "Pairing code: K4Q7-9XPM"; sleep 30 ;;
    existing) echo "Existing session found, verifying..."; echo "Session valid."; echo "Syncing chats, messages, and contacts..."; exit 0 ;;
    *) echo "Pairing code: K4Q7-9XPM"; echo "Open WhatsApp on your phone -> Linked Devices -> Link with phone number."; sleep 0.2
       echo "Login successful."; echo "Syncing chats, messages, and contacts..."; echo "Sync complete. Chats: 3, messages: 10"; exit 0 ;;
  esac
fi
`

const sha = (s: string) => createHash('sha256').update(s).digest('hex')

class FakeWorld {
  chats: { jid: string; name: string; is_group: boolean; locked: boolean }[] = [
    { jid: '111@s.whatsapp.net', name: 'Mum', is_group: false, locked: true },
    { jid: '222@g.us', name: 'Family', is_group: true, locked: true }
  ]
  dnd = false
  configured = false
  webhooks: { id: number; url: string; secret?: string; events: string[]; scope: string; chat_jids: string[]; enabled: boolean }[] = []
  nextHook = 1
  sent: { channel_id: string; target: string; content: string }[] = []
  toolStatus = 200
  toolBody: unknown = null
  wacliUp = false
  karmaxUp = false
  token?: string
  addOperatorChatLater = false
  leakUnlockedChat = false
  resolveMap: Record<string, string> = {}

  request = async (req: DaemonRequest): Promise<DaemonResponse> => {
    const ok = (body: unknown, status = 200): DaemonResponse => ({ ok: status < 400, status, body })
    if (req.target === 'wacli') {
      if (!this.wacliUp) return { ok: false, status: 0, body: { error: 'Cannot reach daemon' } }
      const p = req.path
      if (p === '/status') return ok({ connected: true, user_jid: `${KARMAX_NUMBER}:3@s.whatsapp.net`, dnd_mode: this.dnd, initial_access_configured: this.configured, chat_count: this.chats.length })
      if (p === '/chats' && req.method === 'GET') {
        const f = req.query?.filter
        return ok({ chats: this.chats.filter((c) => (f === 'unlocked' ? !c.locked : f === 'locked' ? c.locked : true)) })
      }
      if (p === '/chats/access') {
        const jids = (req.body as { unlocked_jids: string[] }).unlocked_jids
        this.chats.forEach((c) => (c.locked = !jids.includes(c.jid)))
        this.configured = true
        if (this.leakUnlockedChat) this.chats.push({ jid: '333@s.whatsapp.net', name: 'Stranger', is_group: false, locked: false })
        return ok({ ok: true })
      }
      if (p.startsWith('/chats/') && req.method === 'PUT') {
        const jid = decodeURIComponent(p.slice(7))
        const c = this.chats.find((x) => x.jid === jid)
        if (!c) return ok({ error: 'no rows' }, 404)
        c.locked = (req.body as { locked: boolean }).locked
        return ok({ chat: c })
      }
      if (p === '/resolve') {
        const hit = this.resolveMap[String(req.query?.ref)]
        return hit ? ok({ match: { jid: hit, exists_in_chats: true, locked: true } }) : ok({ error: 'no matches' }, 404)
      }
      if (p === '/dnd') {
        if (req.method === 'PUT') this.dnd = (req.body as { enabled: boolean }).enabled
        return ok({ enabled: this.dnd })
      }
      if (p === '/webhooks' && req.method === 'GET') return ok({ webhooks: this.webhooks })
      if (p === '/webhooks' && req.method === 'POST') {
        const b = req.body as { url: string; secret: string; events: string[]; scope: string; chat_jids: string[] }
        const w = { id: this.nextHook++, url: b.url, secret: b.secret, events: b.events, scope: b.scope, chat_jids: b.chat_jids, enabled: true }
        this.webhooks.push(w)
        return ok({ webhook: w }, 201)
      }
      if (p.startsWith('/webhooks/') && req.method === 'DELETE') {
        this.webhooks = this.webhooks.filter((w) => w.id !== Number(p.slice(10)))
        return ok({ ok: true })
      }
    }
    if (req.target === 'karmax' || !req.target) {
      if (!this.karmaxUp) return { ok: false, status: 0, body: { error: 'Cannot reach daemon' } }
      if (req.path === '/api/tools' && req.method === 'GET') return ok([])
      if (req.path === '/api/tools/comms.send') {
        if (this.toolStatus !== 200) return ok(this.toolBody, this.toolStatus)
        if (this.toolBody) return ok(this.toolBody)
        this.sent.push(req.body as { channel_id: string; target: string; content: string })
        return ok({ tool: 'comms.send', ok: true, output: 'sent' })
      }
    }
    return ok({ error: 'not found' }, 404)
  }
}

let root: string
let world: FakeWorld
let logs: { level: LogLevel; message: string }[]
let states: SetupState[]
let procs: ProcStatus[]

const paths = (): Paths => ({
  dataDir: () => join(root, 'home', '.karmax'),
  envFile: () => join(root, 'home', '.karmax', '.env'),
  yamlFile: () => join(root, 'home', '.karmax', 'karmax.yaml'),
  installDir: () => join(root, 'install'),
  karmaxExe: () => join(root, 'install', 'karmax.exe'),
  wacliExe: () => join(root, 'install', 'wacli.exe'),
  wacliHome: () => join(root, 'home', '.wacli'),
  userData: () => join(root, 'userData'),
  resourcesBin: () => join(root, 'res')
})

function makeDeps(): SetupDeps {
  return {
    paths: paths(),
    supervisor: {
      status: () => procs,
      start: async (n: ProcName) => {
        if (n === 'wacli') world.wacliUp = true
        else world.karmaxUp = true
        procs = procs.map((p) => (p.name === n ? { ...p, state: 'running', healthy: true } : p))
      },
      stop: async (n: ProcName) => {
        procs = procs.map((p) => (p.name === n ? { ...p, state: 'stopped', healthy: false } : p))
        if (n === 'wacli') world.wacliUp = false
      },
      restart: async (n: ProcName) => {
        procs = procs.map((p) => (p.name === n ? { ...p, state: 'running', healthy: true } : p))
      },
      waitHealthy: async (n: ProcName) => procs.find((p) => p.name === n)?.healthy ?? false,
      onChange: () => () => undefined
    },
    daemon: {
      request: world.request,
      setToken: (t: string) => (world.token = t),
      getToken: () => world.token,
      setPorts: () => undefined
    },
    log: { app: (level, message) => logs.push({ level, message }), ingest: () => undefined },
    emit: (_c, payload) => states.push(payload as SetupState)
  }
}

async function writeBundle(opts: { tamper?: boolean } = {}) {
  await mkdir(join(root, 'res'), { recursive: true })
  await writeFile(join(root, 'res', 'karmax.exe'), KARMAX_SCRIPT)
  await writeFile(join(root, 'res', 'wacli.exe'), WACLI_SCRIPT)
  const manifest = {
    schema: 1,
    karmax: { version: '0.2.0', file: 'karmax.exe', sha256: sha(KARMAX_SCRIPT) },
    wacli: { version: '1.4.0', file: 'wacli.exe', sha256: opts.tamper ? '0'.repeat(64) : sha(WACLI_SCRIPT) }
  }
  await writeFile(join(root, 'res', 'manifest.json'), JSON.stringify(manifest))
}

const fakeReport = (over: Partial<{ found: boolean; loggedIn: boolean | undefined; free: boolean }> = {}) => async () => ({
  report: {
    os: 'Test OS',
    claudeCli: { found: over.found ?? true, version: '2.1.3', loggedIn: 'loggedIn' in over ? over.loggedIn : true },
    ports: { karmax: 9091, wacli: 8765, webhooks: 9090, free: over.free ?? true },
    ok: (over.found ?? true) && (over.free ?? true)
  },
  adopted: { karmax: false, wacli: false }
})

const hooks = (extra: Record<string, unknown> = {}) => ({
  pollMs: 10,
  operatorTimeoutMs: 400,
  pairingTimeoutMs: 5000,
  syncCapMs: 2000,
  verifyAnthropicKey: async () => 'valid' as const,
  runPrereqs: fakeReport(),
  platform: 'linux' as NodeJS.Platform,
  ...extra
})

async function waitFor<T>(fn: () => T | undefined | false, ms = 4000): Promise<T> {
  const t0 = Date.now()
  for (;;) {
    const v = fn()
    if (v) return v
    if (Date.now() - t0 > ms) throw new Error('waitFor timed out')
    await new Promise((r) => setTimeout(r, 15))
  }
}

const stepOf = (s: ReturnType<typeof createSetup>, id: SetupStepId) => s.getState().steps.find((x) => x.id === id)!

beforeEach(async () => {
  root = await mkdtemp(join(tmpdir(), 'km-setup-'))
  world = new FakeWorld()
  logs = []
  states = []
  procs = [
    { name: 'karmax', state: 'stopped', healthy: false, restarts: 0 },
    { name: 'wacli', state: 'stopped', healthy: false, restarts: 0 }
  ]
  await writeBundle()
  delete process.env.FAKE_WA_MODE
  delete process.env.FAKE_KARMAX_INVALID
})
afterEach(async () => {
  await new Promise((r) => setTimeout(r, 30))
  await rm(root, { recursive: true, force: true })
})

const chmodX = async () => {
  await chmod(join(root, 'install', 'karmax.exe'), 0o755)
  await chmod(join(root, 'install', 'wacli.exe'), 0o755)
}

async function through(s: ReturnType<typeof createSetup>, upTo: SetupStepId, mode: 'dedicated' | 'own' = 'dedicated') {
  await s.api.checkPrereqs()
  if (upTo === 'prereqs') return
  await s.api.saveModelKey(API_KEY)
  if (upTo === 'model') return
  await s.api.installBinaries()
  await chmodX()
  if (upTo === 'binaries') return
  await s.api.writeConfig({ operatorNumber: `+${mode === 'own' ? KARMAX_NUMBER : OPERATOR}`, waMode: mode })
  if (upTo === 'config') return
  await s.api.startPairing({ method: 'code', phone: mode === 'own' ? KARMAX_NUMBER : KARMAX_NUMBER })
  await waitFor(() => stepOf(s, 'whatsapp').status === 'done' || stepOf(s, 'whatsapp').status === 'error')
}

describe.skipIf(process.platform === 'win32')('setup service (fake binaries + fake daemons)', () => {
  it('runs the whole wizard for a dedicated number and ends completed', async () => {
    const s = createSetup(makeDeps(), hooks())
    await s.api.state()

    const rep = await s.api.checkPrereqs()
    expect(rep.ok).toBe(true)
    expect(stepOf(s, 'prereqs').status).toBe('done')

    await s.api.saveModelKey(API_KEY)
    const env = await readFile(join(root, 'home', '.karmax', '.env'), 'utf8')
    expect(readEnvValue(env, 'ANTHROPIC_API_KEY')).toBe(API_KEY)
    expect(readEnvValue(env, 'KARMAX_API_TOKEN')).toMatch(/^[0-9a-f]{64}$/)
    expect(readEnvValue(env, 'WHATSAPP_WEBHOOK_SECRET')).toMatch(/^[0-9a-f]{64}$/)
    expect(world.token).toBe(readEnvValue(env, 'KARMAX_API_TOKEN'))
    expect((await s.api.state()).hasApiKey).toBe(true)

    await s.api.installBinaries()
    await chmodX()
    expect(stepOf(s, 'binaries').detail).toMatch(/verified \(sha256\)/)
    expect((await stat(join(root, 'install', 'karmax.exe'))).size).toBeGreaterThan(0)

    await s.api.writeConfig({ operatorNumber: `+${OPERATOR.slice(0, 2)} ${OPERATOR.slice(2, 7)}-${OPERATOR.slice(7)}`, waMode: 'dedicated' })
    const yaml = await readFile(join(root, 'home', '.karmax', 'karmax.yaml'), 'utf8')
    expect(yaml).toContain(`target_chat: "${OPERATOR}"`)
    expect(yaml).toContain('enabled: true')
    expect(yaml).toContain('id: karmax-agent')
    const env2 = await readFile(join(root, 'home', '.karmax', '.env'), 'utf8')
    expect(readEnvValue(env2, 'WHATSAPP_TARGET')).toBe(OPERATOR)
    expect(readEnvValue(env2, 'WHATSAPP_OPERATOR_CHATS')).toBe(OPERATOR)
    expect(readEnvValue(env2, 'KARMAX_WACLI_PATH')).toBe(join(root, 'install', 'wacli.exe'))

    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    const code = await waitFor(() => s.getState().pairing?.code)
    expect(code).toBe('K4Q7-9XPM')
    expect(s.getState().pairing?.running).toBe(true)
    await waitFor(() => stepOf(s, 'whatsapp').status === 'done')
    expect(s.getState().pairing?.running).toBe(false)
    expect(s.getState().pairing?.lines.join('\n')).toContain('Login successful.')

    await s.api.startServices()
    expect(stepOf(s, 'services').status).toBe('done')
    // Operator step is now waiting for the human's first message and says exactly what to do.
    await waitFor(() => /send "hi"/.test(stepOf(s, 'operator').detail ?? ''))
    expect(stepOf(s, 'operator').status).toBe('active')
    expect(stepOf(s, 'operator').detail).toContain(`+${OPERATOR}`)
    world.chats.unshift({ jid: `${OPERATOR}@s.whatsapp.net`, name: 'Me', is_group: false, locked: true })
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    expect(world.webhooks).toHaveLength(1)
    expect(world.webhooks[0]).toMatchObject({
      url: 'http://127.0.0.1:9090/comms/whatsapp',
      scope: 'selected_chats',
      chat_jids: [`${OPERATOR}@s.whatsapp.net`],
      secret: readEnvValue(env, 'WHATSAPP_WEBHOOK_SECRET')
    })

    await s.api.applyOperatorLockdown()
    expect(world.dnd).toBe(true)
    expect(world.configured).toBe(true)
    expect(world.chats.filter((c) => !c.locked).map((c) => c.jid)).toEqual([`${OPERATOR}@s.whatsapp.net`])

    expect(s.getState().completed).toBe(false)
    await s.api.sendTestMessage()
    expect(world.sent).toHaveLength(1)
    expect(world.sent[0]).toMatchObject({ channel_id: 'whatsapp-main', target: `${OPERATOR}@s.whatsapp.net` })
    expect(s.getState().completed).toBe(true)
    expect(states.at(-1)?.completed).toBe(true)

    // Secrets and raw numbers never reach the log sink.
    const all = logs.map((l) => l.message).join('\n')
    expect(all).not.toContain(API_KEY)
    expect(all).not.toContain(readEnvValue(env, 'KARMAX_API_TOKEN')!)
    expect(all).not.toContain(readEnvValue(env, 'WHATSAPP_WEBHOOK_SECRET')!)
    expect(all).not.toContain(OPERATOR)
    expect(all).not.toContain('K4Q7-9XPM')
    expect(logs.every((l) => l.message.startsWith('[setup:'))).toBe(true)
    s.dispose()
  })

  it('persists progress and resumes in a new instance', async () => {
    const a = createSetup(makeDeps(), hooks())
    await through(a, 'config')
    await new Promise((r) => setTimeout(r, 50))
    const b = createSetup(makeDeps(), hooks())
    const st = await b.api.state()
    expect(st.steps.filter((x) => x.status === 'done').map((x) => x.id)).toEqual(['prereqs', 'model', 'binaries', 'config'])
    expect(st.operatorNumber).toBe(OPERATOR)
    expect(st.waMode).toBe('dedicated')
    expect(st.hasApiKey).toBe(true)
    a.dispose()
    b.dispose()
  })

  it('refuses to run steps out of order', async () => {
    const s = createSetup(makeDeps(), hooks())
    await expect(s.api.saveModelKey(API_KEY)).rejects.toThrow(/Finish "Prerequisites" first/)
    await s.api.checkPrereqs()
    await expect(s.api.installBinaries()).rejects.toThrow(/Model access/)
    await expect(s.api.startServices()).rejects.toThrow(/Model access/)
    s.dispose()
  })

  it('prereqs: a missing Claude CLI is a warning (skipped), busy ports are an error, and the report is still returned', async () => {
    const a = createSetup(makeDeps(), hooks({ runPrereqs: fakeReport({ found: false }) }))
    const r = await a.api.checkPrereqs()
    expect(r.claudeCli.found).toBe(false)
    expect(stepOf(a, 'prereqs').status).toBe('skipped')
    expect(stepOf(a, 'prereqs').detail).toMatch(/Claude Code CLI not found/)
    await a.api.saveModelKey(API_KEY) // skipped counts as passed
    const b = createSetup(makeDeps(), hooks({ runPrereqs: fakeReport({ free: false }) }))
    await b.api.checkPrereqs()
    expect(stepOf(b, 'prereqs').status).toBe('error')
    a.dispose()
    b.dispose()
  })

  it('model: rejects bad and Anthropic-refused keys with human messages and no file written', async () => {
    const s = createSetup(makeDeps(), hooks({ verifyAnthropicKey: async () => 'invalid' }))
    await s.api.checkPrereqs()
    await expect(s.api.saveModelKey('nope')).rejects.toThrow(/sk-ant-/)
    expect(stepOf(s, 'model').error).toMatch(/sk-ant-/)
    await expect(s.api.saveModelKey(API_KEY)).rejects.toThrow(/rejected this API key/)
    await expect(readFile(join(root, 'home', '.karmax', '.env'))).rejects.toThrow()
    s.dispose()
  })

  it('model: keeps an existing token/secret and unrelated .env lines on a second run', async () => {
    await mkdir(join(root, 'home', '.karmax'), { recursive: true })
    await writeFile(join(root, 'home', '.karmax', '.env'), `# mine\nFOO=bar\nKARMAX_API_TOKEN=${'a'.repeat(64)}\nANTHROPIC_AUTH_TOKEN=your_auth_token_here\n`)
    const s = createSetup(makeDeps(), hooks())
    await s.api.checkPrereqs()
    await s.api.saveModelKey(API_KEY)
    const env = await readFile(join(root, 'home', '.karmax', '.env'), 'utf8')
    expect(env).toContain('# mine')
    expect(env).toContain('FOO=bar')
    expect(readEnvValue(env, 'KARMAX_API_TOKEN')).toBe('a'.repeat(64))
    expect(readEnvValue(env, 'ANTHROPIC_AUTH_TOKEN')).toBe('')
    expect(world.token).toBe('a'.repeat(64))
    s.dispose()
  })

  it('binaries: a tampered bundle fails the integrity check with a clear message and installs nothing', async () => {
    await writeBundle({ tamper: true })
    const s = createSetup(makeDeps(), hooks())
    await s.api.checkPrereqs()
    await s.api.saveModelKey(API_KEY)
    await expect(s.api.installBinaries()).rejects.toThrow(/wacli\.exe failed its integrity check/)
    expect(stepOf(s, 'binaries').status).toBe('error')
    await expect(stat(join(root, 'install', 'wacli.exe'))).rejects.toThrow()
    s.dispose()
  })

  it('binaries: without a bundle on a non-Windows dev machine explains why instead of pretending', async () => {
    await rm(join(root, 'res'), { recursive: true })
    const s = createSetup(makeDeps(), hooks())
    await s.api.checkPrereqs()
    await s.api.saveModelKey(API_KEY)
    await expect(s.api.installBinaries()).rejects.toThrow(/no bundled binaries/)
    s.dispose()
  })

  it('binaries: dev fallback says honestly that wacli cannot be provided on Windows', async () => {
    await rm(join(root, 'res'), { recursive: true })
    await mkdir(join(root, 'install'), { recursive: true })
    await writeFile(join(root, 'install', 'karmax.exe'), KARMAX_SCRIPT, { mode: 0o755 }) // karmax already present, wacli is not
    const s = createSetup(makeDeps(), hooks({ platform: 'win32' as NodeJS.Platform }))
    await s.api.checkPrereqs()
    await s.api.saveModelKey(API_KEY)
    await expect(s.api.installBinaries()).rejects.toThrow(/publishes no Windows release/)
    s.dispose()
  })

  it('config: surfaces `karmax config validate` output on failure and validates the operator number', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'binaries')
    await expect(s.api.writeConfig({ operatorNumber: '12345', waMode: 'dedicated' })).rejects.toThrow(/short/)
    process.env.FAKE_KARMAX_INVALID = '1'
    await expect(s.api.writeConfig({ operatorNumber: OPERATOR, waMode: 'dedicated' })).rejects.toThrow(/rejected the generated configuration[\s\S]*boom/)
    expect(stepOf(s, 'config').status).toBe('error')
    delete process.env.FAKE_KARMAX_INVALID
    await s.api.writeConfig({ operatorNumber: OPERATOR, waMode: 'dedicated' })
    expect(stepOf(s, 'config').status).toBe('done')
    s.dispose()
  })

  it('config: is idempotent and changing the operator invalidates the operator-bound steps only', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    const before = await readFile(join(root, 'home', '.karmax', 'karmax.yaml'), 'utf8')
    await s.api.writeConfig({ operatorNumber: OPERATOR, waMode: 'dedicated' })
    expect(await readFile(join(root, 'home', '.karmax', 'karmax.yaml'), 'utf8')).toBe(before)
    s.dispose()
  })

  it('whatsapp: pairing failure sets a human error and can be retried', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    process.env.FAKE_WA_MODE = 'fail'
    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    await waitFor(() => stepOf(s, 'whatsapp').status === 'error')
    expect(stepOf(s, 'whatsapp').error).toMatch(/rejected the pairing request/)
    expect(s.getState().pairing?.running).toBe(false)
    expect(s.getState().pairing?.error).toMatch(/rejected/)
    process.env.FAKE_WA_MODE = 'ok'
    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    await waitFor(() => stepOf(s, 'whatsapp').status === 'done')
    s.dispose()
  })

  it('whatsapp: an existing session is recognised', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    process.env.FAKE_WA_MODE = 'existing'
    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    await waitFor(() => stepOf(s, 'whatsapp').status === 'done')
    expect(stepOf(s, 'whatsapp').detail).toMatch(/existing WhatsApp session/)
    s.dispose()
  })

  it('whatsapp: cancelPairing kills the login process and returns the step to todo', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    process.env.FAKE_WA_MODE = 'hang'
    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    await waitFor(() => s.getState().pairing?.code)
    await expect(s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })).rejects.toThrow(/already in progress/)
    await s.api.cancelPairing()
    await waitFor(() => s.getState().pairing?.running === false)
    expect(stepOf(s, 'whatsapp').status).toBe('todo')
    expect(stepOf(s, 'whatsapp').error).toBeUndefined()
    s.dispose()
  })

  it('whatsapp: validates the phone and stops our own wacli daemon before login', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    await expect(s.api.startPairing({ method: 'code', phone: 'abc' })).rejects.toThrow()
    procs = procs.map((p) => (p.name === 'wacli' ? { ...p, state: 'running', healthy: true } : p))
    world.wacliUp = true
    await s.api.startPairing({ method: 'code', phone: KARMAX_NUMBER })
    expect(procs.find((p) => p.name === 'wacli')?.state).toBe('stopped')
    await waitFor(() => stepOf(s, 'whatsapp').status === 'done')
    s.dispose()
  })

  it('services: reports which daemon failed to become healthy', async () => {
    const deps = makeDeps()
    deps.supervisor.waitHealthy = async (n) => n !== 'karmax'
    const s = createSetup(deps, hooks())
    await through(s, 'whatsapp')
    await expect(s.api.startServices()).rejects.toThrow(/KARMAX did not become healthy/)
    expect(stepOf(s, 'services').status).toBe('error')
    s.dispose()
  })

  it('operator: times out with the exact instruction and can be retried via startServices', async () => {
    const s = createSetup(makeDeps(), hooks({ operatorTimeoutMs: 120 }))
    await through(s, 'whatsapp')
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'error', 3000)
    expect(stepOf(s, 'operator').error).toMatch(/No message from \+919876543210 arrived/)
    expect(stepOf(s, 'operator').error).toMatch(/send "hi"/)
    world.chats.push({ jid: `${OPERATOR}@s.whatsapp.net`, name: 'Me', is_group: false, locked: true })
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    s.dispose()
  })

  it('operator: replaces a stale/secret-less webhook of ours but leaves foreign webhooks alone', async () => {
    world.chats.push({ jid: `${OPERATOR}@s.whatsapp.net`, name: 'Me', is_group: false, locked: true })
    world.webhooks.push({ id: 90, url: 'http://127.0.0.1:9090/comms/whatsapp', events: ['incoming_message'], scope: 'all_unlocked', chat_jids: [], enabled: true })
    world.webhooks.push({ id: 91, url: 'https://example.com/other', events: ['incoming_message'], scope: 'all_unlocked', chat_jids: [], enabled: true })
    world.nextHook = 100
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'whatsapp')
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    expect(world.webhooks.map((w) => w.id).sort((a, b) => a - b)).toEqual([91, 100])
    s.dispose()
  })

  it('operator: a chat keyed by an @lid identity is found via wacli /resolve and BOTH ids go to WHATSAPP_OPERATOR_CHATS', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'whatsapp')
    world.chats.push({ jid: '229896700@lid', name: 'Me', is_group: false, locked: true })
    world.resolveMap[OPERATOR] = '229896700@lid'
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    expect(world.webhooks[0].chat_jids).toEqual(['229896700@lid'])
    const env = await readFile(join(root, 'home', '.karmax', '.env'), 'utf8')
    expect(readEnvValue(env, 'WHATSAPP_OPERATOR_CHATS')).toBe(`${OPERATOR},229896700`)
    s.dispose()
  })

  it('own mode: the self chat (account JID) is the operator chat, and the receive-only limitation is stated', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'whatsapp', 'own')
    world.chats.push({ jid: `${KARMAX_NUMBER}@s.whatsapp.net`, name: 'You', is_group: false, locked: true })
    await s.api.startServices()
    await waitFor(() => /Message yourself/.test(stepOf(s, 'operator').detail ?? '') || stepOf(s, 'operator').status === 'done')
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    expect(stepOf(s, 'operator').detail).toMatch(/ignores/)
    expect(logs.some((l) => l.level === 'warn' && /receive-only/.test(l.message))).toBe(true)
    s.dispose()
  })

  it('lockdown: locks a chat that appears unlocked mid-way and verifies', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'whatsapp')
    world.chats.push({ jid: `${OPERATOR}@s.whatsapp.net`, name: 'Me', is_group: false, locked: true })
    world.leakUnlockedChat = true
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    await s.api.applyOperatorLockdown()
    expect(world.chats.filter((c) => !c.locked).map((c) => c.jid)).toEqual([`${OPERATOR}@s.whatsapp.net`])
    expect(logs.some((l) => /locking them/.test(l.message))).toBe(true)
    s.dispose()
  })

  it('verify: a failed send leaves the wizard incomplete with an actionable message; success afterwards completes it', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'whatsapp')
    world.chats.push({ jid: `${OPERATOR}@s.whatsapp.net`, name: 'Me', is_group: false, locked: true })
    await s.api.startServices()
    await waitFor(() => stepOf(s, 'operator').status === 'done')
    await s.api.applyOperatorLockdown()

    world.toolBody = { tool: 'comms.send', ok: false, error: 'DND mode is off; automation is disabled' }
    await expect(s.api.sendTestMessage()).rejects.toThrow(/DND/)
    expect(s.getState().completed).toBe(false)
    world.toolBody = null
    world.toolStatus = 404
    world.toolBody = { error: 'unknown tool: comms.send' }
    await expect(s.api.sendTestMessage()).rejects.toThrow(/comms\.send is not in its tools/)
    world.toolStatus = 401
    await expect(s.api.sendTestMessage()).rejects.toThrow(/rejected the API token/)
    world.toolStatus = 200
    world.toolBody = null
    await s.api.sendTestMessage()
    expect(s.getState().completed).toBe(true)
    s.dispose()
  })

  it('reset clears setup.json only and never deletes the KARMAX or WhatsApp data', async () => {
    const s = createSetup(makeDeps(), hooks())
    await through(s, 'config')
    await mkdir(join(root, 'home', '.wacli'), { recursive: true })
    await writeFile(join(root, 'home', '.wacli', 'session.db'), 'session')
    await s.api.reset()
    const st = await s.api.state()
    expect(st.steps.filter((x) => x.status !== 'todo' && x.id !== 'model')).toEqual([])
    expect(await readFile(join(root, 'home', '.wacli', 'session.db'), 'utf8')).toBe('session')
    expect((await stat(join(root, 'home', '.karmax', 'karmax.yaml'))).size).toBeGreaterThan(0)
    expect((await stat(join(root, 'home', '.karmax', '.env'))).size).toBeGreaterThan(0)
    s.dispose()
  })
})
