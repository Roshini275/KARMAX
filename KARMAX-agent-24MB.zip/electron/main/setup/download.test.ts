import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { DownloadError, KARMAX_ASSET, downloadKarmax } from './download'

let dir: string
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), 'km-dl-'))
})
afterEach(async () => {
  await rm(dir, { recursive: true, force: true })
})

const zipBytes = Buffer.from('PK-fake-zip')
const sha = (b: Buffer) => createHash('sha256').update(b).digest('hex')

const fakeFetch = (opts: { sums?: string; zip?: Buffer; sumsStatus?: number }) => async (url: string) => {
  if (url.endsWith('checksums.txt')) return { ok: (opts.sumsStatus ?? 200) < 400, status: opts.sumsStatus ?? 200, text: async () => opts.sums ?? '', arrayBuffer: async () => new ArrayBuffer(0) }
  const z = opts.zip ?? zipBytes
  return { ok: true, status: 200, text: async () => '', arrayBuffer: async () => z.buffer.slice(z.byteOffset, z.byteOffset + z.byteLength) as ArrayBuffer }
}

describe('downloadKarmax (dev fallback)', () => {
  it('verifies the zip against checksums.txt and installs karmax.exe', async () => {
    const dest = join(dir, 'bin', 'karmax.exe')
    const extract = async (_zip: string, out: string) => {
      await writeFile(join(out, 'karmax.exe'), 'EXE-BYTES')
    }
    const r = await downloadKarmax(dest, { fetchImpl: fakeFetch({ sums: `${sha(zipBytes)}  ./${KARMAX_ASSET}\n` }), extract })
    expect(await readFile(dest, 'utf8')).toBe('EXE-BYTES')
    expect(r.sha256).toMatch(/^[0-9a-f]{64}$/)
  })

  it('discards a download whose digest does not match', async () => {
    await expect(downloadKarmax(join(dir, 'k.exe'), { fetchImpl: fakeFetch({ sums: `${'0'.repeat(64)}  ./${KARMAX_ASSET}\n` }), extract: async () => undefined })).rejects.toThrow(/integrity check/)
    await expect(readFile(join(dir, 'k.exe'))).rejects.toThrow()
  })

  it('refuses when the release has no checksum entry or GitHub errors', async () => {
    await expect(downloadKarmax(join(dir, 'k.exe'), { fetchImpl: fakeFetch({ sums: 'nothing here' }) })).rejects.toThrow(/cannot be verified/)
    await expect(downloadKarmax(join(dir, 'k.exe'), { fetchImpl: fakeFetch({ sumsStatus: 404 }) })).rejects.toThrow(DownloadError)
  })

  it('reports a network failure in plain words', async () => {
    const failing = async () => {
      throw new Error('getaddrinfo ENOTFOUND github.com')
    }
    await expect(downloadKarmax(join(dir, 'k.exe'), { fetchImpl: failing as never })).rejects.toThrow(/Could not reach GitHub/)
  })
})
