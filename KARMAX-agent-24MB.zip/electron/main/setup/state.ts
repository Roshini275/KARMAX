/**
 * Setup state machine + persistence (`<userData>/setup.json`).
 *
 * Steps run in a fixed order; a step may only run once every earlier step is `done` or `skipped`. Any step can be
 * re-run at any time (they are idempotent) and a failed step keeps its human-readable `error` until it is retried.
 *
 * `reset()` clears ONLY setup.json. It must never touch ~/.karmax (config, database, memory) or ~/.wacli (the
 * linked WhatsApp session): losing either would force the user to re-link their phone and lose their history.
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import type { PairingState, SetupState, SetupStep, SetupStepId, StepStatus, WaMode } from '../../../src/shared/ipc'

export const STEP_ORDER: SetupStepId[] = ['prereqs', 'model', 'binaries', 'config', 'whatsapp', 'services', 'operator', 'lockdown', 'verify']

export const STEP_TITLES: Record<SetupStepId, string> = {
  prereqs: 'Prerequisites',
  model: 'Model access',
  binaries: 'Install KARMAX',
  config: 'Operator number',
  whatsapp: 'Link WhatsApp',
  services: 'Start services',
  operator: 'Connect operator',
  lockdown: 'Lock down chats',
  verify: 'Test message'
}

/** Anything the UI shows verbatim: setup failures are always phrased for a person, never a stack trace. */
export class SetupError extends Error {
  constructor(
    message: string,
    /** Raw tool output / underlying error, logged (redacted) but never shown as the headline. */
    readonly raw?: string
  ) {
    super(message)
    this.name = 'SetupError'
  }
}

export interface PersistedSetup {
  version: 1
  steps: Partial<Record<SetupStepId, { status: StepStatus; detail?: string; error?: string }>>
  operatorNumber?: string
  waMode?: WaMode
  /** JID of the operator's chat once wacli has seen it (may be an @lid JID, not the phone JID). */
  operatorJid?: string
  /** Number of the WhatsApp account that was linked to wacli (the KARMAX number in dedicated mode). */
  linkedNumber?: string
  apiPort?: number
  webhookPort?: number
  modelAuth?: 'api-key' | 'claude-code'
}

const emptyPersisted = (): PersistedSetup => ({ version: 1, steps: {} })

export class SetupStore {
  private data: PersistedSetup = emptyPersisted()
  private pairing: PairingState | undefined
  private hasApiKey = false
  private writing: Promise<void> = Promise.resolve()

  constructor(
    private readonly file: string,
    private readonly onChange: (s: SetupState) => void
  ) {}

  async load(): Promise<void> {
    try {
      const raw = JSON.parse(await readFile(this.file, 'utf8')) as PersistedSetup
      if (raw && raw.version === 1 && typeof raw.steps === 'object') this.data = raw
    } catch {
      this.data = emptyPersisted()
    }
    // A step left `active` by a crash or a quit mid-run is not running any more.
    for (const id of STEP_ORDER) {
      const s = this.data.steps[id]
      if (s?.status === 'active') this.data.steps[id] = { status: 'todo' }
    }
  }

  meta(): Readonly<PersistedSetup> {
    return this.data
  }

  setMeta(patch: Partial<Omit<PersistedSetup, 'version' | 'steps'>>): void {
    this.data = { ...this.data, ...patch }
    this.commit()
  }

  setApiKeyPresent(v: boolean): void {
    if (this.hasApiKey === v) return
    this.hasApiKey = v
    this.commit(false)
  }

  setPairing(p: PairingState | undefined): void {
    this.pairing = p
    this.emit()
  }

  getPairing(): PairingState | undefined {
    return this.pairing
  }

  status(id: SetupStepId): StepStatus {
    return this.data.steps[id]?.status ?? 'todo'
  }

  step(id: SetupStepId): SetupStep {
    const s = this.data.steps[id]
    return { id, status: s?.status ?? 'todo', ...(s?.detail ? { detail: s.detail } : {}), ...(s?.error ? { error: s.error } : {}) }
  }

  private put(id: SetupStepId, status: StepStatus, detail?: string, error?: string): void {
    this.data.steps[id] = { status, ...(detail ? { detail } : {}), ...(error ? { error } : {}) }
    this.commit()
  }

  begin(id: SetupStepId, detail?: string): void {
    this.put(id, 'active', detail)
  }
  detail(id: SetupStepId, detail: string): void {
    const cur = this.data.steps[id]
    this.put(id, cur?.status ?? 'active', detail, cur?.error)
  }
  done(id: SetupStepId, detail?: string): void {
    this.put(id, 'done', detail)
  }
  skip(id: SetupStepId, detail: string): void {
    this.put(id, 'skipped', detail)
  }
  fail(id: SetupStepId, error: string, detail?: string): void {
    this.put(id, 'error', detail, error)
  }
  /** Back to `todo` (used when a later change invalidates a step, e.g. a different operator number). */
  invalidate(id: SetupStepId): void {
    this.put(id, 'todo')
  }

  /** Why `id` cannot run yet, or null. Skipped counts as satisfied: it means "passed with a warning". */
  blocker(id: SetupStepId): string | null {
    for (const prev of STEP_ORDER) {
      if (prev === id) return null
      const st = this.status(prev)
      if (st !== 'done' && st !== 'skipped') return `Finish "${STEP_TITLES[prev]}" first.`
    }
    return null
  }

  snapshot(): SetupState {
    const steps = STEP_ORDER.map((id) => this.step(id))
    return {
      completed: this.status('verify') === 'done' && STEP_ORDER.every((id) => this.status(id) === 'done' || this.status(id) === 'skipped'),
      steps,
      hasApiKey: this.hasApiKey,
      ...(this.data.modelAuth ? { modelAuth: this.data.modelAuth } : {}),
      ...(this.data.operatorNumber ? { operatorNumber: this.data.operatorNumber } : {}),
      ...(this.data.waMode ? { waMode: this.data.waMode } : {}),
      ...(this.pairing ? { pairing: this.pairing } : {})
    }
  }

  async reset(): Promise<void> {
    this.data = emptyPersisted()
    this.pairing = undefined
    this.commit()
    await this.flush()
  }

  private emit(): void {
    this.onChange(this.snapshot())
  }

  private commit(persist = true): void {
    if (persist) this.writing = this.writing.then(() => this.write()).catch(() => undefined)
    this.emit()
  }

  private async write(): Promise<void> {
    await mkdir(dirname(this.file), { recursive: true })
    const tmp = `${this.file}.tmp`
    await writeFile(tmp, JSON.stringify(this.data, null, 2), 'utf8')
    await rename(tmp, this.file)
  }

  /** Await pending writes (tests, shutdown). */
  flush(): Promise<void> {
    return this.writing
  }
}
