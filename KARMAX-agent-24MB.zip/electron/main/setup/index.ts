/**
 * A2 setup backend entry point. A1 imports `registerSetup` and wires `api` to the IPC.setupInvoke channel
 * ({ method, args } -> api[method](...args)); state changes are pushed on IPC.setupChanged by the store.
 */
import type { RegisterSetup } from '../contracts'
import { registerSetupImpl } from './service'

export const registerSetup: RegisterSetup = registerSetupImpl
export { createSetup } from './service'
