import { createHash } from 'node:crypto'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { ManifestError, installVerified, parseChecksums, parseManifest, readManifest, sha256File } from './manifest'

const sha = (b: Buffer | string) => createHash('sha256').update(b).digest('hex')
let dir: string
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), 'km-manifest-'))
})
afterEach(async () => {
  await rm(dir, { recursive: true, force: true })
})

const manifest = (k: string, w: string) => ({
  schema: 1,
  karmax: { version: '0.2.0', file: 'karmax.exe', sha256: k },
  wacli: { version: '1.4.0', file: 'wacli.exe', sha256: w }
})

describe('manifest parsing', () => {
  it('accepts the documented schema', () => {
    const m = parseManifest(JSON.stringify(manifest('a'.repeat(64), 'B'.repeat(64))))
    expect(m.karmax.file).toBe('karmax.exe')
  })
  it('rejects bad JSON, wrong schema, short digests and path traversal', () => {
    expect(() => parseManifest('{')).toThrow(ManifestError)
    expect(() => parseManifest(JSON.stringify({ ...manifest('a'.repeat(64), 'b'.repeat(64)), schema: 2 }))).toThrow(/invalid/)
    expect(() => parseManifest(JSON.stringify(manifest('abc', 'b'.repeat(64))))).toThrow(/sha256/)
    const evil = manifest('a'.repeat(64), 'b'.repeat(64))
    evil.karmax.file = '..\\..\\evil.exe'
    expect(() => parseManifest(JSON.stringify(evil))).toThrow(/bare file name/)
  })
  it('readManifest returns null when there is no bundle', async () => {
    expect(await readManifest(dir)).toBeNull()
    await writeFile(join(dir, 'manifest.json'), JSON.stringify(manifest('a'.repeat(64), 'b'.repeat(64))))
    expect((await readManifest(dir))?.wacli.version).toBe('1.4.0')
  })
})

describe('installVerified', () => {
  it('copies a file whose digest matches, then reports already-current', async () => {
    const src = join(dir, 'src.exe')
    const dest = join(dir, 'out', 'karmax.exe')
    await writeFile(src, 'hello karmax')
    expect(await installVerified(src, dest, sha('hello karmax'))).toBe('installed')
    expect(await readFile(dest, 'utf8')).toBe('hello karmax')
    expect(await installVerified(src, dest, sha('hello karmax').toUpperCase())).toBe('already-current')
  })
  it('refuses a tampered source and leaves nothing behind', async () => {
    const src = join(dir, 'src.exe')
    const dest = join(dir, 'karmax.exe')
    await writeFile(src, 'tampered')
    await expect(installVerified(src, dest, sha('original'))).rejects.toThrow(/integrity check/)
    await expect(readFile(dest)).rejects.toThrow()
    await expect(readFile(`${dest}.part`)).rejects.toThrow()
  })
  it('replaces a stale destination', async () => {
    const src = join(dir, 'src.exe')
    const dest = join(dir, 'karmax.exe')
    await writeFile(src, 'v2')
    await writeFile(dest, 'v1')
    expect(await installVerified(src, dest, sha('v2'))).toBe('installed')
    expect(await readFile(dest, 'utf8')).toBe('v2')
  })
  it('reports a missing source clearly', async () => {
    await expect(installVerified(join(dir, 'nope.exe'), join(dir, 'd.exe'), 'a'.repeat(64))).rejects.toThrow(/missing from the installer/)
  })
  it('sha256File matches node crypto', async () => {
    await writeFile(join(dir, 'f'), 'abc')
    expect(await sha256File(join(dir, 'f'))).toBe(sha('abc'))
  })
})

describe('checksums.txt', () => {
  it('parses sha256sum output', () => {
    const t = `${'a'.repeat(64)}  ./karmax_windows_amd64.zip\n${'b'.repeat(64)} *install.sh\nnot a line\n`
    const m = parseChecksums(t)
    expect(m.get('karmax_windows_amd64.zip')).toBe('a'.repeat(64))
    expect(m.get('install.sh')).toBe('b'.repeat(64))
    expect(m.size).toBe(2)
  })
})
