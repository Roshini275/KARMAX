import { describe, expect, it } from 'vitest'
import { LineSplitter, classifyLoginLine, explainLoginFailure, foldLoginLines, isQrBlockLine, isQrRowLine, parsePairingCode, qrRowsToSvgDataUri, stripAnsi } from './pairing'

// Transcript shape taken from wacli/main.go cmdLogin.
const PAIR_TRANSCRIPT = [
  'Pairing code: K4Q7-9XPM',
  'Open WhatsApp on your phone -> Linked Devices -> Link with phone number.',
  'Login successful.',
  'Syncing chats, messages, and contacts...',
  'Sync complete. Chats: 42, messages: 1300 (history sync observed)',
  'Start the daemon with: wacli daemon'
]

describe('pairing code parsing', () => {
  it('parses and normalises the code', () => {
    expect(parsePairingCode('Pairing code: K4Q7-9XPM')).toBe('K4Q7-9XPM')
    expect(parsePairingCode('Pairing code: k4q79xpm')).toBe('K4Q7-9XPM')
    expect(parsePairingCode('\u001b[32mPairing code: ABCD-1234\u001b[0m')).toBe('ABCD-1234')
    expect(parsePairingCode('Pairing code: ABC')).toBeUndefined()
    expect(parsePairingCode('Open WhatsApp on your phone')).toBeUndefined()
  })
})

describe('login line classification', () => {
  it('recognises the lines wacli prints', () => {
    expect(classifyLoginLine('Login successful.')).toEqual({ kind: 'success' })
    expect(classifyLoginLine('Session valid.')).toEqual({ kind: 'valid' })
    expect(classifyLoginLine('Existing session is stale. Clearing it and starting fresh.')).toEqual({ kind: 'stale' })
    expect(classifyLoginLine('QR code written to C:\\Users\\me\\.wacli\\qr.png')).toEqual({ kind: 'qr', path: 'C:\\Users\\me\\.wacli\\qr.png' })
    expect(classifyLoginLine('Syncing chats, messages, and contacts...')).toEqual({ kind: 'syncing' })
    expect(classifyLoginLine('login timed out; run `wacli login` again')).toEqual({ kind: 'timeout' })
    expect(classifyLoginLine('Open WhatsApp on your phone')).toEqual({ kind: 'other' })
  })
  it('folds a full transcript', () => {
    const p = foldLoginLines(PAIR_TRANSCRIPT)
    expect(p).toMatchObject({ code: 'K4Q7-9XPM', linked: true, syncing: true, synced: true, timedOut: false, existingSession: false })
  })
  it('folds an existing-session transcript', () => {
    const p = foldLoginLines(['Existing session found, verifying...', 'Session valid.', 'Syncing chats, messages, and contacts...'])
    expect(p).toMatchObject({ linked: true, existingSession: true })
    expect(p.code).toBeUndefined()
  })
  it('detects terminal QR block rows', () => {
    expect(isQrBlockLine('Scan this QR with WhatsApp -> Linked Devices.')).toBe(false)
    expect(isQrBlockLine('▀▀▀▄▄▄▀▀▀▄▄▄▀▀▀')).toBe(true)
  })
})

describe('LineSplitter', () => {
  it('reassembles lines split across chunks and handles \\r', () => {
    const s = new LineSplitter()
    expect(s.push('Pairing co')).toEqual([])
    expect(s.push('de: K4Q7-9XPM\nOpen Whats')).toEqual(['Pairing code: K4Q7-9XPM'])
    expect(s.push('App\r\nnext\r')).toEqual(['Open WhatsApp', 'next'])
    expect(s.push('tail')).toEqual([])
    expect(s.flush()).toEqual(['tail'])
  })
  it('strips ANSI and drops blank lines', () => {
    const s = new LineSplitter()
    expect(s.push('\u001b[1mhello\u001b[0m\n\n  \nworld\n')).toEqual(['hello', 'world'])
    expect(stripAnsi('\u001b[31mx\u001b[0m')).toBe('x')
  })
})

describe('explainLoginFailure', () => {
  it('maps known failures to human messages', () => {
    expect(explainLoginFailure(['login timed out; run `wacli login` again'], 1)).toMatch(/expired/)
    expect(explainLoginFailure(['pair phone: not on whatsapp'], 1)).toMatch(/rejected/)
    expect(explainLoginFailure(['boom'], 3)).toMatch(/exit 3/)
  })
})

describe('qrRowsToSvgDataUri', () => {
  // Encode a module grid the way wacli prints it (light quiet zone, half-block glyphs, trailing pad row), then decode it back.
  const encode = (grid: boolean[][]): string[] => {
    const q = 4
    const w = grid[0].length + q * 2
    const px = (y: number, x: number) => (y >= q && x >= q && y < grid.length + q && x < grid[0].length + q ? grid[y - q][x - q] : false)
    const rows: string[] = []
    const h = grid.length + q * 2
    for (let y = 0; y < h; y += 2) {
      let r = ''
      for (let x = 0; x < w; x++) {
        const top = px(y, x)
        const bottom = y + 1 < h ? px(y + 1, x) : false
        r += !top && !bottom ? '█' : top && bottom ? ' ' : top ? '▄' : '▀'
      }
      rows.push(r)
    }
    return rows
  }
  const decode = (uri: string): boolean[][] => {
    const svg = Buffer.from(uri.split(',')[1], 'base64').toString()
    const [w, h] = /viewBox="0 0 (\d+) (\d+)"/.exec(svg)!.slice(1).map(Number)
    const g = Array.from({ length: h }, () => Array<boolean>(w).fill(false))
    for (const m of svg.matchAll(/M(\d+) (\d+)h(\d+)/g)) for (let i = 0; i < +m[3]; i++) g[+m[2]][+m[1] + i] = true
    return g
  }

  it('round-trips a module grid, including the quiet zone', () => {
    const n = 25
    const grid = Array.from({ length: n }, (_, y) => Array.from({ length: n }, (_, x) => (x * 7 + y * 13 + x * y) % 3 === 0))
    const rows = encode(grid)
    const uri = qrRowsToSvgDataUri(rows)!
    expect(uri.startsWith('data:image/svg+xml;base64,')).toBe(true)
    const out = decode(uri)
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) expect(out[y + 4][x + 4]).toBe(grid[y][x])
    expect(out[0].every((v) => !v)).toBe(true)
  })

  it('recognises every kind of QR row, including ones with short glyph runs', () => {
    expect(isQrRowLine('████ ▄ █▄ ▄▄▄█▀▀▀▄▄▄██▄█ ▄ ▄█ █▀   ▄▄▄▄█ ▀█▀ ▄▄▄ ▄█ ▄ ▄██ ▄█▀█ █▀████')).toBe(true)
    expect(isQrRowLine('█'.repeat(69))).toBe(true)
    expect(isQrRowLine('Scan this QR with WhatsApp -> Linked Devices.')).toBe(false)
    expect(isQrRowLine('██ short ██')).toBe(false)
  })

  it('rejects things that are not a QR block', () => {
    expect(qrRowsToSvgDataUri([])).toBeUndefined()
    expect(qrRowsToSvgDataUri(Array(20).fill('█'.repeat(10)))).toBeUndefined()
    expect(qrRowsToSvgDataUri(Array(20).fill('█'.repeat(30)).concat(['██']))).toBeUndefined()
  })
})
