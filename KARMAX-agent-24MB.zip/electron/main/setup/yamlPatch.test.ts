import { parse } from 'yaml'
import { describe, expect, it } from 'vitest'
import { MINIMAL_KARMAX_YAML, OPERATOR_TOOLS, isPlaceholderCredential, patchKarmaxYaml, readKarmaxYaml } from './yamlPatch'

const WACLI = 'C:\\Users\\me\\AppData\\Local\\KARMAX\\wacli.exe'

/** What `karmax init` writes: config.defaultConfig() marshalled by yaml.v3 (no omitempty, so zero values are present). */
const INIT_OUTPUT = `karmax:
    version: "1"
    data_dir: ~/.karmax
    log_level: info
    log_format: pretty
    budget_usd_per_month: 0
database:
    url: ""
webhooks:
    enabled: true
    port: 9090
    host: 0.0.0.0
    public_url: ""
    routes: []
api:
    enabled: false
    port: 0
    host: ""
ai:
    default_provider: anthropic
    default_model: claude-opus-4.6
    providers:
        anthropic:
            api_key: \${ANTHROPIC_API_KEY}
mcps: []
comms:
    channels: []
agents:
    - id: hello-world
      name: Hello World Agent
      system_prompt: You are a friendly assistant.
      memory:
        enabled: true
        namespace: hello-world
        max_entries: 50
      triggers:
        run_on_start: true
loops: []
harness:
    enabled: false
    binary: ""
`

const EXAMPLE_WITH_DISCORD = `# my config
comms:
  channels:
    - id: "discord-main"
      type: "discord"
      agent_id: "karmax-agent"
      token: "YOUR_DISCORD_BOT_TOKEN"
    - id: "whatsapp-main"
      type: "whatsapp"
      agent_id: "karmax-agent"
      token: ""
      settings:
        wacli_path: "/path/to/wacli"          # Path to wacli binary
        target_chat: "YOUR_PHONE_NUMBER"       # Target number
agents:
  - id: "karmax-agent"
    name: "Mine"
    tools:
      - shell.exec
      - file.read
`

const run = (text: string, extra: Partial<Parameters<typeof patchKarmaxYaml>[1]> = {}) =>
  patchKarmaxYaml(text, { operatorDigits: '919876543210', wacliPath: WACLI, envHas: () => false, ...extra })

describe('patchKarmaxYaml on fresh `karmax init` output', () => {
  const r = run(INIT_OUTPUT, { fresh: true })
  const cfg = parse(r.text)

  it('enables the API and harness and binds loopback only', () => {
    expect(cfg.api).toEqual({ enabled: true, port: 9091, host: '127.0.0.1' })
    expect(cfg.webhooks).toMatchObject({ enabled: true, port: 9090, host: '127.0.0.1' })
    expect(cfg.harness.enabled).toBe(true)
    expect(r.apiPort).toBe(9091)
    expect(r.webhookPort).toBe(9090)
  })

  it('replaces the toy sample agent with the operator agent and its tools', () => {
    expect(cfg.agents).toHaveLength(1)
    expect(cfg.agents[0].id).toBe('karmax-agent')
    expect(cfg.agents[0].tools).toEqual(OPERATOR_TOOLS)
    expect(cfg.agents[0].system_prompt).toContain('claude_code.call')
    expect(cfg.agents[0].memory.namespace).toBe('karmax-agent')
    expect(r.agentId).toBe('karmax-agent')
  })

  it('creates the whatsapp channel with the number as a STRING and the wacli path intact', () => {
    expect(cfg.comms.channels).toHaveLength(1)
    const ch = cfg.comms.channels[0]
    expect(ch).toMatchObject({ id: 'whatsapp-main', type: 'whatsapp', agent_id: 'karmax-agent' })
    expect(ch.settings.target_chat).toBe('919876543210')
    expect(typeof ch.settings.target_chat).toBe('string')
    expect(ch.settings.wacli_path).toBe(WACLI)
    expect(r.text).toMatch(/target_chat: "919876543210"/)
  })

  it('is idempotent', () => {
    const again = run(r.text, { fresh: false })
    expect(again.text).toBe(r.text)
    expect(again.changes).toEqual([])
  })
})

describe('patchKarmaxYaml on an existing hand-written config', () => {
  const r = run(EXAMPLE_WITH_DISCORD)
  const cfg = parse(r.text)

  it('removes the discord placeholder channel and keeps whatsapp', () => {
    expect(cfg.comms.channels.map((c: { id: string }) => c.id)).toEqual(['whatsapp-main'])
    expect(r.changes.join('\n')).toMatch(/removed "discord-main"/)
  })

  it('updates only the whatsapp settings and preserves comments and other settings', () => {
    expect(cfg.comms.channels[0].settings).toEqual({ wacli_path: WACLI, target_chat: '919876543210' })
    expect(r.text).toContain('# my config')
    expect(cfg.agents[0].name).toBe('Mine')
  })

  it('keeps the user agent, only adding comms.send', () => {
    expect(cfg.agents[0].id).toBe('karmax-agent')
    expect(cfg.agents[0].tools).toEqual(['shell.exec', 'file.read', 'comms.send'])
  })

  it('does not flip an explicit 0.0.0.0 on a non-fresh file, but warns', () => {
    const t = run('api:\n  enabled: true\n  host: 0.0.0.0\n  port: 9091\nwebhooks:\n  host: 0.0.0.0\n')
    const c = parse(t.text)
    expect(c.api.host).toBe('0.0.0.0')
    expect(t.warnings.join('\n')).toMatch(/api\.host/)
    expect(t.warnings.join('\n')).toMatch(/webhooks\.host/)
  })

  it('respects an explicit harness.enabled: false on a non-fresh file', () => {
    const t = run('harness:\n  enabled: false\n')
    expect(parse(t.text).harness.enabled).toBe(false)
    expect(t.warnings.join('\n')).toMatch(/harness\.enabled/)
  })

  it('keeps a discord channel that has a real token', () => {
    const t = run(`comms:\n  channels:\n    - id: d\n      type: discord\n      token: abc.def.ghi\n`)
    expect(parse(t.text).comms.channels.map((c: { id: string }) => c.id)).toEqual(['d', 'whatsapp-main'])
  })

  it('removes a channel whose ${VAR} token is unresolved but keeps it when the env has it', () => {
    const src = `comms:\n  channels:\n    - id: t\n      type: telegram\n      token: "\${TELEGRAM_BOT_TOKEN}"\n`
    expect(parse(run(src, { envHas: () => false }).text).comms.channels.map((c: { id: string }) => c.id)).toEqual(['whatsapp-main'])
    expect(parse(run(src, { envHas: (n) => n === 'TELEGRAM_BOT_TOKEN' }).text).comms.channels.map((c: { id: string }) => c.id)).toEqual(['t', 'whatsapp-main'])
  })

  it('recognises tool wildcards when checking for comms.send', () => {
    const t = run('agents:\n  - id: a\n    tools: ["comms.*"]\n')
    expect(parse(t.text).agents[0].tools).toEqual(['comms.*'])
  })
})

describe('patchKarmaxYaml edge cases', () => {
  it('builds a working config from an empty file', () => {
    const cfg = parse(run('').text)
    expect(cfg.api.enabled).toBe(true)
    expect(cfg.agents[0].id).toBe('karmax-agent')
    expect(cfg.comms.channels[0].type).toBe('whatsapp')
  })
  it('works on the minimal fallback template', () => {
    const cfg = parse(run(MINIMAL_KARMAX_YAML, { fresh: true }).text)
    expect(cfg.agents[0].id).toBe('karmax-agent')
    expect(cfg.webhooks.host).toBe('127.0.0.1')
  })
  it('rejects invalid YAML with a readable message', () => {
    expect(() => run('a: [1, 2\nb: {')).toThrow(/not valid YAML/)
  })
  it('rejects a non-mapping document', () => {
    expect(() => run('- a\n- b\n')).toThrow(/mapping/)
  })
})

describe('helpers', () => {
  it('isPlaceholderCredential', () => {
    expect(isPlaceholderCredential('')).toBe(true)
    expect(isPlaceholderCredential('YOUR_DISCORD_BOT_TOKEN')).toBe(true)
    expect(isPlaceholderCredential('${X}', () => false)).toBe(true)
    expect(isPlaceholderCredential('${X}', () => true)).toBe(false)
    expect(isPlaceholderCredential('realtoken')).toBe(false)
  })
  it('readKarmaxYaml extracts ports and the whatsapp channel', () => {
    const info = readKarmaxYaml(run(INIT_OUTPUT, { fresh: true }).text)
    expect(info).toMatchObject({ apiPort: 9091, webhookPort: 9090, targetChat: '919876543210', channelId: 'whatsapp-main', hasWhatsapp: true })
    expect(readKarmaxYaml('::: not yaml')).toMatchObject({ apiPort: 9091, hasWhatsapp: false })
  })
})
