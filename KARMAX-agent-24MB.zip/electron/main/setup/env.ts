/**
 * .env merge. KARMAX loads ~/.karmax/.env with godotenv (KARMAX/cmd/karmax/main.go loadDotEnv), which never
 * overrides variables that are already set in the process environment. We therefore edit the file in place:
 * every existing line, comment and blank stays byte-for-byte; only the keys we own are replaced or appended.
 */
import { randomBytes } from 'node:crypto'

const LINE_RE = /^(\s*)(export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)(\s*=\s*)(.*)$/

/** godotenv-safe rendering: bare when the value is boring, single-quoted (literal) when it has spaces/#/\ etc. */
export function formatEnvValue(value: string): string {
  if (value === '') return ''
  if (/^[A-Za-z0-9_@%+=:,./-]+$/.test(value)) return value
  if (!value.includes("'") && !/[\r\n]/.test(value)) return `'${value}'`
  return `"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, '\\n')}"`
}

function unquote(raw: string): string {
  const v = raw.trim()
  if (v.length >= 2 && v.startsWith("'") && v.endsWith("'")) return v.slice(1, -1)
  if (v.length >= 2 && v.startsWith('"') && v.endsWith('"')) {
    return v.slice(1, -1).replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\')
  }
  // Unquoted: an inline " #comment" is not part of the value.
  const hash = v.search(/\s#/)
  return (hash >= 0 ? v.slice(0, hash) : v).trim()
}

/** Values that ship in .env.example and mean "not filled in yet". */
export function isPlaceholder(value: string | undefined): boolean {
  if (value === undefined) return true
  const v = value.trim()
  if (v === '') return true
  return /^your[_-].*[_-]here$/i.test(v) || /^YOUR_[A-Z_]+$/.test(v) || v === 'changeme'
}

export function readEnvValue(text: string, key: string): string | undefined {
  let found: string | undefined
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*#/.test(line)) continue
    const m = LINE_RE.exec(line)
    if (m && m[3] === key) found = unquote(m[5]) // last assignment wins, like godotenv
  }
  return found
}

export interface MergeResult {
  text: string
  /** Keys whose value was written (added or replaced). */
  changed: string[]
  /** Keys left alone because `keepExisting` matched a real value. */
  kept: string[]
}

export interface MergeOptions {
  /** Keys that must not be overwritten when the file already has a real (non-placeholder) value. */
  keepExisting?: string[]
}

/**
 * Set `updates` in `text`. Existing assignments are replaced in place (same position, same `export` prefix);
 * missing keys are appended under a single marker comment. Line endings (LF/CRLF) are preserved.
 */
export function mergeEnv(text: string, updates: Record<string, string>, opts: MergeOptions = {}): MergeResult {
  const eol = text.includes('\r\n') ? '\r\n' : '\n'
  const lines = text === '' ? [] : text.split(/\r?\n/)
  // A trailing newline yields a final empty element; drop it and re-add at the end.
  const hadTrailingNewline = lines.length > 0 && lines[lines.length - 1] === ''
  if (hadTrailingNewline) lines.pop()

  const keep = new Set(opts.keepExisting ?? [])
  const changed: string[] = []
  const kept: string[] = []
  const pending = new Map(Object.entries(updates))

  for (const [key, value] of Object.entries(updates)) {
    let lastIdx = -1
    for (let i = 0; i < lines.length; i++) {
      if (/^\s*#/.test(lines[i])) continue
      const m = LINE_RE.exec(lines[i])
      if (m && m[3] === key) lastIdx = i
    }
    if (lastIdx < 0) continue
    const m = LINE_RE.exec(lines[lastIdx])!
    if (keep.has(key) && !isPlaceholder(unquote(m[5]))) {
      kept.push(key)
      pending.delete(key)
      continue
    }
    lines[lastIdx] = `${m[1]}${m[2] ?? ''}${key}=${formatEnvValue(value)}`
    changed.push(key)
    pending.delete(key)
  }

  if (pending.size > 0) {
    if (lines.length > 0 && lines[lines.length - 1].trim() !== '') lines.push('')
    lines.push('# --- Added by KARMAX Desktop setup ---')
    for (const [key, value] of pending) {
      lines.push(`${key}=${formatEnvValue(value)}`)
      changed.push(key)
    }
  }
  return { text: lines.join(eol) + eol, changed, kept }
}

/** 32 random bytes as hex: API bearer token and the wacli webhook HMAC secret. */
export function generateSecret(bytes = 32): string {
  return randomBytes(bytes).toString('hex')
}

/** "sk-ant-api03-abcdef...wxyz" -> "sk-ant-…wxyz". Safe for logs and the UI. */
export function maskSecret(value: string): string {
  const v = value.trim()
  if (v.length <= 8) return '••••'
  const prefix = v.startsWith('sk-ant-') ? 'sk-ant-' : ''
  return `${prefix}…${v.slice(-4)}`
}

/** Replace every known secret (and any Anthropic-key-shaped token) in free text before it reaches a log. */
export function redactSecrets(text: string, secrets: Iterable<string>): string {
  let out = text
  for (const s of secrets) if (s && s.length >= 8) out = out.split(s).join(maskSecret(s))
  return out.replace(/sk-ant-[A-Za-z0-9_-]{8,}/g, (m) => maskSecret(m))
}

/** The one sanity check the wizard promises: Anthropic keys start with `sk-ant-` and are not tiny. */
export function validateApiKey(input: string): { ok: true; key: string } | { ok: false; reason: string } {
  const key = String(input ?? '').trim()
  if (!key) return { ok: false, reason: 'Paste your Anthropic API key.' }
  if (/\s/.test(key)) return { ok: false, reason: 'The key must not contain spaces or line breaks.' }
  if (!key.startsWith('sk-ant-')) return { ok: false, reason: 'Anthropic API keys start with "sk-ant-".' }
  if (key.length < 24) return { ok: false, reason: 'That key looks too short.' }
  return { ok: true, key }
}
