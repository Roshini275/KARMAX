# Setup backend (`electron/main/setup`)

Implements `SetupApi` from `src/shared/ipc.ts` for the first-run wizard. Entry point: `registerSetup(deps)` in `index.ts`
(A1 wires `api` to `IPC.setupInvoke` and forwards `IPC.setupChanged`). State lives in `<userData>/setup.json`.
`reset()` clears **only** that file; it never touches `~/.karmax` or `~/.wacli`.

## Bundled binaries: `resources/bin/manifest.json` (CI contract)

The installer must ship these files under `resources/bin/` (electron-builder `extraResources`, see `paths.resourcesBin()`):

```
resources/bin/
  karmax.exe
  wacli.exe
  manifest.json
```

`manifest.json` (schema version 1; anything else is rejected):

```json
{
  "schema": 1,
  "karmax": { "version": "0.2.0", "file": "karmax.exe", "sha256": "<64 hex chars>" },
  "wacli":  { "version": "<wacli version or commit>", "file": "wacli.exe", "sha256": "<64 hex chars>" }
}
```

* `file` is a bare file name inside `resources/bin` (no separators; path traversal is rejected).
* `sha256` is the lowercase or uppercase hex SHA-256 of that file. Setup verifies it before copying into
  `%LOCALAPPDATA%\KARMAX` and verifies the copy again before the atomic rename.
* Example CI step (PowerShell):

  ```powershell
  $k = (Get-FileHash resources/bin/karmax.exe -Algorithm SHA256).Hash.ToLower()
  $w = (Get-FileHash resources/bin/wacli.exe  -Algorithm SHA256).Hash.ToLower()
  @{ schema = 1
     karmax = @{ version = $env:KARMAX_VERSION; file = 'karmax.exe'; sha256 = $k }
     wacli  = @{ version = $env:WACLI_VERSION;  file = 'wacli.exe';  sha256 = $w } } |
    ConvertTo-Json -Depth 4 | Set-Content resources/bin/manifest.json -Encoding utf8
  ```

### Where the binaries come from

* **karmax.exe**: the KARMAX release asset `karmax_windows_amd64.zip` (contains `karmax/karmax.exe`), verifiable against the
  release's `checksums.txt`.
* **wacli.exe**: **wacli publishes no Windows release.** CI has to build it (`windows-latest`, Go 1.25+, `CGO_ENABLED=1`
  with mingw for `mattn/go-sqlite3`, `go build -o wacli.exe .` from `github.com/MelloB1989/wacli`).

### Development fallback (no bundle)

Without `manifest.json` (dev builds) setup adopts binaries already present in the install dir. On Windows it will download and
checksum-verify `karmax.exe` from the KARMAX GitHub release; it can only *adopt* an existing/PATH `wacli.exe` and otherwise
fails with an explicit message. On other platforms it refuses (nothing useful can run).

## Step -> API mapping

| Step | `SetupApi` method | Notes |
|------|-------------------|-------|
| prereqs | `checkPrereqs()` | claude CLI, ports 9091/8765/9090. Missing claude = `skipped` (warning). Never throws for "not ok". |
| model | `saveModelKey(key)` | merges `~/.karmax/.env`: `ANTHROPIC_API_KEY`, `KARMAX_API_TOKEN`, `WHATSAPP_WEBHOOK_SECRET` (32 random bytes hex each; existing values kept) |
| binaries | `installBinaries()` | manifest + sha256 verification, idempotent |
| config | `writeConfig({operatorNumber, waMode})` | `karmax init` if needed, then Document-API patch of `karmax.yaml`, then `karmax config validate` |
| whatsapp | `startPairing()` / `cancelPairing()` | `wacli login --skip-access-config [--pair-code]` with `WACLI_PHONE`; must run before the wacli daemon |
| services | `startServices()` | supervisor start + health; then starts the **operator** step in the background |
| operator | (background, retry via `startServices()`) | waits for the operator's first message, then registers one signed webhook scoped to that chat |
| lockdown | `applyOperatorLockdown()` | `PUT /chats/access` (locks all, unlocks operator), DND on, re-reads `/chats` + `/status` |
| verify | `sendTestMessage()` | `POST /api/tools/comms.send` with the bearer token |

Every step also logs to `LogSink.app` with the prefix `[setup:<step>]` (secrets redacted, phone numbers masked), which the
wizard shows as the per-step activity log.

## Operator modes (verified against KARMAX and wacli sources)

* `dedicated`: wacli is linked to a separate KARMAX number; the human messages it. Fully two-way.
* `own`: wacli is linked to the operator's own account ("Message yourself"). KARMAX ignores `outgoing_message` events
  (`internal/comms/whatsapp/whatsapp.go` routeEvent), and messages typed on the phone into that chat are `IsFromMe`, so KARMAX can
  send updates there but does not receive tasks from it.

## Tests

`npx vitest run electron/main/setup` (POSIX; the end-to-end test in `service.test.ts` uses shell-script fakes of karmax/wacli).
