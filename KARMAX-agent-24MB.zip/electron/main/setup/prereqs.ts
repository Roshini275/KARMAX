/**
 * Prerequisite probes: OS, Claude Code CLI, and the three local ports. Everything is best-effort and never throws;
 * anything we cannot prove is reported as "unknown" (a warning), never as a failure.
 */
import { access } from 'node:fs/promises'
import { createServer, connect } from 'node:net'
import { arch, homedir, release, type } from 'node:os'
import { join } from 'node:path'
import type { PrereqReport } from '../../../src/shared/ipc'
import { runCapture, type CaptureResult } from './proc'

export const CLAUDE_INSTALL_URL = 'https://docs.claude.com/en/docs/claude-code/setup'

export function describeOs(platform: NodeJS.Platform = process.platform, rel: string = release(), architecture: string = arch(), osType: string = type()): string {
  if (platform === 'win32') {
    const build = Number(rel.split('.')[2] ?? 0)
    const name = build >= 22000 ? 'Windows 11' : 'Windows 10'
    return `${name} (build ${build || rel}, ${architecture})`
  }
  if (platform === 'darwin') return `macOS ${rel} (${architecture}) — development machine`
  return `${osType} ${rel} (${architecture}) — development machine`
}

export type ClaudeReport = PrereqReport['claudeCli']
type Runner = (cmd: string, args: string[], opts?: { timeoutMs?: number; shell?: boolean }) => Promise<CaptureResult>

/** Where Claude Code's installers put the binary when the GUI process PATH does not include it. */
export function claudeCandidates(platform: NodeJS.Platform = process.platform, home: string = homedir(), env: NodeJS.ProcessEnv = process.env): string[] {
  if (platform === 'win32') {
    const out = [join(home, '.local', 'bin', 'claude.exe')]
    if (env.APPDATA) out.push(join(env.APPDATA, 'npm', 'claude.cmd'))
    if (env.LOCALAPPDATA) out.push(join(env.LOCALAPPDATA, 'Programs', 'claude', 'claude.exe'))
    return out
  }
  return [join(home, '.local', 'bin', 'claude'), '/usr/local/bin/claude', join(home, '.claude', 'local', 'claude')]
}

const versionOf = (out: string) => /(\d+\.\d+\.\d+(?:[-+.\w]*)?)/.exec(out)?.[1]

export async function checkClaude(opts: { run?: Runner; platform?: NodeJS.Platform; home?: string; env?: NodeJS.ProcessEnv; fileExists?: (p: string) => Promise<boolean> } = {}): Promise<ClaudeReport> {
  const run: Runner = opts.run ?? ((c, a, o) => runCapture(c, a, o))
  const platform = opts.platform ?? process.platform
  const home = opts.home ?? homedir()
  const fileExists = opts.fileExists ?? (async (p) => access(p).then(() => true, () => false))
  const shell = platform === 'win32' // claude may be an npm .cmd shim; arguments here are fixed literals

  let cmd = 'claude'
  let res = await run(cmd, ['--version'], { timeoutMs: 10000, shell })
  if (res.spawnError || res.code !== 0) {
    for (const cand of claudeCandidates(platform, home, opts.env)) {
      if (!(await fileExists(cand))) continue
      const r = await run(cand, ['--version'], { timeoutMs: 10000, shell })
      if (!r.spawnError && r.code === 0) {
        cmd = cand
        res = r
        break
      }
    }
  }
  if (res.spawnError || res.code !== 0) {
    return { found: false, hint: `Install Claude Code (${CLAUDE_INSTALL_URL}), then run "claude" once and sign in. KARMAX hands coding work to it.` }
  }
  const version = versionOf(res.stdout + ' ' + res.stderr)

  // Sign-in state, best effort. `claude auth status` exists in current Claude Code releases; older ones do not have it,
  // in which case we fall back to the credentials file, and finally to "unknown" (never a hard failure).
  let loggedIn: boolean | undefined
  const st = await run(cmd, ['auth', 'status'], { timeoutMs: 10000, shell })
  if (!st.spawnError) {
    const text = `${st.stdout}\n${st.stderr}`
    try {
      const j = JSON.parse(st.stdout) as { loggedIn?: unknown }
      if (typeof j.loggedIn === 'boolean') loggedIn = j.loggedIn
    } catch {
      /* not JSON */
    }
    if (loggedIn === undefined && /not\s+logged\s+in|not\s+signed\s+in|no\s+active\s+session/i.test(text)) loggedIn = false
    if (loggedIn === undefined && st.code === 0 && /logged\s+in|signed\s+in/i.test(text)) loggedIn = true
  }
  if (loggedIn === undefined && (await fileExists(join(home, '.claude', '.credentials.json')))) loggedIn = true

  const hint =
    loggedIn === false
      ? 'Claude Code is installed but not signed in. Run "claude" in a terminal and sign in.'
      : loggedIn === undefined
        ? 'Could not verify that Claude Code is signed in. If delegated tasks fail, run "claude" once and sign in.'
        : undefined
  return { found: true, version, loggedIn, ...(hint ? { hint } : {}) }
}

// ── Ports ──────────────────────────────────────────────────────────────────

export type PortState = 'free' | 'busy' | 'blocked'

/** busy = something accepts connections; blocked = nothing listens but we cannot bind (Windows reserved ranges, policy). */
export async function probePort(port: number, host = '127.0.0.1'): Promise<PortState> {
  const inUse = await new Promise<boolean>((resolve) => {
    const s = connect({ port, host })
    const finish = (v: boolean) => {
      s.destroy()
      resolve(v)
    }
    s.setTimeout(800, () => finish(false))
    s.once('connect', () => finish(true))
    s.once('error', () => finish(false))
  })
  if (inUse) return 'busy'
  return new Promise<PortState>((resolve) => {
    const srv = createServer()
    srv.once('error', (e: NodeJS.ErrnoException) => resolve(e.code === 'EADDRINUSE' ? 'busy' : 'blocked'))
    srv.listen({ port, host }, () => srv.close(() => resolve('free')))
  })
}

async function getJson(url: string): Promise<unknown> {
  try {
    const r = await fetch(url, { signal: AbortSignal.timeout(1500) })
    return await r.json()
  } catch {
    return undefined
  }
}

/** Who answers on this port? Only the two programs we deliberately adopt are recognised. */
export async function identifyOccupant(kind: 'karmax' | 'wacli', port: number): Promise<'karmax' | 'wacli' | undefined> {
  if (kind === 'karmax') {
    const j = (await getJson(`http://127.0.0.1:${port}/api/ping`)) as { service?: string } | undefined
    return j?.service === 'karmax' ? 'karmax' : undefined
  }
  const j = (await getJson(`http://127.0.0.1:${port}/status`)) as Record<string, unknown> | undefined
  return j && typeof j === 'object' && 'dnd_mode' in j ? 'wacli' : undefined
}

export interface PortReport {
  report: PrereqReport['ports']
  adopted: { karmax: boolean; wacli: boolean }
}

export async function checkPorts(ports: { karmax: number; wacli: number; webhooks: number }): Promise<PortReport> {
  const [k, w, h] = await Promise.all([probePort(ports.karmax), probePort(ports.wacli), probePort(ports.webhooks)])
  const kOcc = k === 'busy' ? await identifyOccupant('karmax', ports.karmax) : undefined
  const wOcc = w === 'busy' ? await identifyOccupant('wacli', ports.wacli) : undefined
  const notes: string[] = []
  let free = true
  if (k === 'busy') {
    if (kOcc) notes.push(`KARMAX is already running on :${ports.karmax} (it will be adopted)`)
    else {
      free = false
      notes.push(`another program is using :${ports.karmax}`)
    }
  }
  if (w === 'busy') {
    if (wOcc) notes.push(`wacli is already running on :${ports.wacli} (it will be adopted)`)
    else {
      free = false
      notes.push(`another program is using :${ports.wacli}`)
    }
  }
  if (h === 'busy') {
    // The webhook server belongs to KARMAX: if KARMAX answers on its API port, it is the one holding this port.
    if (kOcc) notes.push(`webhook port :${ports.webhooks} is held by the running KARMAX`)
    else {
      free = false
      notes.push(`another program is using :${ports.webhooks}`)
    }
  }
  for (const [name, state, port] of [['KARMAX API', k, ports.karmax], ['wacli', w, ports.wacli], ['webhook', h, ports.webhooks]] as const) {
    if (state === 'blocked') {
      free = false
      notes.push(`Windows will not let apps listen on :${port} (${name}); it may be in a reserved range`)
    }
  }
  return {
    report: { karmax: ports.karmax, wacli: ports.wacli, webhooks: ports.webhooks, free, ...(notes.length ? { busyBy: notes.join('; ') } : {}) },
    adopted: { karmax: !!kOcc, wacli: !!wOcc }
  }
}

export async function runPrereqs(ports: { karmax: number; wacli: number; webhooks: number }): Promise<{ report: PrereqReport; adopted: PortReport['adopted'] }> {
  const [claudeCli, portInfo] = await Promise.all([checkClaude(), checkPorts(ports)])
  const os = describeOs()
  return { report: { os, claudeCli, ports: portInfo.report, ok: claudeCli.found && portInfo.report.free }, adopted: portInfo.adopted }
}
