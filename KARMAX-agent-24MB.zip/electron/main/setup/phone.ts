/**
 * Phone / JID helpers. WhatsApp identifies a person by digits only (E.164 without the "+"), so the wizard stores
 * and compares digits everywhere and never formats them for display in the main process.
 */

export const PHONE_MIN_DIGITS = 8
export const PHONE_MAX_DIGITS = 15 // E.164 upper bound

export type PhoneCheck = { ok: true; digits: string } | { ok: false; reason: string }

/** Strip everything but digits; an international "00" call prefix is dropped ("0091..." -> "91..."). */
export function normalizePhone(input: string): string {
  let d = String(input ?? '').replace(/[^\d]/g, '')
  if (d.startsWith('00')) d = d.slice(2)
  return d
}

/** 8-15 digits, starting with the country code (no national trunk "0"). */
export function validatePhone(input: string): PhoneCheck {
  const digits = normalizePhone(input)
  if (!digits) return { ok: false, reason: 'Enter a phone number.' }
  if (digits.startsWith('0')) return { ok: false, reason: 'Start with the country code, without a leading 0 or +.' }
  if (digits.length < PHONE_MIN_DIGITS) return { ok: false, reason: `Too short: ${PHONE_MIN_DIGITS}-${PHONE_MAX_DIGITS} digits including the country code.` }
  if (digits.length > PHONE_MAX_DIGITS) return { ok: false, reason: `Too long: ${PHONE_MIN_DIGITS}-${PHONE_MAX_DIGITS} digits including the country code.` }
  return { ok: true, digits }
}

/** "15551234567:12@s.whatsapp.net" -> "15551234567" (device suffix and server stripped). */
export function jidUser(jid: string): string {
  const s = String(jid ?? '').trim()
  const i = s.search(/[@:]/)
  return i >= 0 ? s.slice(0, i) : s
}

/** True when a chat JID belongs to this phone number (matches wacli / KARMAX `normalizeJID`, which compare bare digits). */
export function jidMatchesNumber(jid: string, digits: string): boolean {
  const u = jidUser(jid)
  return u !== '' && u === digits
}

/** Redact a phone number for logs: 919876543210 -> 91*******10. */
export function maskPhone(digits: string): string {
  if (digits.length <= 4) return '*'.repeat(digits.length)
  return `${digits.slice(0, 2)}${'*'.repeat(digits.length - 4)}${digits.slice(-2)}`
}
