/**
 * DEV FALLBACK ONLY: fetch karmax.exe from the KARMAX GitHub release when the installer did not bundle it
 * (resources/bin/manifest.json missing). The release publishes karmax_windows_amd64.zip plus checksums.txt
 * (KARMAX/.github/workflows/release.yml: `sha256sum ./* > checksums.txt`), so the download is verified before use.
 *
 * wacli publishes no Windows build at all, so there is intentionally NO equivalent for it here.
 */
import { createHash } from 'node:crypto'
import { copyFile, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { parseChecksums } from './manifest'
import { runCapture } from './proc'

export const KARMAX_RELEASE_BASE = 'https://github.com/MelloB1989/KARMAX/releases/latest/download'
export const KARMAX_ASSET = 'karmax_windows_amd64.zip'

export class DownloadError extends Error {}

type FetchLike = (url: string, init?: { signal?: AbortSignal }) => Promise<{ ok: boolean; status: number; text(): Promise<string>; arrayBuffer(): Promise<ArrayBuffer> }>

async function findFile(dir: string, name: string): Promise<string | undefined> {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, e.name)
    if (e.isDirectory()) {
      const r = await findFile(p, name)
      if (r) return r
    } else if (e.name.toLowerCase() === name.toLowerCase()) return p
  }
  return undefined
}

/** Windows 10+ ships bsdtar as tar.exe, which reads .zip; elsewhere use unzip. */
export async function extractZip(zip: string, dest: string): Promise<void> {
  const r = process.platform === 'win32' ? await runCapture('tar', ['-xf', zip, '-C', dest], { timeoutMs: 120000 }) : await runCapture('unzip', ['-o', '-q', zip, '-d', dest], { timeoutMs: 120000 })
  if (r.spawnError || r.code !== 0) throw new DownloadError(`Could not unpack the download (${(r.stderr || r.spawnError || 'unknown error').trim().slice(0, 200)})`)
}

export async function downloadKarmax(destExe: string, opts: { fetchImpl?: FetchLike; extract?: typeof extractZip; log?: (m: string) => void } = {}): Promise<{ sha256: string }> {
  const f: FetchLike = opts.fetchImpl ?? ((u, i) => fetch(u, { ...i, redirect: 'follow' }) as ReturnType<FetchLike>)
  const log = opts.log ?? (() => undefined)
  const extract = opts.extract ?? extractZip
  const tmp = await mkdtemp(join(tmpdir(), 'karmax-dl-'))
  try {
    log(`Downloading ${KARMAX_ASSET} checksums…`)
    const sums = await f(`${KARMAX_RELEASE_BASE}/checksums.txt`, { signal: AbortSignal.timeout(30000) }).catch((e: unknown) => {
      throw new DownloadError(`Could not reach GitHub (${e instanceof Error ? e.message : String(e)}). Check your internet connection.`)
    })
    if (!sums.ok) throw new DownloadError(`GitHub returned ${sums.status} for the KARMAX release checksums.`)
    const want = parseChecksums(await sums.text()).get(KARMAX_ASSET)
    if (!want) throw new DownloadError(`The KARMAX release has no checksum for ${KARMAX_ASSET}, so it cannot be verified.`)

    log(`Downloading ${KARMAX_ASSET}…`)
    const res = await f(`${KARMAX_RELEASE_BASE}/${KARMAX_ASSET}`, { signal: AbortSignal.timeout(300000) })
    if (!res.ok) throw new DownloadError(`GitHub returned ${res.status} for ${KARMAX_ASSET}.`)
    const buf = Buffer.from(await res.arrayBuffer())
    const got = createHash('sha256').update(buf).digest('hex')
    if (got !== want) throw new DownloadError(`The downloaded ${KARMAX_ASSET} failed its integrity check, so it was discarded.`)

    const zip = join(tmp, KARMAX_ASSET)
    await writeFile(zip, buf)
    const out = join(tmp, 'x')
    await mkdir(out)
    await extract(zip, out)
    const exe = await findFile(out, 'karmax.exe')
    if (!exe) throw new DownloadError('karmax.exe was not found inside the download.')
    const exeHash = createHash('sha256').update(await readFile(exe)).digest('hex')

    await mkdir(dirname(destExe), { recursive: true })
    const part = `${destExe}.part`
    await copyFile(exe, part)
    await rename(part, destExe)
    if (!(await stat(destExe)).size) throw new DownloadError('The installed karmax.exe is empty.')
    return { sha256: exeHash }
  } finally {
    await rm(tmp, { recursive: true, force: true })
  }
}
