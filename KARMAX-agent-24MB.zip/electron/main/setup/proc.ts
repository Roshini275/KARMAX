/** Small child-process helpers used by setup (prereq probes, `karmax init`, `wacli login`). Node-only; no Electron. */
import { execFile, spawn, type ChildProcess } from 'node:child_process'

export interface CaptureResult {
  code: number | null
  stdout: string
  stderr: string
  timedOut: boolean
  /** Set when the process could not be spawned at all (ENOENT etc.). */
  spawnError?: string
}

export interface CaptureOptions {
  env?: NodeJS.ProcessEnv
  cwd?: string
  timeoutMs?: number
  /** Windows npm shims (claude.cmd) need a shell; only ever used with fixed, non-user-supplied arguments. */
  shell?: boolean
  input?: string
}

/** Run a command to completion with a hard timeout. Never rejects. */
export function runCapture(cmd: string, args: string[], opts: CaptureOptions = {}): Promise<CaptureResult> {
  return new Promise((resolve) => {
    let settled = false
    const done = (r: CaptureResult) => {
      if (!settled) {
        settled = true
        resolve(r)
      }
    }
    try {
      const child = execFile(
        cmd,
        args,
        { env: opts.env ?? process.env, cwd: opts.cwd, timeout: opts.timeoutMs ?? 15000, windowsHide: true, shell: opts.shell, maxBuffer: 8 * 1024 * 1024 },
        (err, stdout, stderr) => {
          const e = err as (NodeJS.ErrnoException & { killed?: boolean; code?: number | string }) | null
          if (e && typeof e.code === 'string' && (e.code === 'ENOENT' || e.code === 'EACCES')) {
            return done({ code: null, stdout: String(stdout ?? ''), stderr: String(stderr ?? ''), timedOut: false, spawnError: e.message })
          }
          done({
            code: e ? (typeof e.code === 'number' ? e.code : 1) : 0,
            stdout: String(stdout ?? ''),
            stderr: String(stderr ?? ''),
            timedOut: !!e?.killed
          })
        }
      )
      if (opts.input !== undefined) child.stdin?.end(opts.input)
    } catch (e) {
      done({ code: null, stdout: '', stderr: '', timedOut: false, spawnError: e instanceof Error ? e.message : String(e) })
    }
  })
}

/** Last `n` non-empty lines of some output, for logs and error messages. */
export function tail(text: string, n = 12): string {
  return text
    .split(/\r?\n/)
    .map((l) => l.trimEnd())
    .filter(Boolean)
    .slice(-n)
    .join('\n')
}

/**
 * Kill a child AND its descendants. On Windows `child.kill()` only ends the parent, so `taskkill /T` is used;
 * on POSIX the child was spawned detached (own process group), so the whole group gets the signal.
 */
export function killTree(child: ChildProcess): void {
  const pid = child.pid
  if (!pid) return
  try {
    if (process.platform === 'win32') {
      execFile('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true }, () => undefined)
    } else {
      try {
        process.kill(-pid, 'SIGTERM')
      } catch {
        child.kill('SIGTERM')
      }
      setTimeout(() => {
        try {
          process.kill(-pid, 'SIGKILL')
        } catch {
          /* already gone */
        }
      }, 2500).unref()
    }
  } catch {
    /* already gone */
  }
}

/** Spawn a long-running child whose stdout+stderr are streamed as raw chunks. */
export function spawnStreaming(
  cmd: string,
  args: string[],
  opts: { env?: NodeJS.ProcessEnv; cwd?: string },
  onChunk: (chunk: string) => void
): { child: ChildProcess; exited: Promise<{ code: number | null; signal: NodeJS.Signals | null; error?: string }> } {
  const child = spawn(cmd, args, {
    env: opts.env ?? process.env,
    cwd: opts.cwd,
    windowsHide: true,
    detached: process.platform !== 'win32',
    stdio: ['ignore', 'pipe', 'pipe']
  })
  child.stdout?.setEncoding('utf8').on('data', onChunk)
  child.stderr?.setEncoding('utf8').on('data', onChunk)
  const exited = new Promise<{ code: number | null; signal: NodeJS.Signals | null; error?: string }>((resolve) => {
    child.once('error', (e) => resolve({ code: null, signal: null, error: e.message }))
    child.once('close', (code, signal) => resolve({ code, signal }))
  })
  return { child, exited }
}
