import { describe, expect, it } from 'vitest'
import { jidMatchesNumber, jidUser, maskPhone, normalizePhone, validatePhone } from './phone'

describe('phone validation', () => {
  it('normalises formatting to digits', () => {
    expect(normalizePhone('+91 98765-43210')).toBe('919876543210')
    expect(normalizePhone('(1) 555 123 4567')).toBe('15551234567')
    expect(normalizePhone('0091 9876543210')).toBe('919876543210')
  })

  it('accepts 8-15 digits starting with a country code', () => {
    expect(validatePhone('+91 98765 43210')).toEqual({ ok: true, digits: '919876543210' })
    expect(validatePhone('12345678').ok).toBe(true)
    expect(validatePhone('123456789012345').ok).toBe(true)
  })

  it('rejects empty, short, long and trunk-prefixed numbers', () => {
    expect(validatePhone('')).toMatchObject({ ok: false })
    expect(validatePhone('1234567')).toMatchObject({ ok: false, reason: expect.stringContaining('short') })
    expect(validatePhone('1234567890123456')).toMatchObject({ ok: false, reason: expect.stringContaining('long') })
    expect(validatePhone('09876543210')).toMatchObject({ ok: false, reason: expect.stringContaining('country code') })
    expect(validatePhone('abc')).toMatchObject({ ok: false })
  })
})

describe('jid helpers', () => {
  it('extracts the bare user from device/server suffixes', () => {
    expect(jidUser('15551234567@s.whatsapp.net')).toBe('15551234567')
    expect(jidUser('15551234567:12@s.whatsapp.net')).toBe('15551234567')
    expect(jidUser('229896700@lid')).toBe('229896700')
    expect(jidUser('15551234567')).toBe('15551234567')
  })
  it('matches a chat to a number by digits', () => {
    expect(jidMatchesNumber('15551234567@s.whatsapp.net', '15551234567')).toBe(true)
    expect(jidMatchesNumber('15551234568@s.whatsapp.net', '15551234567')).toBe(false)
    expect(jidMatchesNumber('', '')).toBe(false)
  })
  it('masks numbers for logs', () => {
    expect(maskPhone('919876543210')).toBe('91********10')
    expect(maskPhone('123')).toBe('***')
  })
})
