/**
 * karmax.yaml patcher. Uses the `yaml` package's Document API so comments, ordering and unrelated settings of an
 * existing file survive. Everything here is verified against the KARMAX sources:
 *
 *  - `karmax init` (cmd/karmax/runtime_cmd.go newInitCmd) is NON-interactive: it writes config.defaultConfig() to
 *    ~/.karmax/karmax.yaml. That struct is marshalled without omitempty, so unset fields appear as `0` / `""` / `[]`.
 *    Blank therefore means "absent" for every key we touch (config.applyDefaults fills them in at load time).
 *  - defaultConfig() leaves `api.enabled` false and `harness.enabled` false. runtime.go only starts the HTTP API when
 *    `cfg.API.Enabled` (~L1066) and `harness.send`/coding sessions fail with "the harness is not enabled" otherwise
 *    (runtime/harnesstools.go), so the desktop app cannot work unless both are switched on.
 *  - The channel is read as comms.channels[type=whatsapp].settings.{wacli_path,target_chat} (runtime.go ~L453). `settings`
 *    is map[string]string, so the phone number must be written as a quoted STRING, never a YAML integer.
 *  - Channels whose credentials are empty are skipped at runtime (`unconfiguredChannel`, runtime.go ~L1919), but a
 *    non-empty placeholder such as "YOUR_DISCORD_BOT_TOKEN" is NOT empty, so the daemon would try to log in with it.
 *    We drop such placeholder channels.
 *  - An agent only sees the tools listed in `tools` (agent.go allTools; api handleCallTool -> ExecuteTool), so the
 *    operator agent must list `comms.send` or the wizard's test message (POST /api/tools/comms.send) cannot work.
 */
import { isMap, isScalar, isSeq, parseDocument, type Document, type YAMLMap, type YAMLSeq } from 'yaml'

export const DEFAULT_API_PORT = 9091
export const DEFAULT_WEBHOOK_PORT = 9090
export const WHATSAPP_CHANNEL_ID = 'whatsapp-main'
export const OPERATOR_AGENT_ID = 'karmax-agent'

/** Tools the operator flow needs (all names verified in KARMAX/internal/tools/builtin). */
// task.* is what the desktop Tasks screen calls (POST /api/tools/task.*); an agent only answers tools listed here.
export const OPERATOR_TOOLS = ['comms.send', 'claude_code.call', 'memory.ingest', 'file.read', 'file.list', 'http.request', 'notify.send', 'task.create', 'task.list', 'task.update']

const OPERATOR_PROMPT = `You are KARMAX, an autonomous personal AI agent running on the operator's computer.
The operator sends you tasks over WhatsApp (channel "whatsapp-main") and from the KARMAX desktop app.

## How you work
- Answer simple questions directly.
- Delegate coding and multi-step work to Claude Code with the claude_code.call tool, and keep the session id so related follow-ups continue the same session.
- When a task arrives, acknowledge it in one short message. Send a brief progress update when something material changes and a final summary when it is done. Keep WhatsApp replies short and plain text.

## Safety
- Routine reading and analysis: act autonomously.
- Moderate actions (writing files, API calls): act, then tell the operator what you did.
- Dangerous or irreversible actions (deleting data, force-pushing, spending money, messaging other people): ask the operator first and wait for approval.
- When you are unsure, ask.

## Communication
Reply through comms.send. When answering a message, reply to the chat the message came from.`

export interface PatchInput {
  /** Operator number, digits only. Becomes settings.target_chat. */
  operatorDigits: string
  /** Absolute path to wacli(.exe). Becomes settings.wacli_path. */
  wacliPath: string
  /** The file was just created by `karmax init` (so 0.0.0.0 came from the generator, not from the user). */
  fresh?: boolean
  /** Is this environment variable available (in .env or the process)? Used to spot unresolved ${VAR} credentials. */
  envHas?: (name: string) => boolean
}

export interface PatchResult {
  text: string
  changes: string[]
  warnings: string[]
  apiPort: number
  webhookPort: number
  agentId: string
  channelId: string
}

export class YamlPatchError extends Error {}

const blank = (v: unknown): boolean => v === undefined || v === null || v === '' || v === 0

/** A credential that cannot work: empty, a YOUR_* placeholder, or a ${VAR} that resolves to nothing. */
export function isPlaceholderCredential(value: unknown, envHas: (name: string) => boolean = () => false): boolean {
  if (value === undefined || value === null) return true
  const v = String(value).trim()
  if (v === '') return true
  if (/^YOUR[_-]/i.test(v)) return true
  const ref = /^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$|^\$([A-Za-z_][A-Za-z0-9_]*)$/.exec(v)
  if (ref) return !envHas(ref[1] ?? ref[2])
  return false
}

function mapAt(doc: Document, path: (string | number)[]): YAMLMap | undefined {
  const n = doc.getIn(path, true)
  return isMap(n) ? n : undefined
}

function numAt(doc: Document, path: string[]): number {
  const v = doc.getIn(path)
  return typeof v === 'number' ? v : Number(v) || 0
}

function strAt(node: YAMLMap, key: string): string {
  const v = node.get(key)
  return v === undefined || v === null ? '' : String(v)
}

function toolMatches(patterns: string[], name: string): boolean {
  return patterns.some((p) => (p.endsWith('*') ? name.startsWith(p.slice(0, -1)) : p === name))
}

export function patchKarmaxYaml(text: string, input: PatchInput): PatchResult {
  const envHas = input.envHas ?? ((n) => !!process.env[n])
  const doc = parseDocument(text, { keepSourceTokens: false })
  if (doc.errors.length > 0) throw new YamlPatchError(`karmax.yaml is not valid YAML: ${doc.errors[0].message}`)
  if (doc.contents !== null && !isMap(doc.contents)) throw new YamlPatchError('karmax.yaml must be a YAML mapping at the top level')

  const changes: string[] = []
  const warnings: string[] = []
  const set = (path: string[], value: unknown, label: string) => {
    const before = doc.getIn(path)
    if (before === value) return
    doc.setIn(path, value)
    changes.push(label)
  }

  // ── Local cockpit: HTTP API on, loopback only ───────────────────────────
  set(['api', 'enabled'], true, 'api.enabled = true (the desktop app talks to this API)')
  if (blank(doc.getIn(['api', 'port']))) set(['api', 'port'], DEFAULT_API_PORT, `api.port = ${DEFAULT_API_PORT}`)
  const apiHost = doc.getIn(['api', 'host'])
  if (blank(apiHost) || (apiHost === '0.0.0.0' && input.fresh)) set(['api', 'host'], '127.0.0.1', 'api.host = 127.0.0.1 (local only)')
  else if (apiHost === '0.0.0.0') warnings.push('api.host is 0.0.0.0, so the KARMAX API is reachable from your network (it is protected by the bearer token).')

  set(['webhooks', 'enabled'], true, 'webhooks.enabled = true (wacli delivers WhatsApp messages here)')
  if (blank(doc.getIn(['webhooks', 'port']))) set(['webhooks', 'port'], DEFAULT_WEBHOOK_PORT, `webhooks.port = ${DEFAULT_WEBHOOK_PORT}`)
  const whHost = doc.getIn(['webhooks', 'host'])
  if (blank(whHost) || (whHost === '0.0.0.0' && input.fresh)) set(['webhooks', 'host'], '127.0.0.1', 'webhooks.host = 127.0.0.1 (local only)')
  else if (whHost === '0.0.0.0') warnings.push('webhooks.host is 0.0.0.0, so the WhatsApp webhook port is reachable from your network.')

  // ── Claude Code delegation ──────────────────────────────────────────────
  const harness = doc.getIn(['harness', 'enabled'])
  if (harness === undefined || harness === null) set(['harness', 'enabled'], true, 'harness.enabled = true (delegation to Claude Code)')
  else if (harness === false) {
    // A freshly generated file always says false (Go zero value); an explicit false in an older file is a decision.
    if (input.fresh) set(['harness', 'enabled'], true, 'harness.enabled = true (delegation to Claude Code)')
    else warnings.push('harness.enabled is false in your karmax.yaml, so KARMAX cannot delegate work to Claude Code. Set it to true to enable coding sessions.')
  }

  // ── Agent ───────────────────────────────────────────────────────────────
  let agents = doc.getIn(['agents'], true)
  if (!isSeq(agents)) {
    doc.setIn(['agents'], doc.createNode([]))
    agents = doc.getIn(['agents'], true)
  }
  const agentSeq = agents as YAMLSeq
  const first = agentSeq.items[0]
  const onlyDefaultSample =
    agentSeq.items.length === 1 && isMap(first) && strAt(first, 'id') === 'hello-world' && (first.get('tools') === undefined || (isSeq(first.get('tools')) && (first.get('tools') as YAMLSeq).items.length === 0))
  if (agentSeq.items.length === 0) {
    agentSeq.add(
      doc.createNode({
        id: OPERATOR_AGENT_ID,
        name: 'KARMAX Personal Agent',
        description: 'Autonomous personal agent that takes tasks from the operator and delegates coding work to Claude Code',
        system_prompt: OPERATOR_PROMPT,
        tools: OPERATOR_TOOLS,
        memory: { enabled: true, namespace: OPERATOR_AGENT_ID, max_entries: 1000 },
        restart_policy: 'always',
        triggers: { run_on_start: true }
      })
    )
    changes.push(`agents: added "${OPERATOR_AGENT_ID}"`)
  } else if (onlyDefaultSample) {
    // The sample agent that `karmax init` seeds has no tools at all and a toy prompt: it cannot act on operator tasks.
    const a = first as YAMLMap
    a.set('id', OPERATOR_AGENT_ID)
    a.set('name', 'KARMAX Personal Agent')
    a.set('description', 'Autonomous personal agent that takes tasks from the operator and delegates coding work to Claude Code')
    a.set('system_prompt', doc.createNode(OPERATOR_PROMPT))
    a.set('tools', doc.createNode(OPERATOR_TOOLS))
    a.set('max_tokens', 8192)
    a.set('restart_policy', 'always')
    const mem = a.get('memory')
    if (isMap(mem)) {
      mem.set('namespace', OPERATOR_AGENT_ID)
      mem.set('max_entries', 1000)
    }
    changes.push(`agents: replaced the sample "hello-world" agent with "${OPERATOR_AGENT_ID}" (operator prompt and tools)`)
  }

  const agentNode = agentSeq.items[0]
  if (!isMap(agentNode) || !strAt(agentNode, 'id')) throw new YamlPatchError('The first agent in karmax.yaml has no id.')
  const agentId = strAt(agentNode, 'id')
  // Whatever agent we bind must be able to send: the wizard's test message and every reply go through comms.send.
  if (!isSeq(agentNode.get('tools', true))) agentNode.set('tools', doc.createNode([]))
  const toolSeq = agentNode.get('tools', true)
  if (!isSeq(toolSeq)) throw new YamlPatchError('Could not read the agent tools list.')
  const listed = toolSeq.items.map((i) => (isScalar(i) ? String(i.value) : String(i)))
  if (!toolMatches(listed, 'comms.send')) {
    toolSeq.add(doc.createNode('comms.send'))
    changes.push(`agents.${agentId}.tools += comms.send`)
  }

  // ── Channels ────────────────────────────────────────────────────────────
  let channels = doc.getIn(['comms', 'channels'], true)
  if (!isSeq(channels)) {
    doc.setIn(['comms', 'channels'], doc.createNode([]))
    channels = doc.getIn(['comms', 'channels'], true)
  }
  const chSeq = channels as YAMLSeq

  // Drop channels that could only fail: placeholder credentials would make the daemon try to log in with garbage.
  for (let i = chSeq.items.length - 1; i >= 0; i--) {
    const c = chSeq.items[i]
    if (!isMap(c)) continue
    const type = strAt(c, 'type')
    const settings = c.get('settings')
    const token = strAt(c, 'token')
    let unusable = false
    if (type === 'discord' || type === 'telegram') unusable = isPlaceholderCredential(token, envHas)
    else if (type === 'slack') {
      const app = isMap(settings) ? strAt(settings, 'app_token') : ''
      unusable = isPlaceholderCredential(token || (envHas('SLACK_BOT_TOKEN') ? '${SLACK_BOT_TOKEN}' : ''), envHas) || isPlaceholderCredential(app || (envHas('SLACK_APP_TOKEN') ? '${SLACK_APP_TOKEN}' : ''), envHas)
    }
    if (unusable) {
      chSeq.delete(i)
      changes.push(`comms.channels: removed "${strAt(c, 'id') || type}" (${type} has no credentials)`)
    }
  }

  let wa = chSeq.items.find((c): c is YAMLMap => isMap(c) && strAt(c, 'type') === 'whatsapp')
  if (!wa) {
    wa = doc.createNode({ id: WHATSAPP_CHANNEL_ID, type: 'whatsapp', agent_id: agentId, token: '', settings: {} }) as YAMLMap
    chSeq.add(wa)
    changes.push(`comms.channels: added "${WHATSAPP_CHANNEL_ID}"`)
  }
  const validAgents = new Set(agentSeq.items.filter(isMap).map((a) => strAt(a, 'id')))
  if (!validAgents.has(strAt(wa, 'agent_id'))) {
    wa.set('agent_id', agentId)
    changes.push(`whatsapp channel agent_id = ${agentId}`)
  }
  if (!isMap(wa.get('settings', true))) wa.set('settings', doc.createNode({}))
  const st = wa.get('settings', true)
  if (!isMap(st)) throw new YamlPatchError('Could not read the whatsapp channel settings.')
  if (strAt(st, 'wacli_path') !== input.wacliPath) {
    st.set('wacli_path', input.wacliPath)
    changes.push('whatsapp settings.wacli_path')
  }
  if (strAt(st, 'target_chat') !== input.operatorDigits) {
    // A string on purpose: ChannelConfig.Settings is map[string]string.
    st.set('target_chat', doc.createNode(String(input.operatorDigits)))
    changes.push('whatsapp settings.target_chat')
  }
  const channelId = strAt(wa, 'id') || WHATSAPP_CHANNEL_ID

  // Nodes created into an originally-empty `[]` inherit flow style; block style is what a person would expect to read.
  chSeq.flow = false
  wa.flow = false
  st.flow = false
  agentSeq.flow = false
  toolSeq.flow = false

  const out = doc.toString({ lineWidth: 0 })
  return {
    text: out,
    changes,
    warnings,
    apiPort: numAt(doc, ['api', 'port']) || DEFAULT_API_PORT,
    webhookPort: numAt(doc, ['webhooks', 'port']) || DEFAULT_WEBHOOK_PORT,
    agentId: strAt(agentNode, 'id'),
    channelId
  }
}

/** Read the ports / whatsapp channel out of a yaml text without modifying it. Tolerates broken files (returns defaults). */
export function readKarmaxYaml(text: string): { apiPort: number; webhookPort: number; targetChat?: string; wacliPath?: string; channelId?: string; hasWhatsapp: boolean } {
  try {
    const doc = parseDocument(text)
    const ch = doc.getIn(['comms', 'channels'], true)
    let wa: YAMLMap | undefined
    if (isSeq(ch)) wa = ch.items.find((c): c is YAMLMap => isMap(c) && strAt(c, 'type') === 'whatsapp')
    const st = wa?.get('settings', true)
    return {
      apiPort: numAt(doc, ['api', 'port']) || DEFAULT_API_PORT,
      webhookPort: numAt(doc, ['webhooks', 'port']) || DEFAULT_WEBHOOK_PORT,
      targetChat: isMap(st) ? strAt(st, 'target_chat') || undefined : undefined,
      wacliPath: isMap(st) ? strAt(st, 'wacli_path') || undefined : undefined,
      channelId: wa ? strAt(wa, 'id') || undefined : undefined,
      hasWhatsapp: !!wa
    }
  } catch {
    return { apiPort: DEFAULT_API_PORT, webhookPort: DEFAULT_WEBHOOK_PORT, hasWhatsapp: false }
  }
}

/** Minimal equivalent of KARMAX config.defaultConfig(), used only when `karmax init` cannot be run against our data dir. */
export const MINIMAL_KARMAX_YAML = `karmax:
  version: "1"
  data_dir: ~/.karmax
  log_level: info
  log_format: pretty
webhooks:
  enabled: true
  port: 9090
  host: 0.0.0.0
ai:
  default_provider: anthropic
  default_model: claude-opus-4.6
  providers:
    anthropic:
      api_key: \${ANTHROPIC_API_KEY}
      base_url: \${ANTHROPIC_BASE_URL}
      auth_token: \${ANTHROPIC_AUTH_TOKEN}
agents:
  - id: hello-world
    name: Hello World Agent
    description: A sample agent that responds to greetings
    system_prompt: You are a friendly assistant. Respond helpfully and concisely.
    model: claude-opus-4.6
    provider: anthropic
    temperature: 0.7
    max_tokens: 1024
    memory:
      enabled: true
      namespace: hello-world
      max_entries: 50
    restart_policy: on-failure
    triggers:
      run_on_start: true
`
