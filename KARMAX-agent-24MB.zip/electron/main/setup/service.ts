/**
 * First-run setup backend. Implements SetupApi (src/shared/ipc.ts) on top of the SetupDeps that A1 provides.
 *
 * Steps run in this order: prereqs -> model -> binaries -> config -> whatsapp -> services -> operator -> lockdown -> verify
 * (see state.ts). SetupApi has no dedicated "operator" method, so the mapping is:
 *   checkPrereqs()          -> prereqs
 *   saveModelKey()          -> model
 *   installBinaries()       -> binaries
 *   writeConfig()           -> config
 *   startPairing()/cancelPairing() -> whatsapp (long running; resolves once the login process is spawned)
 *   startServices()         -> services, then the `operator` step starts in the BACKGROUND (it waits for the human's first
 *                              message, which can take minutes). Calling startServices() again retries a failed operator step.
 *   applyOperatorLockdown() -> lockdown
 *   sendTestMessage()       -> verify
 *
 * Operator-number semantics (verified in KARMAX/internal/comms/whatsapp/whatsapp.go routeEvent and wacli/wa/service.go
 * onLiveMessage):
 *   - KARMAX only routes `incoming_message` events to the agent; `outgoing_message` is "never routed as inbound" (L282-292).
 *   - wacli labels a message `outgoing_message` when IsFromMe, and only `incoming_message` requires DND on + an unlocked chat.
 *   - waMode 'dedicated': wacli is linked to a SEPARATE KARMAX number; the human messages it from their own phone. Those are
 *     `incoming_message` events in the chat named by the operator's number -> the whole loop works (commands in, updates out).
 *   - waMode 'own': wacli is linked to the OPERATOR's own account and the human "messages themselves". Messages typed on the
 *     phone in that chat are IsFromMe -> `outgoing_message` -> dropped by KARMAX. KARMAX can still SEND updates into that chat,
 *     but tasks typed there are not picked up by this KARMAX version. We set it up (webhook + lock) and say so honestly.
 *   In both modes the webhook is scoped `selected_chats` to exactly the operator's chat, and target_chat = the operator number.
 */
import { chmod, copyFile, mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises'
import { basename, dirname, join } from 'node:path'
import { IPC, type PairingState, type PrereqReport, type SetupApi, type SetupState, type SetupStepId, type WaMode } from '../../../src/shared/ipc'
import type { RegisterSetup, SetupDeps } from '../contracts'
import { KARMAX_ASSET, downloadKarmax } from './download'
import { generateSecret, isPlaceholder, maskSecret, mergeEnv, readEnvValue, redactSecrets, validateApiKey } from './env'
import { installVerified, exists, ManifestError, readManifest, sha256File } from './manifest'
import { LineSplitter, explainLoginFailure, foldLoginLines, isQrBlockLine, isQrRowLine, qrRowsToSvgDataUri, type LoginProgress } from './pairing'
import { jidUser, maskPhone, validatePhone } from './phone'
import { runPrereqs } from './prereqs'
import { killTree, runCapture, spawnStreaming, tail } from './proc'
import { STEP_TITLES, SetupError, SetupStore } from './state'
import { WacliError, createWacli, findOperatorChat, type Wacli } from './wacli'
import { DEFAULT_API_PORT, DEFAULT_WEBHOOK_PORT, MINIMAL_KARMAX_YAML, WHATSAPP_CHANNEL_ID, patchKarmaxYaml, readKarmaxYaml } from './yamlPatch'

const WACLI_DEFAULT_PORT = 8765

export interface SetupHooks {
  /** Poll interval while waiting for the operator's first message. */
  pollMs: number
  operatorTimeoutMs: number
  wacliHealthMs: number
  karmaxHealthMs: number
  /** Time allowed for the human to enter the pairing code before we give up and kill `wacli login`. */
  pairingTimeoutMs: number
  /** After "Login successful." wacli syncs chats; cap how long we wait for it to exit on its own. */
  syncCapMs: number
  fetchImpl: typeof fetch
  /** Verify an Anthropic key against the API; 'unknown' (offline etc.) never blocks setup. */
  verifyAnthropicKey: (key: string) => Promise<'valid' | 'invalid' | 'unknown'>
  runPrereqs: typeof runPrereqs
  platform: NodeJS.Platform
}

const defaultVerifyKey =
  (fetchImpl: typeof fetch) =>
  async (key: string): Promise<'valid' | 'invalid' | 'unknown'> => {
    try {
      const r = await fetchImpl('https://api.anthropic.com/v1/models?limit=1', { headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, signal: AbortSignal.timeout(6000) })
      if (r.status === 401 || r.status === 403) return 'invalid'
      return r.ok ? 'valid' : 'unknown'
    } catch {
      return 'unknown'
    }
  }

export function createSetup(deps: SetupDeps, override: Partial<SetupHooks> = {}): { api: SetupApi; getState(): SetupState; dispose(): void } {
  const fetchImpl = override.fetchImpl ?? fetch
  const hooks: SetupHooks = {
    pollMs: 3000,
    operatorTimeoutMs: 10 * 60_000,
    wacliHealthMs: 60_000,
    karmaxHealthMs: 120_000,
    pairingTimeoutMs: 4 * 60_000,
    syncCapMs: 4 * 60_000,
    fetchImpl,
    verifyAnthropicKey: defaultVerifyKey(fetchImpl),
    runPrereqs,
    platform: process.platform,
    ...override
  }
  const { paths, supervisor, daemon } = deps
  const store = new SetupStore(join(paths.userData(), 'setup.json'), (s) => deps.emit(IPC.setupChanged, s))
  const wacli: Wacli = createWacli(daemon)
  const secrets = new Set<string>()
  const running = new Set<SetupStepId>()
  let operatorAbort: AbortController | undefined
  let pairing: { child: ReturnType<typeof spawnStreaming>['child']; cancelled: boolean; timers: NodeJS.Timeout[] } | undefined
  let disposed = false

  // ── logging (never secrets, never raw phone numbers) ──────────────────────
  const log = (id: SetupStepId, level: 'debug' | 'info' | 'warn' | 'error', msg: string) => deps.log.app(level, `[setup:${id}] ${redactSecrets(msg, secrets)}`)
  const humanize = (e: unknown): { message: string; raw?: string } => {
    if (e instanceof SetupError) return { message: e.message, raw: e.raw }
    if (e instanceof ManifestError) return { message: e.message }
    if (e instanceof WacliError) return { message: e.status === 0 ? e.message : `wacli said: ${e.message}`, raw: e.message }
    const m = e instanceof Error ? e.message : String(e)
    return { message: m, raw: e instanceof Error ? e.stack : undefined }
  }

  // ── files ────────────────────────────────────────────────────────────────
  const readText = async (p: string): Promise<string> => readFile(p, 'utf8').catch((e: NodeJS.ErrnoException) => (e.code === 'ENOENT' ? '' : Promise.reject(e)))
  const writeAtomic = async (p: string, text: string, mode?: number) => {
    await mkdir(dirname(p), { recursive: true })
    const tmp = `${p}.tmp`
    await writeFile(tmp, text, { encoding: 'utf8', mode })
    await rename(tmp, p)
    if (mode !== undefined && process.platform !== 'win32') await chmod(p, mode).catch(() => undefined)
  }
  const readEnv = () => readText(paths.envFile())
  const writeEnv = (text: string) => writeAtomic(paths.envFile(), text, 0o600)
  const rememberSecrets = (envText: string) => {
    for (const k of ['ANTHROPIC_API_KEY', 'KARMAX_API_TOKEN', 'WHATSAPP_WEBHOOK_SECRET']) {
      const v = readEnvValue(envText, k)
      if (v && !isPlaceholder(v)) secrets.add(v)
    }
  }

  /**
   * `karmax init` and the CLI resolve ~/.karmax from the OS home directory. When our data dir is the standard
   * <home>/.karmax we point HOME/USERPROFILE at its parent so the CLI acts on exactly the directory we manage
   * (this is also what makes the backend testable); otherwise we set KARMAX_DATA_DIR.
   */
  const karmaxEnv = (): NodeJS.ProcessEnv => {
    const dataDir = paths.dataDir()
    if (basename(dataDir) === '.karmax') return { ...process.env, HOME: dirname(dataDir), USERPROFILE: dirname(dataDir) }
    return { ...process.env, KARMAX_DATA_DIR: dataDir }
  }

  const localPorts = async () => {
    const y = readKarmaxYaml(await readText(paths.yamlFile()))
    return { karmax: y.apiPort || DEFAULT_API_PORT, wacli: WACLI_DEFAULT_PORT, webhooks: y.webhookPort || DEFAULT_WEBHOOK_PORT }
  }

  // ── step runner ──────────────────────────────────────────────────────────
  type Outcome<T> = { value: T; status?: 'done' | 'skipped'; detail?: string }
  async function run<T>(id: SetupStepId, work: () => Promise<Outcome<T>>): Promise<T> {
    await ready
    const block = store.blocker(id)
    if (block) throw new SetupError(block)
    if (running.has(id)) throw new SetupError(`"${STEP_TITLES[id]}" is already running.`)
    running.add(id)
    store.begin(id)
    try {
      const out = await work()
      if (out.status === 'skipped') store.skip(id, out.detail ?? '')
      else store.done(id, out.detail)
      return out.value
    } catch (e) {
      const h = humanize(e)
      store.fail(id, h.message)
      log(id, 'error', h.message)
      if (h.raw) log(id, 'debug', tail(h.raw, 20))
      throw new SetupError(h.message, h.raw)
    } finally {
      running.delete(id)
    }
  }

  // ── derived facts (cheap re-checks so a resumed wizard never lies) ────────
  async function refreshDerived(): Promise<void> {
    const env = await readEnv()
    rememberSecrets(env)
    const key = readEnvValue(env, 'ANTHROPIC_API_KEY')
    store.setApiKeyPresent(!!key && !isPlaceholder(key))
    if (store.status('model') === 'done' && store.meta().modelAuth !== 'claude-code' && (!key || isPlaceholder(key))) store.invalidate('model')
    if (store.status('binaries') === 'done' && !((await exists(paths.karmaxExe())) && (await exists(paths.wacliExe())))) store.invalidate('binaries')
    if (store.status('config') === 'done') {
      const y = readKarmaxYaml(await readText(paths.yamlFile()))
      if (!y.hasWhatsapp || y.targetChat !== store.meta().operatorNumber) store.invalidate('config')
    }
  }
  const ready: Promise<void> = store
    .load()
    .then(refreshDerived)
    .catch(() => undefined)

  // ══ prereqs ═══════════════════════════════════════════════════════════════
  async function checkPrereqs(): Promise<PrereqReport> {
    await ready
    running.add('prereqs')
    store.begin('prereqs', 'Checking this computer…')
    try {
      const { report } = await hooks.runPrereqs(await localPorts())
      log('prereqs', 'info', `os=${report.os} claude=${report.claudeCli.found ? report.claudeCli.version ?? 'found' : 'missing'} loggedIn=${String(report.claudeCli.loggedIn)} ports.free=${report.ports.free}`)
      // Never throw from here: the UI needs the report itself. A blocking problem is an `error` step; a missing/unsigned
      // Claude Code CLI is `skipped` (passes with a warning) because the rest of setup does not depend on it.
      if (!report.ports.free) store.fail('prereqs', report.ports.busyBy ?? 'A required port is already in use.')
      else if (!report.claudeCli.found) store.skip('prereqs', 'Claude Code CLI not found. KARMAX cannot delegate coding tasks until it is installed.')
      else if (report.claudeCli.loggedIn === false) store.skip('prereqs', report.claudeCli.hint ?? 'Claude Code is not signed in.')
      else if (report.claudeCli.loggedIn === undefined) store.done('prereqs', 'Claude Code found. Could not verify that it is signed in.')
      else store.done('prereqs', `Claude Code ${report.claudeCli.version ?? ''} is installed and signed in.`.replace('  ', ' '))
      return report
    } catch (e) {
      const h = humanize(e)
      store.fail('prereqs', h.message)
      throw new SetupError(h.message)
    } finally {
      running.delete('prereqs')
    }
  }

  // ══ model ═════════════════════════════════════════════════════════════════
  async function saveModelKey(apiKey: string): Promise<void> {
    await run('model', async () => {
      const v = validateApiKey(apiKey)
      if (!v.ok) throw new SetupError(v.reason)
      secrets.add(v.key)
      const verdict = await hooks.verifyAnthropicKey(v.key)
      if (verdict === 'invalid') throw new SetupError('Anthropic rejected this API key. Check that you copied all of it and that it has not been revoked.')
      log('model', 'info', `key ${maskSecret(v.key)} (${verdict === 'valid' ? 'verified with Anthropic' : 'could not be verified online; saved anyway'})`)

      await writeModelEnv(v.key)
      store.setMeta({ modelAuth: 'api-key' })
      return { value: undefined, detail: `Key ${maskSecret(v.key)} saved locally. API token and webhook secret generated.` }
    })
  }

  // Claude Code as the only brain: KARMAX's chat and orchestrator run through the `claude` CLI harness on its own login,
  // so no Anthropic key is written. The local API token and webhook secret are still needed.
  async function saveModelClaudeCode(): Promise<void> {
    await run('model', async () => {
      await writeModelEnv(undefined)
      store.setMeta({ modelAuth: 'claude-code' })
      return { value: undefined, detail: 'Using your signed-in Claude Code. No API key needed. API token and webhook secret generated.' }
    })
  }

  async function writeModelEnv(apiKey: string | undefined): Promise<void> {
    let env = await readEnv()
    const updates: Record<string, string> = {
      // 32 random bytes: bearer token for the local KARMAX API, and the HMAC secret wacli signs webhook deliveries with.
      // KARMAX reads the secret from WHATSAPP_WEBHOOK_SECRET (KARMAX/internal/runtime/runtime.go L378).
      KARMAX_API_TOKEN: generateSecret(),
      WHATSAPP_WEBHOOK_SECRET: generateSecret()
    }
    if (apiKey) updates.ANTHROPIC_API_KEY = apiKey
    // .env.example placeholders would be sent as real credentials.
    for (const k of apiKey ? ['ANTHROPIC_AUTH_TOKEN'] : ['ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_API_KEY']) {
      const cur = readEnvValue(env, k)
      if (cur !== undefined && isPlaceholder(cur)) updates[k] = ''
    }
    const merged = mergeEnv(env, updates, { keepExisting: ['KARMAX_API_TOKEN', 'WHATSAPP_WEBHOOK_SECRET'] })
    env = merged.text
    await writeEnv(env)
    rememberSecrets(env)
    daemon.setToken(readEnvValue(env, 'KARMAX_API_TOKEN')!)
    const stored = readEnvValue(env, 'ANTHROPIC_API_KEY')
    store.setApiKeyPresent(!!stored && !isPlaceholder(stored))
    log('model', 'info', `.env updated (${merged.changed.join(', ') || 'no changes'}${merged.kept.length ? `; kept existing ${merged.kept.join(', ')}` : ''})`)
  }

  // ══ binaries ══════════════════════════════════════════════════════════════
  const NO_WACLI =
    'wacli.exe is not bundled with this build, and the wacli project publishes no Windows release. Use an installer that includes resources/bin/wacli.exe (see electron/main/setup/README.md), or build wacli for Windows and place it at the path shown in the log.'

  async function findOnPath(name: string): Promise<string | undefined> {
    const r = await runCapture(hooks.platform === 'win32' ? 'where' : 'which', [name], { timeoutMs: 5000 })
    const first = r.code === 0 ? r.stdout.split(/\r?\n/).find((l) => l.trim()) : undefined
    return first?.trim()
  }

  async function installBundled(name: 'karmax' | 'wacli', src: string, dest: string, sha: string): Promise<string> {
    try {
      return await installVerified(src, dest, sha)
    } catch (e) {
      if (!(e instanceof ManifestError) || !/in use/.test(e.message)) throw e
      const st = supervisor.status().find((s) => s.name === name)
      if (st && st.state === 'external') throw new SetupError(`${name} is running outside KARMAX Desktop and is using the file being updated. Quit it, then retry.`)
      log('binaries', 'info', `stopping ${name} to replace its executable`)
      await supervisor.stop(name)
      return installVerified(src, dest, sha)
    }
  }

  async function installBinaries(): Promise<void> {
    await run('binaries', async () => {
      const manifest = await readManifest(paths.resourcesBin())
      const kDest = paths.karmaxExe()
      const wDest = paths.wacliExe()
      let detail: string
      if (manifest) {
        const kOut = await installBundled('karmax', join(paths.resourcesBin(), manifest.karmax.file), kDest, manifest.karmax.sha256)
        const wOut = await installBundled('wacli', join(paths.resourcesBin(), manifest.wacli.file), wDest, manifest.wacli.sha256)
        log('binaries', 'info', `karmax ${manifest.karmax.version}: ${kOut}; wacli ${manifest.wacli.version}: ${wOut}`)
        detail = `karmax ${manifest.karmax.version} and wacli ${manifest.wacli.version} verified (sha256) and installed.`
      } else {
        // No bundle (dev build): adopt what is already installed, otherwise fall back honestly.
        log('binaries', 'warn', `no manifest at ${paths.resourcesBin()}; this is a development build`)
        if (!(await exists(kDest))) {
          if (hooks.platform !== 'win32') throw new SetupError('This development build has no bundled binaries (resources/bin/manifest.json is missing) and downloads only work on Windows.')
          store.detail('binaries', `Downloading ${KARMAX_ASSET} from GitHub…`)
          await downloadKarmax(kDest, { log: (m) => log('binaries', 'info', m) })
          log('binaries', 'info', 'karmax.exe downloaded and verified against the release checksums.txt')
        }
        if (!(await exists(wDest))) {
          const onPath = await findOnPath('wacli')
          if (!onPath) throw new SetupError(NO_WACLI, `expected ${wDest}`)
          log('binaries', 'warn', `no bundled wacli; using the one found on PATH (${onPath}) WITHOUT an integrity check`)
          await mkdir(dirname(wDest), { recursive: true })
          await copyFile(onPath, wDest)
        }
        detail = 'Using existing binaries (development build: no bundled manifest to verify against).'
      }
      // The exe must actually start: antivirus quarantine and missing runtimes surface here, not later as "service failed".
      const ver = await runCapture(kDest, ['--version'], { timeoutMs: 15000 })
      if (ver.spawnError) throw new SetupError(`karmax could not be started (${ver.spawnError}). Antivirus software may have blocked it.`)
      const v = /(\d+\.\d+\.\d+\S*)/.exec(ver.stdout + ver.stderr)?.[1]
      if (v) log('binaries', 'info', `karmax --version -> ${v}`)
      return { value: undefined, detail }
    })
  }

  // ══ config ════════════════════════════════════════════════════════════════
  async function writeConfig(input: { operatorNumber: string; waMode: WaMode }): Promise<void> {
    await run('config', async () => {
      const phone = validatePhone(input.operatorNumber)
      if (!phone.ok) throw new SetupError(phone.reason)
      if (input.waMode !== 'dedicated' && input.waMode !== 'own') throw new SetupError('Choose a dedicated KARMAX number or your own number.')
      const digits = phone.digits

      const yamlPath = paths.yamlFile()
      let fresh = false
      if (!(await exists(yamlPath))) {
        // `karmax init` is non-interactive (runtime_cmd.go newInitCmd): it writes the default config to ~/.karmax/karmax.yaml.
        const r = await runCapture(paths.karmaxExe(), ['init'], { env: karmaxEnv(), timeoutMs: 30000 })
        log('config', 'info', `karmax init -> exit ${String(r.code)}${r.spawnError ? ` (${r.spawnError})` : ''}`)
        if (r.code !== 0 || !(await exists(yamlPath))) {
          log('config', 'warn', `karmax init did not produce ${yamlPath}; writing the equivalent default config instead\n${tail(r.stdout + r.stderr)}`)
          await mkdir(dirname(yamlPath), { recursive: true })
          await writeAtomic(yamlPath, MINIMAL_KARMAX_YAML)
        }
        fresh = true
      }

      const envText = await readEnv()
      const original = await readText(yamlPath)
      const patched = patchKarmaxYaml(original, {
        operatorDigits: digits,
        wacliPath: paths.wacliExe(),
        fresh,
        envHas: (n) => !!process.env[n] || !!readEnvValue(envText, n)
      })
      if (patched.text !== original) {
        if (!fresh && !(await exists(`${yamlPath}.pre-setup`))) await writeAtomic(`${yamlPath}.pre-setup`, original)
        await writeAtomic(yamlPath, patched.text)
      }
      for (const c of patched.changes) log('config', 'info', `karmax.yaml: ${c}`)
      for (const w of patched.warnings) log('config', 'warn', w)

      // The monitor loop reads WHATSAPP_OPERATOR_CHATS WITHOUT the fallback to target_chat (runtime.go ~L489-501), so both
      // must be set. KARMAX_WACLI_PATH makes hostpaths.Wacli() find our bundled wacli.exe, which is not on PATH.
      const known = store.meta().operatorJid
      const operatorChats = [digits, ...(known && jidUser(known) !== digits ? [jidUser(known)] : [])].join(',')
      await writeEnv(mergeEnv(envText, { WHATSAPP_TARGET: digits, WHATSAPP_OPERATOR_CHATS: operatorChats, KARMAX_WACLI_PATH: paths.wacliExe() }).text)

      const val = await runCapture(paths.karmaxExe(), ['--config', yamlPath, 'config', 'validate'], { env: karmaxEnv(), timeoutMs: 30000 })
      log('config', 'debug', tail(val.stdout + val.stderr, 10))
      if (val.spawnError || val.code !== 0) {
        const out = tail(val.stdout + val.stderr, 6) || val.spawnError || 'no output'
        throw new SetupError(`karmax rejected the generated configuration:\n${out}`, val.stdout + val.stderr)
      }

      const prev = store.meta()
      if (prev.operatorNumber && prev.operatorNumber !== digits) {
        // A different operator invalidates everything that was bound to the old chat. wacli sessions are untouched.
        for (const id of ['operator', 'lockdown', 'verify'] as const) store.invalidate(id)
        store.setMeta({ operatorJid: undefined })
      }
      store.setMeta({ operatorNumber: digits, waMode: input.waMode, apiPort: patched.apiPort, webhookPort: patched.webhookPort })
      log('config', 'info', `operator ${maskPhone(digits)} (${input.waMode}) -> whatsapp channel "${patched.channelId}" bound to agent "${patched.agentId}"`)
      return { value: undefined, detail: `${patched.channelId} → ${maskPhone(digits)} (${input.waMode === 'dedicated' ? 'dedicated number' : 'own number'})` }
    })
  }

  // ══ whatsapp (wacli login) ════════════════════════════════════════════════
  const clearPairingTimers = () => {
    pairing?.timers.forEach((t) => clearTimeout(t))
    pairing?.timers.forEach((t) => clearInterval(t))
  }

  async function startPairing(input: { method: 'code' | 'qr'; phone?: string }): Promise<void> {
    await ready
    const block = store.blocker('whatsapp')
    if (block) throw new SetupError(block)
    if (pairing) throw new SetupError('WhatsApp pairing is already in progress.')

    const method = input.method
    let digits = ''
    if (method === 'code') {
      const p = validatePhone(input.phone ?? '')
      if (!p.ok) throw new SetupError(p.reason)
      digits = p.digits
    }
    if (!(await exists(paths.wacliExe()))) throw new SetupError('wacli is not installed yet. Finish "Install KARMAX" first.')

    // `wacli login` opens the WhatsApp session store directly, so no wacli daemon may be using it (wacli/main.go cmdLogin).
    const waSt = supervisor.status().find((s) => s.name === 'wacli')
    if (waSt && ['running', 'starting', 'backoff', 'crashed'].includes(waSt.state)) {
      log('whatsapp', 'info', 'stopping our wacli daemon before login')
      await supervisor.stop('wacli')
    } else if (waSt?.state === 'external') {
      const st = await wacli.status().catch(() => undefined)
      if (st?.connected) {
        store.done('whatsapp', `Using the wacli session that is already running${st.user_jid ? ` (${maskPhone(jidUser(st.user_jid))})` : ''}.`)
        log('whatsapp', 'info', 'adopted an already-connected external wacli; pairing skipped')
        return
      }
      throw new SetupError('A wacli daemon that KARMAX Desktop did not start is running. Stop it, then try again.')
    }

    store.begin('whatsapp', method === 'code' ? 'Requesting a pairing code…' : 'Waiting for the QR code…')
    const qrPath = join(paths.wacliHome(), 'qr.png')
    await mkdir(paths.wacliHome(), { recursive: true })
    await rm(qrPath, { force: true }) // stale QR would be shown as if it were current
    const args = ['login', '--skip-access-config', ...(method === 'code' ? ['--pair-code'] : [])]
    const env: NodeJS.ProcessEnv = { ...process.env, WACLI_HOME: paths.wacliHome(), ...(method === 'code' ? { WACLI_PHONE: digits } : {}) }
    log('whatsapp', 'info', `wacli ${args.join(' ')}${digits ? ` (phone ${maskPhone(digits)})` : ''}`)

    let progress: LoginProgress = { linked: false, existingSession: false, syncing: false, synced: false, timedOut: false }
    let expired = false // WE killed it because the code was never entered
    const lines: string[] = []
    const splitter = new LineSplitter()
    let qrMtime = 0
    let qrRows: string[] = []
    let state: PairingState = { running: true, method, lines }
    const publish = () => store.setPairing({ ...state, lines: [...lines] })
    const ingest = (chunk: string) => {
      const fresh = splitter.push(chunk)
      if (!fresh.length) return
      for (const l of fresh) {
        if (isQrRowLine(l) || isQrBlockLine(l)) {
          qrRows.push(l)
          continue
        }
        if (qrRows.length) {
          // The block is over: WhatsApp rotates the QR every ~20s, so each complete block replaces the last one.
          const uri = qrRowsToSvgDataUri(qrRows)
          qrRows = []
          if (uri) state = { ...state, qrDataUri: uri }
        }
        lines.push(l)
        log('whatsapp', 'info', l.replace(/([A-Z0-9]{4})-([A-Z0-9]{4})/, 'XXXX-XXXX'))
      }
      while (lines.length > 200) lines.shift()
      progress = foldLoginLines(fresh, progress)
      if (progress.code) state = { ...state, code: progress.code }
      if (progress.linked && !state.error) store.detail('whatsapp', progress.existingSession ? 'Existing WhatsApp session verified. Syncing chats…' : 'Linked. Syncing chats…')
      publish()
    }

    const { child, exited } = spawnStreaming(paths.wacliExe(), args, { env, cwd: paths.wacliHome() }, ingest)
    const session = { child, cancelled: false, timers: [] as NodeJS.Timeout[] }
    pairing = session
    publish()

    if (method === 'qr') {
      // `wacli login` only writes qr.png when `qrencode` is installed (main.go showQRCode); otherwise nothing appears.
      const t = setInterval(async () => {
        try {
          const st = await stat(qrPath)
          if (st.mtimeMs !== qrMtime) {
            qrMtime = st.mtimeMs
            const png = await readFile(qrPath)
            state = { ...state, qrDataUri: `data:image/png;base64,${png.toString('base64')}` }
            publish()
          }
        } catch {
          /* not written (yet) */
        }
      }, 1500)
      session.timers.push(t)
    }
    const expiry = setTimeout(() => {
      if (!progress.linked) {
        log('whatsapp', 'warn', 'pairing timed out; stopping wacli login')
        expired = true
        killTree(child)
      }
    }, hooks.pairingTimeoutMs)
    session.timers.push(expiry)

    void (async () => {
      // Once linked, wacli keeps syncing history for a while. The link itself is what matters: cap the wait.
      const watch = setInterval(() => {
        if (progress.linked) {
          clearInterval(watch)
          session.timers.push(setTimeout(() => killTree(child), hooks.syncCapMs))
        }
      }, 500)
      session.timers.push(watch)
      const exit = await exited
      for (const l of splitter.flush()) lines.push(l)
      progress = foldLoginLines(lines, { linked: false, existingSession: false, syncing: false, synced: false, timedOut: false })
      clearPairingTimers()
      pairing = undefined
      if (disposed) return
      if (session.cancelled) {
        state = { running: false, method, lines: [...lines] }
        store.setPairing(state)
        store.invalidate('whatsapp')
        log('whatsapp', 'info', 'pairing cancelled')
      } else if (progress.linked) {
        state = { running: false, method, lines: [...lines] }
        store.setPairing(state)
        if (digits) store.setMeta({ linkedNumber: digits })
        store.done('whatsapp', progress.existingSession ? 'An existing WhatsApp session was found and verified.' : digits ? `WhatsApp linked (${maskPhone(digits)}).` : 'WhatsApp linked.')
        log('whatsapp', 'info', 'linked')
      } else {
        const msg = expired || progress.timedOut ? 'The pairing code expired before it was entered on the phone. Start again to get a fresh code.' : exit.error ? `Could not start wacli (${exit.error}).` : explainLoginFailure(lines, exit.code)
        state = { running: false, method, lines: [...lines], error: msg }
        store.setPairing(state)
        store.fail('whatsapp', msg)
        log('whatsapp', 'error', msg)
      }
    })()
  }

  async function cancelPairing(): Promise<void> {
    if (!pairing) return
    pairing.cancelled = true
    killTree(pairing.child)
  }

  // ══ services (+ background operator) ═══════════════════════════════════════
  // The model step generates these, but .env can be deleted or replaced afterwards; regenerate rather than dead-end the wizard.
  async function ensureLocalSecrets(): Promise<string> {
    const env = await readEnv()
    const merged = mergeEnv(env, { KARMAX_API_TOKEN: generateSecret(), WHATSAPP_WEBHOOK_SECRET: generateSecret() }, { keepExisting: ['KARMAX_API_TOKEN', 'WHATSAPP_WEBHOOK_SECRET'] })
    if (merged.changed.length) {
      await writeEnv(merged.text)
      log('services', 'warn', `.env was missing ${merged.changed.join(', ')}; generated new values`)
    }
    rememberSecrets(merged.text)
    const token = readEnvValue(merged.text, 'KARMAX_API_TOKEN')!
    if (daemon.getToken() !== token) daemon.setToken(token)
    return token
  }

  async function ensureTokenKnown(): Promise<string> {
    return ensureLocalSecrets()
  }

  async function startServices(): Promise<void> {
    await ready
    // Retry path: services already done, so this call only (re)starts the background operator step.
    if (store.status('services') === 'done' && store.status('operator') !== 'done' && !running.has('operator')) {
      const st = supervisor.status()
      // Only when both daemons are actually up (after an app restart they may not be): otherwise run the full step again.
      if (['karmax', 'wacli'].every((n) => st.find((s) => s.name === n)?.healthy)) {
        void runOperator()
        return
      }
    }
    await run('services', async () => {
      const ports = await localPorts()
      daemon.setPorts({ karmax: ports.karmax, wacli: ports.wacli })
      await ensureTokenKnown()
      const failed: string[] = []

      store.detail('services', 'Starting wacli…')
      await supervisor.start('wacli')
      if (!(await supervisor.waitHealthy('wacli', hooks.wacliHealthMs))) failed.push('wacli')
      else if (!(await wacli.status().then((s) => s.connected, () => false))) log('services', 'warn', 'wacli is up but reports it is not connected to WhatsApp yet')

      if (failed.length === 0) {
        store.detail('services', 'Starting KARMAX…')
        const k = supervisor.status().find((s) => s.name === 'karmax')
        // A running KARMAX that we own must be restarted to pick up the config we just wrote; an external one cannot be.
        if (k && k.state === 'running') await supervisor.restart('karmax')
        else await supervisor.start('karmax')
        if (!(await supervisor.waitHealthy('karmax', hooks.karmaxHealthMs))) failed.push('KARMAX')
      }
      if (failed.length) {
        const st = supervisor.status()
        const why = failed.map((n) => {
          const s = st.find((x) => x.name === (n === 'wacli' ? 'wacli' : 'karmax'))
          return `${n} did not become healthy${s?.lastExit ? ` (last exit ${String(s.lastExit.code ?? s.lastExit.signal)})` : ''}`
        })
        throw new SetupError(`${why.join('; ')}. Open the Logs page for the process output.`)
      }
      // Prove the token we generated is the one the running daemon accepts.
      const probe = await daemon.request({ target: 'karmax', method: 'GET', path: '/api/tools' })
      if (probe.status === 401) throw new SetupError('KARMAX rejected the API token. Restart KARMAX from Settings, or run "Model access" again.')
      if (!probe.ok) throw new SetupError(`KARMAX started but its API answered ${probe.status}.`)
      return { value: undefined, detail: 'wacli and KARMAX are running and healthy.' }
    })
    void runOperator()
  }

  // ══ operator (background) ═════════════════════════════════════════════════
  const sleep = (ms: number, signal: AbortSignal) =>
    new Promise<void>((resolve) => {
      const t = setTimeout(resolve, ms)
      signal.addEventListener('abort', () => (clearTimeout(t), resolve()), { once: true })
    })

  async function runOperator(): Promise<void> {
    if (running.has('operator')) return
    operatorAbort?.abort()
    const ac = new AbortController()
    operatorAbort = ac
    running.add('operator')
    const meta = store.meta()
    const digits = meta.operatorNumber
    const mode: WaMode = meta.waMode ?? 'dedicated'
    try {
      if (!digits) throw new SetupError('The operator number is not set. Finish "Operator number" first.')
      store.begin('operator', 'Checking WhatsApp…')
      await ensureLocalSecrets()
      const token = await readEnv().then((t) => readEnvValue(t, 'WHATSAPP_WEBHOOK_SECRET'))
      if (!token || isPlaceholder(token)) throw new SetupError('The webhook secret is missing from .env and could not be regenerated.')
      const webhookUrl = `http://127.0.0.1:${meta.webhookPort ?? DEFAULT_WEBHOOK_PORT}/comms/whatsapp`

      // Wait for wacli to know the operator's chat. wacli only learns a chat after the first message in it.
      const status = await wacli.status()
      const linked = status.user_jid ? jidUser(status.user_jid) : meta.linkedNumber
      const instruction =
        mode === 'dedicated'
          ? `Waiting for your first message. From +${digits}, send "hi" to the KARMAX number${linked ? ` (+${linked})` : ''} on WhatsApp.`
          : 'Waiting for your first message. On your phone, open WhatsApp, open "Message yourself" and send "hi".'
      store.begin('operator', instruction)
      log('operator', 'info', `waiting for a chat with ${maskPhone(digits)} (${mode})`)

      const deadline = Date.now() + hooks.operatorTimeoutMs
      let chat: { jid: string } | undefined
      while (!ac.signal.aborted && Date.now() < deadline) {
        const st = await wacli.status().catch(() => status)
        const all = await wacli.chats()
        chat = findOperatorChat(all, digits, mode, st)
        if (!chat) {
          const r = await wacli.resolveChat(digits).catch(() => undefined)
          if (r?.exists_in_chats && !all.find((c) => c.jid === r.jid)?.is_group) chat = { jid: r.jid }
        }
        if (chat) break
        await sleep(hooks.pollMs, ac.signal)
      }
      if (ac.signal.aborted) return
      if (!chat) throw new SetupError(`No message from ${'+' + digits} arrived within ${Math.round(hooks.operatorTimeoutMs / 60000)} minutes. ${instruction.replace('Waiting for your first message. ', '')} Then retry.`)
      log('operator', 'info', `operator chat found: ${maskPhone(jidUser(chat.jid))}`)
      store.setMeta({ operatorJid: chat.jid })

      // wacli starts every chat locked after login and refuses to subscribe a webhook to a locked chat. Unlock the operator
      // chat only; "Lock down chats" later re-locks everything else.
      await wacli.setLocked(chat.jid, false)
      log('operator', 'info', 'operator chat unlocked (all other chats stay locked)')

      // One webhook, scoped to the operator chat only, signed with the secret KARMAX verifies. Same shape KARMAX itself
      // builds in tools/builtin/monitor.go applyWebhook (both events, selected_chats) minus --include-mentions: this install
      // must not react to @-mentions from chats we just locked.
      const events = ['incoming_message', 'outgoing_message']
      const existing = (await wacli.webhooks()).filter((w) => w.url === webhookUrl)
      const wantChat = jidUser(chat.jid)
      const healthy =
        existing.length === 1 &&
        existing[0].enabled &&
        existing[0].secret === token &&
        existing[0].scope === 'selected_chats' &&
        (existing[0].chat_jids ?? []).length === 1 &&
        jidUser(existing[0].chat_jids![0]) === wantChat &&
        events.every((e) => existing[0].events.includes(e))
      let hookId = existing[0]?.id
      if (!healthy) {
        for (const w of existing) await wacli.deleteWebhook(w.id) // only OUR url; never touches other webhooks
        const created = await wacli.addWebhook({ url: webhookUrl, secret: token, events, scope: 'selected_chats', chatJids: [chat.jid], contextLimit: 12 })
        hookId = created.id
        log('operator', 'info', `webhook #${hookId} created -> ${webhookUrl} (selected_chats: operator only)`)
      } else log('operator', 'info', `webhook #${hookId} already correct`)

      // The chat may be keyed by an @lid identity whose digits differ from the phone number; KARMAX compares bare digits.
      const envText = await readEnv()
      const wanted = [digits, ...(wantChat !== digits ? [wantChat] : [])].join(',')
      if (readEnvValue(envText, 'WHATSAPP_OPERATOR_CHATS') !== wanted) {
        await writeEnv(mergeEnv(envText, { WHATSAPP_OPERATOR_CHATS: wanted }).text)
        const k = supervisor.status().find((s) => s.name === 'karmax')
        if (k && k.state === 'running') {
          log('operator', 'info', 'restarting KARMAX to load WHATSAPP_OPERATOR_CHATS')
          await supervisor.restart('karmax')
          await supervisor.waitHealthy('karmax', hooks.karmaxHealthMs)
        }
      }
      const note = mode === 'own' ? ' Note: messages you type to yourself reach KARMAX as "sent by you", which this KARMAX version ignores, so tasks must come from the app; KARMAX can still message you here.' : ''
      if (mode === 'own') log('operator', 'warn', 'own-number mode is receive-only for the operator (self-messages are outgoing_message events)')
      store.done('operator', `Webhook #${hookId} delivers only ${maskPhone(digits)} to KARMAX.${note}`)
    } catch (e) {
      if (ac.signal.aborted) return
      const h = humanize(e)
      store.fail('operator', h.message, store.step('operator').detail)
      log('operator', 'error', h.message)
      if (h.raw) log('operator', 'debug', tail(h.raw, 10))
    } finally {
      running.delete('operator')
    }
  }

  // ══ lockdown ══════════════════════════════════════════════════════════════
  async function applyOperatorLockdown(): Promise<void> {
    await run('lockdown', async () => {
      const meta = store.meta()
      const jid = meta.operatorJid
      if (!jid) throw new SetupError('The operator chat is not known yet. Finish "Connect operator" first.')

      // ConfigureInitialAccess locks EVERY chat and unlocks only what we list. It also flips wacli's
      // "initial access configured" flag, after which wacli auto-unlocks chats it discovers LATER. Those cannot reach KARMAX
      // (the webhook is scoped to the operator chat) but they are re-checked below and can be locked from the WhatsApp page.
      store.detail('lockdown', 'Locking every chat except the operator…')
      await wacli.configureAccess([jid])
      await wacli.setDnd(true)

      let unlocked: string[] = []
      for (let attempt = 0; attempt < 3; attempt++) {
        unlocked = (await wacli.chats('unlocked')).map((c) => c.jid)
        const extra = unlocked.filter((j) => j !== jid)
        if (extra.length === 0) break
        log('lockdown', 'warn', `${extra.length} chat(s) appeared unlocked meanwhile; locking them`)
        for (const j of extra) await wacli.setLocked(j, true)
      }
      const [status, dnd, all] = await Promise.all([wacli.status(), wacli.dnd(), wacli.chats()])
      const stillOpen = all.filter((c) => !c.locked && c.jid !== jid)
      if (!all.some((c) => c.jid === jid && !c.locked)) throw new SetupError('wacli did not unlock the operator chat.')
      if (stillOpen.length) throw new SetupError(`${stillOpen.length} other chat(s) are still unlocked in wacli.`)
      if (!dnd || !status.dnd_mode) throw new SetupError('wacli refused to turn Do Not Disturb on, so it will not send or deliver anything.')
      if (!status.connected) log('lockdown', 'warn', 'wacli reports it is not connected to WhatsApp right now')
      log('lockdown', 'info', `verified: ${all.length - 1} chats locked, operator unlocked, DND on`)
      return { value: undefined, detail: `Only ${maskPhone(jidUser(jid))} is unlocked. ${Math.max(0, all.length - 1)} other chats are locked. DND is on.` }
    })
  }

  // ══ verify ════════════════════════════════════════════════════════════════
  async function sendTestMessage(): Promise<void> {
    await run('verify', async () => {
      const meta = store.meta()
      const target = meta.operatorJid ?? meta.operatorNumber
      if (!target) throw new SetupError('The operator is not configured yet.')
      await ensureTokenKnown()
      const channelId = readKarmaxYaml(await readText(paths.yamlFile())).channelId ?? WHATSAPP_CHANNEL_ID
      const at = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      // POST /api/tools/comms.send (KARMAX/internal/api/server.go handleCallTool): HTTP 200 {ok:true,output} on success, or
      // HTTP 200 {ok:false,error} when the tool itself fails. Input schema: internal/tools/builtin/comms.go.
      const r = await daemon.request({
        target: 'karmax',
        method: 'POST',
        path: '/api/tools/comms.send',
        body: { channel_id: channelId, target, content: `KARMAX is online. This is the setup test message (${at}). Reply here any time to give me a task.` }
      })
      const b = (r.body && typeof r.body === 'object' ? r.body : {}) as { ok?: boolean; error?: string }
      if (r.status === 401) throw new SetupError('KARMAX rejected the API token. Restart KARMAX from Settings and try again.')
      if (r.status === 404) throw new SetupError('The KARMAX agent cannot send messages (comms.send is not in its tools). Run "Operator number" again to repair the configuration.', JSON.stringify(r.body))
      if (r.status === 0) throw new SetupError('Cannot reach KARMAX. Start the services and try again.')
      if (!r.ok || b.ok !== true) {
        const why = String(b.error ?? `HTTP ${r.status}`)
        const hint = /DND/i.test(why) ? ' Turn Do Not Disturb on in wacli.' : /locked/i.test(why) ? ' The operator chat is locked in wacli.' : ''
        throw new SetupError(`KARMAX could not send the message: ${why}${hint}`, why)
      }
      log('verify', 'info', `comms.send accepted (${channelId} -> ${maskPhone(jidUser(String(target)))})`)
      return { value: undefined, detail: `Test message sent at ${at}. Check your phone.` }
    })
  }

  // ══ reset ═════════════════════════════════════════════════════════════════
  async function reset(): Promise<void> {
    operatorAbort?.abort()
    if (pairing) {
      pairing.cancelled = true
      killTree(pairing.child)
    }
    // Clears ONLY <userData>/setup.json. NEVER delete ~/.karmax (config, database, memory) or ~/.wacli (the linked WhatsApp
    // session): re-linking a phone and losing history is not something a "restart the wizard" button may cause.
    await ready
    await store.reset()
    await refreshDerived()
    log('prereqs', 'info', 'setup state reset (config, data and the WhatsApp session were left untouched)')
  }

  const api: SetupApi = {
    state: async () => {
      await ready
      await refreshDerived().catch(() => undefined)
      return store.snapshot()
    },
    checkPrereqs,
    saveModelKey,
    saveModelClaudeCode,
    installBinaries,
    writeConfig,
    startServices,
    startPairing,
    cancelPairing,
    applyOperatorLockdown,
    sendTestMessage,
    reset
  }

  return {
    api,
    getState: () => store.snapshot(),
    dispose: () => {
      disposed = true
      operatorAbort?.abort()
      clearPairingTimers()
      if (pairing) killTree(pairing.child)
    }
  }
}

export const registerSetupImpl: RegisterSetup = (deps) => {
  const s = createSetup(deps)
  return { api: s.api, getState: s.getState }
}
