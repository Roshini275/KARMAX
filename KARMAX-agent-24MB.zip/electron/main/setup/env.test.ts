import { describe, expect, it } from 'vitest'
import { formatEnvValue, generateSecret, isPlaceholder, maskSecret, mergeEnv, readEnvValue, redactSecrets, validateApiKey } from './env'

const EXAMPLE = `# Anthropic-compatible gateway
ANTHROPIC_BASE_URL=http://localhost:9000
ANTHROPIC_AUTH_TOKEN=your_auth_token_here
ANTHROPIC_API_KEY=your_api_key_here

# WhatsApp chat
WHATSAPP_TARGET=

# ntfy
NTFY_TOPIC=my-topic # inline comment
`

describe('mergeEnv', () => {
  it('replaces placeholders in place and keeps comments, order and unrelated keys', () => {
    const r = mergeEnv(EXAMPLE, { ANTHROPIC_API_KEY: 'sk-ant-abc123', WHATSAPP_TARGET: '919876543210' })
    expect(r.changed).toEqual(['ANTHROPIC_API_KEY', 'WHATSAPP_TARGET'])
    const lines = r.text.split('\n')
    expect(lines[0]).toBe('# Anthropic-compatible gateway')
    expect(lines[1]).toBe('ANTHROPIC_BASE_URL=http://localhost:9000')
    expect(lines[3]).toBe('ANTHROPIC_API_KEY=sk-ant-abc123')
    expect(r.text).toContain('WHATSAPP_TARGET=919876543210')
    expect(r.text).toContain('NTFY_TOPIC=my-topic # inline comment')
    expect(r.text.endsWith('\n')).toBe(true)
  })

  it('appends missing keys under one marker and is idempotent', () => {
    const once = mergeEnv('FOO=1\n', { KARMAX_API_TOKEN: 'a'.repeat(64) })
    expect(once.text).toBe(`FOO=1\n\n# --- Added by KARMAX Desktop setup ---\nKARMAX_API_TOKEN=${'a'.repeat(64)}\n`)
    const twice = mergeEnv(once.text, { KARMAX_API_TOKEN: 'a'.repeat(64) })
    expect(twice.text).toBe(once.text)
  })

  it('keepExisting preserves a real value but overwrites a placeholder', () => {
    const real = mergeEnv('KARMAX_API_TOKEN=realtoken1234567890\n', { KARMAX_API_TOKEN: 'newtoken' }, { keepExisting: ['KARMAX_API_TOKEN'] })
    expect(real.kept).toEqual(['KARMAX_API_TOKEN'])
    expect(real.text).toContain('realtoken1234567890')
    const ph = mergeEnv('KARMAX_API_TOKEN=\n', { KARMAX_API_TOKEN: 'newtoken' }, { keepExisting: ['KARMAX_API_TOKEN'] })
    expect(ph.changed).toEqual(['KARMAX_API_TOKEN'])
  })

  it('preserves CRLF line endings and an export prefix', () => {
    const r = mergeEnv('export A=1\r\n# c\r\nB=2\r\n', { A: '9' })
    expect(r.text).toBe('export A=9\r\n# c\r\nB=2\r\n')
  })

  it('does not treat commented assignments as existing', () => {
    const r = mergeEnv('# ANTHROPIC_API_KEY=old\n', { ANTHROPIC_API_KEY: 'sk-ant-x' })
    expect(r.text).toContain('# ANTHROPIC_API_KEY=old')
    expect(r.text).toContain('\nANTHROPIC_API_KEY=sk-ant-x')
  })

  it('handles an empty file', () => {
    expect(mergeEnv('', { A: '1' }).text).toBe('# --- Added by KARMAX Desktop setup ---\nA=1\n')
  })

  it('quotes Windows paths literally so godotenv keeps the backslashes', () => {
    const p = 'C:\\Users\\Me\\AppData\\Local\\KARMAX\\wacli.exe'
    const r = mergeEnv('', { KARMAX_WACLI_PATH: p })
    expect(r.text).toContain(`KARMAX_WACLI_PATH='${p}'`)
    expect(readEnvValue(r.text, 'KARMAX_WACLI_PATH')).toBe(p)
  })
})

describe('env helpers', () => {
  it('reads values with quotes and inline comments; last assignment wins', () => {
    const t = 'A=1\nB="two words"\nC=x # note\nA=3\n#D=4\n'
    expect(readEnvValue(t, 'A')).toBe('3')
    expect(readEnvValue(t, 'B')).toBe('two words')
    expect(readEnvValue(t, 'C')).toBe('x')
    expect(readEnvValue(t, 'D')).toBeUndefined()
  })
  it('formats values safely', () => {
    expect(formatEnvValue('abc')).toBe('abc')
    expect(formatEnvValue('a b')).toBe("'a b'")
    expect(formatEnvValue("it's")).toBe('"it\'s"')
    expect(formatEnvValue('')).toBe('')
  })
  it('detects .env.example placeholders', () => {
    expect(isPlaceholder(undefined)).toBe(true)
    expect(isPlaceholder('')).toBe(true)
    expect(isPlaceholder('your_api_key_here')).toBe(true)
    expect(isPlaceholder('YOUR_ANTHROPIC_API_KEY')).toBe(true)
    expect(isPlaceholder('sk-ant-real')).toBe(false)
  })
  it('generates 32-byte hex secrets', () => {
    const a = generateSecret()
    expect(a).toMatch(/^[0-9a-f]{64}$/)
    expect(generateSecret()).not.toBe(a)
  })
  it('masks and redacts secrets', () => {
    expect(maskSecret('sk-ant-api03-supersecretvalue1234')).toBe('sk-ant-…1234')
    expect(maskSecret('short')).toBe('••••')
    const out = redactSecrets('token=abcdef0123456789 key=sk-ant-api03-zzzzzzzzzz', ['abcdef0123456789'])
    expect(out).not.toContain('abcdef0123456789')
    expect(out).not.toContain('api03-zzzz')
  })
  it('validates API keys', () => {
    expect(validateApiKey('  ')).toMatchObject({ ok: false })
    expect(validateApiKey('sk-openai-123456789012345678901234')).toMatchObject({ ok: false })
    expect(validateApiKey('sk-ant-short')).toMatchObject({ ok: false })
    expect(validateApiKey('sk-ant-api03-abcdefghijklmnopqrstuvwx')).toMatchObject({ ok: true })
    expect(validateApiKey('sk-ant-api03-abc def-ghijklmnopqrstuvwx')).toMatchObject({ ok: false })
  })
})
