/**
 * Thin client for the wacli local API (127.0.0.1:8765, no auth), going through the supervisor-owned DaemonApi so the
 * port override is respected. Endpoint shapes are verified against wacli/wa/api.go:
 *   GET  /status                {connected, user_jid, user_lid, dnd_mode, initial_access_configured, chat_count, ...}
 *   GET  /chats?filter&limit    {chats:[{jid,name,is_group,locked,...}]}
 *   PUT  /chats/access          {unlocked_jids:[...]}  -> locks EVERY chat, unlocks the listed ones, marks initial access configured
 *   PUT  /chats/<jid>           {locked:boolean}
 *   GET  /resolve?ref&kind=chat&best=1   {match:{jid,exists_in_chats,locked,...}} | 404 | 409 {candidates}
 *   GET|PUT /dnd                {enabled}
 *   GET|POST /webhooks, DELETE /webhooks/<id>
 */
import type { DaemonResponse } from '../../../src/shared/ipc'
import type { DaemonApi } from '../contracts'
import { jidUser } from './phone'

export class WacliError extends Error {
  constructor(
    message: string,
    readonly status: number
  ) {
    super(message)
    this.name = 'WacliError'
  }
}

export interface WaStatus {
  connected: boolean
  user_jid?: string
  user_lid?: string
  dnd_mode: boolean
  initial_access_configured: boolean
  chat_count?: number
}
export interface WaChat {
  jid: string
  name: string
  is_group: boolean
  locked: boolean
  last_message_preview?: string
}
export interface WaWebhook {
  id: number
  url: string
  secret?: string
  events: string[]
  scope: string
  chat_jids?: string[]
  enabled: boolean
}
export interface WaResolved {
  jid: string
  name?: string
  locked: boolean
  exists_in_chats: boolean
}

const obj = (v: unknown): Record<string, unknown> => (v && typeof v === 'object' ? (v as Record<string, unknown>) : {})

export function errorText(r: DaemonResponse): string {
  const b = obj(r.body)
  if (typeof b.error === 'string') return b.error
  if (typeof r.body === 'string' && r.body.trim()) return r.body.trim().slice(0, 300)
  return `HTTP ${r.status}`
}

export function createWacli(daemon: Pick<DaemonApi, 'request'>) {
  const call = async (method: string, path: string, opts: { query?: Record<string, string | number | boolean>; body?: unknown } = {}): Promise<DaemonResponse> =>
    daemon.request({ target: 'wacli', method, path, query: opts.query, body: opts.body })

  const must = async (method: string, path: string, opts: { query?: Record<string, string | number | boolean>; body?: unknown } = {}) => {
    const r = await call(method, path, opts)
    if (!r.ok) {
      if (r.status === 0) throw new WacliError('Cannot reach the wacli daemon. Is it running?', 0)
      throw new WacliError(errorText(r), r.status)
    }
    return obj(r.body)
  }

  return {
    async status(): Promise<WaStatus> {
      const b = await must('GET', '/status')
      return {
        connected: b.connected === true,
        user_jid: typeof b.user_jid === 'string' ? b.user_jid : undefined,
        user_lid: typeof b.user_lid === 'string' ? b.user_lid : undefined,
        dnd_mode: b.dnd_mode === true,
        initial_access_configured: b.initial_access_configured === true,
        chat_count: typeof b.chat_count === 'number' ? b.chat_count : undefined
      }
    },

    async chats(filter?: 'locked' | 'unlocked' | 'groups' | 'dms'): Promise<WaChat[]> {
      const b = await must('GET', '/chats', { query: { limit: 5000, ...(filter ? { filter } : {}) } })
      const list = Array.isArray(b.chats) ? b.chats : []
      return list.map((c) => {
        const o = obj(c)
        return { jid: String(o.jid ?? ''), name: String(o.name ?? ''), is_group: o.is_group === true, locked: o.locked === true, last_message_preview: typeof o.last_message_preview === 'string' ? o.last_message_preview : undefined }
      })
    },

    /** Resolve a phone/JID to a chat. Undefined when wacli has never seen it (404) or the reference is ambiguous (409). */
    async resolveChat(ref: string): Promise<WaResolved | undefined> {
      const r = await call('GET', '/resolve', { query: { ref, kind: 'chat', best: 1 } })
      if (r.status === 404 || r.status === 409) return undefined
      if (!r.ok) throw new WacliError(errorText(r), r.status)
      const m = obj(obj(r.body).match)
      if (typeof m.jid !== 'string' || !m.jid) return undefined
      return { jid: m.jid, name: typeof m.name === 'string' ? m.name : undefined, locked: m.locked === true, exists_in_chats: m.exists_in_chats === true }
    },

    async dnd(): Promise<boolean> {
      return (await must('GET', '/dnd')).enabled === true
    },
    async setDnd(enabled: boolean): Promise<void> {
      await must('PUT', '/dnd', { body: { enabled } })
    },

    /** Lock everything, unlock exactly `unlocked` (wacli ConfigureInitialAccess). */
    async configureAccess(unlocked: string[]): Promise<void> {
      await must('PUT', '/chats/access', { body: { unlocked_jids: unlocked } })
    },
    async setLocked(jid: string, locked: boolean): Promise<void> {
      await must('PUT', `/chats/${encodeURIComponent(jid)}`, { body: { locked } })
    },

    async webhooks(): Promise<WaWebhook[]> {
      const b = await must('GET', '/webhooks')
      const list = Array.isArray(b.webhooks) ? b.webhooks : []
      return list.map((w) => {
        const o = obj(w)
        return {
          id: Number(o.id ?? 0),
          url: String(o.url ?? ''),
          secret: typeof o.secret === 'string' ? o.secret : undefined,
          events: Array.isArray(o.events) ? o.events.map(String) : [],
          scope: String(o.scope ?? ''),
          chat_jids: Array.isArray(o.chat_jids) ? o.chat_jids.map(String) : [],
          enabled: o.enabled !== false
        }
      })
    },
    async addWebhook(input: { url: string; secret: string; events: string[]; scope: 'selected_chats'; chatJids: string[]; contextLimit?: number }): Promise<WaWebhook> {
      const b = await must('POST', '/webhooks', {
        body: { url: input.url, secret: input.secret, events: input.events, scope: input.scope, chat_jids: input.chatJids, ...(input.contextLimit ? { context_limit: input.contextLimit } : {}) }
      })
      const o = obj(b.webhook)
      return { id: Number(o.id ?? 0), url: String(o.url ?? input.url), events: input.events, scope: input.scope, chat_jids: input.chatJids, enabled: true }
    },
    async deleteWebhook(id: number): Promise<void> {
      await must('DELETE', `/webhooks/${id}`)
    }
  }
}

export type Wacli = ReturnType<typeof createWacli>

/**
 * Find the operator's chat among wacli's chats.
 *  - dedicated: the human messages the KARMAX number, so the chat is named by the OPERATOR's number.
 *  - own: wacli is logged into the operator's account, so the operator's chat is the "message yourself" chat, which
 *    wacli may key by the phone JID or by the account's LID (status.user_jid / user_lid).
 * Group chats are never candidates.
 */
export function findOperatorChat(chats: WaChat[], operatorDigits: string, mode: 'dedicated' | 'own', status?: Pick<WaStatus, 'user_jid' | 'user_lid'>): WaChat | undefined {
  const wanted = new Set([operatorDigits])
  if (mode === 'own') {
    if (status?.user_jid) wanted.add(jidUser(status.user_jid))
    if (status?.user_lid) wanted.add(jidUser(status.user_lid))
  }
  return chats.find((c) => !c.is_group && wanted.has(jidUser(c.jid)))
}
