/**
 * Registers every `IPC.*` channel from src/shared/ipc.ts. Each handler verifies the sender is our own top-level page
 * (security.isTrustedSender) and validates its arguments: the renderer is treated as untrusted input.
 */
import { BrowserWindow, app, ipcMain, type IpcMainEvent, type IpcMainInvokeEvent, type WebContents } from 'electron'
import {
  IPC,
  type ConnectionState,
  type DaemonRequest,
  type LogLevel,
  type LogLine,
  type LogQuery,
  type LogSource,
  type ProcName,
  type SetupApi,
  type SetupState,
  type StartupPrefs
} from '../../src/shared/ipc'
import type { DaemonService } from './daemon'
import type { LogSinkImpl } from './logs'
import type { PrefsStore } from './prefs'
import type { Security } from './security'
import { openExternalSafe } from './security'
import type { Supervisor } from './supervisor'

/** Send to every live window. Used for supervisor/log/connection/setup events. */
export function broadcast(channel: string, payload: unknown): void {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed() && !win.webContents.isDestroyed()) win.webContents.send(channel, payload)
  }
}

export const SETUP_METHODS = [
  'state',
  'checkPrereqs',
  'saveModelKey',
  'saveModelClaudeCode',
  'installBinaries',
  'writeConfig',
  'startServices',
  'startPairing',
  'cancelPairing',
  'applyOperatorLockdown',
  'sendTestMessage',
  'reset'
] as const satisfies ReadonlyArray<keyof SetupApi>
export type SetupMethod = (typeof SETUP_METHODS)[number]

const PROC_NAMES: readonly ProcName[] = ['karmax', 'wacli']
const LOG_SOURCES: readonly LogSource[] = ['karmax', 'wacli', 'app']
const LOG_LEVELS: readonly LogLevel[] = ['debug', 'info', 'warn', 'error']

export function parseProcName(v: unknown): ProcName {
  if (typeof v === 'string' && (PROC_NAMES as readonly string[]).includes(v)) return v as ProcName
  throw new Error('Unknown process name')
}

export function parseLogQuery(v: unknown): LogQuery {
  const q: LogQuery = {}
  if (!v || typeof v !== 'object') return q
  const src = v as Record<string, unknown>
  if (typeof src.limit === 'number' && Number.isFinite(src.limit)) q.limit = Math.max(1, Math.min(5000, Math.floor(src.limit)))
  if (typeof src.sinceSeq === 'number' && Number.isFinite(src.sinceSeq)) q.sinceSeq = Math.max(0, Math.floor(src.sinceSeq))
  if (typeof src.source === 'string' && (LOG_SOURCES as readonly string[]).includes(src.source)) q.source = src.source as LogSource
  if (typeof src.level === 'string' && (LOG_LEVELS as readonly string[]).includes(src.level)) q.level = src.level as LogLevel
  return q
}

const STREAM_ID_RE = /^[A-Za-z0-9_-]{8,64}$/

export interface IpcContext {
  daemon: DaemonService
  supervisor: Supervisor
  logs: LogSinkImpl
  prefs: PrefsStore
  security: Security
  /** Late-bound: the setup backend is registered after IPC (it needs `broadcast`). */
  setup: () => { api: SetupApi; getState(): SetupState } | undefined
  /** Called after the startup prefs changed (index.ts applies openAtLogin). */
  onPrefsChanged?: (p: StartupPrefs) => void
}

export function registerIpc(ctx: IpcContext): { dispose(): void } {
  const disposers: Array<() => void> = []
  const streams = new Map<string, { abort(): void; wcId: number }>()
  const watched = new WeakSet<WebContents>()

  const trusted = (e: IpcMainEvent | IpcMainInvokeEvent): void => {
    if (!ctx.security.isTrustedSender(e)) throw new Error('Untrusted IPC sender')
  }
  const handle = (channel: string, fn: (e: IpcMainInvokeEvent, ...args: unknown[]) => unknown): void => {
    ipcMain.handle(channel, (e, ...args) => {
      trusted(e)
      return fn(e, ...args)
    })
    disposers.push(() => ipcMain.removeHandler(channel))
  }
  const on = (channel: string, fn: (e: IpcMainEvent, ...args: unknown[]) => void): void => {
    const listener = (e: IpcMainEvent, ...args: unknown[]): void => {
      try {
        trusted(e)
      } catch {
        return
      }
      fn(e, ...args)
    }
    ipcMain.on(channel, listener)
    disposers.push(() => ipcMain.removeListener(channel, listener))
  }

  // ── app / window ──
  handle(IPC.appVersion, () => app.getVersion())
  handle(IPC.openExternal, (_e, url) => openExternalSafe(url))
  on(IPC.winMinimize, (e) => BrowserWindow.fromWebContents(e.sender)?.minimize())
  on(IPC.winToggleMax, (e) => {
    const w = BrowserWindow.fromWebContents(e.sender)
    if (!w) return
    if (w.isMaximized()) w.unmaximize()
    else w.maximize()
  })
  on(IPC.winClose, (e) => BrowserWindow.fromWebContents(e.sender)?.close())

  // ── daemon proxy ──
  handle(IPC.daemonRequest, (_e, req) => ctx.daemon.request(req as DaemonRequest))

  const abortStreamsOf = (wcId: number): void => {
    for (const [id, s] of streams) {
      if (s.wcId === wcId) {
        s.abort()
        streams.delete(id)
      }
    }
  }
  handle(IPC.daemonStreamStart, (e, arg) => {
    const { id, req } = (arg ?? {}) as { id?: unknown; req?: unknown }
    if (typeof id !== 'string' || !STREAM_ID_RE.test(id)) throw new Error('Invalid stream id')
    if (streams.has(id)) throw new Error('Duplicate stream id')
    const wc = e.sender
    if (!watched.has(wc)) {
      watched.add(wc)
      wc.once('destroyed', () => abortStreamsOf(wc.id))
      // A reload/navigation orphans in-flight streams; stop paying for them.
      wc.on('did-start-navigation', (details) => {
        if (details.isMainFrame && !details.isSameDocument) abortStreamsOf(wc.id)
      })
    }
    const ctl = ctx.daemon.stream(req as DaemonRequest, (ev) => {
      if (wc.isDestroyed()) {
        streams.get(id)?.abort()
        streams.delete(id)
        return
      }
      wc.send(IPC.daemonStreamEvent, { id, ...ev })
      if (ev.end || ev.error !== undefined) streams.delete(id)
    })
    streams.set(id, { abort: () => ctl.abort(), wcId: wc.id })
  })
  on(IPC.daemonStreamAbort, (e, id) => {
    if (typeof id !== 'string') return
    const s = streams.get(id)
    if (s && s.wcId === e.sender.id) {
      s.abort()
      streams.delete(id)
    }
  })

  // ── connection (poll main-side; push on change) ──
  handle(IPC.connectionGet, () => ctx.daemon.connection())
  let lastConn = ''
  let checking = false
  const checkConnection = async (): Promise<void> => {
    if (checking) return
    checking = true
    try {
      const s: ConnectionState = await ctx.daemon.connection()
      const key = JSON.stringify(s)
      if (key !== lastConn) {
        lastConn = key
        broadcast(IPC.connectionChanged, s)
      }
    } finally {
      checking = false
    }
  }
  const connTimer = setInterval(() => void checkConnection(), 5000)
  connTimer.unref?.()
  disposers.push(() => clearInterval(connTimer))
  disposers.push(ctx.daemon.onConfigChange(() => void checkConnection()))
  void checkConnection()

  // ── supervisor ──
  handle(IPC.supervisorStatus, () => ctx.supervisor.status())
  handle(IPC.supervisorStart, (_e, name) => ctx.supervisor.start(parseProcName(name)))
  handle(IPC.supervisorStop, (_e, name) => ctx.supervisor.stop(parseProcName(name)))
  handle(IPC.supervisorRestart, (_e, name) => ctx.supervisor.restart(parseProcName(name)))
  let connDebounce: ReturnType<typeof setTimeout> | undefined
  disposers.push(
    ctx.supervisor.onChange((s) => {
      broadcast(IPC.supervisorChanged, s)
      // A daemon coming or going changes reachability: re-ping soon rather than waiting for the next poll.
      if (connDebounce) clearTimeout(connDebounce)
      connDebounce = setTimeout(() => void checkConnection(), 400)
    })
  )

  // ── logs (batched: a chatty daemon must not flood IPC) ──
  handle(IPC.logsHistory, (_e, q) => ctx.logs.history(parseLogQuery(q)))
  let batch: LogLine[] = []
  let batchTimer: ReturnType<typeof setTimeout> | undefined
  disposers.push(
    ctx.logs.subscribe((line) => {
      batch.push(line)
      if (batchTimer) return
      batchTimer = setTimeout(() => {
        batchTimer = undefined
        const out = batch
        batch = []
        if (out.length) broadcast(IPC.logsLine, out)
      }, 50)
    })
  )

  // ── setup wizard (A2) ──
  handle(IPC.setupInvoke, (_e, arg) => {
    const { method, args } = (arg ?? {}) as { method?: unknown; args?: unknown }
    if (typeof method !== 'string' || !(SETUP_METHODS as readonly string[]).includes(method)) throw new Error('Unknown setup method')
    const setup = ctx.setup()
    if (!setup) throw new Error('Setup backend is not available')
    const fn = setup.api[method as SetupMethod] as (...a: unknown[]) => Promise<unknown>
    return fn.apply(setup.api, Array.isArray(args) ? args : [])
  })

  // ── startup prefs ──
  handle(IPC.startupGet, () => ctx.prefs.get())
  handle(IPC.startupSet, (_e, patch) => {
    const next = ctx.prefs.set(patch && typeof patch === 'object' ? (patch as Partial<StartupPrefs>) : {})
    ctx.onPrefsChanged?.(next)
    return next
  })

  return {
    dispose() {
      for (const d of disposers.splice(0)) d()
      for (const s of streams.values()) s.abort()
      streams.clear()
      if (batchTimer) clearTimeout(batchTimer)
      if (connDebounce) clearTimeout(connDebounce)
    }
  }
}
