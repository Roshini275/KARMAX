import { describe, expect, it } from 'vitest'
import { createPaths } from './paths'

describe('paths (Windows)', () => {
  const env = { LOCALAPPDATA: 'C:\\Users\\Ro\\AppData\\Local' }
  const base = { platform: 'win32' as const, home: 'C:\\Users\\Ro', env, userData: 'C:\\Users\\Ro\\AppData\\Roaming\\KARMAX', appPath: 'C:\\repo' }

  it('resolves the install dir under %LOCALAPPDATA%\\KARMAX and exe names', () => {
    const p = createPaths(base)
    expect(p.installDir()).toBe('C:\\Users\\Ro\\AppData\\Local\\KARMAX')
    expect(p.karmaxExe()).toBe('C:\\Users\\Ro\\AppData\\Local\\KARMAX\\karmax.exe')
    expect(p.wacliExe()).toBe('C:\\Users\\Ro\\AppData\\Local\\KARMAX\\wacli.exe')
  })
  it('falls back to <home>\\AppData\\Local when LOCALAPPDATA is unset', () => {
    expect(createPaths({ ...base, env: {} }).installDir()).toBe('C:\\Users\\Ro\\AppData\\Local\\KARMAX')
  })
  it('data dir is ~/.karmax with .env and karmax.yaml, wacli home is ~/.wacli', () => {
    const p = createPaths(base)
    expect(p.dataDir()).toBe('C:\\Users\\Ro\\.karmax')
    expect(p.envFile()).toBe('C:\\Users\\Ro\\.karmax\\.env')
    expect(p.yamlFile()).toBe('C:\\Users\\Ro\\.karmax\\karmax.yaml')
    expect(p.wacliHome()).toBe('C:\\Users\\Ro\\.wacli')
  })
  it('honours WACLI_HOME and KARMAX_HOME', () => {
    const p = createPaths({ ...base, env: { ...env, WACLI_HOME: 'D:\\wa', KARMAX_HOME: 'D:\\km' } })
    expect(p.wacliHome()).toBe('D:\\wa')
    expect(p.dataDir()).toBe('D:\\km')
    expect(p.envFile()).toBe('D:\\km\\.env')
  })
  it('ignores blank overrides', () => {
    expect(createPaths({ ...base, env: { ...env, WACLI_HOME: '  ', KARMAX_HOME: '' } }).wacliHome()).toBe('C:\\Users\\Ro\\.wacli')
  })
  it('resources: repo resources/bin in dev, <resources>\\bin when packaged', () => {
    expect(createPaths(base).resourcesBin()).toBe('C:\\repo\\resources\\bin')
    const packaged = createPaths({ ...base, isPackaged: true, resourcesPath: 'C:\\Program Files\\KARMAX\\resources', appPath: 'C:\\Program Files\\KARMAX\\resources\\app.asar' })
    expect(packaged.resourcesBin()).toBe('C:\\Program Files\\KARMAX\\resources\\bin')
    expect(packaged.iconFile()).toBe('C:\\Program Files\\KARMAX\\resources\\icon.ico')
    expect(createPaths(base).iconFile()).toBe('C:\\repo\\build\\icon.ico')
  })
  it('userData and its children', () => {
    const p = createPaths(base)
    expect(p.userData()).toBe('C:\\Users\\Ro\\AppData\\Roaming\\KARMAX')
    expect(p.logsDir()).toBe('C:\\Users\\Ro\\AppData\\Roaming\\KARMAX\\logs')
    expect(p.prefsFile()).toBe('C:\\Users\\Ro\\AppData\\Roaming\\KARMAX\\prefs.json')
    expect(p.secretsDir()).toBe('C:\\Users\\Ro\\AppData\\Roaming\\KARMAX\\secrets')
  })
  it('built output locations', () => {
    const p = createPaths(base)
    expect(p.rendererIndex()).toBe('C:\\repo\\out\\renderer\\index.html')
    expect(p.preloadDir()).toBe('C:\\repo\\out\\preload')
  })
})

describe('paths (POSIX, for tests and CI)', () => {
  const base = { platform: 'linux' as const, home: '/home/ro', env: {}, userData: '/home/ro/.config/KARMAX', appPath: '/repo' }
  it('uses ~/.karmax, ~/.wacli and XDG for the install dir; no .exe suffix', () => {
    const p = createPaths(base)
    expect(p.dataDir()).toBe('/home/ro/.karmax')
    expect(p.wacliHome()).toBe('/home/ro/.wacli')
    expect(p.installDir()).toBe('/home/ro/.local/share/KARMAX')
    expect(p.karmaxExe()).toBe('/home/ro/.local/share/KARMAX/karmax')
    expect(p.wacliExe()).toBe('/home/ro/.local/share/KARMAX/wacli')
    expect(p.iconFile()).toBe('/repo/build/icon.png')
  })
  it('KARMAX_HOME / WACLI_HOME / KARMAX_INSTALL_DIR overrides (test isolation)', () => {
    const p = createPaths({ ...base, env: { KARMAX_HOME: '/tmp/k', WACLI_HOME: '/tmp/w', KARMAX_INSTALL_DIR: '/tmp/bin' } })
    expect(p.dataDir()).toBe('/tmp/k')
    expect(p.yamlFile()).toBe('/tmp/k/karmax.yaml')
    expect(p.wacliHome()).toBe('/tmp/w')
    expect(p.karmaxExe()).toBe('/tmp/bin/karmax')
  })
  it('defaults work with no options at all', () => {
    const p = createPaths()
    expect(typeof p.dataDir()).toBe('string')
    expect(p.envFile().endsWith('.env')).toBe(true)
  })
})
