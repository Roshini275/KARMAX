import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'
import type { ChildProcess } from 'node:child_process'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { ProcName } from '../../src/shared/ipc'
import { BACKOFF_CAP_MS, DEFAULT_TIMING, NO_SESSION_RE, backoffDelay, createSupervisor, type SupervisorDeps } from './supervisor'

describe('backoffDelay', () => {
  it('doubles from 1s and caps at 30s', () => {
    expect([0, 1, 2, 3, 4, 5, 6, 7, 20].map((n) => backoffDelay(n))).toEqual([1000, 2000, 4000, 8000, 16000, 30000, 30000, 30000, 30000])
    expect(BACKOFF_CAP_MS).toBe(30000)
  })
  it('is safe for silly inputs', () => {
    expect(backoffDelay(-3)).toBe(1000)
    expect(backoffDelay(1e9)).toBe(30000)
    expect(backoffDelay(2, 500, 1500)).toBe(1500)
  })
})

describe('NO_SESSION_RE', () => {
  it("matches wacli's real message", () => {
    // wacli/wa/service.go: errors.New("not logged in; run `wacli login` first")
    expect(NO_SESSION_RE.test('not logged in; run `wacli login` first')).toBe(true)
    expect(NO_SESSION_RE.test('http server: listen tcp 127.0.0.1:8765: bind: address already in use')).toBe(false)
  })
})

let nextPid = 1000
class FakeChild extends EventEmitter {
  pid = nextPid++
  stdout = new PassThrough()
  stderr = new PassThrough()
  signals: string[] = []
  ignoreTerm = false
  kill(signal: string = 'SIGTERM'): boolean {
    this.signals.push(signal)
    if (signal === 'SIGTERM' && this.ignoreTerm) return true
    this.die(null, signal)
    return true
  }
  die(code: number | null, signal: string | null = null): void {
    this.stdout.end()
    this.stderr.end()
    this.emit('exit', code, signal)
    this.emit('close', code, signal)
  }
}

interface Harness {
  sup: ReturnType<typeof createSupervisor>
  children: Record<ProcName, FakeChild[]>
  spawnCalls: Array<{ cmd: string; args: string[]; opts: Record<string, unknown> }>
  healthy: Record<ProcName, boolean>
  setup: { completed: boolean }
  exists: { value: boolean }
  logs: string[]
  ingested: string[]
  states: string[]
}

function harness(over: Partial<SupervisorDeps> = {}): Harness {
  const h: Harness = {
    children: { karmax: [], wacli: [] },
    spawnCalls: [],
    healthy: { karmax: false, wacli: false },
    setup: { completed: true },
    exists: { value: true },
    logs: [],
    ingested: [],
    states: [],
    sup: undefined as never
  }
  h.sup = createSupervisor({
    paths: { karmaxExe: () => '/bin/karmax', wacliExe: () => '/bin/wacli', dataDir: () => '/tmp/km-supervisor-test', yamlFile: () => '/tmp/km-supervisor-test/karmax.yaml' },
    ports: () => ({ karmax: 9091, wacli: 8765 }),
    log: { app: (_l, m) => void h.logs.push(m), ingest: (s, c) => void h.ingested.push(`${s}:${c}`) },
    setupCompleted: () => h.setup.completed,
    env: { PATH: '/usr/bin' },
    platform: 'linux',
    exists: () => h.exists.value,
    probe: async (name) => h.healthy[name],
    spawn: ((cmd: string, args: string[], opts: Record<string, unknown>) => {
      const name: ProcName = args[0] === 'daemon' ? 'wacli' : 'karmax'
      const c = new FakeChild()
      h.children[name].push(c)
      h.spawnCalls.push({ cmd, args, opts })
      return c as unknown as ChildProcess
    }) as never,
    killTree: async (child, force) => (child as unknown as FakeChild).kill(force ? 'SIGKILL' : 'SIGTERM'),
    killTreeSync: (child) => (child as unknown as FakeChild).kill('SIGKILL'),
    ...over
  })
  h.sup.onChange((s) => h.states.push(s.map((p) => `${p.name}:${p.state}`).join(',')))
  return h
}

const st = (h: Harness, n: ProcName) => h.sup.status().find((s) => s.name === n)!
const last = <T>(a: T[]): T => a[a.length - 1]

describe('supervisor', () => {
  beforeEach(() => {
    vi.useFakeTimers()
    vi.setSystemTime(new Date('2026-09-19T12:00:00.000Z'))
  })
  afterEach(() => {
    vi.useRealTimers()
  })

  it('reports missing when the binary is not installed (and does not spawn)', async () => {
    const h = harness()
    h.exists.value = false
    await h.sup.start('karmax')
    expect(st(h, 'karmax')).toMatchObject({ state: 'missing', healthy: false, binaryPath: '/bin/karmax' })
    expect(h.spawnCalls).toHaveLength(0)
  })

  it('spawns wacli and karmax with the verified invocations and env', async () => {
    const h = harness()
    await h.sup.start('wacli')
    await h.sup.start('karmax')
    const w = h.spawnCalls[0]
    const k = h.spawnCalls[1]
    expect(w).toMatchObject({ cmd: '/bin/wacli', args: ['daemon'] })
    expect((w.opts.env as Record<string, string>).WACLI_HTTP_ADDR).toBe('127.0.0.1:8765')
    expect(k).toMatchObject({ cmd: '/bin/karmax', args: ['start', '--config', '/tmp/km-supervisor-test/karmax.yaml'] })
    const kenv = k.opts.env as Record<string, string>
    expect(kenv.KARMAX_WACLI_PATH).toBe('/bin/wacli')
    expect(kenv.KARMAX_WACLI_API_URL).toBe('http://127.0.0.1:8765')
    expect(kenv.KARMAX_DATA_DIR).toBeUndefined() // only forwarded when KARMAX_HOME is set
    expect(k.opts).toMatchObject({ windowsHide: true, cwd: '/tmp/km-supervisor-test' })
    expect(st(h, 'karmax')).toMatchObject({ state: 'starting', healthy: false, pid: h.children.karmax[0].pid, restarts: 0 })
  })

  it('forwards KARMAX_HOME to the daemon as KARMAX_DATA_DIR', async () => {
    const h = harness({ env: { KARMAX_HOME: '/tmp/x' } })
    await h.sup.start('karmax')
    expect((h.spawnCalls[0].opts.env as Record<string, string>).KARMAX_DATA_DIR).toBe('/tmp/km-supervisor-test')
  })

  it('goes starting -> running once the health probe answers, and pipes output to the log sink', async () => {
    const h = harness()
    h.sup.startMonitor()
    await h.sup.start('karmax')
    h.children.karmax[0].stdout.write('hello from karmax\n')
    await vi.advanceTimersByTimeAsync(1000)
    expect(st(h, 'karmax').state).toBe('starting')
    expect(h.ingested).toContain('karmax:hello from karmax\n')
    h.healthy.karmax = true
    await vi.advanceTimersByTimeAsync(1000)
    expect(st(h, 'karmax')).toMatchObject({ state: 'running', healthy: true })
    expect(await h.sup.waitHealthy('karmax', 1000)).toBe(true)
    h.sup.dispose()
  })

  it('attaches to an already-running daemon as external and never kills it', async () => {
    const h = harness()
    h.healthy.karmax = true
    await h.sup.start('karmax')
    expect(st(h, 'karmax')).toMatchObject({ state: 'external', healthy: true })
    expect(h.spawnCalls).toHaveLength(0)
    await h.sup.stop('karmax')
    await h.sup.restart('karmax')
    await h.sup.stopAll()
    h.sup.killAllSync()
    expect(st(h, 'karmax').state).toBe('external')
    expect(h.spawnCalls).toHaveLength(0)
  })

  it('external that disappears becomes stopped (no takeover)', async () => {
    const h = harness()
    h.healthy.wacli = true
    h.sup.startMonitor()
    await h.sup.start('wacli')
    h.healthy.wacli = false
    await vi.advanceTimersByTimeAsync(15_000)
    expect(st(h, 'wacli')).toMatchObject({ state: 'stopped', healthy: false })
    expect(h.spawnCalls).toHaveLength(0)
    h.sup.dispose()
  })

  it('detects an external daemon that appears while we are stopped', async () => {
    const h = harness()
    h.sup.startMonitor()
    h.healthy.karmax = true
    await vi.advanceTimersByTimeAsync(1000)
    expect(st(h, 'karmax').state).toBe('external')
    h.sup.dispose()
  })

  async function runHealthy(h: Harness, name: ProcName = 'karmax'): Promise<void> {
    h.healthy[name] = false // the pre-spawn probe must find nothing on the port, or we would (correctly) attach as external
    await h.sup.start(name)
    h.healthy[name] = true
    await vi.advanceTimersByTimeAsync(1000)
    expect(st(h, name).state).toBe('running')
  }

  it('crash -> crashed/backoff with nextRestartAt, restart counter, then respawn after 1s', async () => {
    const h = harness()
    h.sup.startMonitor()
    await runHealthy(h)
    h.healthy.karmax = false // the crashed process no longer answers
    const t0 = Date.now()
    h.children.karmax[0].die(1)
    await vi.advanceTimersByTimeAsync(0)
    const s = st(h, 'karmax')
    expect(s.state).toBe('backoff')
    expect(s.nextRestartAt).toBe(new Date(t0 + 1000).toISOString())
    expect(s.lastExit).toMatchObject({ code: 1 })
    expect(s.restarts).toBe(0)
    expect(h.states.some((x) => x.startsWith('karmax:crashed'))).toBe(true)
    await vi.advanceTimersByTimeAsync(1100)
    expect(h.children.karmax).toHaveLength(2)
    expect(st(h, 'karmax')).toMatchObject({ state: 'starting', restarts: 1 })
    h.sup.dispose()
  })

  it('backs off 1s, 2s, 4s ... on consecutive crashes and resets after 60s of health', async () => {
    const h = harness()
    h.sup.startMonitor()
    await runHealthy(h)
    h.healthy.karmax = false
    const delays: number[] = []
    for (let i = 0; i < 3; i++) {
      const at = Date.now()
      h.children.karmax[i].die(1)
      await vi.advanceTimersByTimeAsync(0)
      delays.push(Date.parse(st(h, 'karmax').nextRestartAt!) - at)
      await vi.advanceTimersByTimeAsync(delays[i] + 100)
      // second instance never becomes healthy (probe is false): immediate crash again
    }
    expect(delays).toEqual([1000, 2000, 4000])

    // Now stay healthy for a full minute: ladder resets.
    h.healthy.karmax = true
    await vi.advanceTimersByTimeAsync(1000)
    expect(st(h, 'karmax').state).toBe('running')
    await vi.advanceTimersByTimeAsync(DEFAULT_TIMING.healthyResetMs + 100)
    h.healthy.karmax = false
    const at = Date.now()
    h.children.karmax[3].die(1)
    await vi.advanceTimersByTimeAsync(0)
    expect(Date.parse(st(h, 'karmax').nextRestartAt!) - at).toBe(1000)
    h.sup.dispose()
  })

  it('caps the backoff at 30s', async () => {
    const h = harness()
    h.sup.startMonitor()
    await runHealthy(h)
    h.healthy.karmax = false
    let d = 0
    for (let i = 0; i < 8; i++) {
      const at = Date.now()
      h.children.karmax[i].die(1)
      await vi.advanceTimersByTimeAsync(0)
      d = Date.parse(st(h, 'karmax').nextRestartAt!) - at
      await vi.advanceTimersByTimeAsync(d + 50)
    }
    expect(d).toBe(30_000)
    h.sup.dispose()
  })

  it('wacli with no WhatsApp session is "stopped", not a crash loop, even after setup completed', async () => {
    const h = harness()
    await h.sup.start('wacli')
    h.children.wacli[0].stderr.write('not logged in; run `wacli login` first\n')
    await vi.advanceTimersByTimeAsync(0)
    h.children.wacli[0].die(1)
    await vi.advanceTimersByTimeAsync(60_000)
    expect(st(h, 'wacli')).toMatchObject({ state: 'stopped', healthy: false, lastExit: { code: 1 } })
    expect(h.children.wacli).toHaveLength(1) // never restarted
    expect(h.logs.some((l) => /not logged in to WhatsApp/.test(l))).toBe(true)
    // An explicit start (after pairing) works again.
    await h.sup.start('wacli')
    expect(h.children.wacli).toHaveLength(2)
  })

  it('a daemon that dies before ever being healthy while setup is incomplete does not crash-loop', async () => {
    const h = harness()
    h.setup.completed = false
    await h.sup.start('karmax')
    h.children.karmax[0].die(2)
    await vi.advanceTimersByTimeAsync(60_000)
    expect(st(h, 'karmax')).toMatchObject({ state: 'crashed', lastExit: { code: 2 } })
    expect(st(h, 'karmax').nextRestartAt).toBeUndefined()
    expect(h.children.karmax).toHaveLength(1)
  })

  it('stop: SIGTERM then state stopped, no restart', async () => {
    const h = harness()
    h.sup.startMonitor()
    await runHealthy(h)
    await h.sup.stop('karmax')
    expect(h.children.karmax[0].signals).toEqual(['SIGTERM'])
    expect(st(h, 'karmax')).toMatchObject({ state: 'stopped', healthy: false })
    expect(st(h, 'karmax').pid).toBeUndefined()
    await vi.advanceTimersByTimeAsync(60_000)
    expect(h.children.karmax).toHaveLength(1)
    h.sup.dispose()
  })

  it('stop escalates SIGTERM -> SIGKILL when the process ignores it', async () => {
    const h = harness()
    await h.sup.start('karmax')
    h.children.karmax[0].ignoreTerm = true
    const p = h.sup.stop('karmax')
    await vi.advanceTimersByTimeAsync(DEFAULT_TIMING.termStopMs + 100)
    await p
    expect(h.children.karmax[0].signals).toEqual(['SIGTERM', 'SIGKILL'])
    expect(st(h, 'karmax').state).toBe('stopped')
  })

  it('on Windows: graceful taskkill declined -> immediate forced tree kill', async () => {
    const calls: Array<{ pid: number | undefined; force: boolean }> = []
    const h = harness({
      platform: 'win32',
      killTree: async (child, force) => {
        calls.push({ pid: child.pid, force })
        if (force) (child as unknown as FakeChild).die(1)
        return force // plain taskkill on a windowless console process fails ("can only be terminated forcefully")
      }
    })
    await h.sup.start('karmax')
    await h.sup.stop('karmax')
    expect(calls.map((c) => c.force)).toEqual([false, true])
    expect(calls[0].pid).toBe(h.children.karmax[0].pid)
    expect(st(h, 'karmax').state).toBe('stopped')
  })

  it('stop cancels a pending backoff restart', async () => {
    const h = harness()
    h.sup.startMonitor()
    await runHealthy(h)
    h.healthy.karmax = false
    h.children.karmax[0].die(1)
    await vi.advanceTimersByTimeAsync(0)
    expect(st(h, 'karmax').state).toBe('backoff')
    await h.sup.stop('karmax')
    expect(st(h, 'karmax').state).toBe('stopped')
    await vi.advanceTimersByTimeAsync(5000)
    expect(h.children.karmax).toHaveLength(1)
    h.sup.dispose()
  })

  it('restart stops then starts a fresh process', async () => {
    const h = harness()
    await h.sup.start('karmax')
    await h.sup.restart('karmax')
    expect(h.children.karmax).toHaveLength(2)
    expect(h.children.karmax[0].signals).toEqual(['SIGTERM'])
    expect(st(h, 'karmax').state).toBe('starting')
  })

  it('a failed spawn (ENOENT) becomes missing', async () => {
    const h = harness({
      spawn: ((_c: string, _a: string[]) => {
        const c = new FakeChild()
        queueMicrotask(() => c.emit('error', Object.assign(new Error('spawn ENOENT'), { code: 'ENOENT' })))
        return c as unknown as ChildProcess
      }) as never
    })
    await h.sup.start('karmax')
    await vi.advanceTimersByTimeAsync(10)
    expect(st(h, 'karmax').state).toBe('missing')
  })

  it('a process that never becomes healthy is killed after the startup grace and restarted with backoff', async () => {
    const h = harness()
    h.sup.startMonitor()
    await h.sup.start('karmax') // probe stays false
    await vi.advanceTimersByTimeAsync(DEFAULT_TIMING.startupGraceMs + 2000)
    expect(h.children.karmax[0].signals).toContain('SIGTERM')
    expect(h.logs.some((l) => /not healthy/.test(l))).toBe(true)
    await vi.advanceTimersByTimeAsync(3000)
    expect(h.children.karmax.length).toBeGreaterThanOrEqual(2)
    h.sup.dispose()
  })

  it('waitHealthy returns false quickly when the process is stopped, true when healthy, false on timeout', async () => {
    const h = harness()
    expect(await h.sup.waitHealthy('wacli', 5000)).toBe(false)
    h.healthy.karmax = true
    h.sup.startMonitor()
    await h.sup.start('karmax') // external
    expect(await h.sup.waitHealthy('karmax', 1000)).toBe(true)
    h.healthy.wacli = false
    await h.sup.start('wacli')
    const p = h.sup.waitHealthy('wacli', 1500)
    await vi.advanceTimersByTimeAsync(1600)
    expect(await p).toBe(false)
    h.sup.dispose()
  })

  it('emits status changes and de-duplicates identical snapshots', async () => {
    const h = harness()
    await h.sup.start('karmax')
    const n = h.states.length
    await h.sup.start('karmax') // already starting: no new emission
    expect(h.states.length).toBe(n)
    expect(last(h.states)).toContain('karmax:starting')
  })

  it('killAllSync kills owned children without flagging a restart', async () => {
    const h = harness()
    await h.sup.start('karmax')
    h.sup.killAllSync()
    expect(h.children.karmax[0].signals).toEqual(['SIGKILL'])
    await vi.advanceTimersByTimeAsync(60_000)
    expect(h.children.karmax).toHaveLength(1)
  })
})
