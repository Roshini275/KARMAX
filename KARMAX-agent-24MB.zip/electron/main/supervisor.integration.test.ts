/**
 * Real child processes (a tiny node script standing in for karmax / wacli), real HTTP health probes, real signals.
 * POSIX only: on Windows the tree-kill path is taskkill and cannot be exercised here.
 */
import { chmodSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { createLogSink } from './logs'
import { createSupervisor } from './supervisor'

const FAKE = `#!/usr/bin/env node
const http = require('http')
const isWacli = process.argv[2] === 'daemon'
if (isWacli && process.env.FAKE_NO_SESSION) {
  process.stderr.write('not logged in; run \`wacli login\` first\\n')
  process.exit(1)
}
const port = Number(process.env[isWacli ? 'FAKE_WACLI_PORT' : 'FAKE_KARMAX_PORT'])
const srv = http.createServer((req, res) => {
  res.setHeader('content-type', 'application/json')
  if (!isWacli && req.url === '/api/ping') return res.end(JSON.stringify({ service: 'karmax', version: 'fake' }))
  if (isWacli && req.url === '/status') return res.end(JSON.stringify({ connected: true }))
  res.statusCode = 404; res.end('{}')
})
srv.listen(port, '127.0.0.1', () => {
  process.stderr.write('2026-09-19T12:00:00.000+0530\\tINFO\\truntime/x.go:12\\tlistening\\t{"loop":"fake"}\\n')
  if (!isWacli) process.stdout.write('args=' + process.argv.slice(2).join(' ') + ' wacli=' + process.env.KARMAX_WACLI_API_URL + '\\n')
})
process.on('SIGTERM', () => { srv.close(); process.exit(0) })
`

async function freePort(): Promise<number> {
  return new Promise((resolve) => {
    const s = createServer()
    s.listen(0, '127.0.0.1', () => {
      const p = (s.address() as { port: number }).port
      s.close(() => resolve(p))
    })
  })
}

const until = async (cond: () => boolean, ms = 8000): Promise<void> => {
  const end = Date.now() + ms
  while (!cond()) {
    if (Date.now() > end) throw new Error('timed out waiting for condition')
    await new Promise((r) => setTimeout(r, 25))
  }
}

describe.skipIf(process.platform === 'win32')('supervisor with real processes', () => {
  let dir: string
  beforeAll(() => {
    dir = mkdtempSync(join(tmpdir(), 'km-sup-'))
    writeFileSync(join(dir, 'fake'), FAKE)
    chmodSync(join(dir, 'fake'), 0o755)
  })
  afterAll(() => rmSync(dir, { recursive: true, force: true }))

  const make = async (env: Record<string, string> = {}) => {
    const kp = await freePort()
    const wp = await freePort()
    const sink = createLogSink()
    const sup = createSupervisor({
      paths: { karmaxExe: () => join(dir, 'fake'), wacliExe: () => join(dir, 'fake'), dataDir: () => dir, yamlFile: () => join(dir, 'karmax.yaml') },
      ports: () => ({ karmax: kp, wacli: wp }),
      log: sink,
      setupCompleted: () => true,
      env: { ...process.env, FAKE_KARMAX_PORT: String(kp), FAKE_WACLI_PORT: String(wp), ...env },
      timing: { tickMs: 40, startingProbeMs: 40, runningProbeMs: 200, termStopMs: 3000 }
    })
    sup.startMonitor()
    return { sup, sink, kp, wp }
  }

  it('starts wacli then karmax, reaches healthy, captures parsed logs, and stops cleanly', async () => {
    const { sup, sink, kp } = await make()
    await sup.startAll()
    await until(() => sup.status().every((s) => s.state === 'running' && s.healthy))
    const lines = sink.history()
    expect(lines.some((l) => l.source === 'karmax' && l.level === 'info' && l.loop === 'fake' && l.message === 'listening')).toBe(true)
    const argsLine = lines.find((l) => l.message.startsWith('args='))
    expect(argsLine?.message).toMatch(/^args=start --config .*karmax\.yaml wacli=http:\/\/127\.0\.0\.1:\d+$/)

    await sup.stopAll()
    expect(sup.status().map((s) => s.state)).toEqual(['stopped', 'stopped'])
    await expect(fetch(`http://127.0.0.1:${kp}/api/ping`)).rejects.toThrow() // really gone
    sup.dispose()
  }, 20000)

  it('wacli with no session ends up stopped (not crash-looping) and karmax still starts', async () => {
    const { sup } = await make({ FAKE_NO_SESSION: '1' })
    await sup.startAll()
    await until(() => sup.status().find((s) => s.name === 'karmax')!.healthy)
    const w = sup.status().find((s) => s.name === 'wacli')!
    expect(w.state).toBe('stopped')
    expect(w.lastExit?.code).toBe(1)
    await new Promise((r) => setTimeout(r, 1500))
    expect(sup.status().find((s) => s.name === 'wacli')!.restarts).toBe(0)
    await sup.stopAll()
    sup.dispose()
  }, 20000)

  it('a killed daemon is restarted after the backoff', async () => {
    const { sup } = await make()
    await sup.start('karmax')
    await until(() => sup.status()[0].healthy)
    const pid = sup.status()[0].pid!
    process.kill(pid, 'SIGKILL')
    await until(() => ['crashed', 'backoff'].includes(sup.status()[0].state))
    await until(() => sup.status()[0].state === 'running' && sup.status()[0].pid !== pid, 8000)
    expect(sup.status()[0].restarts).toBe(1)
    await sup.stopAll()
    sup.dispose()
  }, 20000)
})
