/**
 * Supervises the two local daemons (implements `SupervisorApi` from ./contracts): `wacli daemon`, then `karmax start`.
 *
 * Invocations, verified upstream:
 *  - `karmax start [--config <path>]`  (KARMAX/cmd/karmax/runtime_cmd.go newStartCmd; `-c/--config` is a persistent root flag in
 *    root.go). It calls loadDotEnv() itself, which loads ./.env, <config dir>/.env and ~/.karmax/.env WITHOUT overriding real env
 *    vars (main.go), so we do not inject .env. We spawn with cwd = the data dir. Env we DO set: KARMAX_WACLI_PATH and
 *    KARMAX_WACLI_API_URL (internal/hostpaths/hostpaths.go), and KARMAX_DATA_DIR only when this app's KARMAX_HOME override is set.
 *  - `wacli daemon` (wacli/main.go cmdDaemon): needs a paired WhatsApp session. Without one, service.Connect() returns
 *    "not logged in; run `wacli login` first" and die() exits with status 1 (wacli/wa/service.go Connect). We therefore treat
 *    that exit as "stopped, not paired yet" rather than a crash, and never auto-restart it: doing so would crash-loop during the
 *    first-run wizard, which runs `wacli login` BEFORE the daemon (it opens the session store directly). Listen address is
 *    WACLI_HTTP_ADDR (wacli/wa/app.go), default 127.0.0.1:8765; we set it explicitly from the configured port.
 *  - Health: karmax `GET /api/ping` -> {"service":"karmax"} (internal/api/server.go handlePing, unauthenticated); wacli `GET /status`.
 *
 * Windows caveat: Go's signal.Notify(SIGINT, SIGTERM) can only be triggered on Windows by console control events, which a
 * windowless child (windowsHide) cannot receive from Node. "Graceful" is therefore a plain `taskkill /pid N /T` (WM_CLOSE — accepted
 * by GUI processes only) and in practice the tree kill `taskkill /pid N /T /F` does the work. SQLite (WAL) in both daemons is crash-safe.
 */
import { spawn, spawnSync, type ChildProcess, type SpawnOptions } from 'node:child_process'
import { existsSync, mkdirSync } from 'node:fs'
import type { ProcName, ProcState, ProcStatus } from '../../src/shared/ipc'
import type { LogSink, Paths, SupervisorApi } from './contracts'

// ── pure logic ───────────────────────────────────────────────────────────────

export const BACKOFF_BASE_MS = 1_000
export const BACKOFF_CAP_MS = 30_000

/** Delay before restart attempt number `attempt` (0-based): 1s, 2s, 4s, 8s, 16s, 30s, 30s … */
export function backoffDelay(attempt: number, base = BACKOFF_BASE_MS, cap = BACKOFF_CAP_MS): number {
  const n = Math.max(0, Math.floor(attempt))
  return Math.min(cap, base * 2 ** Math.min(n, 30))
}

/** wacli/wa/service.go Connect(): "not logged in; run `wacli login` first". */
export const NO_SESSION_RE = /not logged in/i

export interface Timing {
  tickMs: number
  startingProbeMs: number
  runningProbeMs: number
  probeTimeoutMs: number
  startupGraceMs: number
  healthyResetMs: number
  gracefulStopMs: number
  forceStopMs: number
  termStopMs: number
  closeGraceMs: number
  unhealthyAfterMisses: number
  externalGoneAfterMisses: number
}

export const DEFAULT_TIMING: Timing = {
  tickMs: 500,
  startingProbeMs: 500,
  runningProbeMs: 5_000,
  probeTimeoutMs: 2_000,
  startupGraceMs: 120_000,
  healthyResetMs: 60_000,
  gracefulStopMs: 2_500,
  forceStopMs: 4_000,
  termStopMs: 5_000,
  closeGraceMs: 250,
  unhealthyAfterMisses: 3,
  externalGoneAfterMisses: 2
}

// ── dependencies (injectable for tests) ──────────────────────────────────────

export type SpawnFn = (command: string, args: string[], options: SpawnOptions) => ChildProcess

export interface SupervisorDeps {
  paths: Pick<Paths, 'karmaxExe' | 'wacliExe' | 'dataDir' | 'yamlFile'>
  /** Current API ports (daemon.ts resolves these from karmax.yaml / env). */
  ports: () => { karmax: number; wacli: number }
  log: Pick<LogSink, 'app' | 'ingest'>
  /** True once the first-run wizard has finished. Gates auto-start and pre-setup crash loops. */
  setupCompleted: () => boolean
  env?: NodeJS.ProcessEnv
  platform?: NodeJS.Platform
  spawn?: SpawnFn
  exists?: (path: string) => boolean
  /** Returns true when a health probe answers as the right service. */
  probe?: (name: ProcName, url: string, timeoutMs: number) => Promise<boolean>
  /** Ask the OS to end a process (tree on Windows). Resolves whether the request was accepted. */
  killTree?: (child: ChildProcess, force: boolean) => Promise<boolean>
  killTreeSync?: (child: ChildProcess) => void
  timing?: Partial<Timing>
}

export interface Supervisor extends SupervisorApi {
  /** Begin the health/monitor loop. */
  startMonitor(): void
  /** wacli first, then karmax. Used at app launch (after setup) and by the tray. */
  startAll(): Promise<void>
  /** karmax first, then wacli. */
  stopAll(): Promise<void>
  restartAll(): Promise<void>
  /** Last-resort synchronous kill for `process.on('exit')`. Owned children only. */
  killAllSync(): void
  dispose(): void
}

interface Rec {
  name: ProcName
  status: ProcStatus
  desired: boolean
  child?: ChildProcess
  gen: number
  stopping: boolean
  tail: string
  everHealthy: boolean
  consecutive: number
  backoffTimer?: ReturnType<typeof setTimeout>
  resetTimer?: ReturnType<typeof setTimeout>
  closeTimer?: ReturnType<typeof setTimeout>
  nextProbeAt: number
  probing: boolean
  misses: number
  exitWaiters: Array<() => void>
  finalized: boolean
  pendingExit?: { code: number | null; signal?: string }
  spawnError?: NodeJS.ErrnoException
  busy: number
  lock: Promise<void>
}

const NAMES: readonly ProcName[] = ['karmax', 'wacli']

function defaultProbe(timeoutMsDefault = 2000) {
  return async (name: ProcName, url: string, timeoutMs = timeoutMsDefault): Promise<boolean> => {
    try {
      const res = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(timeoutMs) })
      if (!res.ok) return false
      if (name === 'wacli') {
        await res.text().catch(() => '')
        return true
      }
      const body: unknown = await res.json().catch(() => undefined)
      return !!body && typeof body === 'object' && (body as { service?: unknown }).service === 'karmax'
    } catch {
      return false
    }
  }
}

function defaultKillTree(platform: NodeJS.Platform) {
  return (child: ChildProcess, force: boolean): Promise<boolean> => {
    const pid = child.pid
    if (!pid) return Promise.resolve(false)
    if (platform === 'win32') {
      return new Promise((resolve) => {
        const root = process.env.SystemRoot
        const exe = root ? `${root}\\System32\\taskkill.exe` : 'taskkill'
        const args = ['/pid', String(pid), '/T', ...(force ? ['/F'] : [])]
        try {
          const k = spawn(exe, args, { windowsHide: true, stdio: 'ignore' })
          k.on('error', () => resolve(false))
          k.on('exit', (code) => resolve(code === 0))
        } catch {
          resolve(false)
        }
      })
    }
    try {
      return Promise.resolve(child.kill(force ? 'SIGKILL' : 'SIGTERM'))
    } catch {
      return Promise.resolve(false)
    }
  }
}

function defaultKillTreeSync(platform: NodeJS.Platform) {
  return (child: ChildProcess): void => {
    const pid = child.pid
    if (!pid) return
    try {
      if (platform === 'win32') {
        const root = process.env.SystemRoot
        spawnSync(root ? `${root}\\System32\\taskkill.exe` : 'taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore', timeout: 4000 })
      } else child.kill('SIGKILL')
    } catch {
      /* nothing more we can do while exiting */
    }
  }
}

export function createSupervisor(deps: SupervisorDeps): Supervisor {
  const platform = deps.platform ?? process.platform
  const timing: Timing = { ...DEFAULT_TIMING, ...deps.timing }
  const spawnFn: SpawnFn = deps.spawn ?? ((c, a, o) => spawn(c, a, o))
  const exists = deps.exists ?? existsSync
  const probeFn = deps.probe ?? defaultProbe(timing.probeTimeoutMs)
  const killTree = deps.killTree ?? defaultKillTree(platform)
  const killTreeSync = deps.killTreeSync ?? defaultKillTreeSync(platform)
  const baseEnv = deps.env ?? process.env
  const { log } = deps

  const iso = (ms = Date.now()): string => new Date(ms).toISOString()
  const listeners = new Set<(s: ProcStatus[]) => void>()
  let lastSnapshot = ''
  let monitor: ReturnType<typeof setInterval> | undefined

  const recs: Record<ProcName, Rec> = {
    karmax: makeRec('karmax'),
    wacli: makeRec('wacli')
  }

  function makeRec(name: ProcName): Rec {
    return {
      name,
      status: { name, state: 'stopped', healthy: false, restarts: 0 },
      desired: false,
      gen: 0,
      stopping: false,
      tail: '',
      everHealthy: false,
      consecutive: 0,
      nextProbeAt: 0,
      probing: false,
      misses: 0,
      exitWaiters: [],
      finalized: true,
      busy: 0,
      lock: Promise.resolve()
    }
  }

  const snapshot = (): ProcStatus[] =>
    NAMES.map((n) => {
      const s = recs[n].status
      return { ...s, ...(s.lastExit ? { lastExit: { ...s.lastExit } } : {}) }
    })

  const emit = (): void => {
    const snap = snapshot()
    const key = JSON.stringify(snap)
    if (key === lastSnapshot) return
    lastSnapshot = key
    for (const cb of listeners) {
      try {
        cb(snap)
      } catch {
        /* subscriber errors must not break supervision */
      }
    }
  }

  const setState = (r: Rec, state: ProcState, patch: Partial<ProcStatus> = {}): void => {
    r.status = { ...r.status, state, ...patch }
    if (state !== 'backoff') delete r.status.nextRestartAt
    if (state !== 'starting' && state !== 'running') {
      delete r.status.pid
      if (state !== 'external') delete r.status.startedAt
    }
    emit()
  }

  const healthUrl = (name: ProcName): string => {
    const p = deps.ports()
    return name === 'karmax' ? `http://127.0.0.1:${p.karmax}/api/ping` : `http://127.0.0.1:${p.wacli}/status`
  }
  const probe = (name: ProcName): Promise<boolean> => probeFn(name, healthUrl(name), timing.probeTimeoutMs)
  const exePath = (name: ProcName): string => (name === 'karmax' ? deps.paths.karmaxExe() : deps.paths.wacliExe())

  const clearBackoff = (r: Rec): void => {
    if (r.backoffTimer) clearTimeout(r.backoffTimer)
    r.backoffTimer = undefined
  }

  const enqueue = <T>(r: Rec, fn: () => Promise<T>): Promise<T> => {
    r.busy++
    const run = r.lock.then(fn)
    r.lock = run.then(
      () => undefined,
      () => undefined
    )
    return run.finally(() => {
      r.busy--
    })
  }

  const buildSpawn = (name: ProcName): { args: string[]; env: NodeJS.ProcessEnv } => {
    const p = deps.ports()
    const wacliUrl = `http://127.0.0.1:${p.wacli}`
    if (name === 'wacli') {
      return { args: ['daemon'], env: { ...baseEnv, WACLI_HTTP_ADDR: `127.0.0.1:${p.wacli}` } }
    }
    const env: NodeJS.ProcessEnv = { ...baseEnv, KARMAX_WACLI_PATH: deps.paths.wacliExe(), KARMAX_WACLI_API_URL: wacliUrl }
    // KARMAX_HOME is this app's override (tests / portable installs); the daemon's own knob is KARMAX_DATA_DIR and it wins over the yaml.
    if (baseEnv.KARMAX_HOME?.trim()) env.KARMAX_DATA_DIR = deps.paths.dataDir()
    return { args: ['start', '--config', deps.paths.yamlFile()], env }
  }

  // ── lifecycle ──────────────────────────────────────────────────────────────

  const setExternal = (r: Rec): void => {
    r.misses = 0
    r.desired = true
    setState(r, 'external', { healthy: true, restarts: r.status.restarts })
    log.app('info', `${r.name}: something already answers on its port and was not started by KARMAX Desktop; attaching read-only (it will never be stopped from here).`)
  }

  const doStart = async (r: Rec, auto: boolean): Promise<void> => {
    if (auto && !r.desired) return
    if (!auto) r.desired = true
    clearBackoff(r)
    if (r.child) return // already starting/running under our control
    const bin = exePath(r.name)
    r.status.binaryPath = bin
    if (!exists(bin)) {
      // A daemon installed elsewhere may already be up.
      if (await probe(r.name)) return setExternal(r)
      r.desired = false
      setState(r, 'missing', { healthy: false, binaryPath: bin })
      log.app('warn', `${r.name}: binary not found at ${bin} (run the setup wizard to install it).`)
      return
    }
    if (await probe(r.name)) return setExternal(r)

    try {
      mkdirSync(deps.paths.dataDir(), { recursive: true })
    } catch {
      /* spawn reports a clearer error if it matters */
    }
    const { args, env } = buildSpawn(r.name)
    r.gen++
    const gen = r.gen
    r.tail = ''
    r.everHealthy = false
    r.finalized = false
    r.stopping = false
    r.misses = 0
    r.spawnError = undefined
    r.pendingExit = undefined
    let child: ChildProcess
    try {
      child = spawnFn(bin, args, { cwd: deps.paths.dataDir(), env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] })
    } catch (e) {
      r.spawnError = e as NodeJS.ErrnoException
      r.finalized = false
      r.child = undefined
      finalize(r, gen, null, undefined)
      return
    }
    r.child = child
    r.nextProbeAt = Date.now() + 300
    setState(r, 'starting', { healthy: false, pid: child.pid, startedAt: iso(), binaryPath: bin })
    log.app('info', `${r.name}: started (pid ${child.pid ?? '?'}) ${bin} ${args.join(' ')}`)

    const onData = (chunk: string | Buffer): void => {
      const text = typeof chunk === 'string' ? chunk : chunk.toString('utf8')
      r.tail = (r.tail + text).slice(-4096)
      log.ingest(r.name, text)
    }
    child.stdout?.setEncoding('utf8')
    child.stderr?.setEncoding('utf8')
    child.stdout?.on('data', onData)
    child.stderr?.on('data', onData)
    child.stdout?.on('error', () => undefined)
    child.stderr?.on('error', () => undefined)
    child.on('error', (err) => {
      if (gen !== r.gen) return
      r.spawnError = err as NodeJS.ErrnoException
      // A failed spawn never emits 'exit'; make sure we still finalize.
      finalize(r, gen, null, undefined)
    })
    child.on('exit', (code, signal) => {
      if (gen !== r.gen) return
      r.pendingExit = { code, ...(signal ? { signal } : {}) }
      // stdio may stay open if a grandchild inherited the pipes: do not wait for 'close' forever.
      if (!r.closeTimer) r.closeTimer = setTimeout(() => finalize(r, gen, code, signal ?? undefined), timing.closeGraceMs)
    })
    child.on('close', (code, signal) => {
      if (gen !== r.gen) return
      const pe = r.pendingExit
      finalize(r, gen, pe ? pe.code : code, pe?.signal ?? signal ?? undefined)
    })
  }

  function finalize(r: Rec, gen: number, code: number | null, signal: string | undefined): void {
    if (gen !== r.gen || r.finalized) return
    r.finalized = true
    if (r.closeTimer) clearTimeout(r.closeTimer)
    r.closeTimer = undefined
    if (r.resetTimer) clearTimeout(r.resetTimer)
    r.resetTimer = undefined
    r.child = undefined
    const at = iso()
    r.status = { ...r.status, healthy: false, lastExit: { code, ...(signal ? { signal } : {}), at } }
    const waiters = r.exitWaiters.splice(0)
    const wake = (): void => waiters.forEach((w) => w())

    if (r.stopping) {
      r.stopping = false
      setState(r, 'stopped')
      log.app('info', `${r.name}: stopped`)
      return wake()
    }

    const how = r.spawnError ? `failed to start (${r.spawnError.code ?? r.spawnError.message})` : `exited unexpectedly (code ${code ?? 'null'}${signal ? `, signal ${signal}` : ''})`
    log.app('warn', `${r.name}: ${how}`)

    if (r.spawnError?.code === 'ENOENT') {
      r.desired = false
      setState(r, 'missing')
    } else if (r.name === 'wacli' && NO_SESSION_RE.test(r.tail)) {
      // Not a crash: there is no paired WhatsApp session yet. Wait for the wizard to pair, then an explicit start().
      r.desired = false
      setState(r, 'stopped')
      log.app('warn', 'wacli: not logged in to WhatsApp yet. The daemon will not be restarted until pairing has finished (wacli login, then start).')
    } else if (!deps.setupCompleted() && !r.everHealthy) {
      // First-run wizard: fail visibly, do not crash-loop while the user is still configuring things.
      r.desired = false
      setState(r, 'crashed')
      log.app('warn', `${r.name}: crashed before setup finished; not restarting automatically.`)
    } else {
      const delay = backoffDelay(r.consecutive)
      r.consecutive++
      setState(r, 'crashed')
      const nextRestartAt = iso(Date.now() + delay)
      setState(r, 'backoff', { nextRestartAt })
      log.app('info', `${r.name}: restarting in ${Math.round(delay / 1000)}s (attempt ${r.status.restarts + 1})`)
      r.backoffTimer = setTimeout(() => {
        r.backoffTimer = undefined
        if (!r.desired) return
        r.status = { ...r.status, restarts: r.status.restarts + 1 }
        void enqueue(r, () => doStart(r, true)).catch((e) => log.app('error', `${r.name}: restart failed: ${String(e)}`))
      }, delay)
    }
    wake()
  }

  const sleepUntil = (ms: number, until: (cb: () => void) => void): Promise<boolean> =>
    new Promise((resolve) => {
      let done = false
      const t = setTimeout(() => {
        if (!done) {
          done = true
          resolve(false)
        }
      }, ms)
      until(() => {
        if (!done) {
          done = true
          clearTimeout(t)
          resolve(true)
        }
      })
    })

  /** Ask the child to end, escalating; resolves once the exit has been observed (or we gave up). */
  const killChild = async (r: Rec): Promise<void> => {
    const child = r.child
    if (!child) return
    const gen = r.gen
    const waitExit = (ms: number): Promise<boolean> => (r.child ? sleepUntil(ms, (cb) => r.exitWaiters.push(cb)) : Promise.resolve(true))

    if (platform === 'win32') {
      const accepted = await killTree(child, false)
      if (accepted && (await waitExit(timing.gracefulStopMs))) return
      await killTree(child, true)
      if (await waitExit(timing.forceStopMs)) return
    } else {
      await killTree(child, false)
      if (await waitExit(timing.termStopMs)) return
      await killTree(child, true)
      if (await waitExit(timing.forceStopMs)) return
    }
    log.app('error', `${r.name}: process did not exit after a forced kill; giving up on it.`)
    finalize(r, gen, null, 'SIGKILL')
  }

  const doStop = async (r: Rec): Promise<void> => {
    r.desired = false
    clearBackoff(r)
    if (r.status.state === 'external') {
      log.app('info', `${r.name}: not stopping an external process (KARMAX Desktop did not start it).`)
      return
    }
    if (!r.child) {
      if (r.status.state === 'backoff' || r.status.state === 'crashed' || r.status.state === 'starting') setState(r, 'stopped', { healthy: false })
      return
    }
    r.stopping = true
    await killChild(r)
  }

  // ── health monitor ─────────────────────────────────────────────────────────

  const probeRec = async (r: Rec): Promise<void> => {
    r.probing = true
    const gen = r.gen
    const stateAtStart = r.status.state
    try {
      const ok = await probe(r.name)
      if (gen !== r.gen || r.status.state !== stateAtStart) return // something changed while probing
      const now = Date.now()
      if (r.child && (stateAtStart === 'starting' || stateAtStart === 'running')) {
        if (ok) {
          r.misses = 0
          r.nextProbeAt = now + timing.runningProbeMs
          if (stateAtStart === 'starting') {
            r.everHealthy = true
            setState(r, 'running', { healthy: true })
            log.app('info', `${r.name}: healthy`)
            // Reset the backoff ladder only after a full minute of health, so a flapping daemon keeps climbing it.
            if (r.resetTimer) clearTimeout(r.resetTimer)
            r.resetTimer = setTimeout(() => {
              r.consecutive = 0
              r.resetTimer = undefined
            }, timing.healthyResetMs)
          } else if (!r.status.healthy) setState(r, 'running', { healthy: true })
        } else {
          r.misses++
          r.nextProbeAt = now + (stateAtStart === 'starting' ? timing.startingProbeMs : timing.runningProbeMs)
          if (stateAtStart === 'starting') {
            const started = r.status.startedAt ? Date.parse(r.status.startedAt) : now
            if (now - started > timing.startupGraceMs) {
              log.app('error', `${r.name}: not healthy ${Math.round(timing.startupGraceMs / 1000)}s after start; killing it to retry.`)
              void killChild(r)
            }
          } else if (r.misses >= timing.unhealthyAfterMisses && r.status.healthy) setState(r, 'running', { healthy: false })
        }
      } else if (stateAtStart === 'external') {
        r.nextProbeAt = now + timing.runningProbeMs
        if (ok) r.misses = 0
        else if (++r.misses >= timing.externalGoneAfterMisses) {
          r.desired = false
          setState(r, 'stopped', { healthy: false })
          log.app('info', `${r.name}: the external process is gone.`)
        }
      } else if (!r.child && !r.desired && (stateAtStart === 'stopped' || stateAtStart === 'missing' || stateAtStart === 'crashed')) {
        r.nextProbeAt = now + timing.runningProbeMs
        if (ok) setExternal(r)
      }
    } finally {
      r.probing = false
    }
  }

  const tick = (): void => {
    const now = Date.now()
    for (const n of NAMES) {
      const r = recs[n]
      if (r.probing || r.busy > 0 || now < r.nextProbeAt) continue
      if (r.status.state === 'backoff') continue
      void probeRec(r)
    }
  }

  // ── public API ─────────────────────────────────────────────────────────────

  const start = (name: ProcName): Promise<void> => enqueue(recs[name], () => doStart(recs[name], false))
  const stop = (name: ProcName): Promise<void> => enqueue(recs[name], () => doStop(recs[name]))
  const restart = async (name: ProcName): Promise<void> => {
    if (recs[name].status.state === 'external') log.app('warn', `${name}: cannot restart an external process from here.`)
    await stop(name)
    recs[name].consecutive = 0
    await start(name)
  }

  const waitHealthy = async (name: ProcName, timeoutMs: number): Promise<boolean> => {
    const r = recs[name]
    const deadline = Date.now() + timeoutMs
    for (;;) {
      if (r.status.healthy) return true
      if (Date.now() >= deadline) return false
      const st = r.status.state
      if (r.busy === 0 && (st === 'stopped' || st === 'missing' || st === 'crashed')) return false
      await new Promise<void>((res) => setTimeout(res, 100))
    }
  }

  return {
    status: snapshot,
    start,
    stop,
    restart,
    waitHealthy,
    onChange(cb) {
      listeners.add(cb)
      return () => void listeners.delete(cb)
    },
    startMonitor() {
      if (monitor) return
      monitor = setInterval(tick, timing.tickMs)
      monitor.unref?.()
    },
    async startAll() {
      await start('wacli')
      // karmax talks to wacli on start-up; give wacli a moment, but never block karmax on it (no session => it stays stopped).
      await waitHealthy('wacli', 20_000)
      await start('karmax')
    },
    async stopAll() {
      await stop('karmax')
      await stop('wacli')
    },
    async restartAll() {
      await stop('karmax')
      await stop('wacli')
      for (const n of NAMES) recs[n].consecutive = 0
      await start('wacli')
      await waitHealthy('wacli', 20_000)
      await start('karmax')
    },
    killAllSync() {
      for (const n of NAMES) {
        const r = recs[n]
        r.desired = false
        if (r.child) killTreeSync(r.child)
      }
    },
    dispose() {
      if (monitor) clearInterval(monitor)
      monitor = undefined
      for (const n of NAMES) {
        const r = recs[n]
        clearBackoff(r)
        if (r.resetTimer) clearTimeout(r.resetTimer)
        if (r.closeTimer) clearTimeout(r.closeTimer)
      }
      listeners.clear()
    }
  }
}
