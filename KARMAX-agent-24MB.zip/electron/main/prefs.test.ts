import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { DEFAULT_PREFS, createPrefs, sanitizePrefs } from './prefs'

describe('prefs', () => {
  const dirs: string[] = []
  const tmp = (): string => {
    const d = mkdtempSync(join(tmpdir(), 'karmax-prefs-'))
    dirs.push(d)
    return d
  }
  afterEach(() => {
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true })
  })

  it('defaults: openAtLogin off until the user opts in, minimizeToTray on', () => {
    expect(DEFAULT_PREFS).toEqual({ openAtLogin: false, minimizeToTray: true })
    expect(createPrefs(join(tmp(), 'prefs.json')).get()).toEqual(DEFAULT_PREFS)
  })
  it('sanitizes junk', () => {
    expect(sanitizePrefs({ openAtLogin: 'yes', minimizeToTray: 0, extra: 1 })).toEqual(DEFAULT_PREFS)
    expect(sanitizePrefs(null)).toEqual(DEFAULT_PREFS)
    expect(sanitizePrefs({ openAtLogin: true })).toEqual({ openAtLogin: true, minimizeToTray: true })
  })
  it('persists patches, notifies on change only, and survives a corrupt file', () => {
    const file = join(tmp(), 'sub', 'prefs.json')
    const p = createPrefs(file)
    const cb = vi.fn()
    p.onChange(cb)
    expect(p.set({ openAtLogin: true })).toEqual({ openAtLogin: true, minimizeToTray: true })
    p.set({ openAtLogin: true })
    expect(cb).toHaveBeenCalledTimes(1)
    expect(JSON.parse(readFileSync(file, 'utf8'))).toEqual({ openAtLogin: true, minimizeToTray: true })
    expect(createPrefs(file).get().openAtLogin).toBe(true)
    writeFileSync(file, '{not json')
    expect(createPrefs(file).get()).toEqual(DEFAULT_PREFS)
  })
})
