import { mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { LineBuffer, createLogSink, looksLikeContinuation, parseLine, parseZapTime, redact, stripAnsi } from './logs'

describe('stripAnsi', () => {
  it('removes colour and cursor sequences', () => {
    expect(stripAnsi('\u001b[31mred\u001b[0m and \u001b[1;33mbold yellow\u001b[0m')).toBe('red and bold yellow')
    expect(stripAnsi('\u001b[2K\u001b[1Gprogress')).toBe('progress')
  })
  it('leaves plain text alone', () => {
    expect(stripAnsi('plain [not ansi] text')).toBe('plain [not ansi] text')
  })
})

describe('parseZapTime', () => {
  it('handles the colon-less offset zap emits', () => {
    expect(parseZapTime('2026-09-19T12:00:00.000+0530')).toBe('2026-09-19T06:30:00.000Z')
    expect(parseZapTime('2026-09-19T12:00:00.000Z')).toBe('2026-09-19T12:00:00.000Z')
    expect(parseZapTime('nonsense')).toBeUndefined()
  })
})

describe('parseLine: zap development console', () => {
  it('parses level, message and the loop field', () => {
    const p = parseLine('2026-09-19T12:00:00.000+0530\tINFO\truntime/x.go:12\tloop finished\t{"loop":"gchat-watch"}')
    expect(p).toMatchObject({ level: 'info', loop: 'gchat-watch', message: 'loop finished', ts: '2026-09-19T06:30:00.000Z', structured: true })
  })
  it('keeps non-loop fields in the message', () => {
    const p = parseLine('2026-09-19T12:00:00.000+0530\tWARN\truntime/x.go:12\tslow tick\t{"loop":"a","elapsed":"3s"}')
    expect(p.level).toBe('warn')
    expect(p.loop).toBe('a')
    expect(p.message).toBe('slow tick {"elapsed":"3s"}')
  })
  it('handles a logger name segment and no fields', () => {
    const p = parseLine('2026-09-19T12:00:00.000+0530\tERROR\tcomms\tcomms/manager.go:99\tsend failed')
    expect(p).toMatchObject({ level: 'error', message: 'send failed' })
    expect(p.loop).toBeUndefined()
  })
  it('handles DEBUG and captures without a caller', () => {
    expect(parseLine('2026-09-19T12:00:00.000Z\tDEBUG\tjust a message').level).toBe('debug')
    expect(parseLine('2026-09-19T12:00:00.000Z\tDEBUG\tjust a message').message).toBe('just a message')
  })
  it('extracts the loopkit [loop:name] prefix', () => {
    const p = parseLine('2026-09-19T12:00:00.000+0530\tINFO\truntime/loophost.go:1133\t[loop:daily-brief] fetched 3 items')
    expect(p.loop).toBe('daily-brief')
    expect(p.message).toBe('fetched 3 items')
  })
})

describe('parseLine: zap JSON', () => {
  it('parses epoch-seconds ts, level, msg and loop', () => {
    const p = parseLine('{"level":"error","ts":1758268800.123,"caller":"runtime/x.go:12","msg":"boom","loop":"x","err":"bad"}')
    expect(p.level).toBe('error')
    expect(p.loop).toBe('x')
    expect(p.message).toBe('boom {"err":"bad"}')
    expect(p.ts).toBe(new Date(1758268800123).toISOString())
    expect(p.structured).toBe(true)
  })
  it('accepts an ISO ts and unknown levels default to info', () => {
    const p = parseLine('{"level":"weird","ts":"2026-09-19T12:00:00.000Z","msg":"hi"}')
    expect(p).toMatchObject({ level: 'info', message: 'hi', ts: '2026-09-19T12:00:00.000Z' })
  })
  it('does not treat arbitrary JSON as a log entry', () => {
    const p = parseLine('{"foo":1}')
    expect(p.structured).toBe(false)
    expect(p.message).toBe('{"foo":1}')
  })
  it('survives truncated JSON', () => {
    expect(parseLine('{"level":"info","msg":"cut').message).toBe('{"level":"info","msg":"cut')
  })
})

describe('parseLine: wacli formats', () => {
  it('whatsmeow logger', () => {
    expect(parseLine('12:00:00.123 [wacli WARN] failed to decrypt call key')).toMatchObject({ level: 'warn', message: 'failed to decrypt call key' })
    expect(parseLine('12:00:00.123 [wacli/Client ERROR] socket closed')).toMatchObject({ level: 'error' })
  })
  it('zerolog console', () => {
    expect(parseLine('12:00:00.123 INF relay ready peer=abc')).toMatchObject({ level: 'info', message: 'relay ready peer=abc' })
    expect(parseLine('12:00:00.123 ERR relay failed')).toMatchObject({ level: 'error' })
    expect(parseLine('12:00:00.123 DBG rtp')).toMatchObject({ level: 'debug' })
  })
})

describe('parseLine: plain lines', () => {
  it('defaults to info', () => {
    expect(parseLine('karmax stopped')).toMatchObject({ level: 'info', message: 'karmax stopped', structured: false })
  })
  it('detects obvious errors and warnings conservatively', () => {
    expect(parseLine('Error: listen tcp :9091: bind: address already in use').level).toBe('error')
    expect(parseLine('panic: runtime error: nil pointer').level).toBe('error')
    expect(parseLine('fatal error: all goroutines are asleep').level).toBe('error')
    expect(parseLine('[warn] disk almost full').level).toBe('warn')
    expect(parseLine('WARNING: something').level).toBe('warn')
    expect(parseLine('level=error msg="x"').level).toBe('error')
  })
  it('does not flag lines that merely contain the word error', () => {
    expect(parseLine('no errors found').level).toBe('info')
    expect(parseLine('error handling is enabled').level).toBe('info')
    expect(parseLine('retrying after warning window').level).toBe('info')
  })
  it('picks up loop=<name> text patterns', () => {
    expect(parseLine('run complete loop=nightly-sync ok=true').loop).toBe('nightly-sync')
    expect(parseLine('[loop:nightly-sync] hello')).toMatchObject({ loop: 'nightly-sync', message: 'hello' })
    expect(parseLine('nothing here').loop).toBeUndefined()
  })
})

describe('LineBuffer', () => {
  it('reassembles lines across chunks and handles CRLF', () => {
    const b = new LineBuffer()
    expect(b.push('hel')).toEqual([])
    expect(b.push('lo\r\nwor')).toEqual(['hello'])
    expect(b.push('ld\n\nlast')).toEqual(['world', ''])
    expect(b.flush()).toBe('last')
    expect(b.flush()).toBeUndefined()
  })
  it('force-flushes an enormous partial line', () => {
    const b = new LineBuffer(10)
    expect(b.push('x'.repeat(11))).toEqual(['x'.repeat(11)])
    expect(b.pending).toBe(false)
  })
})

describe('looksLikeContinuation', () => {
  it('recognises zap stack trace lines', () => {
    expect(looksLikeContinuation('\t/src/runtime/runtime.go:412')).toBe(true)
    expect(looksLikeContinuation('github.com/MelloB1989/karmax/internal/runtime.(*Runtime).Start')).toBe(true)
    expect(looksLikeContinuation('goroutine 1 [running]:')).toBe(true)
    expect(looksLikeContinuation('a normal sentence with spaces')).toBe(false)
  })
})

describe('redact', () => {
  it('scrubs bearer tokens, api keys and key=value secrets', () => {
    expect(redact('Authorization: Bearer abcdef1234567890')).not.toContain('abcdef1234567890')
    expect(redact('key sk-ant-api03-AAAAAAAAAAAAAAAAAAAA used')).not.toContain('AAAAAAAA')
    expect(redact('KARMAX_API_TOKEN=supersecretvalue')).toBe('KARMAX_API_TOKEN=[redacted]')
    expect(redact('{"token":"abcd1234"}')).toBe('{"token":"[redacted]"}')
    expect(redact('password: hunter22')).toBe('password: [redacted]')
  })
  it('scrubs exact known secrets anywhere', () => {
    expect(redact('the value is xyz-123-secret here', ['xyz-123-secret'])).toBe('the value is [redacted] here')
  })
  it('does not mangle ordinary text', () => {
    expect(redact('max_tokens=500 tokens used: 12')).toBe('max_tokens=500 tokens used: 12')
  })
})

describe('createLogSink', () => {
  const dirs: string[] = []
  const tmp = (): string => {
    const d = mkdtempSync(join(tmpdir(), 'karmax-logs-'))
    dirs.push(d)
    return d
  }
  afterEach(() => {
    vi.useRealTimers()
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true })
  })

  it('assigns monotonic seq, parses levels and honours history queries', () => {
    const sink = createLogSink()
    sink.ingest('karmax', '2026-09-19T12:00:00.000+0530\tINFO\tx.go:1\ta\t{"loop":"l1"}\n\u001b[31m2026-09-19T12:00:01.000+0530\tERROR\tx.go:2\tb\u001b[0m\n')
    sink.ingest('wacli', '12:00:00.000 [wacli WARN] w\n')
    sink.app('info', 'app line')
    const all = sink.history()
    expect(all.map((l) => l.seq)).toEqual([1, 2, 3, 4])
    expect(all.map((l) => [l.source, l.level, l.loop])).toEqual([
      ['karmax', 'info', 'l1'],
      ['karmax', 'error', undefined],
      ['wacli', 'warn', undefined],
      ['app', 'info', undefined]
    ])
    expect(sink.history({ source: 'karmax' })).toHaveLength(2)
    expect(sink.history({ level: 'warn' }).map((l) => l.message)).toEqual(['w'])
    expect(sink.history({ sinceSeq: 2 }).map((l) => l.seq)).toEqual([3, 4])
    expect(sink.history({ limit: 2 }).map((l) => l.seq)).toEqual([3, 4]) // newest N without a cursor
    expect(sink.history({ sinceSeq: 0, limit: 1 })).toHaveLength(1)
  })

  it('caps the ring buffer', () => {
    const sink = createLogSink({ ringSize: 5 })
    for (let i = 0; i < 12; i++) sink.app('info', `m${i}`)
    const h = sink.history({ limit: 100 })
    expect(h).toHaveLength(5)
    expect(h[0].message).toBe('m7')
    expect(h.at(-1)?.seq).toBe(12)
  })

  it('reassembles chunks and flushes an unterminated line after a delay', () => {
    vi.useFakeTimers()
    const sink = createLogSink()
    sink.ingest('wacli', 'hello wor')
    expect(sink.history()).toHaveLength(0)
    sink.ingest('wacli', 'ld\nprompt> ')
    expect(sink.history().map((l) => l.message)).toEqual(['hello world'])
    vi.advanceTimersByTime(1100)
    expect(sink.history().map((l) => l.message)).toEqual(['hello world', 'prompt>'])
  })

  it('keeps stack traces under an error entry at error level', () => {
    const sink = createLogSink()
    sink.ingest(
      'karmax',
      '2026-09-19T12:00:01.000+0530\tERROR\tx.go:2\tboom\ngithub.com/x/y.(*T).Run\n\t/src/y.go:10\n2026-09-19T12:00:02.000+0530\tINFO\tx.go:3\tafter\nplain follow-up\n'
    )
    expect(sink.history().map((l) => l.level)).toEqual(['error', 'error', 'error', 'info', 'info'])
  })

  it('never emits secrets, including the live API token', () => {
    const sink = createLogSink({ secrets: () => ['tok-live-123456'] })
    const seen: string[] = []
    sink.subscribe((l) => seen.push(l.message))
    sink.ingest('karmax', 'using tok-live-123456 and Bearer abcdefghijkl\n')
    expect(seen.join()).not.toContain('tok-live-123456')
    expect(seen.join()).not.toContain('abcdefghijkl')
  })

  it('persists per-source files and rotates by size', () => {
    vi.useFakeTimers()
    const dir = tmp()
    const sink = createLogSink({ dir, maxFileBytes: 200, maxFiles: 3, flushMs: 10 })
    for (let i = 0; i < 40; i++) {
      sink.ingest('karmax', `line number ${i} with some padding to take space\n`)
      vi.advanceTimersByTime(20)
    }
    sink.app('info', 'hello app')
    sink.close()
    const files = readdirSync(dir).sort()
    expect(files).toContain('karmax.log')
    expect(files).toContain('app.log')
    // 3 files max: karmax.log, karmax.log.1, karmax.log.2 — never .3
    expect(files.filter((f) => f.startsWith('karmax.log'))).toEqual(['karmax.log', 'karmax.log.1', 'karmax.log.2'])
    expect(readFileSync(join(dir, 'app.log'), 'utf8')).toMatch(/INFO\s+hello app/)
    expect(readFileSync(join(dir, 'karmax.log'), 'utf8')).toContain('line number 39')
  })

  it('appends to an existing log file across restarts', () => {
    const dir = tmp()
    writeFileSync(join(dir, 'app.log'), 'previous run\n')
    const sink = createLogSink({ dir })
    sink.app('info', 'next run')
    sink.close()
    const text = readFileSync(join(dir, 'app.log'), 'utf8')
    expect(text.startsWith('previous run\n')).toBe(true)
    expect(text).toContain('next run')
  })
})
