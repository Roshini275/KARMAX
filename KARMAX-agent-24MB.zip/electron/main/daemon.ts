/**
 * Proxy between the renderer and the two local daemons (implements `DaemonApi` from ./contracts).
 *
 *  - karmax  : http://127.0.0.1:<api.port> with `Authorization: Bearer <KARMAX_API_TOKEN>`. Only /api/ping is open
 *              (KARMAX/internal/api/server.go: "token gates everything except /api/ping").
 *  - wacli   : http://127.0.0.1:<port>, NO auth (wacli/wa/api.go registers plain handlers; wacli/wa/app.go binds
 *              127.0.0.1:8765 unless WACLI_HTTP_ADDR is set).
 *
 * The renderer only ever supplies a path + query. The base URL is fixed here, so a hostile or buggy renderer cannot use
 * this proxy to reach another host (SSRF) — see `validateProxyPath` — and it never sees the token.
 *
 * Ports come from ~/.karmax/karmax.yaml `api.port` (KARMAX/internal/config/types.go APIConfig: `port`) defaulting to 9091,
 * and `webhooks.port` defaulting to 9090 (config.go applyDefaults). KARMAX_API_PORT / KARMAX_WEBHOOK_PORT env vars beat the
 * file in the daemon, so they are honoured here too (process env first, then the ~/.karmax/.env the daemon also loads).
 */
import { existsSync, mkdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import YAML from 'yaml'
import type { ConnectionState, DaemonRequest, DaemonResponse, DaemonTarget } from '../../src/shared/ipc'
import type { DaemonApi, LogSink, Paths } from './contracts'

export const DEFAULT_KARMAX_PORT = 9091
export const DEFAULT_WEBHOOK_PORT = 9090
export const DEFAULT_WACLI_PORT = 8765
export const REQUEST_TIMEOUT_MS = 15_000
const PING_TIMEOUT_MS = 3_000

// ── validation (unit-tested; this is the SSRF boundary) ──────────────────────

export const ALLOWED_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] as const

export type Validation<T> = { ok: true; value: T } | { ok: false; error: string }

const fail = (error: string): { ok: false; error: string } => ({ ok: false, error })

// eslint-disable-next-line no-control-regex
const CONTROL_OR_SPACE_RE = /[\u0000- \u007f-\u009f]/

/**
 * A renderer-supplied path must be a plain absolute path on the *fixed* base URL. Rejected: anything not starting with a
 * single "/", protocol-relative "//host", schemes ("http://x" fails the leading-"/" rule; "/http://x" is harmless as a path
 * but ":" schemes in the first segment are not a thing after "/"), backslashes (browsers/WHATWG treat "\" as "/"), control
 * characters and spaces, "?"/"#" (queries go in `query`), and "." / ".." segments — also when percent-encoded.
 */
export function validateProxyPath(path: unknown): Validation<string> {
  if (typeof path !== 'string' || path.length === 0) return fail('path must be a non-empty string')
  if (path.length > 2048) return fail('path is too long')
  if (path[0] !== '/') return fail('path must start with "/"')
  if (path[1] === '/' || path[1] === '\\') return fail('path must not start with "//"')
  if (path.includes('\\')) return fail('path must not contain backslashes')
  if (CONTROL_OR_SPACE_RE.test(path)) return fail('path must not contain control characters or spaces')
  if (path.includes('?') || path.includes('#')) return fail('put the query string in `query`, not in `path`')
  if (path.includes('..')) return fail('path must not contain ".."')
  for (const seg of path.split('/')) {
    let decoded: string
    try {
      decoded = decodeURIComponent(seg)
    } catch {
      return fail('path contains a malformed percent-escape')
    }
    if (decoded === '.' || decoded === '..') return fail('path must not contain dot segments')
    if (decoded.includes('\\') || CONTROL_OR_SPACE_RE.test(decoded.replace(/ /g, '_'))) return fail('path contains a forbidden encoded character')
  }
  return { ok: true, value: path }
}

export function validateMethod(method: unknown): Validation<(typeof ALLOWED_METHODS)[number]> {
  if (typeof method !== 'string') return fail('method must be a string')
  const m = method.toUpperCase()
  return (ALLOWED_METHODS as readonly string[]).includes(m) ? { ok: true, value: m as (typeof ALLOWED_METHODS)[number] } : fail(`method ${method} is not allowed`)
}

export function validateTarget(target: unknown): Validation<DaemonTarget> {
  if (target === undefined || target === 'karmax') return { ok: true, value: 'karmax' }
  if (target === 'wacli') return { ok: true, value: 'wacli' }
  return fail('unknown target')
}

/** Build the final URL. Throws never: returns a Validation. Verifies the origin did not change. */
export function buildProxyUrl(base: string, path: string, query?: DaemonRequest['query']): Validation<string> {
  const p = validateProxyPath(path)
  if (!p.ok) return p
  let url: URL
  try {
    url = new URL(base + p.value)
  } catch {
    return fail('could not build URL')
  }
  const baseUrl = new URL(base)
  if (url.origin !== baseUrl.origin || url.username || url.password) return fail('request would leave the daemon origin')
  if (query !== undefined) {
    if (typeof query !== 'object' || query === null || Array.isArray(query)) return fail('query must be an object')
    for (const [k, v] of Object.entries(query)) {
      if (v === undefined) continue
      if (typeof v !== 'string' && typeof v !== 'number' && typeof v !== 'boolean') return fail(`query value for "${k}" must be a string, number or boolean`)
      url.searchParams.set(k, String(v))
    }
  }
  return { ok: true, value: url.toString() }
}

/** Minimal dotenv parser (KEY=VALUE, `export `, quotes, `#` comments) — enough for ~/.karmax/.env. */
export function parseEnvFile(text: string): Record<string, string> {
  const out: Record<string, string> = {}
  for (const rawLine of text.replace(/^﻿/, '').split(/\r?\n/)) {
    const line = rawLine.trim()
    if (!line || line.startsWith('#')) continue
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)\s*=\s*(.*)$/.exec(line)
    if (!m) continue
    let v = m[2].trim()
    if (v.startsWith('"') || v.startsWith("'")) {
      const q = v[0]
      const end = v.indexOf(q, 1)
      v = end > 0 ? v.slice(1, end) : v.slice(1)
      if (q === '"') v = v.replace(/\\n/g, '\n').replace(/\\"/g, '"')
    } else {
      const hash = v.search(/\s#/)
      if (hash >= 0) v = v.slice(0, hash).trim()
    }
    out[m[1]] = v
  }
  return out
}

export interface ResolvedPorts {
  karmax: number
  webhooks: number
  wacli: number
}

const asPort = (v: unknown): number | undefined => {
  const n = typeof v === 'number' ? v : typeof v === 'string' ? Number(v.trim()) : NaN
  return Number.isInteger(n) && n > 0 && n < 65536 ? n : undefined
}

/** `host:port`, `:port` or a bare port -> port. */
export function portFromAddr(addr: string | undefined): number | undefined {
  if (!addr) return undefined
  const m = /(?::|^)(\d{1,5})$/.exec(addr.trim())
  return m ? asPort(m[1]) : undefined
}

/**
 * Precedence mirrors the daemon (config.go applyDefaults): env var > karmax.yaml > default.
 * `fileEnv` is the parsed ~/.karmax/.env (the daemon loads it without overriding the real environment).
 */
export function resolvePorts(input: { yamlText?: string; env?: NodeJS.ProcessEnv; fileEnv?: Record<string, string>; overrides?: Partial<Pick<ResolvedPorts, 'karmax' | 'wacli'>> }): ResolvedPorts {
  let yamlKarmax: number | undefined
  let yamlWebhooks: number | undefined
  if (input.yamlText) {
    try {
      const doc: unknown = YAML.parse(input.yamlText)
      if (doc && typeof doc === 'object') {
        const d = doc as { api?: { port?: unknown }; webhooks?: { port?: unknown } }
        yamlKarmax = asPort(d.api?.port)
        yamlWebhooks = asPort(d.webhooks?.port)
      }
    } catch {
      /* invalid yaml: use defaults */
    }
  }
  const env = input.env ?? {}
  const fileEnv = input.fileEnv ?? {}
  const pick = (k: string): string | undefined => (env[k]?.trim() ? env[k] : fileEnv[k])
  return {
    karmax: input.overrides?.karmax ?? asPort(pick('KARMAX_API_PORT')) ?? yamlKarmax ?? DEFAULT_KARMAX_PORT,
    webhooks: asPort(pick('KARMAX_WEBHOOK_PORT')) ?? yamlWebhooks ?? DEFAULT_WEBHOOK_PORT,
    // wacli does not read ~/.karmax/.env; its listen address is WACLI_HTTP_ADDR (wacli/wa/app.go).
    wacli: input.overrides?.wacli ?? portFromAddr(env.WACLI_HTTP_ADDR) ?? DEFAULT_WACLI_PORT
  }
}

/** Parse a response body: JSON when it looks like JSON, otherwise the raw text ("" -> null). */
export function parseBody(text: string, contentType: string | null): unknown {
  if (!text) return null
  const t = text.trimStart()
  if ((contentType ?? '').toLowerCase().includes('json') || t.startsWith('{') || t.startsWith('[')) {
    try {
      return JSON.parse(text)
    } catch {
      /* fall through to text */
    }
  }
  return text
}

/** Split an NDJSON byte-decoded stream into parsed JSON values. Malformed lines are skipped. */
export function createNdjsonParser(onValue: (v: unknown) => void, maxLine = 8 * 1024 * 1024): { push(chunk: string): void; end(): void } {
  let buf = ''
  const emit = (raw: string): void => {
    const line = raw.trim()
    if (!line) return
    try {
      onValue(JSON.parse(line))
    } catch {
      /* skip malformed line, same as the browser shim */
    }
  }
  return {
    push(chunk) {
      buf += chunk
      let nl: number
      while ((nl = buf.indexOf('\n')) >= 0) {
        emit(buf.slice(0, nl))
        buf = buf.slice(nl + 1)
      }
      if (buf.length > maxLine) {
        buf = '' // a single line this big is not a ChatEvent; drop rather than grow without bound
      }
    },
    end() {
      emit(buf)
      buf = ''
    }
  }
}

// ── secret storage ───────────────────────────────────────────────────────────

/** The slice of Electron's `safeStorage` we use (injected so tests need no Electron). */
export interface SecretBox {
  isEncryptionAvailable(): boolean
  encryptString(plain: string): Buffer
  decryptString(encrypted: Buffer): string
}

export interface TokenStore {
  load(): string | undefined
  save(token: string): void
  /** True when the token sits unencrypted on disk (safeStorage unavailable). */
  readonly plaintextFallback: boolean
}

const ENC_FILE = 'karmax-api-token.bin'
const PLAIN_FILE = 'karmax-api-token.UNENCRYPTED.json'

export function createTokenStore(dir: string, box?: SecretBox): TokenStore {
  const enc = join(dir, ENC_FILE)
  const plain = join(dir, PLAIN_FILE)
  let plaintextFallback = false
  const canEncrypt = (): boolean => {
    try {
      return !!box && box.isEncryptionAvailable()
    } catch {
      return false
    }
  }
  const readPlain = (): string | undefined => {
    try {
      const j: unknown = JSON.parse(readFileSync(plain, 'utf8'))
      return j && typeof j === 'object' && typeof (j as { token?: unknown }).token === 'string' ? ((j as { token: string }).token || undefined) : undefined
    } catch {
      return undefined
    }
  }
  const writeEnc = (token: string): void => {
    mkdirSync(dir, { recursive: true })
    writeFileSync(enc, box!.encryptString(token), { mode: 0o600 })
  }
  return {
    get plaintextFallback() {
      return plaintextFallback
    },
    load() {
      try {
        if (existsSync(enc) && canEncrypt()) {
          const t = box!.decryptString(readFileSync(enc)).trim()
          if (t) return t
        }
      } catch {
        /* corrupt blob or different user/machine: fall through */
      }
      const p = readPlain()
      if (p) {
        if (canEncrypt()) {
          // Encryption became available: migrate off the plaintext file.
          try {
            writeEnc(p)
            unlinkSync(plain)
          } catch {
            plaintextFallback = true
          }
        } else plaintextFallback = true
      }
      return p
    },
    save(token) {
      mkdirSync(dir, { recursive: true })
      if (canEncrypt()) {
        writeEnc(token)
        plaintextFallback = false
        if (existsSync(plain)) {
          try {
            unlinkSync(plain)
          } catch {
            /* ignore */
          }
        }
        return
      }
      plaintextFallback = true
      writeFileSync(
        plain,
        JSON.stringify({ _warning: 'safeStorage encryption is unavailable on this system, so this token is stored UNENCRYPTED. Protect this file.', token }, null, 2),
        { mode: 0o600 }
      )
    }
  }
}

// ── the service ──────────────────────────────────────────────────────────────

export interface StreamEvent {
  line?: unknown
  end?: true
  error?: string
}

export interface StreamControl {
  abort(): void
}

export interface DaemonService extends DaemonApi {
  ports(): ResolvedPorts
  baseUrl(target: DaemonTarget): string
  hasToken(): boolean
  connection(): Promise<ConnectionState>
  /** Start an NDJSON POST stream; `emit` receives lines, then exactly one of `end` / `error`. */
  stream(req: DaemonRequest, emit: (e: StreamEvent) => void): StreamControl
  /** Fires when the token or ports change (so main can refresh the ConnectionState immediately). */
  onConfigChange(cb: () => void): () => void
  /** Where the token currently lives, for diagnostics (never the token itself). */
  storageKind(): 'safeStorage' | 'plaintext-fallback' | 'env-file' | 'none'
}

export interface DaemonOptions {
  paths: Pick<Paths, 'envFile' | 'yamlFile' | 'userData'> & { secretsDir?: () => string }
  log?: Pick<LogSink, 'app'>
  safeStorage?: SecretBox
  env?: NodeJS.ProcessEnv
  fetchImpl?: typeof fetch
}

function errorText(e: unknown): string {
  return e instanceof Error ? e.message : String(e)
}

function extractError(body: unknown, status: number): string {
  if (body && typeof body === 'object' && 'error' in body && typeof (body as { error: unknown }).error === 'string') return (body as { error: string }).error
  if (typeof body === 'string' && body.trim()) return body.trim().slice(0, 300)
  return `Request failed (${status})`
}

export function createDaemon(opts: DaemonOptions): DaemonService {
  const env = opts.env ?? process.env
  const doFetch: typeof fetch = opts.fetchImpl ?? ((input, init) => fetch(input, init))
  const secretsDir = opts.paths.secretsDir?.() ?? join(opts.paths.userData(), 'secrets')
  const store = createTokenStore(secretsDir, opts.safeStorage)

  let token: string | undefined
  let tokenSource: 'safeStorage' | 'plaintext-fallback' | 'env-file' | 'none' = 'none'
  let overrides: Partial<Pick<ResolvedPorts, 'karmax' | 'wacli'>> = {}
  const configListeners = new Set<() => void>()
  const notify = (): void => {
    for (const cb of configListeners) {
      try {
        cb()
      } catch {
        /* ignore */
      }
    }
  }

  // cache for yaml/.env so ports() is cheap enough to call per request
  let cache: { key: string; ports: ResolvedPorts } | undefined
  const statKey = (p: string): string => {
    try {
      const s = statSync(p)
      return `${s.mtimeMs}:${s.size}`
    } catch {
      return 'absent'
    }
  }
  const readEnvFile = (): Record<string, string> => {
    try {
      return parseEnvFile(readFileSync(opts.paths.envFile(), 'utf8'))
    } catch {
      return {}
    }
  }

  const ports = (): ResolvedPorts => {
    const key = `${statKey(opts.paths.yamlFile())}|${statKey(opts.paths.envFile())}|${overrides.karmax ?? ''}|${overrides.wacli ?? ''}|${env.KARMAX_API_PORT ?? ''}|${env.KARMAX_WEBHOOK_PORT ?? ''}|${env.WACLI_HTTP_ADDR ?? ''}`
    if (cache && cache.key === key) return cache.ports
    let yamlText: string | undefined
    try {
      yamlText = readFileSync(opts.paths.yamlFile(), 'utf8')
    } catch {
      yamlText = undefined
    }
    const resolved = resolvePorts({ yamlText, env, fileEnv: readEnvFile(), overrides })
    cache = { key, ports: resolved }
    return resolved
  }

  const baseUrl = (target: DaemonTarget): string => `http://127.0.0.1:${target === 'wacli' ? ports().wacli : ports().karmax}`

  // Token: stored (safeStorage) first; otherwise KARMAX_API_TOKEN from ~/.karmax/.env (what the daemon itself uses).
  const initToken = (): void => {
    const stored = store.load()
    if (stored) {
      token = stored
      tokenSource = store.plaintextFallback ? 'plaintext-fallback' : 'safeStorage'
      if (store.plaintextFallback) opts.log?.app('warn', 'safeStorage is unavailable: the API token is stored unencrypted in the app data folder.')
      return
    }
    const fromEnv = readEnvFile().KARMAX_API_TOKEN?.trim()
    if (fromEnv) {
      token = fromEnv
      tokenSource = 'env-file'
      try {
        store.save(fromEnv)
        tokenSource = store.plaintextFallback ? 'plaintext-fallback' : 'safeStorage'
      } catch {
        /* keep the in-memory token */
      }
    }
  }
  initToken()

  const adoptEnvTokenIfChanged = (): boolean => {
    const fromEnv = readEnvFile().KARMAX_API_TOKEN?.trim()
    if (fromEnv && fromEnv !== token) {
      token = fromEnv
      try {
        store.save(fromEnv)
      } catch {
        /* keep in memory */
      }
      notify()
      return true
    }
    return false
  }

  const headers = (target: DaemonTarget, hasBody: boolean): Record<string, string> => {
    const h: Record<string, string> = { Accept: 'application/json, text/plain, */*' }
    if (hasBody) h['Content-Type'] = 'application/json'
    if (target === 'karmax' && token) h.Authorization = `Bearer ${token}`
    return h
  }

  interface Prepared {
    target: DaemonTarget
    method: (typeof ALLOWED_METHODS)[number]
    url: string
    body: string | undefined
  }

  const prepare = (req: DaemonRequest): Validation<Prepared> => {
    if (!req || typeof req !== 'object') return fail('invalid request')
    const target = validateTarget(req.target)
    if (!target.ok) return target
    const method = validateMethod(req.method)
    if (!method.ok) return method
    const url = buildProxyUrl(baseUrl(target.value), req.path, req.query)
    if (!url.ok) return url
    let body: string | undefined
    if (req.body !== undefined && method.value !== 'GET') {
      try {
        body = JSON.stringify(req.body)
      } catch {
        return fail('request body is not serialisable')
      }
    }
    return { ok: true, value: { target: target.value, method: method.value, url: url.value, body } }
  }

  const send = async (p: Prepared): Promise<DaemonResponse> => {
    const res = await doFetch(p.url, {
      method: p.method,
      headers: headers(p.target, p.body !== undefined),
      body: p.body,
      redirect: 'manual',
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
    })
    const text = await res.text()
    return { ok: res.ok, status: res.status, body: parseBody(text, res.headers.get('content-type')) }
  }

  const request = async (req: DaemonRequest): Promise<DaemonResponse> => {
    const prepared = prepare(req)
    if (!prepared.ok) return { ok: false, status: 400, body: { error: `Blocked request: ${prepared.error}` } }
    try {
      let res = await send(prepared.value)
      if (res.status === 401 && prepared.value.target === 'karmax' && adoptEnvTokenIfChanged()) res = await send(prepared.value)
      return res
    } catch (e) {
      const timedOut = e instanceof Error && (e.name === 'TimeoutError' || e.name === 'AbortError')
      return {
        ok: false,
        status: 0,
        body: { error: timedOut ? `Daemon did not answer within ${REQUEST_TIMEOUT_MS / 1000}s` : `Cannot reach daemon: ${errorText(e)}` }
      }
    }
  }

  const stream = (req: DaemonRequest, emit: (e: StreamEvent) => void): StreamControl => {
    const ctl = new AbortController()
    let finished = false
    const finish = (e: StreamEvent): void => {
      if (finished) return
      finished = true
      emit(e)
    }
    void (async () => {
      const prepared = prepare(req)
      if (!prepared.ok) return finish({ error: `Blocked request: ${prepared.error}` })
      if (prepared.value.method !== 'POST') return finish({ error: 'Streaming requests must use POST' })
      try {
        let res = await doFetch(prepared.value.url, {
          method: 'POST',
          headers: headers(prepared.value.target, prepared.value.body !== undefined),
          body: prepared.value.body,
          redirect: 'manual',
          signal: ctl.signal
        })
        if (res.status === 401 && prepared.value.target === 'karmax' && adoptEnvTokenIfChanged()) {
          res = await doFetch(prepared.value.url, {
            method: 'POST',
            headers: headers(prepared.value.target, prepared.value.body !== undefined),
            body: prepared.value.body,
            redirect: 'manual',
            signal: ctl.signal
          })
        }
        if (!res.ok || !res.body) {
          const t = await res.text().catch(() => '')
          return finish({ error: extractError(parseBody(t, res.headers.get('content-type')), res.status) })
        }
        const reader = res.body.getReader()
        const dec = new TextDecoder()
        const parser = createNdjsonParser((line) => {
          if (!finished) emit({ line })
        })
        for (;;) {
          const { value, done } = await reader.read()
          if (done) break
          parser.push(dec.decode(value, { stream: true }))
        }
        parser.push(dec.decode())
        parser.end()
        finish({ end: true })
      } catch (e) {
        // Aborting is a normal end from the renderer's point of view (matches the browser shim).
        if (ctl.signal.aborted || (e instanceof Error && e.name === 'AbortError')) finish({ end: true })
        else finish({ error: `Stream failed: ${errorText(e)}` })
      }
    })()
    return {
      abort: () => {
        ctl.abort()
        finish({ end: true })
      }
    }
  }

  const connection = async (): Promise<ConnectionState> => {
    const base: ConnectionState = {
      mode: 'electron',
      karmaxUrl: baseUrl('karmax'),
      wacliUrl: baseUrl('wacli'),
      hasToken: !!token,
      reachable: false
    }
    try {
      const res = await doFetch(`${base.karmaxUrl}/api/ping`, { redirect: 'manual', signal: AbortSignal.timeout(PING_TIMEOUT_MS) })
      const body = parseBody(await res.text(), res.headers.get('content-type')) as { service?: string; version?: string; agent?: string } | string | null
      if (res.ok && body && typeof body === 'object' && body.service === 'karmax') {
        return { ...base, reachable: true, version: body.version, agent: body.agent }
      }
    } catch {
      /* unreachable */
    }
    return base
  }

  return {
    request,
    stream,
    connection,
    ports,
    baseUrl,
    hasToken: () => !!token,
    getToken: () => token,
    setToken(t) {
      const next = t.trim()
      if (!next) return
      token = next
      try {
        store.save(next)
        tokenSource = store.plaintextFallback ? 'plaintext-fallback' : 'safeStorage'
        if (store.plaintextFallback) opts.log?.app('warn', 'safeStorage is unavailable: the API token is stored unencrypted in the app data folder.')
      } catch (e) {
        opts.log?.app('error', `Could not persist the API token: ${errorText(e)}`)
      }
      notify()
    },
    setPorts(p) {
      overrides = { ...overrides, ...(p.karmax ? { karmax: p.karmax } : {}), ...(p.wacli ? { wacli: p.wacli } : {}) }
      cache = undefined
      notify()
    },
    onConfigChange(cb) {
      configListeners.add(cb)
      return () => void configListeners.delete(cb)
    },
    storageKind: () => tokenSource
  }
}
