import { mkdtempSync, readFileSync, existsSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  buildProxyUrl,
  createDaemon,
  createNdjsonParser,
  createTokenStore,
  parseBody,
  parseEnvFile,
  portFromAddr,
  resolvePorts,
  validateMethod,
  validateProxyPath,
  validateTarget,
  type SecretBox,
  type StreamEvent
} from './daemon'

describe('validateProxyPath (SSRF boundary)', () => {
  const good = ['/api/ping', '/api/loops', '/api/chat/conversations/abc-123', '/status', '/api/loops/registry/my%20loop', '/api/x/a%2Fb', '/']
  it.each(good)('accepts %s', (p) => {
    expect(validateProxyPath(p).ok).toBe(true)
  })

  const bad: Array<[string, string]> = [
    ['//evil.com', 'protocol-relative'],
    ['//evil.com/api/loops', 'protocol-relative with path'],
    ['/\\evil.com', 'slash-backslash'],
    ['\\\\evil.com', 'UNC style'],
    ['\\evil', 'leading backslash'],
    ['/..', 'parent dir'],
    ['/../etc/passwd', 'parent dir traversal'],
    ['/api/../../x', 'nested traversal'],
    ['/api/%2e%2e/x', 'encoded dot-dot'],
    ['/api/%2E%2E/x', 'encoded dot-dot uppercase'],
    ['/api/%2e/x', 'encoded single dot'],
    ['/api/./x', 'single dot'],
    ['http://x', 'absolute URL'],
    ['https://evil.com/api', 'absolute https URL'],
    ['evil.com/api', 'no leading slash'],
    ['api/loops', 'relative'],
    ['', 'empty'],
    ['/api/a\\b', 'backslash mid-path'],
    ['/api/a%5Cb', 'encoded backslash'],
    ['/api/x\r\nHost: evil', 'CRLF injection'],
    ['/api/x\u0000', 'NUL'],
    ['/api/x y', 'space'],
    ['/api/x?y=1', 'query in path'],
    ['/api/x#frag', 'fragment in path'],
    ['/api/%zz', 'malformed percent-escape'],
    ['/api/%00', 'encoded NUL'],
    ['/api/%0d%0a', 'encoded CRLF']
  ]
  it.each(bad)('rejects %j (%s)', (p) => {
    expect(validateProxyPath(p).ok).toBe(false)
  })

  it('rejects non-strings and absurd lengths', () => {
    expect(validateProxyPath(undefined).ok).toBe(false)
    expect(validateProxyPath(42).ok).toBe(false)
    expect(validateProxyPath({ toString: () => '/x' }).ok).toBe(false)
    expect(validateProxyPath('/' + 'a'.repeat(3000)).ok).toBe(false)
  })
})

describe('buildProxyUrl', () => {
  const base = 'http://127.0.0.1:9091'
  it('joins base + path + query, skipping undefined', () => {
    const r = buildProxyUrl(base, '/api/loops', { a: 1, b: 'x y', c: true, d: undefined })
    expect(r).toEqual({ ok: true, value: 'http://127.0.0.1:9091/api/loops?a=1&b=x+y&c=true' })
  })
  it('never changes origin, whatever the path says', () => {
    for (const p of ['//evil.com', '/\\evil.com', 'http://evil.com', '@evil.com', ':80/x', '/api/@evil.com']) {
      const r = buildProxyUrl(base, p)
      if (r.ok) expect(new URL(r.value).origin).toBe('http://127.0.0.1:9091')
    }
    expect(buildProxyUrl(base, '@evil.com').ok).toBe(false)
    expect(buildProxyUrl(base, '//evil.com').ok).toBe(false)
  })
  it('rejects malformed query objects', () => {
    expect(buildProxyUrl(base, '/x', 'a=1' as never).ok).toBe(false)
    expect(buildProxyUrl(base, '/x', { a: { b: 1 } } as never).ok).toBe(false)
  })
  it('query values cannot smuggle a host', () => {
    const r = buildProxyUrl(base, '/x', { next: 'http://evil.com', 'a&b': 'c#d' })
    expect(r.ok && new URL(r.value).host).toBe('127.0.0.1:9091')
  })
})

describe('method / target validation', () => {
  it('allows only the known methods, case-insensitively', () => {
    expect(validateMethod('get')).toEqual({ ok: true, value: 'GET' })
    for (const m of ['POST', 'PUT', 'PATCH', 'DELETE']) expect(validateMethod(m).ok).toBe(true)
    for (const m of ['CONNECT', 'TRACE', 'OPTIONS', 'HEAD', 'GET /x HTTP/1.1', '', 5]) expect(validateMethod(m as never).ok).toBe(false)
  })
  it('only knows karmax and wacli', () => {
    expect(validateTarget(undefined)).toEqual({ ok: true, value: 'karmax' })
    expect(validateTarget('wacli')).toEqual({ ok: true, value: 'wacli' })
    expect(validateTarget('http://evil.com').ok).toBe(false)
    expect(validateTarget('evil').ok).toBe(false)
  })
})

describe('parseEnvFile', () => {
  it('parses dotenv syntax', () => {
    const env = parseEnvFile(
      '﻿# comment\nKARMAX_API_TOKEN=abc123\nexport ANTHROPIC_API_KEY="sk-ant-x y"\nQUOTED=\'single # kept\'\nINLINE=val # trailing\nEMPTY=\nnot a line\n  SPACED = padded  \r\nWIN=1\r\n'
    )
    expect(env.KARMAX_API_TOKEN).toBe('abc123')
    expect(env.ANTHROPIC_API_KEY).toBe('sk-ant-x y')
    expect(env.QUOTED).toBe('single # kept')
    expect(env.INLINE).toBe('val')
    expect(env.EMPTY).toBe('')
    expect(env.SPACED).toBe('padded')
    expect(env.WIN).toBe('1')
  })
})

describe('resolvePorts', () => {
  it('defaults', () => {
    expect(resolvePorts({})).toEqual({ karmax: 9091, webhooks: 9090, wacli: 8765 })
  })
  it('reads api.port and webhooks.port from karmax.yaml', () => {
    expect(resolvePorts({ yamlText: 'karmax:\n  data_dir: ~/.karmax\nwebhooks:\n  port: 9190\napi:\n  enabled: true\n  port: 9191\n' })).toMatchObject({ karmax: 9191, webhooks: 9190 })
  })
  it('env beats yaml (as in the daemon), process env beats .env, overrides beat all', () => {
    const yamlText = 'api:\n  port: 9191\n'
    expect(resolvePorts({ yamlText, fileEnv: { KARMAX_API_PORT: '9300' } }).karmax).toBe(9300)
    expect(resolvePorts({ yamlText, fileEnv: { KARMAX_API_PORT: '9300' }, env: { KARMAX_API_PORT: '9400' } }).karmax).toBe(9400)
    expect(resolvePorts({ yamlText, env: { KARMAX_API_PORT: '9400' }, overrides: { karmax: 9500 } }).karmax).toBe(9500)
  })
  it('ignores garbage and unparsable yaml', () => {
    expect(resolvePorts({ yamlText: 'api:\n  port: banana\n' }).karmax).toBe(9091)
    expect(resolvePorts({ yamlText: ': : :\n\t- [' }).karmax).toBe(9091)
    expect(resolvePorts({ yamlText: 'api:\n  port: 99999\n' }).karmax).toBe(9091)
  })
  it('derives the wacli port from WACLI_HTTP_ADDR', () => {
    expect(resolvePorts({ env: { WACLI_HTTP_ADDR: '127.0.0.1:8899' } }).wacli).toBe(8899)
    expect(portFromAddr(':8123')).toBe(8123)
    expect(portFromAddr('8124')).toBe(8124)
    expect(portFromAddr('localhost')).toBeUndefined()
  })
})

describe('parseBody', () => {
  it('parses JSON by content type or shape, else returns text', () => {
    expect(parseBody('{"a":1}', 'application/json')).toEqual({ a: 1 })
    expect(parseBody('[1,2]', 'text/plain')).toEqual([1, 2])
    expect(parseBody('OK', 'text/plain')).toBe('OK')
    expect(parseBody('{broken', 'application/json')).toBe('{broken')
    expect(parseBody('', 'application/json')).toBeNull()
  })
})

describe('createNdjsonParser', () => {
  it('handles split chunks, blank lines and malformed lines', () => {
    const got: unknown[] = []
    const p = createNdjsonParser((v) => got.push(v))
    p.push('{"type":"mess')
    p.push('age","text":"hi"}\n\n{bad json}\n{"type":"meta"}')
    p.end()
    expect(got).toEqual([{ type: 'message', text: 'hi' }, { type: 'meta' }])
  })
})

describe('token store', () => {
  const dirs: string[] = []
  const tmp = (): string => {
    const d = mkdtempSync(join(tmpdir(), 'karmax-daemon-'))
    dirs.push(d)
    return d
  }
  afterEach(() => {
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true })
  })
  const fakeBox = (available = true): SecretBox => ({
    isEncryptionAvailable: () => available,
    encryptString: (s) => Buffer.from(`ENC:${Buffer.from(s).toString('base64')}`),
    decryptString: (b) => Buffer.from(b.toString().replace(/^ENC:/, ''), 'base64').toString()
  })

  it('round-trips through safeStorage and never writes the plaintext token', () => {
    const dir = tmp()
    const s = createTokenStore(dir, fakeBox())
    s.save('super-secret-token')
    expect(readFileSync(join(dir, 'karmax-api-token.bin'), 'utf8')).not.toContain('super-secret-token')
    expect(createTokenStore(dir, fakeBox()).load()).toBe('super-secret-token')
    expect(s.plaintextFallback).toBe(false)
  })
  it('falls back to a clearly-marked plaintext file when encryption is unavailable', () => {
    const dir = tmp()
    const s = createTokenStore(dir, fakeBox(false))
    s.save('tok')
    expect(s.plaintextFallback).toBe(true)
    const raw = readFileSync(join(dir, 'karmax-api-token.UNENCRYPTED.json'), 'utf8')
    expect(raw).toMatch(/UNENCRYPTED/)
    expect(createTokenStore(dir, fakeBox(false)).load()).toBe('tok')
  })
  it('migrates a plaintext token once encryption becomes available', () => {
    const dir = tmp()
    createTokenStore(dir, fakeBox(false)).save('tok')
    const s2 = createTokenStore(dir, fakeBox(true))
    expect(s2.load()).toBe('tok')
    expect(existsSync(join(dir, 'karmax-api-token.UNENCRYPTED.json'))).toBe(false)
    expect(existsSync(join(dir, 'karmax-api-token.bin'))).toBe(true)
  })
  it('returns undefined when nothing is stored or the blob is corrupt', () => {
    const dir = tmp()
    expect(createTokenStore(dir, fakeBox()).load()).toBeUndefined()
    writeFileSync(join(dir, 'karmax-api-token.bin'), 'garbage')
    const broken: SecretBox = { ...fakeBox(), decryptString: () => { throw new Error('bad') } }
    expect(createTokenStore(dir, broken).load()).toBeUndefined()
  })
})

describe('createDaemon', () => {
  const dirs: string[] = []
  const setup = (opts: { env?: string; yaml?: string; token?: string } = {}) => {
    const dir = mkdtempSync(join(tmpdir(), 'karmax-daemon-'))
    dirs.push(dir)
    const envFile = join(dir, '.env')
    const yamlFile = join(dir, 'karmax.yaml')
    if (opts.env !== undefined) writeFileSync(envFile, opts.env)
    if (opts.yaml !== undefined) writeFileSync(yamlFile, opts.yaml)
    const calls: Array<{ url: string; init: RequestInit }> = []
    return { dir, envFile, yamlFile, calls }
  }
  afterEach(() => {
    vi.restoreAllMocks()
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true })
  })

  const json = (body: unknown, status = 200): Response => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })

  it('falls back to KARMAX_API_TOKEN from the .env file and sends it as a bearer to karmax only', async () => {
    const s = setup({ env: 'KARMAX_API_TOKEN=envtok\n' })
    const fetchImpl = vi.fn(async (url: string | URL | Request, init?: RequestInit) => {
      s.calls.push({ url: String(url), init: init ?? {} })
      return json({ ok: true })
    })
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    expect(d.getToken()).toBe('envtok')
    await d.request({ method: 'GET', path: '/api/loops' })
    await d.request({ target: 'wacli', method: 'GET', path: '/status' })
    expect(s.calls[0].url).toBe('http://127.0.0.1:9091/api/loops')
    expect((s.calls[0].init.headers as Record<string, string>).Authorization).toBe('Bearer envtok')
    expect(s.calls[1].url).toBe('http://127.0.0.1:8765/status')
    expect((s.calls[1].init.headers as Record<string, string>).Authorization).toBeUndefined() // wacli has no auth
  })

  it('a stored token wins over .env; setToken persists and is used', async () => {
    const s = setup({ env: 'KARMAX_API_TOKEN=envtok\n' })
    const paths = { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }
    const d1 = createDaemon({ paths, env: {}, fetchImpl: vi.fn() as never })
    d1.setToken('newtok')
    const d2 = createDaemon({ paths, env: {}, fetchImpl: vi.fn() as never })
    expect(d2.getToken()).toBe('newtok')
  })

  it('refuses hostile paths without touching the network', async () => {
    const s = setup()
    const fetchImpl = vi.fn()
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    for (const path of ['//evil.com', '/..', 'http://x', '\\\\evil']) {
      const r = await d.request({ method: 'GET', path })
      expect(r.ok).toBe(false)
      expect(r.status).toBe(400)
    }
    expect((await d.request({ method: 'TRACE', path: '/x' })).status).toBe(400)
    expect((await d.request({ target: 'evil' as never, method: 'GET', path: '/x' })).status).toBe(400)
    expect(fetchImpl).not.toHaveBeenCalled()
  })

  it('uses the api.port from karmax.yaml and reflects later edits', async () => {
    const s = setup({ yaml: 'api:\n  port: 9555\n' })
    const urls: string[] = []
    const fetchImpl = vi.fn(async (u: string | URL | Request) => {
      urls.push(String(u))
      return json({})
    })
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    await d.request({ method: 'GET', path: '/api/ping' })
    d.setPorts({ karmax: 9777 })
    await d.request({ method: 'GET', path: '/api/ping' })
    expect(urls).toEqual(['http://127.0.0.1:9555/api/ping', 'http://127.0.0.1:9777/api/ping'])
  })

  it('maps network failures and non-JSON bodies', async () => {
    const s = setup()
    let mode: 'down' | 'text' | 'empty' = 'down'
    const fetchImpl = vi.fn(async () => {
      if (mode === 'down') throw new TypeError('fetch failed')
      if (mode === 'empty') return new Response(null, { status: 204 })
      return new Response('plain text', { status: 500, headers: { 'content-type': 'text/plain' } })
    })
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    const down = await d.request({ method: 'GET', path: '/x' })
    expect(down).toMatchObject({ ok: false, status: 0 })
    expect(JSON.stringify(down.body)).toMatch(/Cannot reach daemon/)
    mode = 'text'
    expect(await d.request({ method: 'GET', path: '/x' })).toEqual({ ok: false, status: 500, body: 'plain text' })
    mode = 'empty'
    expect(await d.request({ method: 'GET', path: '/x' })).toEqual({ ok: true, status: 204, body: null })
  })

  it('on 401 adopts a changed .env token and retries once', async () => {
    const s = setup({ env: 'KARMAX_API_TOKEN=old\n' })
    const auths: Array<string | undefined> = []
    const fetchImpl = vi.fn(async (_u: string | URL | Request, init?: RequestInit) => {
      const a = (init?.headers as Record<string, string>).Authorization
      auths.push(a)
      return a === 'Bearer fresh' ? json({ ok: 1 }) : json({ error: 'unauthorized' }, 401)
    })
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    writeFileSync(s.envFile, 'KARMAX_API_TOKEN=fresh\n')
    const r = await d.request({ method: 'GET', path: '/api/loops' })
    expect(r.ok).toBe(true)
    expect(auths).toEqual(['Bearer old', 'Bearer fresh'])
  })

  it('connection() reports reachable only for service=karmax', async () => {
    const s = setup()
    let body: unknown = { service: 'karmax', version: '1.2.3', agent: 'main' }
    const fetchImpl = vi.fn(async () => json(body))
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    expect(await d.connection()).toMatchObject({ mode: 'electron', reachable: true, version: '1.2.3', agent: 'main', hasToken: false, karmaxUrl: 'http://127.0.0.1:9091', wacliUrl: 'http://127.0.0.1:8765' })
    body = { service: 'something-else' }
    expect((await d.connection()).reachable).toBe(false)
  })

  it('streams NDJSON lines then ends; POST only; abort ends cleanly', async () => {
    const s = setup({ env: 'KARMAX_API_TOKEN=t\n' })
    const enc = new TextEncoder()
    const fetchImpl = vi.fn(async (_u: string | URL | Request, init?: RequestInit) => {
      const stream = new ReadableStream<Uint8Array>({
        start(c) {
          c.enqueue(enc.encode('{"type":"message","text":"he'))
          c.enqueue(enc.encode('llo"}\n{"type":"meta"}\n'))
          if (!(init?.body as string)?.includes('hang')) c.close()
          else init?.signal?.addEventListener('abort', () => c.error(Object.assign(new Error('aborted'), { name: 'AbortError' })))
        }
      })
      return new Response(stream, { status: 200, headers: { 'content-type': 'application/x-ndjson' } })
    })
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })

    const events: StreamEvent[] = []
    await new Promise<void>((resolve) => {
      d.stream({ method: 'POST', path: '/api/chat/stream', body: { message: 'x' } }, (e) => {
        events.push(e)
        if (e.end || e.error) resolve()
      })
    })
    expect(events).toEqual([{ line: { type: 'message', text: 'hello' } }, { line: { type: 'meta' } }, { end: true }])

    const bad: StreamEvent[] = []
    d.stream({ method: 'GET', path: '/api/chat/stream' }, (e) => bad.push(e))
    d.stream({ method: 'POST', path: '//evil.com' }, (e) => bad.push(e))
    await new Promise((r) => setTimeout(r, 10))
    expect(bad).toHaveLength(2)
    expect(bad.every((e) => typeof e.error === 'string')).toBe(true)

    const hung: StreamEvent[] = []
    const ctl = d.stream({ method: 'POST', path: '/api/chat/stream', body: { message: 'hang' } }, (e) => hung.push(e))
    await new Promise((r) => setTimeout(r, 10))
    ctl.abort()
    await new Promise((r) => setTimeout(r, 10))
    expect(hung.at(-1)).toEqual({ end: true })
    expect(hung.filter((e) => e.end)).toHaveLength(1)
  })

  it('stream surfaces the daemon error message on non-2xx', async () => {
    const s = setup()
    const fetchImpl = vi.fn(async () => json({ error: 'bad token' }, 401))
    const d = createDaemon({ paths: { envFile: () => s.envFile, yamlFile: () => s.yamlFile, userData: () => s.dir }, env: {}, fetchImpl: fetchImpl as never })
    const events: StreamEvent[] = []
    await new Promise<void>((resolve) => d.stream({ method: 'POST', path: '/api/chat/stream', body: {} }, (e) => { events.push(e); resolve() }))
    expect(events).toEqual([{ error: 'bad token' }])
  })
})
