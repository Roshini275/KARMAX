// Browser-only dev/test build of the renderer. The same UI runs against the mock daemon
// (fixtures/mock-daemon) with a fetch-based bridge shim, which is how it is screenshotted
// and tested without Electron.
import { resolve } from 'node:path'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  root: resolve('src/renderer'),
  resolve: { alias: { '@': resolve('src/renderer'), '@shared': resolve('src/shared') } },
  plugins: [react(), tailwindcss()],
  server: { port: 5173, strictPort: true, host: '127.0.0.1' },
  build: { outDir: resolve('out/web'), emptyOutDir: true }
})
