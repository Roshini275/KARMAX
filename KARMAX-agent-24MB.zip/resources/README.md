# resources

`resources/bin/` is where CI drops the daemon binaries that get bundled into the installer:

- `karmax.exe`
- `wacli.exe`
- `manifest.json` (versions + sha256, verified by the setup wizard before it installs them to `%LOCALAPPDATA%\KARMAX`)

The folder is git-ignored (`resources/bin`) and copied by electron-builder (`extraResources`) to `<install>\resources\bin`
at package time. In development `resources/bin` inside the repo is used (see `electron/main/paths.ts`).
