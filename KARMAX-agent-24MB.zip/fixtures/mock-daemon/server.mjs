// Mock KARMAX + wacli daemons for building/testing the UI without the real Go binaries.
//   node fixtures/mock-daemon/server.mjs   ->  KARMAX API on :9091, wacli API on :8765
// Response shapes mirror the real handlers (KARMAX/internal/api/*.go, runtime/tasktools.go, wacli/wa/api.go).
// Nothing here is authoritative for behaviour: it is deliberately lively so screens have something to show.
import http from 'node:http'
import { readdirSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { dirname, join } from 'node:path'

const KARMAX_PORT = Number(process.env.MOCK_KARMAX_PORT || 9091)
const WACLI_PORT = Number(process.env.MOCK_WACLI_PORT || 8765)
const now = () => Date.now()
const iso = (t = now()) => new Date(t).toISOString()
const ago = (ms) => iso(now() - ms)
const MIN = 60_000
const HOUR = 60 * MIN
const rnd = (a, b) => a + Math.random() * (b - a)
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const uid = () => Math.random().toString(36).slice(2, 10)

/* ── loops ─────────────────────────────────────────────────────────────── */
const loopDefs = [
  ['tech-news', 'recipe', 'Morning digest of what moved in tech', '@every 6h', 6 * HOUR, 'ok'],
  ['hot-sync', 'recipe', 'Keeps the hot memory tier in sync with the repo', '@every 15m', 15 * MIN, 'ok'],
  ['profile-refresh', 'recipe', 'Refreshes the operator profile from recent activity', '@every 12h', 12 * HOUR, 'ok'],
  ['daily-briefing', 'recipe', 'Composes and sends the daily briefing over WhatsApp', '0 0 8 * * *', 24 * HOUR, 'ok'],
  ['hn-digest', 'recipe', 'Hacker News digest filtered to what you care about', '@every 3h', 3 * HOUR, 'ok'],
  ['wa-monitor', 'workflow', 'Watches WhatsApp chats and drafts replies for the operator', '@every 2m', 2 * MIN, 'ok'],
  ['chat-sweep', 'workflow', 'Sweeps unanswered chats and queues nudges', '@every 30m', 30 * MIN, 'ok'],
  ['gchat-watch', 'workflow', 'Watches Google Chat spaces for mentions', '@every 5m', 5 * MIN, 'failing'],
  ['cold-scan', 'workflow', 'Scans cold contacts for re-engagement opportunities', '0 0 */4 * * *', 4 * HOUR, 'dark'],
  ['lyzn-tasks', 'workflow', 'Claims and runs LYZN tasks through Claude Code', '@every 1m', MIN, 'ok'],
  ['memmerge', 'compiled', 'Consolidates duplicate memory documents', '@every 1h', HOUR, 'ok'],
  ['weekly-review', 'prompt', 'Asks the agent for a weekly review of open threads', '0 0 18 * * 5', 7 * 24 * HOUR, 'ok']
]
const loops = loopDefs.map(([name, kind, description, schedule, every, mode], i) => ({
  name, kind, description, schedule, every,
  enabled: true,
  lastSuccess: mode === 'dark' ? now() - every * 4.2 : now() - rnd(0.1, 0.9) * every,
  lastFailure: mode === 'failing' ? now() - 40_000 : mode === 'ok' && i % 5 === 0 ? now() - every * 3 : null,
  consecFails: mode === 'failing' ? 4 : 0,
  running: false,
  lastError: mode === 'failing' ? 'google chat api: 429 Too Many Requests (rate limited, retry in 60s)' : '',
  runs: Array.from({ length: 24 }, (_, k) => ({ at: now() - (24 - k) * every * 0.9, ok: !(mode === 'failing' && k > 19) && !(mode === 'dark' && k > 15) }))
}))
loops.find((l) => l.name === 'chat-sweep').enabled = false
loops.find((l) => l.name === 'lyzn-tasks').running = true

/* ── logs ──────────────────────────────────────────────────────────────── */
const logs = []
let seq = 0
function log(source, level, message, loop) {
  logs.push({ seq: ++seq, ts: iso(), source, level, message, ...(loop ? { loop } : {}) })
  if (logs.length > 4000) logs.splice(0, logs.length - 3000)
}
const seedLines = [
  ['karmax', 'info', 'runtime started', undefined], ['karmax', 'info', 'api listening on :9091', undefined],
  ['karmax', 'info', 'comms: whatsapp channel started (webhook consumer)', undefined], ['wacli', 'info', 'connected to WhatsApp', undefined],
  ['wacli', 'info', 'webhook registered -> http://127.0.0.1:9090/comms/whatsapp scope=selected_chats', undefined]
]
seedLines.forEach(([s, l, m]) => log(s, l, m))
const chatter = () => {
  const l = pick(loops.filter((x) => x.enabled))
  const r = Math.random()
  if (r < 0.22) log('karmax', 'info', `loop=${l.name} tick ok processed=${Math.floor(rnd(0, 9))}`, l.name)
  else if (r < 0.36) log('karmax', 'debug', `harness claude_code.call session=task:${uid()} turn=${Math.floor(rnd(1, 6))}`)
  else if (r < 0.46) log('wacli', 'info', `message received chat=operator type=text len=${Math.floor(rnd(8, 140))}`)
  else if (r < 0.54) log('wacli', 'info', 'outgoing_message delivered (dnd=on)')
  else if (r < 0.62) log('karmax', 'warn', `loop=${l.name} run slow: ${Math.floor(rnd(20, 60))}s`, l.name)
  else if (r < 0.7) log('karmax', 'info', `memory: folded 1 fact into subject "${pick(['lyzn', 'karmax', 'schedule', 'people'])}"`)
  else if (r < 0.74) log('karmax', 'error', 'loop=gchat-watch google api 429: rate limited', 'gchat-watch')
  else if (r < 0.82) log('karmax', 'info', `comms.send refused ErrDuplicateSend (identical < 6h)`)
  else if (r < 0.9) log('app', 'info', `supervisor: karmax healthy (ping ${Math.floor(rnd(2, 12))}ms)`)
  else log('karmax', 'debug', `scheduler: next run of ${l.name} in ${Math.floor(rnd(1, 60))}m`)
}
for (let i = 0; i < 90; i++) chatter()
setInterval(chatter, 900)

/* ── tasks ─────────────────────────────────────────────────────────────── */
const tasks = [
  { task_id: 't-1001', title: 'Migrate billing service to the new Stripe API', status: 'working', rounds: 3, updated: ago(2 * MIN), last_told_operator: 'Started on billing migration. Found 14 call sites; 9 converted, running tests.' },
  { task_id: 't-1002', title: 'Draft launch post for LYZN early access', status: 'working', rounds: 1, updated: ago(6 * MIN), last_told_operator: 'Drafting three variants; will send them for your pick.' },
  { task_id: 't-1003', title: 'Fix flaky CI on wacli desktop build', status: 'blocked', rounds: 4, updated: ago(25 * MIN), last_told_operator: 'Blocked: which runner image do you want, windows-2022 or windows-latest?' },
  { task_id: 't-1004', title: 'Summarise this week\'s investor emails', status: 'open', rounds: 0, updated: ago(1 * MIN) },
  { task_id: 't-1005', title: 'Rotate the staging API keys', status: 'failed', rounds: 5, updated: ago(3 * HOUR), last_error: 'aws: AccessDenied on secretsmanager:RotateSecret', last_told_operator: 'Failed: no permission to rotate secrets. Needs an IAM change.' },
  { task_id: 't-1006', title: 'Book flights for the Bengaluru trip', status: 'done', rounds: 3, updated: ago(5 * HOUR), last_told_operator: 'Done: shortlisted 3 options in your notes.' },
  { task_id: 't-1007', title: 'Clean up stale feature branches', status: 'done', rounds: 2, updated: ago(9 * HOUR), last_told_operator: 'Done: deleted 11 merged branches.' },
  { task_id: 't-1008', title: 'Reply to Aarav about the deck', status: 'done', rounds: 1, updated: ago(22 * HOUR), last_told_operator: 'Sent.' }
]
setInterval(() => {
  for (const t of tasks) {
    if (t.status === 'open' && now() - Date.parse(t.updated) > 4000) { t.status = 'working'; t.updated = iso(); log('karmax', 'info', `task ${t.task_id} claimed: "${t.title}"`) }
    else if (t.status === 'working' && Math.random() < 0.25) {
      t.rounds++; t.updated = iso()
      log('karmax', 'info', `task ${t.task_id} round ${t.rounds} complete`)
      if (t.rounds >= 5 && Math.random() < 0.6) { t.status = 'done'; t.last_told_operator = 'Done.'; log('karmax', 'info', `task ${t.task_id} done, operator notified`) }
    }
  }
}, 5000)

/* ── proposals / notifications / registry ──────────────────────────────── */
const proposals = [
  { id: 'p-1', kind: 'post', title: 'Post launch thread on X', summary: 'Publish the 6-post thread announcing LYZN early access.', context: 'Drafted from your notes; passed the privacy guard.', action: 'x.post_thread(6 posts)', status: 'pending', note: '', result: '', created_at: ago(14 * MIN) },
  { id: 'p-2', kind: 'delete', title: 'Delete 11 merged branches in MelloB1989/lyzn', summary: 'All fully merged into main more than 30 days ago.', context: 'Irreversible on the remote.', action: 'git push origin --delete ...', status: 'pending', note: '', result: '', created_at: ago(52 * MIN) },
  { id: 'p-3', kind: 'spend', title: 'Renew the domain gitloom.cloud (₹1,499)', summary: 'Expires in 9 days. Auto-renew is off.', context: '', action: 'registrar.renew(gitloom.cloud, 1y)', status: 'pending', note: '', result: '', created_at: ago(3 * HOUR) },
  { id: 'p-4', kind: 'post', title: 'Reply publicly to a HN comment', summary: '', context: '', action: 'hn.reply', status: 'approved', note: '', result: 'Posted.', created_at: ago(20 * HOUR), decided_at: ago(19 * HOUR) },
  { id: 'p-5', kind: 'spend', title: 'Buy 100 API credits', summary: '', context: '', action: 'billing.topup', status: 'rejected', note: 'Not this month.', result: '', created_at: ago(30 * HOUR), decided_at: ago(29 * HOUR) }
]
const registry = [
  ['tech-news', 'recipe', 'Daily tech news digest', 'MelloB1989', [], true], ['hot-sync', 'recipe', 'Hot-tier sync', 'MelloB1989', [], true],
  ['profile-refresh', 'recipe', 'Profile refresh', 'MelloB1989', [], true], ['daily-briefing', 'recipe', 'Daily briefing', 'MelloB1989', [], true],
  ['hn-digest', 'recipe', 'Hacker News digest', 'MelloB1989', [], false], ['wa-monitor', 'workflow', 'WhatsApp monitor', 'MelloB1989', ['whatsapp.read', 'whatsapp.send'], true],
  ['chat-sweep', 'workflow', 'Chat sweep with outbox', 'MelloB1989', ['whatsapp.read'], false], ['gchat-watch', 'workflow', 'Google Chat watcher', 'MelloB1989', ['google_workspace'], false],
  ['cold-scan', 'workflow', 'Cold contact scan', 'MelloB1989', ['whatsapp.read', 'memory:write'], false], ['lyzn-tasks', 'workflow', 'LYZN task runner', 'MelloB1989', ['claude_code.call'], false],
  ['daily-post', 'workflow', 'Daily social post (privacy-guarded)', 'MelloB1989', ['x.post', 'linkedin.post'], false]
].map(([name, kind, description, author, requires, ships]) => ({
  name, kind, version: '1.0.0', description, author, requires, shipsWithEngine: ships,
  installed: loops.some((l) => l.name === name), installedVersion: loops.some((l) => l.name === name) ? '1.0.0' : '',
  active: loops.some((l) => l.name === name && l.enabled), sourceUrl: `https://github.com/MelloB1989/karmax-loops/tree/main/${kind === 'recipe' ? 'recipes' : 'workflows'}/${name}`
}))

/* ── supervisor (fake) ─────────────────────────────────────────────────── */
const procs = {
  karmax: { name: 'karmax', state: 'running', healthy: true, pid: 12744, startedAt: ago(3 * HOUR), restarts: 0, binaryPath: 'C:\\Users\\rosh\\AppData\\Local\\KARMAX\\karmax.exe' },
  wacli: { name: 'wacli', state: 'running', healthy: true, pid: 9312, startedAt: ago(3 * HOUR), restarts: 1, lastExit: { code: 1, at: ago(5 * HOUR) }, binaryPath: 'C:\\Users\\rosh\\AppData\\Local\\KARMAX\\wacli.exe' }
}

/* ── wacli state ───────────────────────────────────────────────────────── */
const wa = {
  connected: true, user_jid: '919876500001@s.whatsapp.net', dnd_mode: true, initial_access_configured: true, chat_count: 7, message_count: 1284, last_history_sync: ago(40 * MIN),
  chats: [
    { jid: '919876543210@s.whatsapp.net', name: 'Operator (Rosh)', is_group: false, locked: false, first_seen_at: ago(9 * 24 * HOUR), last_message_at: ago(3 * MIN), last_message_preview: 'ship the billing migration and tell me when tests pass' },
    { jid: '919812345678@s.whatsapp.net', name: 'Aarav', is_group: false, locked: true, first_seen_at: ago(30 * 24 * HOUR), last_message_at: ago(2 * HOUR), last_message_preview: 'Thanks for the deck!' },
    { jid: '120363001122334455@g.us', name: 'LYZN AI | Early access', is_group: true, locked: true, first_seen_at: ago(20 * 24 * HOUR), last_message_at: ago(5 * HOUR), last_message_preview: 'New signup: priya@…' },
    { jid: '919700000000@s.whatsapp.net', name: 'Mom', is_group: false, locked: true, first_seen_at: ago(90 * 24 * HOUR), last_message_at: ago(26 * HOUR), last_message_preview: 'Call me when free' },
    { jid: '120363999888777666@g.us', name: 'College friends', is_group: true, locked: true, first_seen_at: ago(200 * 24 * HOUR), last_message_at: ago(40 * MIN), last_message_preview: '😂😂' }
  ],
  webhooks: [{ id: 1, url: 'http://127.0.0.1:9090/comms/whatsapp', events: ['incoming_message', 'outgoing_message'], scope: 'selected_chats', chat_jids: ['919876543210@s.whatsapp.net'], enabled: true }]
}
const waLogs = Array.from({ length: 40 }, (_, i) => ({ id: i + 1, level: i % 11 === 0 ? 'warn' : 'info', category: pick(['sync', 'webhook', 'send', 'session']), message: pick(['history sync batch applied', 'webhook delivered 200', 'message sent via api', 'keepalive ok']), created_at: ago((40 - i) * 3 * MIN) }))

/* ── chat simulation ───────────────────────────────────────────────────── */
const conversations = [
  { id: 'c-1', title: 'Plan the billing migration', opening: 'Can you plan the Stripe API migration for billing?', updated: ago(20 * MIN) },
  { id: 'c-2', title: 'Weekly review', opening: 'What did I leave unfinished this week?', updated: ago(26 * HOUR) },
  { id: 'c-3', title: 'LYZN launch copy', opening: 'Draft three variants of the early-access post.', updated: ago(3 * 24 * HOUR) }
]
const history = {
  'c-1': [
    { role: 'user', text: 'Can you plan the Stripe API migration for billing?', at: ago(24 * MIN), toolCalls: [] },
    { role: 'assistant', text: 'I scanned the repo. There are **14 call sites** across `billing/` and `webhooks/`.\n\n1. Introduce a thin adapter\n2. Convert call sites behind a flag\n3. Backfill and verify\n\nWant me to open this as a tracked task?', at: ago(23 * MIN), toolCalls: [{ id: 'tc1', title: 'Grep "stripe." in billing/', kind: 'search', status: 'completed', output: '14 matches in 6 files', locations: [{ path: 'billing/charge.go', line: 41 }], input: { pattern: 'stripe\\.' } }] }
  ]
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function streamChat(req, res, body) {
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store', ...cors })
  const send = (o) => res.write(JSON.stringify(o) + '\n')
  const msg = String(body.message || '')
  let id = body.conversationId
  if (!id) { id = 'c-' + uid(); send({ kind: 'conversation', id }); conversations.unshift({ id, title: msg.slice(0, 48), opening: msg, updated: iso() }) }
  if (/error|fail me/i.test(msg)) { await sleep(400); send({ kind: 'error', text: 'the brain is not running (mock error)' }); return res.end() }
  send({ kind: 'thought', text: 'The operator wants ' + msg.slice(0, 60) + '. Check memory first, then decide whether this needs a tracked task.' })
  await sleep(500)
  send({ kind: 'tool', tool: { id: 'tc-a', title: 'memory.retrieve "' + msg.slice(0, 30) + '"', kind: 'search', status: 'in_progress', input: { query: msg } } })
  await sleep(700)
  send({ kind: 'tool_update', tool: { id: 'tc-a', status: 'completed', output: '3 relevant memories: billing, stripe, deadlines' } })
  send({ kind: 'plan', plan: [{ content: 'Recall context', status: 'completed' }, { content: 'Decide approach', status: 'in_progress', activeForm: 'Deciding approach' }, { content: 'Report back', status: 'pending' }] })
  await sleep(400)
  const reply = /task|do |build|fix|ship|migrate|draft/i.test(msg)
    ? `On it. I've taken ownership of that as a tracked task, so it keeps going after this turn and I'll message you when it's done or stuck.\n\n- Scope: ${msg.slice(0, 80)}\n- Harness: Claude Code\n- Updates: WhatsApp + the Tasks view`
    : `Here's what I know: your billing service has **14 call sites** to convert, and the deadline in memory is *end of month*. Ask me to turn it into a task whenever you're ready.`
  for (const w of reply.split(/(\s+)/)) { send({ kind: 'message', text: w }); await sleep(18) }
  if (/task|do |build|fix|ship|migrate|draft/i.test(msg)) {
    const t = { task_id: 't-' + (1009 + tasks.length), title: msg.slice(0, 70), status: 'open', rounds: 0, updated: iso() }
    tasks.unshift(t); send({ kind: 'ticket', jobId: t.task_id, title: t.title })
  }
  send({ kind: 'plan', plan: [{ content: 'Recall context', status: 'completed' }, { content: 'Decide approach', status: 'completed' }, { content: 'Report back', status: 'completed' }] })
  send({ kind: 'meta', model: 'claude-sonnet-4-6', durationMs: 3200 + Math.floor(rnd(0, 1800)), costUsd: 0.0142 })
  send({ kind: 'done', text: reply })
  res.end()
}

/* ── http plumbing ─────────────────────────────────────────────────────── */
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS' }
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', ...cors }); res.end(JSON.stringify(obj)) }
const readBody = (req) => new Promise((ok) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}) } catch { ok({}) } }) })
const latency = () => sleep(rnd(15, 90))

// Per-feature extensions: drop a file named ext-<feature>.mjs next to this one. It default-exports
// (api) => { api.karmax('GET', /^\/api\/x$/, ({ json }) => json(200, {...})); api.wacli(...) } and gets access to the
// shared state (tasks, loops, wa, proposals, ...) and helpers. Loaded once at startup.
const extKarmax = []
const extWacli = []
const extApi = {
  karmax: (method, re, handler) => extKarmax.push({ method, re, handler }),
  wacli: (method, re, handler) => extWacli.push({ method, re, handler }),
  state: { get tasks() { return tasks }, get loops() { return loops }, get wa() { return wa }, get proposals() { return proposals }, get logs() { return logs }, get conversations() { return conversations }, get registry() { return registry } },
  helpers: { iso, ago, now, rnd, pick, uid, sleep, log, MIN, HOUR }
}
const here = dirname(fileURLToPath(import.meta.url))
for (const f of readdirSync(here).filter((f) => /^ext-.+\.mjs$/.test(f))) {
  try { await (await import(pathToFileURL(join(here, f)).href)).default(extApi); console.log('loaded', f) } catch (e) { console.error('ext failed', f, e) }
}

const loopInfo = (l) => ({ name: l.name, description: l.description, schedule: l.schedule, kind: l.kind, enabled: l.enabled, events: l.kind === 'workflow' ? ['whatsapp.message'] : null })
const loopHealth = (l) => ({
  name: l.name, schedule: l.schedule, last_success: iso(l.lastSuccess), last_failure: l.lastFailure ? iso(l.lastFailure) : null,
  consecutive_failures: l.consecFails, running: l.running, dark: l.enabled && now() - l.lastSuccess > l.every * 3, last_error: l.lastError || undefined,
  retry_at: l.consecFails ? iso(now() + 60_000) : null
})

async function karmax(req, res) {
  const url = new URL(req.url, 'http://x'); const p = url.pathname; const m = req.method
  if (m === 'OPTIONS') { res.writeHead(204, cors); return res.end() }
  await latency()
  const body = m === 'GET' || m === 'DELETE' ? {} : await readBody(req)

  if (p === '/api/ping') return json(res, 200, { service: 'karmax', version: '0.2.0-mock', agent: 'karmax-agent', auth: false, time: iso() })
  if (p === '/api/chat/options') return json(res, 200, { brain: 'claude', models: [{ id: 'fable', label: 'Fable' }, { id: 'opus', label: 'Opus' }, { id: 'sonnet', label: 'Sonnet' }, { id: 'haiku', label: 'Haiku' }], efforts: ['low', 'medium', 'high', 'xhigh', 'max'], defaultModel: 'sonnet', defaultEffort: '' })
  if (p === '/api/chat/conversations' && m === 'GET') return json(res, 200, { conversations: conversations, brain: 'claude' })
  let mm
  if ((mm = p.match(/^\/api\/chat\/conversations\/([^/]+)$/))) {
    if (m === 'DELETE') { const i = conversations.findIndex((c) => c.id === mm[1]); if (i >= 0) conversations.splice(i, 1); return json(res, 200, { deleted: true }) }
    return history[mm[1]] ? json(res, 200, { messages: history[mm[1]] }) : m === 'GET' && conversations.some((c) => c.id === mm[1]) ? json(res, 200, { messages: [{ role: 'user', text: conversations.find((c) => c.id === mm[1]).opening, at: iso(), toolCalls: [] }] }) : json(res, 404, { error: 'no such conversation' })
  }
  if (p === '/api/chat/stream' && m === 'POST') return streamChat(req, res, body)
  if (p === '/api/loops' && m === 'GET') return json(res, 200, { loops: loops.map(loopInfo) })
  if (p === '/api/loops/health') return json(res, 200, { loops: loops.filter((l) => l.enabled).map(loopHealth) })
  if ((mm = p.match(/^\/api\/loops\/([^/]+)\/(run|enable|disable)$/)) && m === 'POST') {
    const l = loops.find((x) => x.name === mm[1]); if (!l) return json(res, 404, { error: 'no such loop: ' + mm[1] })
    if (mm[2] === 'enable') l.enabled = true
    else if (mm[2] === 'disable') l.enabled = false
    else { l.running = true; log('karmax', 'info', `loop=${l.name} manual run started`, l.name); setTimeout(() => { l.running = false; l.lastSuccess = now(); l.consecFails = 0; l.lastError = ''; l.runs.push({ at: now(), ok: true }); log('karmax', 'info', `loop=${l.name} manual run ok`, l.name) }, 3500) }
    return json(res, 200, mm[2] === 'run' ? { ran: l.name } : { name: l.name, enabled: l.enabled })
  }
  if (p === '/api/loops/registry' && m === 'GET') return json(res, 200, { entries: registry, fetchedAt: iso(), source: 'https://raw.githubusercontent.com/MelloB1989/karmax-loops/main/index.json' })
  if ((mm = p.match(/^\/api\/loops\/registry\/([^/]+)$/))) {
    const e = registry.find((r) => r.name === mm[1]); if (!e) return json(res, 404, { error: 'no such loop in the registry: ' + mm[1] })
    if (m === 'DELETE') { e.installed = false; e.active = false; return json(res, 200, { removed: e.name }) }
    return json(res, 200, { entry: e, definition: e.kind === 'recipe' ? `name: ${e.name}\nschedule: "@every 3h"\nprompt: |\n  ${e.description}\n` : `name: ${e.name}\nversion: 1.0.0\nschedule: "@every 5m"\nhost: [log, config, tool, remember]\ntools:\n${e.requires.map((r) => '  - ' + r).join('\n') || '  []'}\n`, trigger: { kind: 'schedule', schedule: '@every 3h' }, tools: e.requires, host: e.kind === 'workflow' ? ['log', 'config', 'tool', 'remember'] : [] })
  }
  if ((mm = p.match(/^\/api\/loops\/registry\/([^/]+)\/install$/)) && m === 'POST') { const e = registry.find((r) => r.name === mm[1]); if (!e) return json(res, 404, { error: 'not in registry' }); e.installed = true; e.installedVersion = e.version; return json(res, 200, { installed: e.name, restartRequired: e.kind === 'workflow' }) }
  if (p === '/api/activity') return json(res, 200, {
    jobs: [{ id: 'j1', name: 'memory-review', cron: '@every 1h', agent: 'karmax-agent', enabled: true, run_count: 71, next_run: iso(now() + 22 * MIN), last_run: ago(38 * MIN) }],
    webhooks: [{ id: 1, route: '/comms/whatsapp', method: 'POST', received_at: ago(3 * MIN) }, { id: 2, route: '/comms/whatsapp', method: 'POST', received_at: ago(9 * MIN) }],
    coding_sessions: [
      { id: 's1', tool: 'claude_code', description: 'Migrate billing service to the new Stripe API', status: 'running', session_id: 'task:t-1001', updated_at: ago(90_000) },
      { id: 's2', tool: 'claude_code', description: 'Draft launch post for LYZN early access', status: 'running', session_id: 'task:t-1002', updated_at: ago(5 * MIN) },
      { id: 's3', tool: 'claude_code', description: 'Rotate the staging API keys', status: 'failed', session_id: 'task:t-1005', updated_at: ago(3 * HOUR) },
      { id: 's4', tool: 'codex', description: 'Bump dependencies in wacli', status: 'completed', session_id: 'codex:abc', updated_at: ago(8 * HOUR) }
    ],
    events: Array.from({ length: 12 }, (_, i) => ({ id: i + 1, kind: pick(['whatsapp.message', 'loop.tick', 'task.progress', 'delegation.done']), agent: 'karmax-agent', created_at: ago(i * 4 * MIN) }))
  })
  if ((mm = p.match(/^\/api\/tools\/(task\.(?:list|create|update))$/)) && m === 'POST') {
    const name = mm[1]
    if (name === 'task.list') {
      const st = body.status && body.status !== 'all' ? (body.status === 'live' ? ['open', 'working', 'blocked'] : [body.status]) : null
      const rows = tasks.filter((t) => !st || st.includes(t.status)).slice(0, body.limit || 20)
      return json(res, 200, { tool: name, ok: true, output: { tasks: rows, count: rows.length } })
    }
    if (name === 'task.create') {
      if (!String(body.goal || '').trim()) return json(res, 200, { tool: name, ok: false, error: 'a task needs a goal — what must be true for it to be finished' })
      const t = { task_id: 't-' + (1009 + tasks.length), title: body.title || String(body.goal).split('\n')[0].slice(0, 100), status: 'open', rounds: 0, updated: iso() }
      tasks.unshift(t); log('karmax', 'info', `task ${t.task_id} created: "${t.title}"`)
      return json(res, 200, { tool: name, ok: true, output: { task_id: t.task_id, title: t.title, status: 'open', note: 'Owned. KARMAX will work it in its own session until it is done and report back.' } })
    }
    const t = tasks.find((x) => x.task_id === body.task_id); if (!t) return json(res, 200, { tool: name, ok: false, error: 'no task with id ' + body.task_id })
    t.status = body.status; t.updated = iso(); if (body.note) t.last_told_operator = '[operator] ' + body.note
    return json(res, 200, { tool: name, ok: true, output: { task_id: t.task_id, title: t.title, status: t.status } })
  }
  if ((mm = p.match(/^\/api\/tasks\/([^/]+)\/transcript$/))) return json(res, 404, { error: 'no transcript for that task' })
  if (p === '/api/proposals' && m === 'GET') { const s = url.searchParams.get('status'); return json(res, 200, { proposals: proposals.filter((x) => !s || x.status === s) }) }
  if ((mm = p.match(/^\/api\/proposals\/([^/]+)\/decision$/)) && m === 'POST') {
    const x = proposals.find((q) => q.id === mm[1]); if (!x) return json(res, 404, { error: 'not found' })
    x.status = body.decision === 'approve' ? 'approved' : 'rejected'; x.decided_at = iso(); x.note = body.note || ''; x.result = body.decision === 'approve' ? 'Done.' : ''
    return json(res, 200, x)
  }
  if (p === '/api/notifications') return json(res, 200, { notifications: [{ id: 'n1', kind: 'task', title: 'Task blocked', body: 'Fix flaky CI on wacli desktop build needs an answer', read: false, created_at: ago(25 * MIN) }], unread: 1 })

  /* mock-only control surface (used by the browser bridge shim) */
  if (p === '/__mock/supervisor') return json(res, 200, Object.values(procs))
  if ((mm = p.match(/^\/__mock\/supervisor\/(karmax|wacli)\/(start|stop|restart)$/))) {
    const q = procs[mm[1]]; q.state = mm[2] === 'stop' ? 'stopped' : 'starting'; q.healthy = false
    setTimeout(() => { if (mm[2] !== 'stop') { q.state = 'running'; q.healthy = true; q.startedAt = iso(); if (mm[2] === 'restart') q.restarts++ } }, 1800)
    return json(res, 200, q)
  }
  if (p === '/__mock/logs') {
    const since = Number(url.searchParams.get('sinceSeq') || 0); const limit = Number(url.searchParams.get('limit') || 500)
    const src = url.searchParams.get('source'); const lvl = url.searchParams.get('level')
    let out = logs.filter((l) => l.seq > since && (!src || l.source === src) && (!lvl || l.level === lvl))
    return json(res, 200, since ? out.slice(0, limit) : out.slice(-limit))
  }
  for (const r of extKarmax) { const em = p.match(r.re); if (em && (!r.method || r.method === m)) return r.handler({ req, res, url, m, mm: em, body, json: (c, o) => json(res, c, o) }) }
  return json(res, 404, { error: 'not found: ' + p })
}

async function wacliApi(req, res) {
  const url = new URL(req.url, 'http://x'); const p = url.pathname; const m = req.method
  if (m === 'OPTIONS') { res.writeHead(204, cors); return res.end() }
  await latency()
  const body = m === 'GET' ? {} : await readBody(req)
  if (p === '/status') return json(res, 200, { connected: wa.connected, user_jid: wa.user_jid, dnd_mode: wa.dnd_mode, initial_access_configured: wa.initial_access_configured, chat_count: wa.chats.length, message_count: wa.message_count, last_history_sync: wa.last_history_sync })
  if (p === '/dnd') { if (m === 'PUT') { wa.dnd_mode = !!body.enabled; log('wacli', 'warn', `dnd ${wa.dnd_mode ? 'ON: automation armed' : 'OFF: automation blocked'}`) } return json(res, 200, { dnd_mode: wa.dnd_mode, enabled: wa.dnd_mode }) }
  if (p === '/chats') { const f = url.searchParams.get('filter'); const q = (url.searchParams.get('query') || '').toLowerCase(); return json(res, 200, { chats: wa.chats.filter((c) => (!f || (f === 'locked' ? c.locked : f === 'unlocked' ? !c.locked : f === 'groups' ? c.is_group : true)) && (!q || c.name.toLowerCase().includes(q))) }) }
  if (p === '/chats/access') { const c = wa.chats.find((x) => x.jid === (body.jid || body.chat_jid)); if (c) c.locked = body.locked !== undefined ? !!body.locked : !body.unlocked; return json(res, 200, { ok: true }) }
  if (p === '/logs') return json(res, 200, { logs: waLogs.slice(-(Number(url.searchParams.get('limit')) || 200)) })
  if (p === '/webhooks') return json(res, 200, { webhooks: wa.webhooks })
  for (const r of extWacli) { const em = p.match(r.re); if (em && (!r.method || r.method === m)) return r.handler({ req, res, url, m, mm: em, body, json: (c, o) => json(res, c, o) }) }
  return json(res, 404, { error: 'not found: ' + p })
}

// Loop scheduler simulation: enabled loops run when due; gchat-watch keeps failing.
setInterval(() => {
  for (const l of loops) {
    if (!l.enabled || l.running || l.name === 'cold-scan') continue
    // Only the fast loops (< 5 min) actually cycle in the sim; slow ones keep their seeded history.
    if (l.every >= 5 * MIN) continue
    const last = Math.max(l.lastSuccess, l.lastFailure || 0)
    if (now() - last < l.every) continue
    l.running = true
    setTimeout(() => {
      l.running = false
      const fail = l.name === 'gchat-watch'
      if (fail) { l.lastFailure = now(); l.consecFails++; l.lastError = 'google chat api: 429 Too Many Requests'; l.runs.push({ at: now(), ok: false }) }
      else { l.lastSuccess = now(); l.consecFails = 0; l.runs.push({ at: now(), ok: true }) }
    }, rnd(1500, 4500))
  }
}, 4000)

http.createServer((q, s) => karmax(q, s).catch((e) => json(s, 500, { error: String(e) }))).listen(KARMAX_PORT, '127.0.0.1', () => console.log(`mock KARMAX  http://127.0.0.1:${KARMAX_PORT}`))
http.createServer((q, s) => wacliApi(q, s).catch((e) => json(s, 500, { error: String(e) }))).listen(WACLI_PORT, '127.0.0.1', () => console.log(`mock wacli   http://127.0.0.1:${WACLI_PORT}`))
