// Extension for workstream D (tasks board, log console, approvals inbox).
// Adds: a richer task board (incl. a LYZN-style task), a backdated multi-source log backlog with error/warn bursts,
// task-id mentions in the live stream, a log flood endpoint for perf testing, more proposals, and the
// approved -> executed transition the real daemon performs after a decision.
//   POST /__mock/flood?n=20000   append n lines (backdated over the last 10 min); retention is lifted so they stay
export default function (api) {
  const { tasks, logs, proposals } = api.state
  const { iso, ago, now, rnd, pick, uid, log, MIN, HOUR } = api.helpers

  /* ── retention: the base mock trims logs to 3000 at 4000 lines; allow a much bigger buffer for flood tests ── */
  const nativeSplice = Array.prototype.splice
  logs.splice = function (start, count, ...rest) {
    if (this.length < 60_000) return []
    return nativeSplice.call(this, start, count, ...rest)
  }

  /* ── tasks ───────────────────────────────────────────────────────────── */
  // Tasks that must stay queued: the base sim promotes any `open` task to `working` after 4s, so hide the held ones from
  // the sim's `for...of` (the API handlers use filter/find/slice, which are unaffected).
  const held = new WeakSet()
  const nativeIter = Array.prototype[Symbol.iterator]
  Object.defineProperty(tasks, Symbol.iterator, {
    configurable: true,
    value: function* () { for (const t of nativeIter.call(this)) if (!held.has(t)) yield t },
  })
  const holdOpen = (t) => (held.add(t), t)
  const add = (t) => (tasks.push(t), t)
  holdOpen(add({ task_id: 't-1101', title: 'Reconcile March invoices against bank export', status: 'open', rounds: 0, updated: ago(3 * MIN) }))
  holdOpen(add({ task_id: 't-1102', title: 'Write the changelog for wacli v0.9', status: 'open', rounds: 0, updated: ago(11 * MIN) }))
  holdOpen(add({ task_id: 't-1103', title: 'Renew the SSL cert for gitloom.cloud and update the load balancer listeners', status: 'open', rounds: 0, updated: ago(40 * MIN) }))
  add({ task_id: 'lyzn-9f2c1a', title: 'LYZN: add referral tracking to the signup flow', status: 'working', rounds: 2, updated: ago(90_000), last_told_operator: 'Picked up from LYZN. Reading the signup handler and the analytics events first.' })
  add({ task_id: 't-1104', title: 'Deploy karmax v0.2.1 to the staging box', status: 'blocked', rounds: 2, updated: ago(70 * MIN), last_told_operator: 'Blocked: the staging box asks for a sudo password. Want me to use the deploy key instead?' })
  add({ task_id: 't-1105', title: 'Triage the 34 unread GitHub notifications', status: 'done', rounds: 2, updated: ago(26 * HOUR), last_told_operator: 'Done: closed 9 stale, labelled 14, 11 need a look (listed in your notes).' })
  add({ task_id: 't-1106', title: 'Export the Q1 expense report to CSV', status: 'done', rounds: 1, updated: ago(30 * HOUR), last_told_operator: 'Done: expenses-q1.csv saved to Documents.' })
  add({ task_id: 't-1107', title: 'Compare three vector DBs for the memory tier', status: 'done', rounds: 4, updated: ago(2 * 24 * HOUR), last_told_operator: 'Done: recommendation is sqlite-vec for now; comparison table in memory.' })
  add({
    task_id: 't-1108', title: 'Backfill missing thumbnails for the LYZN gallery', status: 'failed', rounds: 6, updated: ago(4 * HOUR),
    last_error: 'exec: "convert": executable file not found in %PATH%\n  at thumbnails.generate (gallery/thumbs.go:88)\n  at runner.round (tasks/runner.go:214)\nretried 5 times; giving up',
    last_told_operator: 'Failed: ImageMagick is not installed on this machine, so I could not generate thumbnails.'
  })
  add({ task_id: 't-1109', title: 'Ping Priya about the onboarding call', status: 'done', rounds: 1, updated: ago(3 * 24 * HOUR), last_told_operator: 'Sent.' })

  // Keep a few tasks "running" for the whole session (the base sim would finish them within a minute or two) and
  // give them a heartbeat so the board and the drawer stay alive.
  const runners = ['t-1001', 't-1002', 'lyzn-9f2c1a'].map((id) => tasks.find((t) => t.task_id === id)).filter(Boolean)
  runners.forEach(holdOpen)
  setInterval(() => {
    const t = pick(runners)
    if (t.status !== 'working') return
    if (t.rounds < 8) t.rounds++
    t.updated = iso()
    log('karmax', 'info', `task ${t.task_id} round ${t.rounds} complete`)
  }, 7000)

  /* ── log backlog: backdated over the last 45 minutes, with an error burst ~13 minutes ago ─────────────── */
  const loopNames = api.state.loops.map((l) => l.name)
  const seeds = []
  const S = (source, level, message, loop) => seeds.push([source, level, message, loop])
  for (let i = 0; i < 260; i++) {
    const r = Math.random()
    const tk = pick(['t-1001', 't-1002', 't-1003', 't-1005', 'lyzn-9f2c1a'])
    if (r < 0.12) S('karmax', 'info', `task ${tk} round ${Math.floor(rnd(1, 6))} complete`)
    else if (r < 0.2) S('karmax', 'info', `harness claude_code.call session=task:${tk} turn=${Math.floor(rnd(1, 8))} tokens=${Math.floor(rnd(800, 9000))}`)
    else if (r < 0.28) S('karmax', 'debug', `scheduler: next run of ${pick(loopNames)} in ${Math.floor(rnd(1, 60))}m`)
    else if (r < 0.4) { const l = pick(loopNames); S('karmax', 'info', `loop=${l} tick ok processed=${Math.floor(rnd(0, 9))}`, l) }
    else if (r < 0.48) S('wacli', 'info', `message received chat=operator type=text len=${Math.floor(rnd(8, 140))}`)
    else if (r < 0.54) S('wacli', 'info', 'outgoing_message delivered (dnd=on)')
    else if (r < 0.6) S('wacli', 'debug', `webhook delivered 200 in ${Math.floor(rnd(4, 40))}ms`)
    else if (r < 0.68) S('app', 'info', `supervisor: karmax healthy (ping ${Math.floor(rnd(2, 12))}ms)`)
    else if (r < 0.74) S('karmax', 'warn', `loop=gchat-watch run slow: ${Math.floor(rnd(20, 60))}s`, 'gchat-watch')
    else if (r < 0.8) S('karmax', 'info', `memory: folded 1 fact into subject "${pick(['lyzn', 'karmax', 'schedule', 'people'])}"`)
    else if (r < 0.84) S('karmax', 'warn', `comms.send refused ErrDuplicateSend (identical < 6h) task=${tk}`)
    else if (r < 0.88) S('karmax', 'debug', `tool task.list status=all limit=100 -> ${Math.floor(rnd(8, 20))} rows`)
    else S('karmax', 'info', `task ${tk} operator notified via whatsapp-main`)
  }
  // The error burst (gchat-watch rate-limited) and one long multi-line panic.
  const burst = []
  for (let i = 0; i < 14; i++) burst.push(['karmax', 'error', `loop=gchat-watch google api 429: rate limited (attempt ${i + 1}/14, retry in ${60 + i * 5}s)`, 'gchat-watch'])
  for (let i = 0; i < 5; i++) burst.push(['karmax', 'warn', 'loop=gchat-watch backing off after 429', 'gchat-watch'])
  seeds.splice(150, 0, ...burst)
  seeds.splice(60, 0, [
    'karmax', 'error',
    'task t-1005 round 5 failed: aws: AccessDenied on secretsmanager:RotateSecret\n  status code: 403, request id: 7f3a9c1e-22b0-4c1d-9d2f-58c11f7d3e02\n  caused by: not authorized to perform secretsmanager:RotateSecret on resource arn:aws:secretsmanager:ap-south-1:123456789012:secret:staging/api-keys-Vq3xLm\n  at runtime.(*taskRunner).round (tasks.go:214)\n  at runtime.(*taskRunner).run (tasks.go:131)'
  ])
  seeds.splice(95, 0, ['karmax', 'warn', `task t-1003 blocked: waiting for the operator to choose a runner image — reply "windows-2022" or "windows-latest" on WhatsApp, or resume the task from the desktop app once you have decided. The runner will not touch this task again until it is set back to working (${'context '.repeat(18)}end)`])
  seeds.splice(120, 0, ['karmax', 'info', 'task t-1001 claude_code.call output: {"files_changed":9,"tests":{"passed":41,"failed":0},"summary":"converted billing/charge.go, billing/refund.go, webhooks/stripe.go to the v2025 API behind FEATURE_STRIPE_V2"}'])
  seeds.forEach(([s, l, m, lp]) => log(s, l, m, lp))
  {
    // Spread every existing line evenly across the last 45 minutes, preserving order.
    const span = 45 * MIN
    const t0 = now() - span
    logs.forEach((l, i) => { l.ts = iso(t0 + (i / logs.length) * span * 0.985) })
  }

  /* ── live stream: mention the in-flight tasks so the drawer's "Related logs" stays lively ── */
  setInterval(() => {
    const live = tasks.filter((t) => t.status === 'working')
    if (!live.length) return
    const t = pick(live)
    const r = Math.random()
    if (r < 0.5) log('karmax', 'info', `harness claude_code.call session=task:${t.task_id} turn=${Math.floor(rnd(1, 9))} tokens=${Math.floor(rnd(800, 9000))}`)
    else if (r < 0.8) log('karmax', 'debug', `task ${t.task_id} heartbeat rounds=${t.rounds}`)
    else if (r < 0.92) log('karmax', 'warn', `task ${t.task_id} tool call took ${Math.floor(rnd(20, 90))}s`)
    else log('karmax', 'error', `task ${t.task_id} transient error: read tcp 127.0.0.1:9091: i/o timeout (will retry)`)
  }, 2500)

  /* ── flood ───────────────────────────────────────────────────────────── */
  api.karmax('POST', /^\/__mock\/flood$/, ({ url, json }) => {
    const n = Math.min(100_000, Number(url.searchParams.get('n') || 20_000))
    const t0 = now() - 10 * MIN
    const before = logs.length
    for (let i = 0; i < n; i++) {
      const r = Math.random()
      const lvl = r < 0.03 ? 'error' : r < 0.1 ? 'warn' : r < 0.25 ? 'debug' : 'info'
      const src = pick(['karmax', 'karmax', 'karmax', 'wacli', 'app'])
      const lp = src === 'karmax' && Math.random() < 0.3 ? pick(loopNames) : undefined
      const msg = i % 997 === 0 ? `panic recovered in worker ${i}\n  at worker.go:${i % 300}\n  at main.go:88` : `flood #${i} ${src} ${lvl} ${uid()} payload=${'x'.repeat(Math.floor(rnd(4, 90)))}`
      log(src, lvl, msg, lp)
      logs[logs.length - 1].ts = iso(t0 + (i / n) * 10 * MIN)
    }
    json(200, { added: logs.length - before, total: logs.length })
  })

  /* ── proposals ───────────────────────────────────────────────────────── */
  const P = (p) => proposals.unshift({ note: '', result: '', context: '', summary: '', ...p })
  P({ id: 'p-10', kind: 'other', title: 'Grant the deploy key access to the staging box', summary: 'Task t-1104 is blocked on a sudo prompt. Using the existing deploy key avoids sharing a password.', context: 'Requested by task t-1104 (Deploy karmax v0.2.1). The key is already in the operator keychain; this only adds it to authorized_keys on staging.\nScope: read/execute on /opt/karmax, no sudo.', action: 'ssh staging "echo $KEY >> ~/.ssh/authorized_keys"\nsystemctl --user restart karmax', status: 'pending', created_at: ago(6 * MIN) })
  P({ id: 'p-9', kind: 'message', title: 'Reply to Priya about the onboarding call', summary: 'She asked for a slot on Thursday. Two are free on your calendar.', context: 'From the wa-monitor loop.', action: 'whatsapp.send(chat="Priya", text="Hi Priya! Thursday 11:00 or 16:30 IST both work for me. Which do you prefer? I will send the invite as soon as you pick.")', status: 'pending', created_at: ago(2 * MIN) })
  P({ id: 'p-8', kind: 'schedule', title: 'Move the weekly review to Friday 17:00', summary: 'Friday 18:00 clashes with the travel block you added.', context: '', action: 'loops.schedule(weekly-review, "0 0 17 * * 5")', status: 'pending', created_at: ago(35 * MIN) })
  P({ id: 'p-7', kind: 'task', title: 'Start a task: audit unused IAM roles', summary: '', context: 'Surfaced while investigating t-1005.', action: 'task.create(goal="List IAM roles unused for 90+ days and propose which to delete")', status: 'executed', result: 'Created task t-1110 and started the first round.', created_at: ago(5 * HOUR), decided_at: ago(5 * HOUR - 2 * MIN) })
  P({ id: 'p-6', kind: 'spend', title: 'Buy a Cloudflare Workers Paid plan ($5/mo)', summary: 'Needed for the LYZN edge cache.', context: '', action: 'billing.subscribe(cloudflare, workers-paid)', status: 'failed', result: 'card declined: insufficient funds (code 51). No charge was made.', created_at: ago(9 * HOUR), decided_at: ago(9 * HOUR - 3 * MIN) })

  /* the real daemon flips approved -> executed once the agent finished the action (server.go handleProposalDecision) */
  setInterval(() => {
    for (const p of proposals) {
      if (p.status === 'approved' && p.decided_at && now() - Date.parse(p.decided_at) > 3500) {
        p.status = 'executed'
        p.result = `Done: ${String(p.action).split('\n')[0].slice(0, 80)}`
      }
    }
  }, 1000)
}
