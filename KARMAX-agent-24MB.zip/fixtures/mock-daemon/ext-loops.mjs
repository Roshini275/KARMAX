// Extra data for the Loops overview (workstream C): more loops so the constellation is dense (22 nodes across
// every cadence ring and kind, including an event-driven one with no clock, a dark and a second failing loop),
// and a bigger registry so browse/filter/install has something to chew on.
// Extension API: see the comment block in server.mjs. We only add to the shared state; routes are the built-in ones.
export default function (api) {
  const { now, MIN, HOUR, rnd } = api.helpers
  const DAY = 24 * HOUR
  const loops = api.state.loops
  const add = (name, kind, description, schedule, every, mode = 'ok', extra = {}) => {
    if (loops.some((l) => l.name === name)) return
    loops.push({
      name, kind, description, schedule, every,
      enabled: true,
      lastSuccess: mode === 'dark' ? now() - every * 4.5 : now() - rnd(0.1, 0.8) * Math.min(every, 20 * HOUR),
      lastFailure: mode === 'failing' ? now() - 6 * MIN : null,
      consecFails: mode === 'failing' ? 2 : 0,
      running: false,
      lastError: mode === 'failing' ? 'ledger api: 503 upstream unavailable (retry scheduled)' : '',
      runs: [],
      ...extra
    })
  }

  add('inbox-triage', 'recipe', 'Sorts new email into act / read / ignore and drafts replies for the first bucket', '@every 20m', 20 * MIN)
  add('gh-notifications', 'recipe', 'Summarises GitHub notifications that mention you', '@every 10m', 10 * MIN)
  add('calendar-sync', 'workflow', 'Mirrors your calendar into KARMAX memory so scheduling questions have context', '@every 5m', 5 * MIN)
  add('backup-verify', 'compiled', 'Verifies last night\'s memory backup restores cleanly', '0 0 3 * * *', DAY)
  add('invoice-watch', 'recipe', 'Flags invoices that are about to fall overdue', '0 0 9 * * 1-5', DAY)
  add('reminder-sync', 'prompt', 'Asks the agent to reconcile reminders with open tasks', '@every 45m', 45 * MIN)
  add('quarterly-report', 'prompt', 'Drafts the quarterly summary for your review', '0 0 9 1 1,4,7,10 *', 90 * DAY)
  add('ledger-export', 'workflow', 'Exports the ledger to the accountant\'s shared folder', '@every 1h', HOUR, 'failing')
  add('cdn-purge', 'recipe', 'Purges the CDN cache after a deploy lands', '@every 30m', 30 * MIN, 'dark')
  // event-driven: no schedule at all, driven by webhooks/events
  add('webhook-intake', 'workflow', 'Turns inbound webhooks into tracked tasks', '', 1e15, 'ok')

  // A bigger registry (some installed above, most not).
  const reg = api.state.registry
  const addReg = (name, kind, description, author, requires, ships = false) => {
    if (reg.some((r) => r.name === name)) return
    const installed = loops.some((l) => l.name === name)
    reg.push({
      name, kind, version: kind === 'recipe' ? '1.0.0' : '1.2.0', description, author, requires, shipsWithEngine: ships,
      installed, installedVersion: installed ? (name === 'calendar-sync' ? '1.1.0' : kind === 'recipe' ? '1.0.0' : '1.2.0') : '',
      active: installed && loops.some((l) => l.name === name && l.enabled),
      sourceUrl: `https://github.com/MelloB1989/karmax-loops/tree/main/${kind === 'recipe' ? 'recipes' : 'workflows'}/${name}`
    })
  }
  addReg('inbox-triage', 'recipe', 'Sorts new email into act / read / ignore and drafts replies for the first bucket', 'MelloB1989', ['google_workspace'])
  addReg('gh-notifications', 'recipe', 'Summarises GitHub notifications that mention you', 'community/dev-loops', ['github'])
  addReg('calendar-sync', 'workflow', 'Mirrors your calendar into KARMAX memory so scheduling questions have context', 'MelloB1989', ['google_workspace', 'memory:write'])
  addReg('ledger-export', 'workflow', 'Exports the ledger to the accountant\'s shared folder', 'community/finance', ['ledger.read', 'fs.write'])
  addReg('cdn-purge', 'recipe', 'Purges the CDN cache after a deploy lands', 'community/dev-loops', ['cloudflare.purge'])
  addReg('webhook-intake', 'workflow', 'Turns inbound webhooks into tracked tasks', 'MelloB1989', ['task.create'])
  addReg('expense-digest', 'recipe', 'Weekly digest of expenses grouped by category, sent to your feed', 'community/finance', ['ledger.read'])
  addReg('weather-brief', 'recipe', 'One-line weather and commute note before you leave', 'community/daily', [])
  addReg('pr-reviewer', 'workflow', 'Reviews new pull requests with the coding harness and comments on the PR', 'community/dev-loops', ['github', 'harness'])
  addReg('stripe-watch', 'workflow', 'Watches Stripe for failed payments and proposes follow-ups for approval', 'community/finance', ['stripe.read', 'propose'])
  addReg('news-radar', 'recipe', 'Tracks the topics you care about across a few feeds and pushes only what is new', 'community/daily', ['web.fetch'])
  addReg('standup-notes', 'recipe', 'Writes your standup update from yesterday\'s activity', 'community/dev-loops', ['activity.recent'])
}
