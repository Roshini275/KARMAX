// Mock memory endpoints (workstream E). Shapes mirror KARMAX/internal/api/server.go + cleanup.go:
//   GET    /api/memory/entries?q=&limit=      -> { namespace, entries: [{id, role, content, tags, created_at}] }   (ids may be GitLoom repo paths)
//   DELETE /api/memory/entries/{id}           -> { deleted: id }        (id is URL-encoded: paths contain "/")
//   GET    /api/memory/tree                   -> { namespace, tree: TreeNode | null }   TreeNode = {node_id,title,summary?,content?,children?}
//   GET    /api/memory/cleanup/question       -> { done: true } | { memory_id, memory, question, options }   (costs an LLM call; slow)
//   POST   /api/memory/cleanup/answer         -> { action: 'delete'|'update', memory_id, content? }
// Scenario: POST /__mock/memory {"empty":true} | {"reset":true} | {"slow":ms}
export default function (api) {
  const { ago, iso, HOUR, sleep } = api.helpers
  const D = 24 * HOUR
  const seed = () => [
    ['people/aarav.md', 'gitloom', 'Aarav Mehta is a design lead at a fintech startup. Prefers concise updates over calls. Received the LYZN deck on Tuesday.', ['people', 'contacts'], 2 * D],
    ['people/priya.md', 'gitloom', 'Priya runs design for LYZN early access. Wants onboarding mocks reviewed before Friday.', ['people', 'lyzn'], 1 * D],
    ['projects/lyzn/launch.md', 'gitloom', 'LYZN early access launches at the end of the month. Launch thread on X needs operator approval; three copy variants are being drafted.', ['lyzn', 'launch'], 6 * HOUR],
    ['projects/lyzn/stack.md', 'gitloom', 'LYZN backend: Go services, Postgres on Neon, background jobs via KARMAX loops. Deploys from main through GitHub Actions.', ['lyzn', 'stack'], 9 * D],
    ['projects/billing/stripe-migration.md', 'gitloom', 'Billing service is moving to the new Stripe API. 14 call sites in billing/ and webhooks/. Tests must pass before the flag flips. Deadline: end of month.', ['billing', 'stripe', 'deadline'], 3 * HOUR],
    ['prefs/communication.md', 'gitloom', 'Operator prefers WhatsApp for urgent items and the app for everything else. No messages between 23:00 and 07:00 unless critical.', ['preferences'], 12 * D],
    ['prefs/style.md', 'gitloom', 'Writing style: plain, direct, no exclamation marks. Sign-offs are never needed.', ['preferences', 'writing'], 20 * D],
    ['schedule/weekly.md', 'gitloom', 'Weekly review happens Friday at 18:00. Investor updates go out on the first Monday of the month.', ['schedule'], 5 * D],
    ['people/dad.md', 'gitloom', 'Dad is travelling to Bengaluru this week. Flight details are in the notes app.', ['people', 'family'], 2 * D],
    ['infra/wacli.md', 'gitloom', 'wacli runs as a supervised process on the laptop. DND must be on for KARMAX to message; every chat except the operator chat stays locked.', ['whatsapp', 'infra'], 4 * D],
    ['infra/domains.md', 'gitloom', 'gitloom.cloud expires in nine days and auto-renew is off. Renewal is a proposal awaiting approval.', ['domains', 'deadline'], 1 * D],
    ['infra/ci.md', 'gitloom', 'Windows CI for the wacli desktop build is flaky. Operator chose the windows-latest runner image.', ['ci', 'wacli'], 4 * 60 * 1000],
    ['e-1041', 'memory', 'Operator asked to stop daily briefings on weekends.', ['preferences', 'briefings'], 15 * D],
    ['e-1042', 'memory', 'The staging API keys were last rotated on the 3rd. Rotation failed once because of an IAM permission.', ['security', 'staging'], 7 * D],
    ['e-1043', 'memory', 'Google Chat watcher is rate limited (429). Backing off to every 10 minutes is acceptable.', ['loops', 'gchat'], 1 * D],
    ['e-1044', 'memory', 'Favourite flight seat: aisle. Avoid layovers over 3 hours.', ['travel', 'preferences'], 40 * D],
    ['e-1045', 'memory', 'Mom prefers phone calls on Sunday evenings.', ['people', 'family'], 60 * D],
    ['e-1046', 'memory', 'Hacker News digest should skip crypto and hiring threads.', ['loops', 'preferences'], 25 * D],
    ['e-1047', 'memory', 'Decision: KARMAX delegates heavy work to Claude Code; approvals are needed for anything irreversible (posting, deleting, spending).', ['policy'], 30 * D],
    ['e-1048', 'memory', 'The operator number is a dedicated SIM. Personal number stays out of automation.', ['whatsapp', 'policy'], 8 * D],
    ['e-1049', 'memory', 'Reads at 1.5x speed. Summaries should lead with the decision needed.', ['preferences'], 45 * D],
    ['e-1050', 'memory', 'Old: office lease renewal is in March.', ['office'], 210 * D]
  ]
  let entries = seed().map(([id, role, content, tags, agoMs]) => ({ id, role, content, tags, created_at: ago(agoMs) }))
  let empty = false
  let slow = 0

  const node = (id, title, summary, children, content) => ({ node_id: id, title, ...(summary ? { summary } : {}), ...(content ? { content } : {}), ...(children ? { children } : {}) })
  const tree = () => node('root', 'Memory', 'Everything KARMAX knows about the operator, projects and preferences', [
    node('people', 'People', 'Contacts and relationships', [
      node('people/aarav', 'Aarav Mehta', 'Design lead, prefers concise updates', null, 'Design lead at a fintech startup. Prefers concise updates over calls.'),
      node('people/priya', 'Priya (LYZN design)', 'Runs design for LYZN early access', null, 'Wants onboarding mocks reviewed before Friday.'),
      node('people/family', 'Family', 'Dad, Mom', [
        node('people/dad', 'Dad', 'Travelling to Bengaluru', null, 'Flight details are in the notes app.'),
        node('people/mom', 'Mom', 'Prefers Sunday evening calls', null)
      ])
    ]),
    node('projects', 'Projects', 'Active work', [
      node('projects/lyzn', 'LYZN', 'Early access launches at the end of the month', [
        node('projects/lyzn/launch', 'Launch', 'Thread on X awaiting approval', null, 'Three copy variants are being drafted.'),
        node('projects/lyzn/stack', 'Stack', 'Go, Postgres on Neon, KARMAX loops')
      ]),
      node('projects/billing', 'Billing', 'Stripe API migration, 14 call sites', [node('projects/billing/stripe', 'Stripe migration', 'Behind a flag; tests must pass first')])
    ]),
    node('prefs', 'Preferences', 'How the operator likes to work', [
      node('prefs/communication', 'Communication', 'WhatsApp for urgent, app for the rest'),
      node('prefs/style', 'Writing style', 'Plain and direct')
    ]),
    node('infra', 'Infrastructure', 'Services and deadlines', [node('infra/wacli', 'wacli'), node('infra/domains', 'Domains'), node('infra/ci', 'CI')])
  ])

  api.karmax('GET', /^\/api\/memory\/entries$/, async ({ url, json }) => {
    if (slow) await sleep(slow)
    const q = (url.searchParams.get('q') || '').toLowerCase().trim()
    const limit = Number(url.searchParams.get('limit')) || 100
    const list = empty ? [] : entries.filter((e) => !q || e.content.toLowerCase().includes(q) || e.tags.some((t) => t.includes(q)) || e.id.toLowerCase().includes(q))
    json(200, { namespace: 'karmax-agent', entries: list.slice(0, limit) })
  })
  api.karmax('DELETE', /^\/api\/memory\/entries\/(.+)$/, ({ mm, json }) => {
    const id = decodeURIComponent(mm[1])
    if (!entries.some((e) => e.id === id)) return json(500, { error: 'memory entry not found: ' + id })
    entries = entries.filter((e) => e.id !== id)
    json(200, { deleted: id })
  })
  api.karmax('GET', /^\/api\/memory\/tree$/, ({ json }) => json(200, { namespace: 'karmax-agent', tree: empty ? null : tree() }))

  const questions = [
    { memory_id: 'e-1050', question: 'This mentions an office lease renewal in March. Is that still true?', options: ['Still true', 'No longer true', 'Update it'] },
    { memory_id: 'e-1049', question: 'You read at 1.5x speed. Should summaries always lead with the decision needed?', options: ['Yes, always', 'Only for tasks', 'Not anymore'] },
    { memory_id: 'e-1044', question: 'Is aisle still your preferred seat, and is 3 hours still the layover limit?', options: ['Both still true', 'Seat changed', 'Layover limit changed'] }
  ]
  let qi = 0
  api.karmax('GET', /^\/api\/memory\/cleanup\/question$/, async ({ json }) => {
    await sleep(900)
    if (empty) return json(200, { done: true })
    const pending = questions.filter((q) => entries.some((e) => e.id === q.memory_id))
    if (!pending.length) return json(200, { done: true })
    const q = pending[qi++ % pending.length]
    json(200, { ...q, memory: entries.find((e) => e.id === q.memory_id).content })
  })
  api.karmax('POST', /^\/api\/memory\/cleanup\/answer$/, async ({ body, json }) => {
    await sleep(700)
    if (!body.memory_id || !String(body.answer || '').trim()) return json(400, { error: 'memory_id and answer are required' })
    const e = entries.find((x) => x.id === body.memory_id)
    if (/no longer|not anymore|forget|delete|wrong/i.test(body.answer)) {
      entries = entries.filter((x) => x.id !== body.memory_id)
      return json(200, { action: 'delete', memory_id: body.memory_id })
    }
    if (e) e.content = `${e.content} (Confirmed by operator: ${String(body.answer).trim()}.)`
    json(200, { action: 'update', memory_id: body.memory_id, content: e?.content })
  })

  api.karmax('POST', /^\/__mock\/memory$/, ({ body, json }) => {
    if (body.reset) { entries = seed().map(([id, role, content, tags, agoMs]) => ({ id, role, content, tags, created_at: ago(agoMs) })); empty = false; slow = 0; qi = 0 }
    if (typeof body.empty === 'boolean') empty = body.empty
    if (typeof body.slow === 'number') slow = body.slow
    json(200, { ok: true, entries: entries.length, at: iso() })
  })
}
