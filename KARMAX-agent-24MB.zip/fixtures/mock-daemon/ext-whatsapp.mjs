// Mock extensions for the WhatsApp operator panel (workstream E).
// Shapes mirror the real handlers:
//   wacli  wa/api.go      GET /messages, PUT /chats/{jid} {locked} -> {chat}  (real GET /webhooks also carries each webhook's `secret`; the base mock omits it)
//   KARMAX internal/tools/builtin/comms.go  POST /api/tools/comms.send {target, content} -> {tool, ok, output|error}
// server.mjs already serves /status /dnd /chats /logs /webhooks; this file only adds what is missing and a
// scenario switch so every verdict / error state can be screenshotted:
//   curl -X POST :8804/__mock/wa/scenario -d '{"webhook":"wide","operator":"absent","connected":false,"failLock":true,"dnd":false}'
//     webhook:   ok | wide (also 2 more chats) | all_unlocked | mentions | missing | disabled | wrongchat
//     operator:  seen | absent | locked          reset: true restores the defaults
export default function (api) {
  const { wa } = api.state
  const { ago, iso, now, MIN, HOUR, log } = api.helpers
  const OP = '919876543210@s.whatsapp.net'
  const AARAV = '919812345678@s.whatsapp.net'
  const LYZN = '120363001122334455@g.us'
  const scenario = { failLock: false }

  // More chats than the base seed, so the table has something to filter/search.
  const extra = [
    ['919900112233@s.whatsapp.net', 'Priya (LYZN design)', false, true, 7 * HOUR, 'Can you look at the onboarding mocks?'],
    ['919611223344@s.whatsapp.net', 'Dad', false, true, 30 * HOUR, 'Reached Bengaluru'],
    ['120363111222333444@g.us', 'Family', true, true, 12 * HOUR, 'Who is picking up the cake?'],
    ['919845000111@s.whatsapp.net', 'Swiggy Instamart', false, true, 4 * 24 * HOUR, 'Your order has been delivered'],
    ['120363555666777888@g.us', 'Hackathon crew', true, true, 2 * 24 * HOUR, 'Demo at 4pm, be early'],
    ['919701234567@s.whatsapp.net', 'Unknown number', false, false, 25 * MIN, 'hi is this the sales team?']
  ]
  for (const [jid, name, is_group, locked, agoMs, preview] of extra) {
    if (!wa.chats.some((c) => c.jid === jid)) wa.chats.push({ jid, name, is_group, locked, first_seen_at: ago(60 * 24 * HOUR), last_message_at: ago(agoMs), last_message_preview: preview })
  }
  wa.chats.sort((a, b) => Date.parse(b.last_message_at) - Date.parse(a.last_message_at))

  /* ── message store ──────────────────────────────────────────────────── */
  const msgs = { [OP]: [], [AARAV]: [], [LYZN]: [] }
  let mid = 1
  const add = (jid, fromMe, content, agoMs, type = 'text') => {
    msgs[jid].push({ id: `3EB0${String(mid++).padStart(6, '0')}`, chat_jid: jid, sender_jid: fromMe ? wa.user_jid : jid, content, timestamp: ago(agoMs), is_from_me: fromMe, message_type: type })
  }
  add(OP, false, 'hey, are you up?', 30 * HOUR + 12 * MIN)
  add(OP, true, 'Online. Three loops ran overnight, all green except gchat-watch (rate limited). Want the details?', 30 * HOUR + 11 * MIN)
  add(OP, false, 'no, ignore it. what is on my plate today', 30 * HOUR + 9 * MIN)
  add(OP, true, 'Today: billing migration (in progress), LYZN launch copy (drafting), 1 approval waiting: post launch thread on X.', 30 * HOUR + 8 * MIN)
  add(OP, false, 'ship the billing migration and tell me when tests pass', 3 * HOUR + 40 * MIN)
  add(OP, true, 'On it. Tracked as t-1001, working in Claude Code. I will message you at milestones.', 3 * HOUR + 39 * MIN)
  add(OP, true, 'Progress: 14 call sites found, 9 converted. Running the test suite next.', 2 * HOUR + 5 * MIN)
  add(OP, false, 'ok', 2 * HOUR + 1 * MIN)
  add(OP, true, 'Progress: all 14 converted. 212 tests pass, 2 fail (webhook signature fixtures). Fixing.', 62 * MIN)
  add(OP, false, '', 40 * MIN, 'audio')
  add(OP, true, 'I could not transcribe that voice note. Can you type it out?', 39 * MIN)
  add(OP, false, 'also draft the launch post, 3 variants', 21 * MIN)
  add(OP, true, 'Added t-1002: launch post, 3 variants. I will send them for your pick.', 20 * MIN)
  add(OP, true, 'Blocked on t-1003: which runner image do you want, windows-2022 or windows-latest?', 9 * MIN)
  add(OP, false, 'windows-latest', 4 * MIN)
  add(OP, false, 'ship the billing migration and tell me when tests pass', 3 * MIN)
  add(AARAV, false, 'Thanks for the deck!', 2 * HOUR)
  add(LYZN, false, 'New signup: priya@example.com', 5 * HOUR)

  api.wacli('GET', /^\/messages$/, ({ url, json }) => {
    const ref = url.searchParams.get('chat_ref') || url.searchParams.get('chat_jid') || ''
    const limit = Number(url.searchParams.get('limit')) || 100
    const chat = wa.chats.find((c) => c.jid === ref)
    if (!chat && ref) return json(400, { error: `no matches found for "${ref}"` })
    const list = (ref ? msgs[ref] || [] : Object.values(msgs).flat()).slice(-limit)
    return json(200, { messages: list, resolved_chat: chat ? { jid: chat.jid, name: chat.name, kind: 'chat' } : null, resolved_sender: null })
  })

  // Per-chat lock. NOT /chats/access (that one is the initial bulk config: {unlocked_jids} and locks everything else).
  api.wacli('PUT', /^\/chats\/(.+)$/, ({ mm, body, json }) => {
    const jid = decodeURIComponent(mm[1])
    if (jid === 'access') return json(405, { error: 'the mock does not implement bulk access' })
    if (scenario.failLock) return json(500, { error: 'database is locked (mock failure)' })
    const c = wa.chats.find((x) => x.jid === jid)
    if (!c) return json(404, { error: 'sql: no rows in result set' })
    c.locked = !!body.locked
    log('wacli', 'info', `Chat ${jid} ${c.locked ? 'locked' : 'unlocked'}`)
    return json(200, { chat: c })
  })

  /* ── scenario switch ────────────────────────────────────────────────── */
  const baseHook = { id: 1, url: 'http://127.0.0.1:9090/comms/whatsapp', events: ['incoming_message', 'outgoing_message'], scope: 'selected_chats', chat_jids: [OP], enabled: true }
  const opChat = wa.chats.find((c) => c.jid === OP)
  api.wacli('POST', /^\/__mock\/wa\/scenario$/, ({ body, json }) => {
    if (body.reset) { for (const c of wa.chats) if (c.jid === AARAV || c.jid === LYZN) c.locked = true; wa.webhooks = [baseHook]; wa.connected = true; wa.dnd_mode = true; scenario.failLock = false; opChat.locked = false; if (!wa.chats.includes(opChat)) wa.chats.unshift(opChat) }
    if (body.webhook) {
      const w = { ...baseHook }
      if (body.webhook === 'wide') { w.chat_jids = [OP, AARAV, LYZN]; for (const c of wa.chats) if (c.jid === AARAV || c.jid === LYZN) c.locked = false }
      if (body.webhook === 'all_unlocked') { w.scope = 'all_unlocked'; w.chat_jids = [] }
      if (body.webhook === 'mentions') w.include_mentions = true
      if (body.webhook === 'disabled') w.enabled = false
      if (body.webhook === 'wrongchat') w.chat_jids = [AARAV]
      wa.webhooks = body.webhook === 'missing' ? [] : [w]
    }
    if (body.operator === 'absent') { const i = wa.chats.findIndex((c) => c.jid === OP); if (i >= 0) wa.chats.splice(i, 1) }
    if (body.operator === 'seen' && !wa.chats.includes(opChat)) wa.chats.unshift(opChat)
    if (body.operator === 'locked') opChat.locked = true
    if (typeof body.connected === 'boolean') { wa.connected = body.connected; if (!body.connected) wa.last_history_sync = null }
    if (typeof body.dnd === 'boolean') wa.dnd_mode = body.dnd
    if (typeof body.failLock === 'boolean') scenario.failLock = body.failLock
    return json(200, { ok: true, webhooks: wa.webhooks.length, chats: wa.chats.length })
  })

  /* ── KARMAX: comms.send ─────────────────────────────────────────────── */
  const said = new Map()
  api.karmax('POST', /^\/api\/tools\/comms\.send$/, ({ body, json }) => {
    const fail = (error) => json(200, { tool: 'comms.send', ok: false, error })
    const target = String(body.target || '')
    const content = String(body.content || '').trim()
    if (!target) return fail('target is required')
    if (!content) return fail('content is required')
    const chat = wa.chats.find((c) => c.jid === target || c.jid.startsWith(target.replace(/\D/g, '') + '@'))
    if (!wa.dnd_mode) return fail('failed to send message: DND mode is off; automation is disabled')
    if (!wa.connected) return fail('failed to send message: WhatsApp client is not connected')
    if (!chat) return fail(`failed to send message: no matches found for "${target}"`)
    if (chat.locked) return fail(`failed to send message: chat ${chat.jid} is locked`)
    const key = chat.jid + '\0' + content
    if (said.has(key)) return fail('failed to send message: comms: refusing to repeat a message already sent to this target: identical message sent under 6h ago')
    said.set(key, now())
    msgs[chat.jid] ??= []
    msgs[chat.jid].push({ id: `3EB0${String(mid++).padStart(6, '0')}`, chat_jid: chat.jid, sender_jid: wa.user_jid, content, timestamp: iso(), is_from_me: true, message_type: 'text' })
    chat.last_message_at = iso()
    chat.last_message_preview = content
    log('wacli', 'info', `Sent text to ${chat.jid}`)
    return json(200, { tool: 'comms.send', ok: true, output: { channel_id: 'whatsapp-main', target, status: 'sent' } })
  })
}
