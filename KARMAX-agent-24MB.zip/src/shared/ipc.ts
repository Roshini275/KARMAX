/**
 * The contract between the Electron main process and the renderer.
 *
 * The renderer NEVER holds secrets and never talks to the daemons directly in Electron: the API token and
 * the Anthropic key live in main (safeStorage) and every daemon call is proxied through `bridge.daemon`.
 * In a plain browser (dev/test against fixtures/mock-daemon) `src/renderer/lib/bridge.ts` supplies a
 * fetch-based shim that implements this SAME interface, so features are written once.
 *
 * Owner: workstream A implements the Electron side (electron/main/*, electron/preload/*).
 * Everyone else only consumes `KarmaxBridge` through `getBridge()`.
 */

// ── Daemon proxy ─────────────────────────────────────────────────────────────

/** karmax = the KARMAX daemon API (default :9091, bearer auth). wacli = the wacli local API (default :8765). */
export type DaemonTarget = 'karmax' | 'wacli'

export interface DaemonRequest {
  target?: DaemonTarget // default 'karmax'
  method: string
  path: string // begins with "/", e.g. "/api/loops"
  query?: Record<string, string | number | boolean | undefined>
  body?: unknown
}

export interface DaemonResponse {
  ok: boolean
  status: number
  /** Parsed JSON when the response was JSON, otherwise the raw text. */
  body: unknown
}

// ── Process supervision (electron/main/supervisor.ts) ────────────────────────

export type ProcName = 'karmax' | 'wacli'

/**
 * stopped  – not running, not desired
 * starting – spawned, waiting for health
 * running  – healthy
 * crashed  – exited unexpectedly, restart pending
 * backoff  – waiting before the next restart attempt
 * external – something we did not spawn already answers on the port; we attach read-only and never kill it
 * missing  – binary not installed yet (setup wizard has not run)
 */
export type ProcState = 'stopped' | 'starting' | 'running' | 'crashed' | 'backoff' | 'external' | 'missing'

export interface ProcStatus {
  name: ProcName
  state: ProcState
  healthy: boolean
  pid?: number
  startedAt?: string
  restarts: number
  nextRestartAt?: string
  lastExit?: { code: number | null; signal?: string; at: string }
  binaryPath?: string
  /** Human-readable why (e.g. "WhatsApp is not paired yet"), shown next to a stopped/crashed state. */
  reason?: string
}

export interface ConnectionState {
  mode: 'electron' | 'web'
  karmaxUrl: string
  wacliUrl: string
  hasToken: boolean
  /** GET /api/ping succeeded and service === "karmax". */
  reachable: boolean
  version?: string
  agent?: string
}

// ── Logs (electron/main/logs.ts) ─────────────────────────────────────────────

export type LogLevel = 'debug' | 'info' | 'warn' | 'error'
export type LogSource = 'karmax' | 'wacli' | 'app'

export interface LogLine {
  /** Monotonic per-process sequence number, for de-duplication and "since" queries. */
  seq: number
  ts: string // ISO 8601
  source: LogSource
  level: LogLevel
  /** Set when the line came from a loop ("loop=<name>" field / prefix) so the UI can filter per loop. */
  loop?: string
  message: string
}

export interface LogQuery {
  limit?: number
  sinceSeq?: number
  source?: LogSource
  level?: LogLevel
}

// ── First-run setup wizard (electron/main/setup/*) ───────────────────────────

export type SetupStepId =
  | 'prereqs' // claude CLI present + logged in, Windows version, ports free
  | 'model' // Anthropic API key -> ~/.karmax/.env (+ generated API token / webhook secret)
  | 'binaries' // karmax.exe + wacli.exe verified (sha256) and placed
  | 'config' // karmax.yaml patched: operator number, wacli path, target_chat
  | 'whatsapp' // `wacli login` (pairing code; QR fallback). MUST run before the wacli daemon starts: it opens the session store directly
  | 'services' // supervisor started wacli daemon + karmax, both healthy
  | 'operator' // wacli webhook -> KARMAX scoped to the operator chat
  | 'lockdown' // every other chat locked, DND on
  | 'verify' // test message round trip

export type StepStatus = 'todo' | 'active' | 'done' | 'error' | 'skipped'

export interface SetupStep {
  id: SetupStepId
  status: StepStatus
  detail?: string
  error?: string
}

export type WaMode = 'dedicated' | 'own'

export interface PairingState {
  running: boolean
  method: 'code' | 'qr'
  /** 8-char pairing code to type into WhatsApp > Linked devices > Link with phone number. */
  code?: string
  /** PNG data URI when wacli produced qr.png. */
  qrDataUri?: string
  lines: string[]
  error?: string
}

export interface PrereqReport {
  os: string
  claudeCli: { found: boolean; version?: string; loggedIn?: boolean; hint?: string }
  ports: { karmax: number; wacli: number; webhooks: number; free: boolean; busyBy?: string }
  ok: boolean
}

export interface SetupState {
  completed: boolean
  steps: SetupStep[]
  hasApiKey: boolean
  /** How the model step was satisfied: an Anthropic key, or KARMAX running purely on the signed-in Claude Code CLI. */
  modelAuth?: 'api-key' | 'claude-code'
  /** Human's number that sends tasks. Digits with country code. Never committed anywhere. */
  operatorNumber?: string
  waMode?: WaMode
  pairing?: PairingState
}

export interface SetupApi {
  state(): Promise<SetupState>
  checkPrereqs(): Promise<PrereqReport>
  saveModelKey(apiKey: string): Promise<void>
  /** No API key: KARMAX's brain is the signed-in Claude Code CLI. Still generates the API token and webhook secret. */
  saveModelClaudeCode(): Promise<void>
  installBinaries(): Promise<void>
  writeConfig(input: { operatorNumber: string; waMode: WaMode }): Promise<void>
  startServices(): Promise<void>
  startPairing(input: { method: 'code' | 'qr'; phone?: string }): Promise<void>
  cancelPairing(): Promise<void>
  applyOperatorLockdown(): Promise<void>
  sendTestMessage(): Promise<void>
  reset(): Promise<void>
}

// ── The bridge ───────────────────────────────────────────────────────────────

export type Unsubscribe = () => void

export interface StreamHandle {
  /** Resolves when the stream ends (server closed it or abort() was called). Rejects on transport error. */
  done: Promise<void>
  abort(): void
}

export interface StartupPrefs {
  /** Launch KARMAX Desktop (and therefore the supervised daemons) when the user signs in to Windows. */
  openAtLogin: boolean
  /** Closing the window hides to the tray and keeps the daemons running; Quit is in the tray menu. */
  minimizeToTray: boolean
}

export interface KarmaxBridge {
  app: {
    version(): Promise<string>
    platform: string
    openExternal(url: string): Promise<void>
    /** Minimise / maximise / close for the frameless window; no-ops in the browser shim. */
    window: { minimize(): void; toggleMaximize(): void; close(): void }
  }

  daemon: {
    request(req: DaemonRequest): Promise<DaemonResponse>
    /** NDJSON stream (POST). `onLine` receives each parsed JSON line. */
    stream(req: DaemonRequest, onLine: (line: unknown) => void): StreamHandle
  }

  connection: {
    get(): Promise<ConnectionState>
    onChange(cb: (s: ConnectionState) => void): Unsubscribe
    /** Web shim only: point at a different daemon. Electron uses the token stored in safeStorage. */
    configure?(input: { karmaxUrl?: string; wacliUrl?: string; token?: string }): Promise<void>
  }

  supervisor: {
    status(): Promise<ProcStatus[]>
    start(name: ProcName): Promise<void>
    stop(name: ProcName): Promise<void>
    restart(name: ProcName): Promise<void>
    onStatus(cb: (s: ProcStatus[]) => void): Unsubscribe
  }

  logs: {
    history(q?: LogQuery): Promise<LogLine[]>
    /** Live tail. Lines already returned by history() may be re-delivered; de-dupe on (source, seq). */
    onLine(cb: (l: LogLine) => void): Unsubscribe
  }

  setup: SetupApi & {
    onChange(cb: (s: SetupState) => void): Unsubscribe
  }

  startup: {
    get(): Promise<StartupPrefs>
    set(patch: Partial<StartupPrefs>): Promise<StartupPrefs>
  }
}

declare global {
  interface Window {
    /** Present only inside Electron (exposed by electron/preload). */
    karmax?: KarmaxBridge
  }
}

// ── IPC channel names (main <-> preload). Renderer code must not import these. ──

export const IPC = {
  appVersion: 'app:version',
  openExternal: 'app:openExternal',
  winMinimize: 'win:minimize',
  winToggleMax: 'win:toggleMaximize',
  winClose: 'win:close',
  daemonRequest: 'daemon:request',
  daemonStreamStart: 'daemon:stream:start',
  daemonStreamAbort: 'daemon:stream:abort',
  daemonStreamEvent: 'daemon:stream:event', // main -> renderer { id, line? , end?, error? }
  connectionGet: 'connection:get',
  connectionChanged: 'connection:changed',
  supervisorStatus: 'supervisor:status',
  supervisorStart: 'supervisor:start',
  supervisorStop: 'supervisor:stop',
  supervisorRestart: 'supervisor:restart',
  supervisorChanged: 'supervisor:changed',
  logsHistory: 'logs:history',
  logsLine: 'logs:line',
  setupInvoke: 'setup:invoke', // { method, args }
  setupChanged: 'setup:changed',
  startupGet: 'startup:get',
  startupSet: 'startup:set'
} as const
