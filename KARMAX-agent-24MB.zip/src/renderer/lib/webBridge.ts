/**
 * Browser implementation of KarmaxBridge, used for `npm run dev:web` and Playwright screenshots against
 * fixtures/mock-daemon. It talks to the daemons over plain fetch. In the real app none of this runs:
 * Electron's preload exposes `window.karmax` and main proxies everything (so secrets never reach the renderer).
 *
 * Workstream A owns the `setup` simulation (webSetup) so the wizard can be built and screenshotted here.
 */
import type {
  ConnectionState,
  DaemonRequest,
  DaemonResponse,
  KarmaxBridge,
  LogLine,
  LogQuery,
  ProcName,
  ProcStatus,
  StreamHandle
} from '@shared/ipc'
import { createWebSetup } from './webSetup'

const qs = new URLSearchParams(typeof location !== 'undefined' ? location.search : '')
const store = (k: string): string | null => {
  try {
    return localStorage.getItem(k)
  } catch {
    return null
  }
}

const cfg = {
  karmaxUrl: qs.get('daemon') || store('km.daemon') || 'http://127.0.0.1:9091',
  wacliUrl: qs.get('wacli') || store('km.wacli') || 'http://127.0.0.1:8765',
  token: qs.get('token') || store('km.token') || ''
}

function urlFor(req: DaemonRequest): string {
  const base = req.target === 'wacli' ? cfg.wacliUrl : cfg.karmaxUrl
  const u = new URL(base + req.path)
  for (const [k, v] of Object.entries(req.query ?? {})) if (v !== undefined) u.searchParams.set(k, String(v))
  return u.toString()
}

function headersFor(req: DaemonRequest): Record<string, string> {
  const h: Record<string, string> = {}
  if (req.body !== undefined) h['Content-Type'] = 'application/json'
  if (cfg.token && req.target !== 'wacli') h.Authorization = `Bearer ${cfg.token}`
  return h
}

async function request(req: DaemonRequest): Promise<DaemonResponse> {
  try {
    const res = await fetch(urlFor(req), {
      method: req.method,
      headers: headersFor(req),
      body: req.body !== undefined ? JSON.stringify(req.body) : undefined
    })
    const text = await res.text()
    let body: unknown = text
    try {
      body = text ? JSON.parse(text) : null
    } catch {
      /* keep text */
    }
    return { ok: res.ok, status: res.status, body }
  } catch (e) {
    return { ok: false, status: 0, body: { error: e instanceof Error ? `Cannot reach daemon: ${e.message}` : 'Cannot reach daemon' } }
  }
}

function stream(req: DaemonRequest, onLine: (line: unknown) => void): StreamHandle {
  const ctl = new AbortController()
  const done = (async () => {
    const res = await fetch(urlFor(req), {
      method: req.method,
      headers: headersFor(req),
      body: req.body !== undefined ? JSON.stringify(req.body) : undefined,
      signal: ctl.signal
    })
    if (!res.ok || !res.body) {
      const t = await res.text().catch(() => '')
      let msg = `Request failed (${res.status})`
      try {
        const j = JSON.parse(t)
        if (j?.error) msg = String(j.error)
      } catch {
        /* ignore */
      }
      throw new Error(msg)
    }
    const reader = res.body.getReader()
    const dec = new TextDecoder()
    let buf = ''
    try {
      for (;;) {
        const { value, done: fin } = await reader.read()
        if (fin) break
        buf += dec.decode(value, { stream: true })
        let nl: number
        while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl).trim()
          buf = buf.slice(nl + 1)
          if (!line) continue
          try {
            onLine(JSON.parse(line))
          } catch {
            /* skip malformed line */
          }
        }
      }
      if (buf.trim()) {
        try {
          onLine(JSON.parse(buf.trim()))
        } catch {
          /* ignore */
        }
      }
    } catch (e) {
      if ((e as Error).name !== 'AbortError') throw e
    }
  })()
  return { done, abort: () => ctl.abort() }
}

async function connection(): Promise<ConnectionState> {
  const r = await request({ target: 'karmax', method: 'GET', path: '/api/ping' })
  const b = (r.body ?? {}) as { service?: string; version?: string; agent?: string }
  return {
    mode: 'web',
    karmaxUrl: cfg.karmaxUrl,
    wacliUrl: cfg.wacliUrl,
    hasToken: !!cfg.token,
    reachable: r.ok && b.service === 'karmax',
    version: b.version,
    agent: b.agent
  }
}

function poll<T>(fn: () => Promise<T>, cb: (v: T) => void, ms: number, same: (a: T, b: T) => boolean = (a, b) => JSON.stringify(a) === JSON.stringify(b)) {
  let last: T | undefined
  let stopped = false
  const tick = async () => {
    try {
      const v = await fn()
      if (!stopped && (last === undefined || !same(last, v))) {
        last = v
        cb(v)
      }
    } catch {
      /* ignore */
    }
  }
  const t = setInterval(tick, ms)
  void tick()
  return () => {
    stopped = true
    clearInterval(t)
  }
}

async function supervisorStatus(): Promise<ProcStatus[]> {
  const r = await request({ target: 'karmax', method: 'GET', path: '/__mock/supervisor' })
  if (r.ok && Array.isArray(r.body)) return r.body as ProcStatus[]
  // Real daemon without the mock: report what we can observe.
  const c = await connection()
  const w = await request({ target: 'wacli', method: 'GET', path: '/status' })
  return [
    { name: 'karmax', state: c.reachable ? 'external' : 'stopped', healthy: c.reachable, restarts: 0 },
    { name: 'wacli', state: w.ok ? 'external' : 'stopped', healthy: w.ok, restarts: 0 }
  ]
}

async function logHistory(q: LogQuery = {}): Promise<LogLine[]> {
  const r = await request({
    target: 'karmax',
    method: 'GET',
    path: '/__mock/logs',
    query: { limit: q.limit ?? 500, sinceSeq: q.sinceSeq, source: q.source, level: q.level }
  })
  return r.ok && Array.isArray(r.body) ? (r.body as LogLine[]) : []
}

const startupPrefs = { openAtLogin: true, minimizeToTray: true }

export function createWebBridge(): KarmaxBridge {
  const setup = createWebSetup(qs.get('setup') === '1')
  return {
    app: {
      version: async () => 'web-preview',
      platform: 'web',
      openExternal: async (url) => void window.open(url, '_blank', 'noopener'),
      window: { minimize() {}, toggleMaximize() {}, close() {} }
    },
    daemon: { request, stream },
    connection: {
      get: connection,
      onChange: (cb) => poll(connection, cb, 4000),
      configure: async (input) => {
        if (input.karmaxUrl) cfg.karmaxUrl = input.karmaxUrl
        if (input.wacliUrl) cfg.wacliUrl = input.wacliUrl
        if (input.token !== undefined) cfg.token = input.token
        try {
          localStorage.setItem('km.daemon', cfg.karmaxUrl)
          localStorage.setItem('km.wacli', cfg.wacliUrl)
          localStorage.setItem('km.token', cfg.token)
        } catch {
          /* private mode */
        }
      }
    },
    supervisor: {
      status: supervisorStatus,
      start: async (n: ProcName) => void (await request({ method: 'POST', path: `/__mock/supervisor/${n}/start` })),
      stop: async (n: ProcName) => void (await request({ method: 'POST', path: `/__mock/supervisor/${n}/stop` })),
      restart: async (n: ProcName) => void (await request({ method: 'POST', path: `/__mock/supervisor/${n}/restart` })),
      onStatus: (cb) => poll(supervisorStatus, cb, 3000)
    },
    logs: {
      history: logHistory,
      onLine: (cb) => {
        let lastSeq = 0
        let alive = true
        const tick = async () => {
          const lines = await logHistory({ sinceSeq: lastSeq, limit: 200 })
          for (const l of lines) {
            if (l.seq > lastSeq) lastSeq = l.seq
            if (alive) cb(l)
          }
        }
        void logHistory({ limit: 1 }).then((l) => {
          lastSeq = l.at(-1)?.seq ?? 0
        })
        const t = setInterval(() => void tick(), 1000)
        return () => {
          alive = false
          clearInterval(t)
        }
      }
    },
    setup,
    startup: {
      get: async () => ({ ...startupPrefs }),
      set: async (patch) => Object.assign(startupPrefs, patch)
    }
  }
}
