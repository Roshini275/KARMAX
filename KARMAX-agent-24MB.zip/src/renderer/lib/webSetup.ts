/**
 * Browser simulation of the first-run wizard backend (the real one is electron/main/setup/*).
 *
 * It mirrors the real state machine closely enough that the wizard UI can be built and screenshotted without Electron:
 * same step order and blocking rules, timed progress with live `detail` updates, a streaming fake pairing code
 * (K4Q7-9XPM), the operator step that waits for a first message, and failure injection.
 *
 * URL switches (all optional):
 *   ?setup=1                      start with the wizard incomplete (otherwise the simulation starts completed)
 *   ?claude=missing|unauth        prereqs: Claude Code CLI not found / not signed in
 *   ?setupfail=<step>             the FIRST attempt of binaries | whatsapp | services | operator | verify fails (retry succeeds)
 *   ?setupat=<step|finish>        start with every earlier step done (screenshots / resume testing)
 *   ?simspeed=0.2                 multiply every delay (0.2 = five times faster)
 */
import type { KarmaxBridge, PairingState, PrereqReport, SetupState, SetupStep, SetupStepId, WaMode } from '@shared/ipc'

const ORDER: SetupStepId[] = ['prereqs', 'model', 'binaries', 'config', 'whatsapp', 'services', 'operator', 'lockdown', 'verify']
const TITLES: Record<SetupStepId, string> = {
  prereqs: 'Prerequisites',
  model: 'Model access',
  binaries: 'Install KARMAX',
  config: 'Operator number',
  whatsapp: 'Link WhatsApp',
  services: 'Start services',
  operator: 'Connect operator',
  lockdown: 'Lock down chats',
  verify: 'Test message'
}

const NO_WACLI =
  'wacli.exe is not bundled with this build, and the wacli project publishes no Windows release. Use an installer that includes resources/bin/wacli.exe, or build wacli for Windows and place it in the install folder.'

/** A deterministic, obviously synthetic QR-looking SVG (the preview cannot produce a scannable code). */
function fakeQr(seed: number): string {
  const n = 29
  let s = seed
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 0xffffffff)
  const cells: string[] = []
  const finder = (x0: number, y0: number) => {
    for (let y = 0; y < 7; y++)
      for (let x = 0; x < 7; x++) if (x === 0 || y === 0 || x === 6 || y === 6 || (x >= 2 && x <= 4 && y >= 2 && y <= 4)) cells.push(`<rect x="${x0 + x}" y="${y0 + y}" width="1" height="1"/>`)
  }
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) {
      const inFinder = (x < 8 && y < 8) || (x > n - 9 && y < 8) || (x < 8 && y > n - 9)
      if (!inFinder && rnd() > 0.52) cells.push(`<rect x="${x}" y="${y}" width="1" height="1"/>`)
    }
  finder(0, 0)
  finder(n - 7, 0)
  finder(0, n - 7)
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-2 -2 ${n + 4} ${n + 4}"><rect x="-2" y="-2" width="${n + 4}" height="${n + 4}" fill="#fff"/><g fill="#111">${cells.join('')}</g></svg>`
  return `data:image/svg+xml;base64,${btoa(svg)}`
}

export function createWebSetup(startIncomplete: boolean): KarmaxBridge['setup'] {
  const qs = new URLSearchParams(typeof location !== 'undefined' ? location.search : '')
  const speed = Math.max(0.02, Number(qs.get('simspeed') ?? 1) || 1)
  const claude = qs.get('claude')
  const failStep = qs.get('setupfail') as SetupStepId | null
  const at = qs.get('setupat')
  const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms * speed))
  const failedOnce = new Set<SetupStepId>()
  const shouldFail = (id: SetupStepId) => {
    if (failStep !== id || failedOnce.has(id)) return false
    failedOnce.add(id)
    return true
  }

  const listeners = new Set<(s: SetupState) => void>()
  let steps: SetupStep[] = ORDER.map((id) => ({ id, status: startIncomplete ? 'todo' : 'done' }))
  let operatorNumber: string | undefined = startIncomplete ? undefined : '919876543210'
  let waMode: WaMode | undefined = startIncomplete ? undefined : 'dedicated'
  let hasApiKey = !startIncomplete
  let modelAuth: 'api-key' | 'claude-code' | undefined = startIncomplete ? undefined : 'api-key'
  let pairing: PairingState | undefined
  let pairingToken = 0
  const running = new Set<SetupStepId>()

  const snapshot = (): SetupState => ({
    completed: steps.every((s) => s.status === 'done' || s.status === 'skipped') && steps.find((s) => s.id === 'verify')?.status === 'done',
    steps: steps.map((s) => ({ ...s })),
    hasApiKey,
    ...(modelAuth ? { modelAuth } : {}),
    ...(operatorNumber ? { operatorNumber } : {}),
    ...(waMode ? { waMode } : {}),
    ...(pairing ? { pairing: { ...pairing, lines: [...pairing.lines] } } : {})
  })
  const emit = () => {
    const s = snapshot()
    listeners.forEach((l) => l(s))
  }
  const put = (id: SetupStepId, patch: Partial<SetupStep>) => {
    steps = steps.map((s) => (s.id === id ? { id, status: patch.status ?? s.status, ...(patch.detail !== undefined ? (patch.detail ? { detail: patch.detail } : {}) : s.detail ? { detail: s.detail } : {}), ...(patch.error ? { error: patch.error } : {}) } : s))
    emit()
  }
  const begin = (id: SetupStepId, detail?: string) => put(id, { status: 'active', detail: detail ?? '', error: undefined })
  const detail = (id: SetupStepId, d: string) => put(id, { detail: d })
  const done = (id: SetupStepId, d?: string) => put(id, { status: 'done', detail: d ?? '', error: undefined })
  const fail = (id: SetupStepId, error: string) => put(id, { status: 'error', error })
  const status = (id: SetupStepId) => steps.find((s) => s.id === id)!.status

  const blocker = (id: SetupStepId): string | null => {
    for (const prev of ORDER) {
      if (prev === id) return null
      if (status(prev) !== 'done' && status(prev) !== 'skipped') return `Finish "${TITLES[prev]}" first.`
    }
    return null
  }
  async function guard<T>(id: SetupStepId, work: () => Promise<T>): Promise<T> {
    const b = blocker(id)
    if (b) throw new Error(b)
    if (running.has(id)) throw new Error(`"${TITLES[id]}" is already running.`)
    running.add(id)
    begin(id)
    try {
      return await work()
    } catch (e) {
      fail(id, e instanceof Error ? e.message : String(e))
      throw e
    } finally {
      running.delete(id)
    }
  }

  // ── preset progress ──────────────────────────────────────────────────────
  if (startIncomplete && at) {
    const idx = at === 'finish' ? ORDER.length : ORDER.indexOf(at as SetupStepId)
    if (idx >= 0) {
      const details: Partial<Record<SetupStepId, string>> = {
        prereqs: 'Claude Code 2.1.3 is installed and signed in.',
        model: 'Key sk-ant-…4f9c saved locally. API token and webhook secret generated.',
        binaries: 'karmax 0.2.0 and wacli 1.4.0 verified (sha256) and installed.',
        config: 'whatsapp-main → 91********10 (dedicated number)',
        whatsapp: 'WhatsApp linked (15*******00).',
        services: 'wacli and KARMAX are running and healthy.',
        operator: 'Webhook #1 delivers only 91********10 to KARMAX.',
        lockdown: 'Only 91********10 is unlocked. 41 other chats are locked. DND is on.',
        verify: 'Test message sent at 09:41. Check your phone.'
      }
      ORDER.slice(0, idx).forEach((id) => {
        steps = steps.map((s) => (s.id === id ? { id, status: 'done', detail: details[id] } : s))
      })
      hasApiKey = idx > 1
      if (idx > 3) {
        operatorNumber = '919876543210'
        waMode = 'dedicated'
      }
    }
  }

  // ── background operator step ─────────────────────────────────────────────
  let operatorRun = 0
  async function runOperator() {
    const run = ++operatorRun
    const dedicated = waMode !== 'own'
    begin(
      'operator',
      dedicated
        ? `Waiting for your first message. From +${operatorNumber ?? '919876543210'}, send "hi" to the KARMAX number (+15551230000) on WhatsApp.`
        : 'Waiting for your first message. On your phone, open WhatsApp, open "Message yourself" and send "hi".'
    )
    const willFail = shouldFail('operator')
    await wait(willFail ? 3500 : 7000)
    if (run !== operatorRun) return
    if (willFail) {
      fail('operator', `No message from +${operatorNumber ?? '919876543210'} arrived within 10 minutes. From that number, send "hi" to the KARMAX number on WhatsApp. Then retry.`)
      return
    }
    detail('operator', 'Message received. Registering the webhook…')
    await wait(900)
    if (run !== operatorRun) return
    done(
      'operator',
      dedicated
        ? `Webhook #1 delivers only ${(operatorNumber ?? '919876543210').replace(/^(\d{2})\d+(\d{2})$/, '$1********$2')} to KARMAX.`
        : 'Webhook #1 delivers only your own chat to KARMAX. Note: messages you type to yourself reach KARMAX as "sent by you", which this KARMAX version ignores, so tasks must come from the app; KARMAX can still message you here.'
    )
  }
  if (startIncomplete && at === 'operator') void runOperator()

  // ── the API ──────────────────────────────────────────────────────────────
  const api: KarmaxBridge['setup'] = {
    state: async () => snapshot(),
    onChange: (cb) => {
      listeners.add(cb)
      return () => listeners.delete(cb)
    },

    checkPrereqs: async (): Promise<PrereqReport> => {
      begin('prereqs', 'Checking this computer…')
      await wait(1100)
      const found = claude !== 'missing'
      const loggedIn = claude === 'unauth' ? false : found ? true : undefined
      const report: PrereqReport = {
        os: 'Windows 11 (build 22631, x64)',
        claudeCli: found
          ? { found: true, version: '2.1.3', loggedIn, ...(loggedIn === false ? { hint: 'Claude Code is installed but not signed in. Run "claude" in a terminal and sign in.' } : {}) }
          : { found: false, hint: 'Install Claude Code (https://docs.claude.com/en/docs/claude-code/setup), then run "claude" once and sign in. KARMAX hands coding work to it.' },
        ports: { karmax: 9091, wacli: 8765, webhooks: 9090, free: true },
        ok: found
      }
      if (!found) put('prereqs', { status: 'skipped', detail: 'Claude Code CLI not found. KARMAX cannot delegate coding tasks until it is installed.' })
      else if (loggedIn === false) put('prereqs', { status: 'skipped', detail: 'Claude Code is installed but not signed in.' })
      else done('prereqs', 'Claude Code 2.1.3 is installed and signed in.')
      return report
    },

    saveModelKey: (apiKey) =>
      guard('model', async () => {
        const key = apiKey.trim()
        if (!key.startsWith('sk-ant-')) throw new Error('Anthropic API keys start with "sk-ant-".')
        if (key.length < 24) throw new Error('That key looks too short.')
        detail('model', 'Checking the key with Anthropic…')
        await wait(700)
        if (/invalid/i.test(key)) throw new Error('Anthropic rejected this API key. Check that you copied all of it and that it has not been revoked.')
        detail('model', 'Writing ~/.karmax/.env…')
        await wait(500)
        hasApiKey = true
        modelAuth = 'api-key'
        done('model', `Key sk-ant-…${key.slice(-4)} saved locally. API token and webhook secret generated.`)
      }),

    saveModelClaudeCode: () =>
      guard('model', async () => {
        detail('model', 'Writing ~/.karmax/.env…')
        await wait(600)
        modelAuth = 'claude-code'
        done('model', 'Using your signed-in Claude Code. No API key needed. API token and webhook secret generated.')
      }),

    installBinaries: () =>
      guard('binaries', async () => {
        const seq = ['Reading manifest.json (schema 1)…', 'Verifying karmax.exe sha256…', 'Copying karmax.exe to %LOCALAPPDATA%\\KARMAX (18.4 MB)…', 'Verifying wacli.exe sha256…']
        for (const d of seq) {
          detail('binaries', d)
          await wait(650)
        }
        if (shouldFail('binaries')) throw new Error(NO_WACLI)
        for (const d of ['Copying wacli.exe to %LOCALAPPDATA%\\KARMAX (24.1 MB)…', 'Checking that karmax starts…']) {
          detail('binaries', d)
          await wait(650)
        }
        done('binaries', 'karmax 0.2.0 and wacli 1.4.0 verified (sha256) and installed.')
      }),

    writeConfig: (input) =>
      guard('config', async () => {
        const digits = input.operatorNumber.replace(/[^\d]/g, '').replace(/^00/, '')
        if (digits.length < 8 || digits.length > 15) throw new Error('Enter 8-15 digits including the country code.')
        if (digits.startsWith('0')) throw new Error('Start with the country code, without a leading 0 or +.')
        for (const d of ['Running karmax init…', 'Patching karmax.yaml (api, harness, whatsapp channel)…', 'Running karmax config validate…']) {
          detail('config', d)
          await wait(480)
        }
        operatorNumber = digits
        waMode = input.waMode
        done('config', `whatsapp-main → ${digits.replace(/^(\d{2})\d+(\d{2})$/, '$1********$2')} (${input.waMode === 'dedicated' ? 'dedicated number' : 'own number'})`)
      }),

    startPairing: async ({ method, phone }) => {
      const b = blocker('whatsapp')
      if (b) throw new Error(b)
      if (pairing?.running) throw new Error('WhatsApp pairing is already in progress.')
      const digits = (phone ?? '').replace(/[^\d]/g, '')
      if (method === 'code' && (digits.length < 8 || digits.length > 15)) throw new Error('Enter 8-15 digits including the country code.')
      const token = ++pairingToken
      const lines: string[] = []
      pairing = { running: true, method, lines }
      begin('whatsapp', method === 'code' ? 'Requesting a pairing code…' : 'Waiting for the QR code…')
      const push = (l: string, patch: Partial<PairingState> = {}) => {
        if (token !== pairingToken) return
        lines.push(l)
        pairing = { ...pairing!, ...patch, lines }
        emit()
      }
      void (async () => {
        await wait(500)
        push(`wacli login --skip-access-config${method === 'code' ? ' --pair-code' : ''}`)
        await wait(900)
        if (token !== pairingToken) return
        if (method === 'code') {
          push('Pairing code: XXXX-XXXX', { code: 'K4Q7-9XPM' })
          push('Open WhatsApp on your phone -> Linked Devices -> Link with phone number.')
        } else {
          push('QR code written to C:\\Users\\you\\.wacli\\qr.png', { qrDataUri: fakeQr(7) })
          push('Scan this QR with WhatsApp -> Linked Devices.')
        }
        await wait(7000)
        if (token !== pairingToken) return
        if (shouldFail('whatsapp')) {
          const msg = 'The pairing code expired before it was entered on the phone. Start again to get a fresh code.'
          pairing = { running: false, method, lines, error: msg }
          fail('whatsapp', msg)
          return
        }
        push('Login successful.')
        detail('whatsapp', 'Linked. Syncing chats…')
        await wait(700)
        push('Syncing chats, messages, and contacts...')
        await wait(1800)
        if (token !== pairingToken) return
        push('Sync complete. Chats: 42, messages: 1300 (history sync observed)')
        pairing = { running: false, method, lines }
        done('whatsapp', digits ? `WhatsApp linked (${digits.replace(/^(\d{2})\d+(\d{2})$/, '$1*******$2')}).` : 'WhatsApp linked.')
      })()
    },
    cancelPairing: async () => {
      if (!pairing?.running) return
      pairingToken++
      pairing = { ...pairing, running: false }
      put('whatsapp', { status: 'todo', detail: '' })
    },

    startServices: async () => {
      if (status('services') === 'done' && status('operator') !== 'done') {
        void runOperator()
        return
      }
      await guard('services', async () => {
        for (const d of ['Starting wacli…', 'wacli is healthy. Starting KARMAX…']) {
          detail('services', d)
          await wait(900)
        }
        if (shouldFail('services')) throw new Error('KARMAX did not become healthy (last exit 1). Open the Logs page for the process output.')
        detail('services', 'KARMAX is healthy. Checking the API token…')
        await wait(600)
        done('services', 'wacli and KARMAX are running and healthy.')
      })
      void runOperator()
    },

    applyOperatorLockdown: () =>
      guard('lockdown', async () => {
        for (const d of ['Locking 41 chats…', 'Turning Do Not Disturb on…', 'Re-reading chats and status to verify…']) {
          detail('lockdown', d)
          await wait(700)
        }
        done('lockdown', `Only ${(operatorNumber ?? '919876543210').replace(/^(\d{2})\d+(\d{2})$/, '$1********$2')} is unlocked. 41 other chats are locked. DND is on.`)
      }),

    sendTestMessage: () =>
      guard('verify', async () => {
        detail('verify', 'Asking KARMAX to send the message…')
        await wait(1400)
        if (shouldFail('verify')) throw new Error('KARMAX could not send the message: DND mode is off; automation is disabled. Turn Do Not Disturb on in wacli.')
        done('verify', `Test message sent at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Check your phone.`)
      }),

    reset: async () => {
      pairingToken++
      operatorRun++
      running.clear()
      pairing = undefined
      operatorNumber = undefined
      waMode = undefined
      hasApiKey = false
      modelAuth = undefined
      failedOnce.clear()
      steps = ORDER.map((id) => ({ id, status: 'todo' }))
      emit()
    }
  }
  return api
}
