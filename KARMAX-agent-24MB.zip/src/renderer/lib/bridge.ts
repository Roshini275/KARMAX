import type { KarmaxBridge } from '@shared/ipc'
import { createWebBridge } from './webBridge'

let web: KarmaxBridge | null = null

/** Inside Electron this is the preload-exposed bridge; in a plain browser it is the fetch-based shim. */
export function getBridge(): KarmaxBridge {
  if (typeof window !== 'undefined' && window.karmax) return window.karmax
  return (web ??= createWebBridge())
}

export const isElectron = () => typeof window !== 'undefined' && !!window.karmax
