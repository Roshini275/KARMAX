import { create } from 'zustand'

export type ThemePref = 'dark' | 'light' | 'system'

const read = (k: string): string | null => {
  try {
    return localStorage.getItem(k)
  } catch {
    return null
  }
}
const write = (k: string, v: string) => {
  try {
    localStorage.setItem(k, v)
  } catch {
    /* storage unavailable: preference just won't persist */
  }
}

export function resolveTheme(pref: ThemePref): 'dark' | 'light' {
  if (pref !== 'system') return pref
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark'
}

interface UiState {
  theme: ThemePref
  sidebarCollapsed: boolean
  setTheme: (t: ThemePref) => void
  toggleSidebar: () => void
}

export const useUi = create<UiState>((set, get) => ({
  theme: (read('km.theme') as ThemePref) || 'dark',
  sidebarCollapsed: read('km.sidebar') === '1',
  setTheme: (theme) => {
    write('km.theme', theme)
    set({ theme })
    document.documentElement.dataset.theme = resolveTheme(theme)
  },
  toggleSidebar: () => {
    const v = !get().sidebarCollapsed
    write('km.sidebar', v ? '1' : '0')
    set({ sidebarCollapsed: v })
  }
}))
