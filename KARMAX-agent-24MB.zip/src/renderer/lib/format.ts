/** Small, dependency-free formatting helpers shared by every feature. */

export function timeAgo(input: string | number | Date | null | undefined, now: number = Date.now()): string {
  if (input == null || input === '') return '—'
  const t = new Date(input).getTime()
  if (Number.isNaN(t)) return '—'
  const s = Math.round((now - t) / 1000)
  const abs = Math.abs(s)
  const fut = s < 0
  const unit = (n: number, u: string) => (fut ? `in ${n}${u}` : `${n}${u} ago`)
  if (abs < 5) return fut ? 'in a moment' : 'just now'
  if (abs < 60) return unit(abs, 's')
  if (abs < 3600) return unit(Math.round(abs / 60), 'm')
  if (abs < 86400) return unit(Math.round(abs / 3600), 'h')
  return unit(Math.round(abs / 86400), 'd')
}

export function formatDuration(ms: number | null | undefined): string {
  if (ms == null || !Number.isFinite(ms)) return '—'
  if (ms < 1000) return `${Math.round(ms)}ms`
  const s = ms / 1000
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`
  const m = Math.floor(s / 60)
  return `${m}m ${Math.round(s % 60)}s`
}

export function formatCost(usd: number | null | undefined): string {
  if (usd == null || !Number.isFinite(usd)) return '—'
  if (usd === 0) return '$0'
  if (usd < 0.01) return `$${usd.toFixed(4)}`
  return `$${usd.toFixed(usd < 1 ? 3 : 2)}`
}

export function formatClock(input: string | number | Date, withMs = false): string {
  const d = new Date(input)
  if (Number.isNaN(d.getTime())) return '—'
  const pad = (n: number, w = 2) => String(n).padStart(w, '0')
  const base = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
  return withMs ? `${base}.${pad(d.getMilliseconds(), 3)}` : base
}

/** "+91 98765 43210" style is locale-specific; keep it honest: digits only, with a leading +. */
export function normalizePhone(input: string): string {
  const digits = input.replace(/[^\d]/g, '')
  return digits
}

export function truncate(s: string, n: number): string {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s
}
