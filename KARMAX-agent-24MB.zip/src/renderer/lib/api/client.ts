/**
 * Typed daemon client. Everything goes through the bridge (Electron IPC in the app, fetch in the browser
 * shim), so the renderer never sees the API token and there is no CORS.
 */
import type { z } from 'zod'
import type { DaemonRequest, DaemonTarget, StreamHandle } from '@shared/ipc'
import { getBridge } from '../bridge'
import {
  ActivitySchema,
  ChatOptionsSchema,
  ConversationsResponseSchema,
  HistoryResponseSchema,
  LoopHealthResponseSchema,
  LoopsResponseSchema,
  NotificationsResponseSchema,
  PingSchema,
  ProposalsResponseSchema,
  RegistryDetailSchema,
  RegistryResponseSchema,
  TaskCreateOutputSchema,
  TaskListOutputSchema,
  ToolEnvelopeSchema,
  WacliChatSchema,
  WacliLogSchema,
  WacliStatusSchema,
  WacliWebhookSchema,
  parseChatEvent,
  type ChatEvent
} from './schemas'
import { z as zod } from 'zod'

export class ApiError extends Error {
  status: number
  constructor(message: string, status: number) {
    super(message)
    this.name = 'ApiError'
    this.status = status
  }
}

function errorMessage(body: unknown, status: number): string {
  if (body && typeof body === 'object' && 'error' in body && typeof (body as { error: unknown }).error === 'string') {
    return (body as { error: string }).error
  }
  if (typeof body === 'string' && body.trim()) return body.slice(0, 300)
  if (status === 401) return 'Unauthorized: the API token is missing or wrong.'
  if (status === 0) return 'Cannot reach the daemon.'
  return `Request failed (${status})`
}

async function call<S extends z.ZodType>(schema: S, req: DaemonRequest): Promise<z.output<S>> {
  let res
  try {
    res = await getBridge().daemon.request(req)
  } catch (e) {
    throw new ApiError(e instanceof Error ? e.message : 'Cannot reach the daemon.', 0)
  }
  if (!res.ok) throw new ApiError(errorMessage(res.body, res.status), res.status)
  const parsed = schema.safeParse(res.body)
  if (!parsed.success) {
    console.warn(`[api] unexpected response shape from ${req.method} ${req.path}`, parsed.error.issues)
    throw new ApiError(`Unexpected response from ${req.path}`, res.status)
  }
  return parsed.data
}

async function send(req: DaemonRequest): Promise<unknown> {
  const res = await getBridge().daemon.request(req)
  if (!res.ok) throw new ApiError(errorMessage(res.body, res.status), res.status)
  return res.body
}

const K = (method: string, path: string, extra: Partial<DaemonRequest> = {}): DaemonRequest => ({ target: 'karmax', method, path, ...extra })
const W = (method: string, path: string, extra: Partial<DaemonRequest> = {}): DaemonRequest => ({ target: 'wacli' as DaemonTarget, method, path, ...extra })

/* ── tools envelope (task.create / task.list / task.update ...) ────────── */

/** POST /api/tools/{name}. Output may arrive as an object or as a JSON string; both are handled. */
export async function callTool<S extends z.ZodType>(name: string, input: Record<string, unknown>, schema: S): Promise<z.output<S>> {
  const env = await call(ToolEnvelopeSchema, K('POST', `/api/tools/${encodeURIComponent(name)}`, { body: input }))
  if (!env.ok) throw new ApiError(env.error || `${name} failed`, 200)
  let out = env.output
  if (typeof out === 'string') {
    try {
      out = JSON.parse(out)
    } catch {
      /* leave as string; schema will reject with a clear message */
    }
  }
  const parsed = schema.safeParse(out)
  if (!parsed.success) {
    console.warn(`[api] tool ${name} returned an unexpected shape`, parsed.error.issues, out)
    throw new ApiError(`Unexpected output from ${name}`, 200)
  }
  return parsed.data
}

/* ── KARMAX endpoints ──────────────────────────────────────────────────── */

export const api = {
  ping: () => call(PingSchema, K('GET', '/api/ping')),

  chat: {
    options: () => call(ChatOptionsSchema, K('GET', '/api/chat/options')),
    conversations: () => call(ConversationsResponseSchema, K('GET', '/api/chat/conversations')),
    history: (id: string) => call(HistoryResponseSchema, K('GET', `/api/chat/conversations/${encodeURIComponent(id)}`)),
    remove: (id: string) => send(K('DELETE', `/api/chat/conversations/${encodeURIComponent(id)}`)),
    reset: () => send(K('POST', '/api/conversation/reset'))
  },

  loops: {
    list: () => call(LoopsResponseSchema, K('GET', '/api/loops')),
    health: () => call(LoopHealthResponseSchema, K('GET', '/api/loops/health')),
    run: (name: string) => send(K('POST', `/api/loops/${encodeURIComponent(name)}/run`)),
    enable: (name: string) => send(K('POST', `/api/loops/${encodeURIComponent(name)}/enable`)),
    disable: (name: string) => send(K('POST', `/api/loops/${encodeURIComponent(name)}/disable`)),
    registry: (refresh = false) => call(RegistryResponseSchema, K('GET', '/api/loops/registry', { query: refresh ? { refresh: 1 } : undefined })),
    registryDetail: (name: string) => call(RegistryDetailSchema, K('GET', `/api/loops/registry/${encodeURIComponent(name)}`)),
    install: (name: string, allowUntrusted = false) => send(K('POST', `/api/loops/registry/${encodeURIComponent(name)}/install`, { body: { allowUntrusted } })),
    uninstall: (name: string) => send(K('DELETE', `/api/loops/registry/${encodeURIComponent(name)}`))
  },

  activity: () => call(ActivitySchema, K('GET', '/api/activity')),

  tasks: {
    list: (status = 'all', limit = 100) => callTool('task.list', { status, limit }, TaskListOutputSchema),
    create: (input: { goal: string; title?: string; workdir?: string; start_in_minutes?: number }) => callTool('task.create', input, TaskCreateOutputSchema),
    update: (input: { task_id: string; status: 'working' | 'blocked' | 'done' | 'failed'; note?: string }) => callTool('task.update', input, zod.looseObject({})),
    /** LYZN tasks only: the daemon has no transcript endpoint for other task kinds. */
    lyznTranscript: (taskId: string) => call(HistoryResponseSchema, K('GET', `/api/tasks/${encodeURIComponent(taskId)}/transcript`))
  },

  proposals: {
    list: (status = 'pending') => call(ProposalsResponseSchema, K('GET', '/api/proposals', { query: { status } })),
    decide: (id: string, decision: 'approve' | 'reject', opts: { edit?: string; note?: string } = {}) =>
      send(K('POST', `/api/proposals/${encodeURIComponent(id)}/decision`, { body: { decision, ...opts } }))
  },

  notifications: {
    list: (limit = 50) => call(NotificationsResponseSchema, K('GET', '/api/notifications', { query: { limit } })),
    read: (id: string) => send(K('POST', `/api/notifications/${encodeURIComponent(id)}/read`)),
    readAll: () => send(K('POST', '/api/notifications/read-all'))
  }
}

/* ── wacli endpoints ───────────────────────────────────────────────────── */

export const wacli = {
  status: () => call(WacliStatusSchema, W('GET', '/status')),
  setDnd: (enabled: boolean) => send(W('PUT', '/dnd', { body: { enabled } })),
  chats: (opts: { filter?: string; query?: string; limit?: number } = {}) =>
    call(zod.union([zod.array(WacliChatSchema), zod.looseObject({ chats: zod.array(WacliChatSchema).nullish() }).transform((v) => v.chats ?? [])]), W('GET', '/chats', { query: opts })).then((v) =>
      Array.isArray(v) ? v : []
    ),
  setChatLocked: (jid: string, locked: boolean) => send(W('PUT', '/chats/access', { body: { jid, locked } })),
  logs: (limit = 200) => call(zod.looseObject({ logs: zod.array(WacliLogSchema).nullish() }).transform((v) => v.logs ?? []), W('GET', '/logs', { query: { limit } })),
  webhooks: () => call(zod.union([zod.array(WacliWebhookSchema), zod.looseObject({ webhooks: zod.array(WacliWebhookSchema).nullish() }).transform((v) => v.webhooks ?? [])]), W('GET', '/webhooks')).then((v) => (Array.isArray(v) ? v : []))
}

/* ── chat streaming ────────────────────────────────────────────────────── */

export interface ChatStreamInput {
  message: string
  conversationId?: string
  model?: string
  effort?: string
}

/**
 * Starts a chat turn. `onEvent` gets each parsed event; unknown kinds are dropped. The returned handle's
 * `done` rejects with ApiError if the transport fails; server-side failures arrive as `error` events.
 */
export function streamChat(input: ChatStreamInput, onEvent: (e: ChatEvent) => void): StreamHandle {
  const body: Record<string, unknown> = { message: input.message }
  if (input.conversationId) body.conversationId = input.conversationId
  if (input.model) body.model = input.model
  if (input.effort) body.effort = input.effort
  return getBridge().daemon.stream(K('POST', '/api/chat/stream', { body }), (line) => {
    const ev = parseChatEvent(line)
    if (ev) onEvent(ev)
  })
}
