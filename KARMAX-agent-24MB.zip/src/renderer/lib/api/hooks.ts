/**
 * Shared TanStack Query hooks. Feature-specific hooks/mutations live in their own feature folder;
 * this file holds only what more than one screen needs (shell badges, overview, etc.).
 */
import { useEffect, useState } from 'react'
import { useQuery, type UseQueryOptions } from '@tanstack/react-query'
import type { ConnectionState, ProcStatus, SetupState } from '@shared/ipc'
import { getBridge } from '../bridge'
import { api, wacli } from './client'

export const qk = {
  ping: ['ping'] as const,
  loops: ['loops'] as const,
  loopHealth: ['loops', 'health'] as const,
  registry: ['loops', 'registry'] as const,
  activity: ['activity'] as const,
  tasks: (status: string) => ['tasks', status] as const,
  proposals: (status: string) => ['proposals', status] as const,
  notifications: ['notifications'] as const,
  conversations: ['chat', 'conversations'] as const,
  chatOptions: ['chat', 'options'] as const,
  wacliStatus: ['wacli', 'status'] as const,
  wacliChats: ['wacli', 'chats'] as const
}

type Opts<T> = Omit<UseQueryOptions<T>, 'queryKey' | 'queryFn'>

export const useLoops = (o?: Opts<Awaited<ReturnType<typeof api.loops.list>>>) =>
  useQuery({ queryKey: qk.loops, queryFn: api.loops.list, refetchInterval: 5000, ...o })

export const useLoopHealth = (o?: Opts<Awaited<ReturnType<typeof api.loops.health>>>) =>
  useQuery({ queryKey: qk.loopHealth, queryFn: api.loops.health, refetchInterval: 4000, ...o })

export const useActivity = () => useQuery({ queryKey: qk.activity, queryFn: api.activity, refetchInterval: 4000 })

export const useTasks = (status = 'all') => useQuery({ queryKey: qk.tasks(status), queryFn: () => api.tasks.list(status), refetchInterval: 3500 })

export const useProposals = (status = 'pending') => useQuery({ queryKey: qk.proposals(status), queryFn: () => api.proposals.list(status), refetchInterval: 5000 })

export const useConversations = () => useQuery({ queryKey: qk.conversations, queryFn: api.chat.conversations, refetchInterval: 8000 })

export const useChatOptions = () => useQuery({ queryKey: qk.chatOptions, queryFn: api.chat.options, staleTime: 5 * 60_000, retry: false })

export const useWacliStatus = () => useQuery({ queryKey: qk.wacliStatus, queryFn: wacli.status, refetchInterval: 4000, retry: false })

export const useWacliChats = () => useQuery({ queryKey: qk.wacliChats, queryFn: () => wacli.chats({ limit: 200 }), refetchInterval: 15000, retry: false })

/* ── bridge-backed live state ──────────────────────────────────────────── */

export function useConnection(): ConnectionState | undefined {
  const [s, setS] = useState<ConnectionState>()
  useEffect(() => {
    const b = getBridge()
    let alive = true
    void b.connection.get().then((v) => alive && setS(v))
    const off = b.connection.onChange((v) => alive && setS(v))
    return () => {
      alive = false
      off()
    }
  }, [])
  return s
}

export function useSupervisor(): ProcStatus[] {
  const [s, setS] = useState<ProcStatus[]>([])
  useEffect(() => {
    const b = getBridge()
    let alive = true
    void b.supervisor.status().then((v) => alive && setS(v))
    const off = b.supervisor.onStatus((v) => alive && setS(v))
    return () => {
      alive = false
      off()
    }
  }, [])
  return s
}

export function useSetupState(): SetupState | undefined {
  const [s, setS] = useState<SetupState>()
  useEffect(() => {
    const b = getBridge()
    let alive = true
    void b.setup.state().then((v) => alive && setS(v))
    const off = b.setup.onChange((v) => alive && setS(v))
    return () => {
      alive = false
      off()
    }
  }, [])
  return s
}
