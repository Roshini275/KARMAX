/**
 * Zod schemas for everything the daemons return. Derived from the Go handlers (KARMAX/internal/api/*.go,
 * internal/runtime/{tasktools,looprun}.go, internal/chatlog) and wacli (wa/api.go, desktop/daemon_client.go).
 *
 * Rules: objects are `looseObject` (a daemon that adds a field must not break the UI); Go nil slices
 * serialise as `null`, so every array goes through `arr()`; Go `omitempty` fields are `.optional()`.
 */
import { z } from 'zod'

const arr = <T extends z.ZodType>(t: T) =>
  z
    .array(t)
    .nullish()
    .transform((v) => v ?? [])

const ts = z.string().nullish()

/* ── ping / connection ─────────────────────────────────────────────────── */

export const PingSchema = z.looseObject({
  service: z.string(),
  version: z.string().optional(),
  agent: z.string().optional(),
  auth: z.boolean().optional(),
  addresses: z.array(z.string()).nullish(),
  time: z.string().optional()
})
export type Ping = z.infer<typeof PingSchema>

/* ── chat ──────────────────────────────────────────────────────────────── */

export const ChatOptionsSchema = z.looseObject({
  brain: z.string().default('claude'),
  models: arr(z.looseObject({ id: z.string(), label: z.string() })),
  efforts: arr(z.string()),
  defaultModel: z.string().optional(),
  defaultEffort: z.string().optional()
})
export type ChatOptions = z.infer<typeof ChatOptionsSchema>

export const ConversationSchema = z.looseObject({
  id: z.string(),
  title: z.string().default(''),
  opening: z.string().default(''),
  updated: z.string()
})
export type Conversation = z.infer<typeof ConversationSchema>
export const ConversationsResponseSchema = z.looseObject({ conversations: arr(ConversationSchema), brain: z.string().optional() })

export const ToolCallSchema = z.looseObject({
  id: z.string(),
  title: z.string().optional(),
  kind: z.string().optional(),
  status: z.string().default('pending'),
  locations: arr(z.looseObject({ path: z.string(), line: z.number().optional() })),
  input: z.unknown().optional(),
  output: z.string().optional()
})
export type ToolCall = z.infer<typeof ToolCallSchema>

export const HistoryMessageSchema = z.looseObject({
  role: z.string(),
  text: z.string().default(''),
  at: z.string().optional(),
  toolCalls: arr(ToolCallSchema)
})
export type HistoryMessage = z.infer<typeof HistoryMessageSchema>
export const HistoryResponseSchema = z.looseObject({ messages: arr(HistoryMessageSchema), live: z.boolean().optional() })

export const PlanEntrySchema = z.looseObject({
  content: z.string(),
  status: z.string(),
  activeForm: z.string().optional(),
  priority: z.string().optional()
})
export type PlanEntry = z.infer<typeof PlanEntrySchema>

/** One NDJSON line of POST /api/chat/stream. Unknown kinds are dropped by parseChatEvent. */
export type ChatEvent =
  | { kind: 'conversation'; id: string }
  | { kind: 'message'; text: string }
  | { kind: 'thought'; text: string }
  | { kind: 'error'; text: string }
  | { kind: 'tool'; tool: ToolCall }
  | { kind: 'tool_update'; tool: Partial<ToolCall> & { id: string } }
  | { kind: 'plan'; plan: PlanEntry[] }
  /** The turn created a tracked job/task; a ticket links the chat to the Tasks view. */
  | { kind: 'ticket'; jobId: string; title: string }
  | { kind: 'meta'; model: string; durationMs: number; costUsd: number }
  | { kind: 'done'; text: string }

const EventBase = z.looseObject({ kind: z.string() })

export function parseChatEvent(line: unknown): ChatEvent | null {
  const base = EventBase.safeParse(line)
  if (!base.success) return null
  const o = base.data as Record<string, unknown>
  switch (o.kind) {
    case 'conversation':
      return typeof o.id === 'string' ? { kind: 'conversation', id: o.id } : null
    case 'message':
    case 'thought':
    case 'error':
    case 'done':
      return { kind: o.kind, text: typeof o.text === 'string' ? o.text : '' } as ChatEvent
    case 'tool': {
      const t = ToolCallSchema.safeParse(o.tool)
      return t.success ? { kind: 'tool', tool: t.data } : null
    }
    case 'tool_update': {
      const t = z.looseObject({ id: z.string() }).safeParse(o.tool)
      return t.success ? { kind: 'tool_update', tool: t.data as unknown as Partial<ToolCall> & { id: string } } : null
    }
    case 'plan': {
      const p = z.array(PlanEntrySchema).safeParse(o.plan ?? [])
      return p.success ? { kind: 'plan', plan: p.data } : null
    }
    case 'ticket':
      return { kind: 'ticket', jobId: String(o.jobId ?? ''), title: String(o.title ?? '') }
    case 'meta':
      return { kind: 'meta', model: String(o.model ?? ''), durationMs: Number(o.durationMs ?? 0), costUsd: Number(o.costUsd ?? 0) }
    default:
      return null
  }
}

/* ── loops ─────────────────────────────────────────────────────────────── */

export const LoopKindSchema = z.enum(['recipe', 'workflow', 'compiled', 'prompt']).or(z.string())

export const LoopInfoSchema = z.looseObject({
  name: z.string(),
  description: z.string().optional(),
  schedule: z.string().default(''),
  webhook: z.string().optional(),
  events: arr(z.string()),
  kind: z.string().optional(),
  enabled: z.boolean().default(true)
})
export type LoopInfo = z.infer<typeof LoopInfoSchema>
export const LoopsResponseSchema = z.looseObject({ loops: arr(LoopInfoSchema) })

export const LoopHealthSchema = z.looseObject({
  name: z.string(),
  schedule: z.string().optional(),
  last_success: ts,
  last_failure: ts,
  consecutive_failures: z.number().default(0),
  running: z.boolean().default(false),
  retry_at: ts,
  dark: z.boolean().default(false),
  last_error: z.string().optional()
})
export type LoopHealth = z.infer<typeof LoopHealthSchema>
export const LoopHealthResponseSchema = z.looseObject({ loops: arr(LoopHealthSchema) })

export const RegistryEntrySchema = z.looseObject({
  name: z.string(),
  kind: z.string(),
  version: z.string().default(''),
  description: z.string().default(''),
  author: z.string().default(''),
  requires: arr(z.string()),
  shipsWithEngine: z.boolean().default(false),
  installed: z.boolean().default(false),
  installedVersion: z.string().default(''),
  active: z.boolean().default(false),
  sourceUrl: z.string().default('')
})
export type RegistryEntry = z.infer<typeof RegistryEntrySchema>
export const RegistryResponseSchema = z.looseObject({ entries: arr(RegistryEntrySchema), fetchedAt: z.string().optional(), source: z.string().optional() })

export const RegistryDetailSchema = z.looseObject({
  entry: RegistryEntrySchema,
  definition: z.string().default(''),
  trigger: z.unknown().optional(),
  tools: arr(z.string()),
  host: arr(z.string())
})
export type RegistryDetail = z.infer<typeof RegistryDetailSchema>

/* ── activity / tasks ──────────────────────────────────────────────────── */

export const ActivitySchema = z.looseObject({
  jobs: arr(
    z.looseObject({
      id: z.string(),
      name: z.string(),
      cron: z.string().default(''),
      agent: z.string().default(''),
      enabled: z.boolean().default(true),
      run_count: z.number().default(0),
      next_run: ts,
      last_run: ts
    })
  ),
  webhooks: arr(z.looseObject({ id: z.union([z.string(), z.number()]), route: z.string(), method: z.string(), received_at: z.string() })),
  coding_sessions: arr(
    z.looseObject({
      id: z.union([z.string(), z.number()]),
      tool: z.string().default(''),
      description: z.string().default(''),
      status: z.string().default(''),
      session_id: z.string().default(''),
      updated_at: z.string()
    })
  ),
  events: arr(z.looseObject({ id: z.union([z.string(), z.number()]), kind: z.string(), agent: z.string().default(''), created_at: z.string() }))
})
export type Activity = z.infer<typeof ActivitySchema>

/** store.Task status values used by task.list / task.update. */
export type TaskStatus = 'open' | 'working' | 'blocked' | 'done' | 'failed' | (string & {})

export const TaskSchema = z.looseObject({
  task_id: z.string(),
  title: z.string().default(''),
  status: z.string(),
  rounds: z.number().default(0),
  updated: z.string().optional(),
  last_error: z.string().optional(),
  last_told_operator: z.string().optional()
})
export type Task = z.infer<typeof TaskSchema>
export const TaskListOutputSchema = z.looseObject({ tasks: arr(TaskSchema), count: z.number().optional() })
export const TaskCreateOutputSchema = z.looseObject({
  task_id: z.string(),
  title: z.string().default(''),
  status: z.string().default('open'),
  note: z.string().optional(),
  warning: z.string().optional()
})
export type TaskCreateOutput = z.infer<typeof TaskCreateOutputSchema>

/** POST /api/tools/{name} envelope. */
export const ToolEnvelopeSchema = z.looseObject({ tool: z.string().optional(), ok: z.boolean(), output: z.unknown().optional(), error: z.string().optional() })

/* ── proposals / notifications ─────────────────────────────────────────── */

export const ProposalSchema = z.looseObject({
  id: z.string(),
  kind: z.string().default(''),
  title: z.string(),
  summary: z.string().default(''),
  context: z.string().default(''),
  action: z.string().default(''),
  status: z.string(),
  note: z.string().default(''),
  result: z.string().default(''),
  created_at: z.string().optional(),
  decided_at: z.string().optional()
})
export type Proposal = z.infer<typeof ProposalSchema>
export const ProposalsResponseSchema = z.looseObject({ proposals: arr(ProposalSchema) })

export const NotificationSchema = z.looseObject({
  id: z.string(),
  kind: z.string().default(''),
  title: z.string().default(''),
  body: z.string().default(''),
  read: z.boolean().default(false),
  created_at: z.string()
})
export type Notification = z.infer<typeof NotificationSchema>
export const NotificationsResponseSchema = z.looseObject({ notifications: arr(NotificationSchema), unread: z.number().default(0) })

/* ── wacli local API (:8765) ───────────────────────────────────────────── */

export const WacliStatusSchema = z.looseObject({
  connected: z.boolean().default(false),
  user_jid: z.string().optional(),
  dnd_mode: z.boolean().default(false),
  initial_access_configured: z.boolean().default(false),
  chat_count: z.number().default(0),
  message_count: z.number().default(0),
  last_history_sync: ts
})
export type WacliStatus = z.infer<typeof WacliStatusSchema>

export const WacliChatSchema = z.looseObject({
  jid: z.string(),
  name: z.string().default(''),
  is_group: z.boolean().default(false),
  locked: z.boolean().default(false),
  first_seen_at: z.string().optional(),
  last_message_at: z.string().optional(),
  last_message_preview: z.string().optional()
})
export type WacliChat = z.infer<typeof WacliChatSchema>

export const WacliLogSchema = z.looseObject({
  id: z.number(),
  level: z.string().default('info'),
  category: z.string().default(''),
  message: z.string().default(''),
  created_at: z.string()
})
export type WacliLog = z.infer<typeof WacliLogSchema>

export const WacliWebhookSchema = z.looseObject({
  id: z.number(),
  url: z.string(),
  events: arr(z.string()),
  scope: z.string().default(''),
  chat_jids: arr(z.string()),
  enabled: z.boolean().default(true)
})
export type WacliWebhook = z.infer<typeof WacliWebhookSchema>
