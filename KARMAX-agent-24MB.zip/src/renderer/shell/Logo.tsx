import { useId } from 'react'

/** KARMAX mark: an orbit ring with a satellite node, on a gradient tile. Original artwork. */
export function Logo({ size = 24 }: { size?: number }) {
  const id = useId()
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="var(--accent)" />
          <stop offset="1" stopColor="var(--accent-2)" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="30" height="30" rx="9" fill={`url(#${id})`} />
      <ellipse cx="16" cy="16" rx="9.5" ry="4.2" transform="rotate(-28 16 16)" fill="none" stroke="rgba(255,255,255,0.9)" strokeWidth="1.6" />
      <circle cx="16" cy="16" r="3.1" fill="#fff" />
      <circle cx="23.6" cy="11.6" r="1.9" fill="#fff" />
    </svg>
  )
}
