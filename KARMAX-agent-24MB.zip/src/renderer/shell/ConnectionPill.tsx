import { useNavigate } from 'react-router-dom'
import { StatusDot } from '@/design/status'
import { useConnection } from '@/lib/api/hooks'

export function ConnectionPill() {
  const c = useConnection()
  const nav = useNavigate()
  const tone = !c ? 'muted' : c.reachable ? 'good' : 'crit'
  const label = !c ? 'Connecting…' : c.reachable ? `KARMAX ${c.version ? 'v' + c.version.replace(/^v/, '') : 'online'}` : 'Daemon offline'
  return (
    <button
      onClick={() => nav('/settings')}
      className="app-no-drag flex h-7 items-center gap-2 rounded-full bg-surface-2/80 px-3 text-[11.5px] font-medium text-ink-2 ring-1 ring-line transition-colors hover:text-ink"
      title={c ? `${c.karmaxUrl} (${c.mode})` : undefined}
    >
      <StatusDot tone={tone} pulse={c?.reachable} size={7} />
      {label}
    </button>
  )
}
