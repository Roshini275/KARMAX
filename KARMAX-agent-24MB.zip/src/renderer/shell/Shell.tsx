import { Suspense, useEffect } from 'react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Monitor, Moon, Sun } from 'lucide-react'
import { IconButton } from '@/design/primitives'
import { Skeleton } from '@/design/primitives'
import { pageTransition } from '@/design/motion'
import { useSetupState } from '@/lib/api/hooks'
import { isElectron } from '@/lib/bridge'
import { resolveTheme, useUi, type ThemePref } from '@/lib/stores'
import { ConnectionPill } from './ConnectionPill'
import { Logo } from './Logo'
import { Sidebar } from './Sidebar'

const nextTheme: Record<ThemePref, ThemePref> = { dark: 'light', light: 'system', system: 'dark' }

export function Shell() {
  const loc = useLocation()
  const setup = useSetupState()
  const theme = useUi((s) => s.theme)
  const setTheme = useUi((s) => s.setTheme)

  useEffect(() => {
    document.documentElement.dataset.theme = resolveTheme(theme)
    if (theme !== 'system') return
    const mq = window.matchMedia('(prefers-color-scheme: light)')
    const h = () => (document.documentElement.dataset.theme = resolveTheme('system'))
    mq.addEventListener('change', h)
    return () => mq.removeEventListener('change', h)
  }, [theme])

  if (setup && !setup.completed) return <Navigate to="/setup" replace />

  const ThemeIcon = theme === 'dark' ? Moon : theme === 'light' ? Sun : Monitor

  return (
    <div className="ambient relative flex h-full flex-col">
      <header className="app-drag relative z-20 flex h-10 shrink-0 items-center justify-between border-b border-line bg-panel/60 pl-4 backdrop-blur-xl" style={{ paddingRight: isElectron() ? 148 : 12 }}>
        <div className="flex items-center gap-2.5">
          <Logo size={20} />
          <span className="font-[family-name:var(--font-display)] text-[13px] font-semibold tracking-[0.16em]">KARMAX</span>
        </div>
        <div className="flex items-center gap-2">
          <ConnectionPill />
          <IconButton label={`Theme: ${theme} (click for ${nextTheme[theme]})`} onClick={() => setTheme(nextTheme[theme])} className="size-7">
            <ThemeIcon className="size-[15px]" />
          </IconButton>
        </div>
      </header>

      <div className="relative z-10 flex min-h-0 flex-1">
        <Sidebar />
        <main className="relative min-w-0 flex-1">
          <AnimatePresence mode="wait">
            <motion.div key={loc.pathname} className="h-full" {...pageTransition}>
              <Suspense fallback={<div className="space-y-3 p-8"><Skeleton className="h-7 w-56" /><Skeleton className="h-40 w-full" /></div>}>
                <Outlet />
              </Suspense>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
