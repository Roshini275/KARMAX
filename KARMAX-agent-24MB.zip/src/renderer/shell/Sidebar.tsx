import { NavLink } from 'react-router-dom'
import { Brain, MessageSquare, Orbit, PanelLeftClose, PanelLeftOpen, ScrollText, Settings, ShieldCheck, Smartphone, SquareKanban, type LucideIcon } from 'lucide-react'
import { cn } from '@/design/cn'
import { StatusDot, type Tone } from '@/design/status'
import { Skeleton } from '@/design/primitives'
import { useProposals, useSupervisor, useTasks } from '@/lib/api/hooks'
import { useUi } from '@/lib/stores'
import type { ProcState } from '@shared/ipc'

interface Item {
  to: string
  label: string
  icon: LucideIcon
  badge?: { n: number; tone: 'accent' | 'warn' }
}

const procTone: Record<ProcState, Tone> = {
  running: 'good',
  external: 'good',
  starting: 'accent',
  backoff: 'warn',
  crashed: 'crit',
  stopped: 'muted',
  missing: 'muted'
}

export function Sidebar() {
  const collapsed = useUi((s) => s.sidebarCollapsed)
  const toggle = useUi((s) => s.toggleSidebar)
  const proposals = useProposals('pending')
  const tasks = useTasks('all')
  const procs = useSupervisor()

  const pending = proposals.data?.proposals.length ?? 0
  const blocked = tasks.data?.tasks.filter((t) => t.status === 'blocked').length ?? 0

  const main: Item[] = [
    { to: '/chat', label: 'Conversation', icon: MessageSquare },
    { to: '/loops', label: 'Loops', icon: Orbit },
    { to: '/tasks', label: 'Tasks', icon: SquareKanban, badge: blocked ? { n: blocked, tone: 'warn' } : undefined },
    { to: '/logs', label: 'Logs', icon: ScrollText },
    { to: '/approvals', label: 'Approvals', icon: ShieldCheck, badge: pending ? { n: pending, tone: 'accent' } : undefined },
    { to: '/whatsapp', label: 'WhatsApp', icon: Smartphone },
    { to: '/memory', label: 'Memory', icon: Brain }
  ]

  return (
    <nav
      aria-label="Primary"
      className={cn('relative z-10 flex shrink-0 flex-col border-r border-line bg-panel/70 pb-3 pt-3 backdrop-blur-xl transition-[width] duration-200', collapsed ? 'w-[62px]' : 'w-[216px]')}
    >
      <div className="flex flex-col gap-0.5 px-2.5">
        {main.map((it) => (
          <NavItem key={it.to} item={it} collapsed={collapsed} />
        ))}
      </div>

      <div className="mt-auto flex flex-col gap-2 px-2.5">
        <div className={cn('rounded-xl bg-surface-2/60 p-2.5 ring-1 ring-line', collapsed && 'px-0')}>
          {!collapsed && <div className="label-micro mb-2 px-0.5">System</div>}
          {procs.length === 0 ? (
            <Skeleton className="h-4 w-full" />
          ) : (
            <div className={cn('flex flex-col gap-1.5', collapsed && 'items-center')}>
              {procs.map((p) => (
                <div key={p.name} className="flex items-center gap-2 text-[12px] text-ink-2" title={`${p.name}: ${p.state}`}>
                  <StatusDot tone={procTone[p.state]} pulse={p.state === 'running' || p.state === 'starting'} size={7} />
                  {!collapsed && (
                    <>
                      <span className="font-medium">{p.name}</span>
                      <span className="ml-auto text-[11px] capitalize text-ink-3">{p.state}</span>
                    </>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
        <NavItem item={{ to: '/settings', label: 'Settings', icon: Settings }} collapsed={collapsed} />
        <button
          onClick={toggle}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className={cn('flex h-8 items-center gap-2 rounded-lg px-2.5 text-[12px] text-ink-3 transition-colors hover:bg-surface-2 hover:text-ink-2', collapsed && 'justify-center px-0')}
        >
          {collapsed ? <PanelLeftOpen className="size-4" /> : <PanelLeftClose className="size-4" />}
          {!collapsed && 'Collapse'}
        </button>
      </div>
    </nav>
  )
}

function NavItem({ item, collapsed }: { item: Item; collapsed: boolean }) {
  const Icon = item.icon
  return (
    <NavLink
      to={item.to}
      title={collapsed ? item.label : undefined}
      className={({ isActive }) =>
        cn(
          'app-no-drag group relative flex h-9 items-center gap-3 rounded-lg px-2.5 text-[13px] font-medium transition-colors',
          collapsed && 'justify-center px-0',
          isActive ? 'bg-accent-soft text-ink' : 'text-ink-2 hover:bg-surface-2 hover:text-ink'
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive && <span className="absolute -left-2.5 top-2 h-5 w-[3px] rounded-r-full bg-accent shadow-[0_0_12px_var(--accent)]" />}
          <Icon className={cn('size-[17px] shrink-0', isActive ? 'text-accent' : 'text-ink-3 group-hover:text-ink-2')} />
          {!collapsed && <span className="truncate">{item.label}</span>}
          {item.badge && (
            <span
              className={cn(
                'ml-auto grid min-w-[18px] place-items-center rounded-full px-1.5 text-[10.5px] font-bold leading-[18px]',
                collapsed && 'absolute right-1 top-1 ml-0 min-w-[15px] px-1 text-[9px] leading-[15px]',
                item.badge.tone === 'warn' ? 'bg-warn text-black' : 'bg-accent text-white'
              )}
            >
              {item.badge.n}
            </span>
          )}
        </>
      )}
    </NavLink>
  )
}
