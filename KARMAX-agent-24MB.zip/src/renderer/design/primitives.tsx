import { forwardRef, type ButtonHTMLAttributes, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react'
import { LoaderCircle } from 'lucide-react'
import { cn } from './cn'

/* ── Button ─────────────────────────────────────────────────────────────── */

type Variant = 'primary' | 'subtle' | 'ghost' | 'danger'
type Size = 'sm' | 'md' | 'lg'

const variants: Record<Variant, string> = {
  primary:
    'bg-accent text-white hover:brightness-110 active:brightness-95 shadow-[0_1px_0_rgba(255,255,255,0.18)_inset,0_6px_18px_-8px_var(--accent)]',
  subtle: 'bg-surface-2 text-ink hover:bg-surface-3 border border-line',
  ghost: 'text-ink-2 hover:text-ink hover:bg-surface-2',
  danger: 'bg-[color-mix(in_oklab,var(--crit)_18%,transparent)] text-crit border border-[color-mix(in_oklab,var(--crit)_40%,transparent)] hover:bg-[color-mix(in_oklab,var(--crit)_28%,transparent)]'
}
const sizes: Record<Size, string> = {
  sm: 'h-7 px-2.5 text-[12px] gap-1.5 rounded-md',
  md: 'h-8 px-3.5 text-[13px] gap-2 rounded-lg',
  lg: 'h-10 px-5 text-[14px] gap-2 rounded-xl'
}

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  icon?: ReactNode
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'subtle', size = 'md', loading, icon, className, children, disabled, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        'app-no-drag inline-flex shrink-0 select-none items-center justify-center font-medium transition-[background,filter,color,transform] duration-150',
        'active:translate-y-px disabled:pointer-events-none disabled:opacity-45',
        variants[variant],
        sizes[size],
        className
      )}
      {...rest}
    >
      {loading ? <LoaderCircle className="size-3.5 animate-[km-spin_0.8s_linear_infinite]" /> : icon}
      {children}
    </button>
  )
})

export const IconButton = forwardRef<HTMLButtonElement, ButtonHTMLAttributes<HTMLButtonElement> & { label: string; active?: boolean }>(
  function IconButton({ label, active, className, children, ...rest }, ref) {
    return (
      <button
        ref={ref}
        aria-label={label}
        title={label}
        className={cn(
          'app-no-drag grid size-8 shrink-0 place-items-center rounded-lg text-ink-2 transition-colors hover:bg-surface-2 hover:text-ink',
          active && 'bg-accent-soft text-accent',
          className
        )}
        {...rest}
      >
        {children}
      </button>
    )
  }
)

/* ── Surfaces ───────────────────────────────────────────────────────────── */

export function Card({ className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('glass rounded-2xl', className)} {...rest} />
}

export function SectionTitle({ title, hint, right }: { title: string; hint?: string; right?: ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-[15px] font-semibold tracking-tight text-ink">{title}</h2>
        {hint && <p className="mt-0.5 text-[12px] text-ink-3">{hint}</p>}
      </div>
      {right}
    </div>
  )
}

/** Page scaffold: header + scrolling body. Every feature page uses it so headers line up. */
export function Page({ title, subtitle, actions, children, flush }: { title: string; subtitle?: string; actions?: ReactNode; children: ReactNode; flush?: boolean }) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex shrink-0 items-center justify-between gap-4 px-7 pb-3 pt-6">
        <div className="min-w-0">
          <h1 className="font-[family-name:var(--font-display)] text-[22px] font-semibold tracking-tight">{title}</h1>
          {subtitle && <p className="mt-0.5 truncate text-[12.5px] text-ink-3">{subtitle}</p>}
        </div>
        {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
      </header>
      <div className={cn('scroll-thin min-h-0 flex-1 overflow-auto', !flush && 'px-7 pb-8')}>{children}</div>
    </div>
  )
}

/* ── Small pieces ───────────────────────────────────────────────────────── */

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="inline-flex h-[18px] min-w-[18px] items-center justify-center rounded border border-line-strong bg-surface-2 px-1 font-[family-name:var(--font-mono)] text-[10.5px] text-ink-2">
      {children}
    </kbd>
  )
}

export function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn('inline-flex items-center gap-1 rounded-md bg-surface-2 px-1.5 py-0.5 text-[11px] font-medium text-ink-2 ring-1 ring-line', className)}>{children}</span>
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('km-skeleton', className)} />
}

export function Spinner({ className }: { className?: string }) {
  return <LoaderCircle className={cn('size-4 animate-[km-spin_0.8s_linear_infinite] text-ink-3', className)} />
}

export function EmptyState({ icon, title, body, action }: { icon?: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="grid place-items-center px-6 py-16 text-center">
      <div className="max-w-sm">
        {icon && <div className="mx-auto mb-4 grid size-12 place-items-center rounded-2xl bg-surface-2 text-ink-3 ring-1 ring-line">{icon}</div>}
        <div className="text-[14px] font-semibold text-ink">{title}</div>
        {body && <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-3">{body}</p>}
        {action && <div className="mt-4 flex justify-center">{action}</div>}
      </div>
    </div>
  )
}

export function ErrorNote({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const msg = error instanceof Error ? error.message : String(error)
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-[color-mix(in_oklab,var(--crit)_35%,transparent)] bg-[color-mix(in_oklab,var(--crit)_10%,transparent)] px-4 py-3 text-[12.5px] text-crit">
      <span className="selectable min-w-0 truncate">{msg}</span>
      {onRetry && <Button size="sm" variant="ghost" onClick={onRetry}>Retry</Button>}
    </div>
  )
}

/* ── Form controls ──────────────────────────────────────────────────────── */

const field =
  'w-full rounded-lg border border-line bg-surface-2/70 px-3 text-[13px] text-ink placeholder:text-ink-3 transition-colors hover:border-line-strong focus:border-accent focus:outline-none focus:ring-2 focus:ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]'

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...rest }, ref) {
  return <input ref={ref} className={cn(field, 'selectable h-9', className)} {...rest} />
})

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, ...rest }, ref) {
  return <textarea ref={ref} className={cn(field, 'selectable resize-none py-2.5 leading-relaxed', className)} {...rest} />
})

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        'app-no-drag relative h-[22px] w-[40px] shrink-0 rounded-full transition-colors disabled:opacity-45',
        checked ? 'bg-accent' : 'bg-surface-3'
      )}
    >
      <span className={cn('absolute top-[3px] size-4 rounded-full bg-white shadow transition-[left] duration-200', checked ? 'left-[21px]' : 'left-[3px]')} />
    </button>
  )
}

export function Segmented<T extends string>({ value, onChange, options, className }: { value: T; onChange: (v: T) => void; options: { value: T; label: ReactNode }[]; className?: string }) {
  return (
    <div role="tablist" className={cn('app-no-drag inline-flex rounded-lg bg-surface-2 p-0.5 ring-1 ring-line', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            'inline-flex h-7 items-center gap-1.5 rounded-md px-3 text-[12px] font-medium transition-colors',
            value === o.value ? 'bg-surface-3 text-ink shadow-sm' : 'text-ink-3 hover:text-ink-2'
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}
