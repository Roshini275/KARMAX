import type { Transition, Variants } from 'framer-motion'

/** One easing curve and a few durations, used everywhere so the app feels like one thing. */
export const ease = [0.22, 1, 0.36, 1] as const
export const spring: Transition = { type: 'spring', stiffness: 420, damping: 34, mass: 0.8 }
export const fast: Transition = { duration: 0.16, ease }
export const base: Transition = { duration: 0.28, ease }

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0, transition: base }
}

export const stagger = (gap = 0.04): Variants => ({
  hidden: {},
  show: { transition: { staggerChildren: gap } }
})

export const pageTransition = {
  initial: { opacity: 0, y: 6 },
  animate: { opacity: 1, y: 0, transition: base },
  exit: { opacity: 0, transition: { duration: 0.1 } }
}
