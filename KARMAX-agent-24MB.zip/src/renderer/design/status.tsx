import type { ReactNode } from 'react'
import { Check, CircleAlert, CircleDashed, LoaderCircle, OctagonX, Pause, TriangleAlert } from 'lucide-react'
import { cn } from './cn'

/**
 * Status colours are reserved for state (never series) and ALWAYS carry an icon + label:
 * on the light surface `warn`/`serious` are below 3:1, so hue alone must never carry meaning.
 */
export type Tone = 'good' | 'warn' | 'serious' | 'crit' | 'accent' | 'muted'

export const toneVar: Record<Tone, string> = {
  good: 'var(--good)',
  warn: 'var(--warn)',
  serious: 'var(--serious)',
  crit: 'var(--crit-mark)',
  accent: 'var(--accent)',
  muted: 'var(--ink-3)'
}

const toneText: Record<Tone, string> = {
  good: 'text-good',
  warn: 'text-warn',
  serious: 'text-serious',
  crit: 'text-crit',
  accent: 'text-accent',
  muted: 'text-ink-3'
}

const toneIcon: Record<Tone, ReactNode> = {
  good: <Check className="size-3" strokeWidth={3} />,
  warn: <TriangleAlert className="size-3" strokeWidth={2.5} />,
  serious: <CircleAlert className="size-3" strokeWidth={2.5} />,
  crit: <OctagonX className="size-3" strokeWidth={2.5} />,
  accent: <LoaderCircle className="size-3 animate-[km-spin_1s_linear_infinite]" strokeWidth={2.5} />,
  muted: <Pause className="size-3" strokeWidth={2.5} />
}

export function StatusPill({ tone, label, icon, className }: { tone: Tone; label: string; icon?: ReactNode; className?: string }) {
  return (
    <span
      className={cn('inline-flex items-center gap-1.5 rounded-full px-2 py-[3px] text-[11px] font-semibold ring-1', toneText[tone], className)}
      style={{
        background: `color-mix(in oklab, ${toneVar[tone]} 13%, transparent)`,
        ['--tw-ring-color' as string]: `color-mix(in oklab, ${toneVar[tone]} 32%, transparent)`
      }}
    >
      {icon ?? toneIcon[tone]}
      {label}
    </span>
  )
}

/** A small glowing dot; `pulse` adds an expanding ring for "live / running". */
export function StatusDot({ tone, pulse, size = 8, className }: { tone: Tone; pulse?: boolean; size?: number; className?: string }) {
  const c = toneVar[tone]
  return (
    <span className={cn('relative inline-grid place-items-center', className)} style={{ width: size, height: size }}>
      {pulse && <span className="absolute inset-0 rounded-full" style={{ background: c, animation: 'km-pulse-ring 1.8s ease-out infinite' }} />}
      <span className="relative rounded-full" style={{ width: size, height: size, background: c, boxShadow: `0 0 10px -1px ${c}` }} />
    </span>
  )
}

export const idleIcon = <CircleDashed className="size-3" />
