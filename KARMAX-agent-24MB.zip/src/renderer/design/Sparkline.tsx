import { useId } from 'react'

/**
 * Minimal sparkline following the dataviz mark specs: 2px line, round joins, a single 8px end marker
 * with a 2px surface ring, a very light area wash, no axes. Pass `color` as a CSS colour or var().
 * `values` are plotted left→right; null values break the line.
 */
export function Sparkline({
  values,
  width = 96,
  height = 28,
  color = 'var(--s1)',
  area = true,
  label
}: {
  values: (number | null)[]
  width?: number
  height?: number
  color?: string
  area?: boolean
  label?: string
}) {
  const id = useId()
  const nums = values.filter((v): v is number => v != null)
  if (nums.length < 2) {
    return (
      <svg width={width} height={height} role="img" aria-label={label ?? 'not enough data'}>
        <line x1={2} x2={width - 2} y1={height / 2} y2={height / 2} stroke="var(--axis)" strokeWidth={1.5} strokeDasharray="2 4" strokeLinecap="round" />
      </svg>
    )
  }
  const pad = 4
  const min = Math.min(...nums)
  const max = Math.max(...nums)
  const span = max - min || 1
  const x = (i: number) => pad + (i * (width - pad * 2)) / (values.length - 1)
  const y = (v: number) => height - pad - ((v - min) / span) * (height - pad * 2)

  let d = ''
  let started = false
  values.forEach((v, i) => {
    if (v == null) {
      started = false
      return
    }
    d += `${started ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`
    started = true
  })
  let lastIdx = values.length - 1
  while (lastIdx > 0 && values[lastIdx] == null) lastIdx--
  const last = values[lastIdx] as number
  const areaD = `${d} L${x(lastIdx).toFixed(1)},${height - pad} L${x(0).toFixed(1)},${height - pad} Z`

  return (
    <svg width={width} height={height} role="img" aria-label={label ?? 'trend'} className="overflow-visible">
      {area && (
        <>
          <defs>
            <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.22" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={areaD} fill={`url(#${id})`} />
        </>
      )}
      <path d={d} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={x(lastIdx)} cy={y(last)} r={4} fill={color} stroke="var(--surface)" strokeWidth={2} />
    </svg>
  )
}
