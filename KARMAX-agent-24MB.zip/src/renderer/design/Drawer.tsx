import { useEffect, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { IconButton } from './primitives'
import { ease } from './motion'

/** Right-hand detail sheet. Esc and scrim-click close it. Content scrolls; header stays. */
export function Drawer({
  open,
  onClose,
  title,
  subtitle,
  width = 520,
  children,
  footer
}: {
  open: boolean
  onClose: () => void
  title: ReactNode
  subtitle?: ReactNode
  width?: number
  children: ReactNode
  footer?: ReactNode
}) {
  useEffect(() => {
    if (!open) return
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-40">
          <motion.div
            className="absolute inset-0 bg-black/45 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            role="dialog"
            aria-modal="true"
            className="glass absolute inset-y-0 right-0 flex max-w-full flex-col border-y-0 border-r-0 shadow-pop"
            style={{ width, background: 'color-mix(in oklab, var(--panel) 92%, transparent)' }}
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1, transition: { duration: 0.28, ease } }}
            exit={{ x: 40, opacity: 0, transition: { duration: 0.16 } }}
          >
            <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
              <div className="min-w-0">
                <div className="truncate text-[15px] font-semibold tracking-tight">{title}</div>
                {subtitle && <div className="mt-0.5 text-[12px] text-ink-3">{subtitle}</div>}
              </div>
              <IconButton label="Close" onClick={onClose}>
                <X className="size-4" />
              </IconButton>
            </div>
            <div className="scroll-thin min-h-0 flex-1 overflow-auto px-5 py-4">{children}</div>
            {footer && <div className="border-t border-line px-5 py-3">{footer}</div>}
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  )
}
