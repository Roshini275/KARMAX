import { lazy } from 'react'
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Shell } from './shell/Shell'

const Chat = lazy(() => import('./features/chat'))
const Loops = lazy(() => import('./features/loops'))
const Tasks = lazy(() => import('./features/tasks'))
const Logs = lazy(() => import('./features/logs'))
const Approvals = lazy(() => import('./features/approvals'))
const WhatsApp = lazy(() => import('./features/whatsapp'))
const Memory = lazy(() => import('./features/memory'))
const Settings = lazy(() => import('./features/settings'))
const Setup = lazy(() => import('./features/setup'))

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 2000, refetchOnWindowFocus: false } }
})

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <HashRouter>
        <Routes>
          <Route path="/setup" element={<Setup />} />
          <Route element={<Shell />}>
            <Route index element={<Navigate to="/chat" replace />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/chat/:conversationId" element={<Chat />} />
            <Route path="/loops" element={<Loops />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/tasks/:taskId" element={<Tasks />} />
            <Route path="/logs" element={<Logs />} />
            <Route path="/approvals" element={<Approvals />} />
            <Route path="/whatsapp" element={<WhatsApp />} />
            <Route path="/memory" element={<Memory />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Routes>
      </HashRouter>
    </QueryClientProvider>
  )
}
