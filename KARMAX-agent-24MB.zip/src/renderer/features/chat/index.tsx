import { useEffect, useMemo, useRef } from 'react'
import { Link, useLocation, useParams } from 'react-router-dom'
import { MotionConfig } from 'framer-motion'
import { useQueryClient } from '@tanstack/react-query'
import { MessageSquarePlus, OctagonX, PanelLeftClose, PanelLeftOpen, RefreshCw } from 'lucide-react'
import { Button, IconButton } from '@/design/primitives'
import { StatusDot } from '@/design/status'
import { qk, useConnection, useConversations } from '@/lib/api/hooks'
import { ConversationList } from './ConversationList'
import { Composer, type ComposerHandle } from './Composer'
import { CopyButton } from './clipboard'
import { Hero } from './Hero'
import { Thread } from './Thread'
import { NEW_KEY, isPendingKey, onChatEffect, setChatUrl, useChat } from './store'
import { firstUserText, turnText } from './stream'
import './chat.css'

/**
 * Conversation: the home screen. Left, the conversation list; right, the transcript and composer.
 *
 * Routing: /chat and /chat/:conversationId are the entry points. Once inside, switching conversation and the URL
 * update after a new chat's first `conversation` event are done with history.replaceState (store.setChatUrl) rather than
 * navigate(): the Shell keys its page transition on the pathname, so a real navigation would fade the whole page out and
 * back in mid-stream.
 */
export default function ConversationPage() {
  const { conversationId } = useParams()
  const loc = useLocation()
  const qc = useQueryClient()
  const conn = useConnection()
  const conversations = useConversations()
  const composer = useRef<ComposerHandle>(null)

  const activeKey = useChat((s) => s.activeKey)
  const thread = useChat((s) => s.threads[s.activeKey])
  const newVid = useChat((s) => s.newVid)
  const collapsed = useChat((s) => s.listCollapsed)
  const toggleList = useChat((s) => s.toggleList)
  const newChat = useChat((s) => s.newChat)
  const streaming = !!thread?.streaming

  /* Keep the store in step with the router. Only REAL navigations change loc.key (our own replaceState does not). */
  const seen = useRef<string | null>(null)
  useEffect(() => {
    if (seen.current === loc.key) return
    const first = seen.current === null
    seen.current = loc.key
    const st = useChat.getState()
    if (conversationId) st.selectConversation(conversationId)
    else if (first && st.threads[st.activeKey]?.streaming) {
      // Coming back to a reply that is still streaming: stay on it rather than showing an empty chat.
      setChatUrl(isPendingKey(st.activeKey) ? null : st.activeKey)
    } else st.newChat()
  }, [loc.key, conversationId])

  /* Refresh cached lists when the store learns something the daemon now knows. */
  useEffect(
    () =>
      onChatEffect((e) => {
        if (e === 'conversations') void qc.invalidateQueries({ queryKey: qk.conversations })
        else void qc.invalidateQueries({ queryKey: ['tasks'] })
      }),
    [qc]
  )

  /* Ctrl+K focuses the composer; Esc stops a running reply from anywhere on the page. */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        composer.current?.focus()
      } else if (e.key === 'Escape' && !e.defaultPrevented) {
        const st = useChat.getState()
        if (st.threads[st.activeKey]?.streaming) st.stop()
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [])

  const offline = !!conn && !conn.reachable
  const title = useMemo(() => {
    if (activeKey === NEW_KEY) return 'New conversation'
    const server = conversations.data?.conversations.find((c) => c.id === activeKey)
    return server?.title || server?.opening || (thread ? firstUserText(thread.turns) : '') || 'Conversation'
  }, [activeKey, conversations.data, thread])

  const transcript = () =>
    (thread?.turns ?? [])
      .filter((t) => t.role !== 'local')
      .map((t) => `${t.role === 'user' ? 'You' : 'KARMAX'}:\n${turnText(t)}`)
      .join('\n\n')

  return (
    <MotionConfig reducedMotion="user">
      <div className="flex h-full min-h-0">
        {!collapsed && (
          <aside aria-label="Conversation list" className="hidden w-[268px] shrink-0 border-r border-line bg-panel/40 md:block">
            <ConversationList />
          </aside>
        )}

        <section className="flex min-w-0 flex-1 flex-col" aria-label="Conversation">
          <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-3">
            <IconButton label={collapsed ? 'Show conversations' : 'Hide conversations'} onClick={toggleList} className="hidden md:grid">
              {collapsed ? <PanelLeftOpen className="size-4" /> : <PanelLeftClose className="size-4" />}
            </IconButton>
            <h1 className="m-0 min-w-0 flex-1 truncate font-[family-name:var(--font-display)] text-[14px] font-semibold tracking-tight">{title}</h1>
            {streaming && (
              <span className="flex items-center gap-2 text-[12px] text-ink-3" role="status">
                <StatusDot tone="accent" pulse size={7} /> Replying
              </span>
            )}
            {thread && thread.turns.some((t) => t.role !== 'local') && <CopyButton text={transcript} label="Copy conversation">Copy</CopyButton>}
            {activeKey !== NEW_KEY && (
              <Button size="sm" variant="ghost" icon={<MessageSquarePlus className="size-3.5" />} onClick={newChat}>
                New chat
              </Button>
            )}
          </header>

          {offline && (
            <div role="alert" className="mx-6 mt-4 flex items-center gap-3 rounded-xl border border-[color-mix(in_oklab,var(--crit)_38%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-4 py-3">
              <OctagonX className="size-4 shrink-0 text-crit" strokeWidth={2.4} />
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-semibold text-crit">KARMAX is unreachable</div>
                <div className="truncate text-[12.5px] text-ink-2">Nothing answered at <span className="font-[family-name:var(--font-mono)] text-[12px]">{conn.karmaxUrl}</span>. Check that the daemon is running.</div>
              </div>
              <Button size="sm" variant="subtle" icon={<RefreshCw className="size-3.5" />} onClick={() => void qc.invalidateQueries()}>Retry</Button>
              <Link to="/settings" className="text-[12px] font-medium text-accent hover:underline">Settings</Link>
            </div>
          )}

          <Thread key={thread?.vid ?? newVid} thread={thread} hero={<Hero disabled={offline} onFocusComposer={() => composer.current?.focus()} />} />
          <Composer ref={composer} disabledReason={offline ? `KARMAX is not reachable at ${conn.karmaxUrl}. Chat and task assignment are off until it is back.` : undefined} />
        </section>
      </div>
    </MotionConfig>
  )
}
