/**
 * Cards that live inside an assistant turn: thought, tool call, plan, ticket, error.
 * Status colours only ever mean STATE and always ship with an icon + a text label (design/status.tsx).
 */
import { memo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowUpRight,
  Brain,
  Check,
  ChevronRight,
  CircleDashed,
  Clock,
  FileText,
  Globe,
  ListChecks,
  LoaderCircle,
  MoveRight,
  OctagonX,
  Pencil,
  RotateCw,
  Search,
  Shuffle,
  SquareKanban,
  Terminal,
  Trash2,
  Wrench,
  type LucideIcon
} from 'lucide-react'
import { cn } from '@/design/cn'
import { Button } from '@/design/primitives'
import { StatusPill, type Tone } from '@/design/status'
import { useTasks } from '@/lib/api/hooks'
import type { PlanEntry, ToolCall } from '@/lib/api/schemas'
import { formatDuration, truncate } from '@/lib/format'
import { CopyButton } from './clipboard'
import type { Block } from './types'
import { ClampedPre, Collapse, useTick } from './ui'

/* ── thought ─────────────────────────────────────────────────────────────── */

export const ThoughtBlock = memo(function ThoughtBlock({ block }: { block: Extract<Block, { kind: 'thought' }> }) {
  const [open, setOpen] = useState(false)
  const active = !block.done
  const now = useTick(active)
  const secs = ((block.endedAt ?? now) - block.startedAt) / 1000
  // History has no timing: startedAt === endedAt === load time, so show a neutral label instead of "0.0s".
  const label = active ? 'Thinking…' : secs >= 1 ? `Thought for ${formatDuration(secs * 1000)}` : 'Thought process'
  const preview = block.text.replace(/\s+/g, ' ').trim().slice(-150)
  return (
    <div className="rounded-xl border border-line bg-surface-2/35">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-[12.5px] transition-colors hover:bg-surface-2/60"
      >
        <Brain className={cn('size-3.5 shrink-0', active ? 'text-accent' : 'text-ink-3')} />
        <span className={cn('font-medium', active ? 'chat-sheen' : 'text-ink-3')}>{label}</span>
        {active && !open && <span className="min-w-0 flex-1 truncate text-[12px] italic text-ink-3">{preview}</span>}
        <ChevronRight className={cn('ml-auto size-3.5 shrink-0 text-ink-3 transition-transform duration-200', open && 'rotate-90')} />
      </button>
      <Collapse open={open}>
        <div className="border-t border-line px-3.5 py-3">
          <p className="selectable scroll-thin m-0 max-h-72 overflow-auto whitespace-pre-wrap break-words text-[12.5px] italic leading-[1.65] text-ink-2">{block.text}</p>
        </div>
      </Collapse>
    </div>
  )
})

/* ── tool call ───────────────────────────────────────────────────────────── */

const kindIcon: Record<string, LucideIcon> = {
  read: FileText,
  edit: Pencil,
  delete: Trash2,
  move: MoveRight,
  search: Search,
  execute: Terminal,
  think: Brain,
  fetch: Globe,
  switch_mode: Shuffle,
  other: Wrench
}

const toolStatus: Record<string, { tone: Tone; label: string; icon?: React.ReactNode }> = {
  pending: { tone: 'muted', label: 'Queued', icon: <Clock className="size-3" strokeWidth={2.5} /> },
  in_progress: { tone: 'accent', label: 'Running' },
  completed: { tone: 'good', label: 'Done' },
  failed: { tone: 'crit', label: 'Failed' }
}

const INPUT_KEYS = ['command', 'file_path', 'path', 'pattern', 'query', 'url', 'description', 'prompt', 'name']
function summarizeInput(input: unknown): string | undefined {
  if (typeof input === 'string') return input
  if (input && typeof input === 'object') {
    const o = input as Record<string, unknown>
    for (const k of INPUT_KEYS) if (typeof o[k] === 'string' && o[k]) return o[k] as string
  }
  return undefined
}

function prettyInput(input: unknown): string {
  if (typeof input === 'string') return input
  try {
    return JSON.stringify(input, null, 2)
  } catch {
    return String(input)
  }
}

const baseName = (p: string) => p.split(/[\\/]/).filter(Boolean).pop() || p

export const ToolCard = memo(function ToolCard({ tool }: { tool: ToolCall }) {
  const failed = tool.status === 'failed'
  const [open, setOpen] = useState(failed)
  const Icon = kindIcon[tool.kind ?? 'other'] ?? Wrench
  const st = toolStatus[tool.status] ?? { tone: 'muted' as Tone, label: tool.status || 'Unknown' }
  const summary = summarizeInput(tool.input)
  const hasInput = tool.input !== undefined && tool.input !== null && !(typeof tool.input === 'object' && Object.keys(tool.input as object).length === 0)
  const hasBody = hasInput || !!tool.output
  const locs = tool.locations ?? []
  const title = tool.title || summary || 'Tool call'
  return (
    <div className={cn('rounded-xl border bg-surface-2/35', failed ? 'border-[color-mix(in_oklab,var(--crit)_35%,transparent)]' : 'border-line')}>
      <button
        type="button"
        onClick={() => hasBody && setOpen((v) => !v)}
        aria-expanded={hasBody ? open : undefined}
        disabled={!hasBody}
        className={cn('flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left', hasBody && 'transition-colors hover:bg-surface-2/60', !hasBody && 'cursor-default')}
      >
        <span className="grid size-6 shrink-0 place-items-center rounded-md bg-surface-3/70 text-ink-2">
          <Icon className="size-3.5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[12.5px] font-medium text-ink" title={title}>{truncate(title, 140)}</span>
          {tool.title && summary && summary !== tool.title && (
            <span className="block truncate font-[family-name:var(--font-mono)] text-[11px] text-ink-3" title={summary}>{truncate(summary.replace(/\s+/g, ' '), 140)}</span>
          )}
        </span>
        <StatusPill tone={st.tone} label={st.label} icon={st.icon} className="shrink-0" />
        {hasBody && <ChevronRight className={cn('size-3.5 shrink-0 text-ink-3 transition-transform duration-200', open && 'rotate-90')} />}
      </button>
      {locs.length > 0 && (
        <div className="flex flex-wrap gap-1.5 px-3 pb-2.5 pt-0.5">
          {locs.slice(0, 4).map((l, i) => (
            <span
              key={`${l.path}:${l.line ?? i}`}
              title={l.line ? `${l.path}:${l.line}` : l.path}
              className="inline-flex max-w-[260px] items-center gap-1 rounded-md bg-surface-3/60 px-1.5 py-0.5 font-[family-name:var(--font-mono)] text-[11px] text-ink-2 ring-1 ring-line"
            >
              <FileText className="size-3 shrink-0 text-ink-3" />
              <span className="truncate">{baseName(l.path)}</span>
              {l.line ? <span className="shrink-0 text-ink-3">:{l.line}</span> : null}
            </span>
          ))}
          {locs.length > 4 && <span className="self-center text-[11px] text-ink-3">+{locs.length - 4} more</span>}
        </div>
      )}
      {hasBody && (
        <Collapse open={open}>
          <div className="space-y-3 border-t border-line px-3.5 py-3">
            {hasInput && (
              <section>
                <div className="label-micro mb-1.5">Input</div>
                <ClampedPre text={prettyInput(tool.input)} maxChars={1200} maxLines={16} />
              </section>
            )}
            {tool.output && (
              <section>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="label-micro">Output</span>
                  <CopyButton text={tool.output} label="Copy output" />
                </div>
                <ClampedPre text={tool.output} />
              </section>
            )}
          </div>
        </Collapse>
      )}
    </div>
  )
})

/* ── plan ────────────────────────────────────────────────────────────────── */

export const PlanCard = memo(function PlanCard({ plan }: { plan: PlanEntry[] }) {
  const done = plan.filter((p) => p.status === 'completed').length
  const pct = plan.length ? (done / plan.length) * 100 : 0
  return (
    <section aria-label="Plan" className="rounded-xl border border-line bg-surface-2/35 px-3.5 py-3">
      <div className="mb-2.5 flex items-center gap-2">
        <ListChecks className="size-3.5 text-ink-3" />
        <span className="text-[12.5px] font-semibold text-ink">Plan</span>
        <span className="tnum text-[11.5px] text-ink-3">{done}/{plan.length}</span>
        <div className="ml-auto h-1 w-24 overflow-hidden rounded-full bg-surface-3" role="progressbar" aria-valuemin={0} aria-valuemax={plan.length} aria-valuenow={done} aria-label="Plan progress">
          <div className="h-full rounded-full bg-accent transition-[width] duration-500" style={{ width: `${pct}%` }} />
        </div>
      </div>
      <ol className="m-0 list-none space-y-1.5 p-0">
        {plan.map((p, i) => {
          const isDone = p.status === 'completed'
          const active = p.status === 'in_progress'
          return (
            <li key={`${i}:${p.content}`} className="flex items-start gap-2.5 text-[13px]">
              <span className="mt-[3px] grid size-4 shrink-0 place-items-center">
                {isDone ? (
                  <span className="grid size-4 place-items-center rounded-full bg-good text-white"><Check className="size-2.5" strokeWidth={3.5} /></span>
                ) : active ? (
                  <LoaderCircle className="size-4 animate-[km-spin_1s_linear_infinite] text-accent" />
                ) : (
                  <CircleDashed className="size-4 text-ink-3" />
                )}
              </span>
              <span className={cn('min-w-0 flex-1 leading-snug', isDone ? 'text-ink-3 line-through decoration-ink-3/50' : active ? 'font-medium text-ink' : 'text-ink-2')}>
                {active && p.activeForm ? p.activeForm : p.content}
                <span className="sr-only">{isDone ? ' (completed)' : active ? ' (in progress)' : ' (pending)'}</span>
              </span>
            </li>
          )
        })}
      </ol>
    </section>
  )
})

/* ── ticket (a background job announced by the daemon) ───────────────────── */

const taskTone: Record<string, { tone: Tone; label: string; icon?: React.ReactNode }> = {
  open: { tone: 'muted', label: 'Queued', icon: <Clock className="size-3" strokeWidth={2.5} /> },
  recorded: { tone: 'warn', label: 'Recorded' },
  working: { tone: 'accent', label: 'Working' },
  blocked: { tone: 'warn', label: 'Blocked' },
  done: { tone: 'good', label: 'Done' },
  failed: { tone: 'crit', label: 'Failed' }
}
export const taskStatus = (s: string) => taskTone[s] ?? { tone: 'muted' as Tone, label: s || 'Unknown' }

/**
 * What a ticket is (KARMAX/internal/runtime/chathost.go ticketFrom): the daemon scans a finished tool result for
 * `task_id`, `job_id` or `run_id`. Only `task_id` (task.create / task.start) is a Task; `job_id` is a backgrounded
 * claude_code.call and `run_id` a sandbox run, neither of which has a /tasks/:id page. So we link to the task page
 * ONLY when the id is actually present in task.list, and otherwise show an informational job card.
 */
export const TicketCard = memo(function TicketCard({ jobId, title }: { jobId: string; title: string }) {
  const tasks = useTasks('all')
  const task = tasks.data?.tasks.find((t) => t.task_id === jobId)
  if (task) {
    const st = taskStatus(task.status)
    return (
      <Link
        to={`/tasks/${encodeURIComponent(task.task_id)}`}
        className="group flex items-center gap-3 rounded-xl border border-line bg-surface-2/35 px-3.5 py-2.5 transition-colors hover:border-line-strong hover:bg-surface-2/70"
      >
        <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-accent-soft text-accent"><SquareKanban className="size-4" /></span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-medium text-ink">{task.title || title || 'Task'}</span>
          <span className="block truncate font-[family-name:var(--font-mono)] text-[11px] text-ink-3">Task {task.task_id}{task.rounds ? ` · round ${task.rounds}` : ''}</span>
        </span>
        <StatusPill tone={st.tone} label={st.label} icon={st.icon} />
        <ArrowUpRight className="size-4 text-ink-3 transition-colors group-hover:text-ink" />
      </Link>
    )
  }
  return (
    <div className="flex items-center gap-3 rounded-xl border border-line bg-surface-2/35 px-3.5 py-2.5">
      <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-surface-3/70 text-ink-2"><Terminal className="size-4" /></span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13px] font-medium text-ink">{title || 'Background job'}</span>
        <span className="block truncate font-[family-name:var(--font-mono)] text-[11px] text-ink-3" title={jobId}>Background job · {truncate(jobId, 40)}</span>
      </span>
      <CopyButton text={jobId} label="Copy job id" />
      <Link to="/tasks" className="inline-flex h-6 items-center gap-1 rounded-md px-1.5 text-[11px] font-medium text-ink-3 transition-colors hover:bg-surface-3 hover:text-ink">
        Tasks <ArrowUpRight className="size-3" />
      </Link>
    </div>
  )
})

/* ── error ───────────────────────────────────────────────────────────────── */

export function ErrorCard({ text, onRetry }: { text: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex items-start gap-3 rounded-xl border border-[color-mix(in_oklab,var(--crit)_38%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-3.5 py-3">
      <OctagonX className="mt-0.5 size-4 shrink-0 text-crit" strokeWidth={2.4} />
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-semibold text-crit">Something went wrong</div>
        <p className="selectable m-0 mt-0.5 whitespace-pre-wrap break-words text-[12.5px] leading-relaxed text-ink-2">{text}</p>
      </div>
      {onRetry && (
        <Button size="sm" variant="subtle" onClick={onRetry} icon={<RotateCw className="size-3.5" />}>
          Retry
        </Button>
      )}
    </div>
  )
}
