/**
 * Slash commands for the composer: autocomplete suggestions + parsing.
 *
 *   /task <goal>          assign a tracked task (POST /api/tools/task.create: no LLM in the loop)
 *   /loop run <name>      run a loop now (POST /api/loops/{name}/run)
 *   /reset                start a fresh conversation (client side; see note below)
 *   /model <id>           model for the next messages (GET /api/chat/options says which exist)
 *   /effort <level>       effort for the next messages
 *
 * NOTE /reset: the daemon's POST /api/conversation/reset clears the MOBILE APP's message thread
 * (server.go handleResetConversation -> ClearAppMessages), not a desktop stream conversation. Calling it from here
 * would silently delete the phone's history, so /reset only starts a new conversation locally.
 */

export interface Suggestion {
  id: string
  /** What is shown in mono, e.g. "/loop run" or "tech-news". */
  label: string
  hint?: string
  desc: string
  /** What the composer text becomes when this is accepted. */
  insert: string
  kind: 'command' | 'loop' | 'model' | 'effort'
  muted?: boolean
}

export interface SlashCtx {
  loops: { name: string; enabled: boolean; description?: string }[]
  loopsLoaded: boolean
  models: { id: string; label: string }[]
  efforts: string[]
  defaultModel?: string
}

interface Command {
  name: string
  hint?: string
  desc: string
  needs?: 'models' | 'efforts'
}

const COMMANDS: Command[] = [
  { name: 'task', hint: '<goal>', desc: 'Assign a tracked task. KARMAX works it on its own and reports back.' },
  { name: 'loop', hint: 'run <name>', desc: 'Run one of your loops right now.' },
  { name: 'reset', desc: 'Start a fresh conversation.' },
  { name: 'model', hint: '<id>', desc: 'Pick the model for the next messages.', needs: 'models' },
  { name: 'effort', hint: '<level>', desc: 'Pick the reasoning effort for the next messages.', needs: 'efforts' }
]

export function parseCommand(text: string): { cmd: string; args: string } | null {
  const m = /^\/([A-Za-z][\w-]*)(?:\s+([\s\S]*))?$/.exec(text.trim())
  return m ? { cmd: m[1].toLowerCase(), args: (m[2] ?? '').trim() } : null
}

export const isKnownCommand = (cmd: string) => COMMANDS.some((c) => c.name === cmd)

const rank = (q: string, s: string) => {
  const a = s.toLowerCase()
  return a === q ? 0 : a.startsWith(q) ? 1 : a.includes(q) ? 2 : 9
}
const filterBy = <T,>(items: T[], q: string, key: (t: T) => string[]) =>
  items
    .map((it) => ({ it, r: Math.min(...key(it).map((k) => rank(q, k))) }))
    .filter((x) => x.r < 9)
    .sort((a, b) => a.r - b.r)
    .map((x) => x.it)

/** Suggestions for the composer text, or null when the popover should be closed. */
export function suggest(text: string, ctx: SlashCtx): { items: Suggestion[]; empty?: string } | null {
  if (!text.startsWith('/') || text.includes('\n')) return null
  const m = /^\/(\S*)(\s+([\s\S]*))?$/.exec(text)
  if (!m) return null
  const name = m[1].toLowerCase()
  const hasArgs = m[2] !== undefined

  if (!hasArgs) {
    const avail = COMMANDS.filter((c) => !c.needs || (c.needs === 'models' ? ctx.models.length > 0 : ctx.efforts.length > 0))
    const list = name ? avail.filter((c) => c.name.startsWith(name)) : avail
    if (!list.length) return { items: [], empty: 'No such command' }
    return {
      items: list.map((c) => ({
        id: c.name,
        label: `/${c.name}`,
        hint: c.hint,
        desc: c.desc,
        insert: c.hint ? `/${c.name} ` : `/${c.name}`,
        kind: 'command' as const
      }))
    }
  }

  const args = (m[3] ?? '').replace(/^\s+/, '')
  if (name === 'loop') {
    const run = /^run(?:\s+([\s\S]*))?$/i.exec(args)
    if (!run || (run[1] === undefined && !/\s$/.test(text))) {
      if (!args || 'run'.startsWith(args.toLowerCase())) {
        return { items: [{ id: 'run', label: '/loop run', hint: '<name>', desc: 'Run one of your loops right now.', insert: '/loop run ', kind: 'command' }] }
      }
      return null
    }
    const q = (run[1] ?? '').trim().toLowerCase()
    if (!ctx.loopsLoaded) return { items: [], empty: 'Loading loops…' }
    const list = q ? filterBy(ctx.loops, q, (l) => [l.name]) : ctx.loops
    if (!list.length) return { items: [], empty: q ? `No loop matches "${q}"` : 'No loops installed' }
    return {
      items: list.slice(0, 8).map((l) => ({
        id: l.name,
        label: l.name,
        desc: l.enabled ? l.description || 'Loop' : `${l.description ? l.description + ' · ' : ''}disabled`,
        insert: `/loop run ${l.name}`,
        kind: 'loop' as const,
        muted: !l.enabled
      }))
    }
  }

  if (name === 'model' && ctx.models.length) {
    const q = args.toLowerCase()
    const opts = [{ id: 'default', label: 'Default', desc: ctx.defaultModel ? `Use the configured model (${ctx.defaultModel})` : 'Use the configured model' }, ...ctx.models.map((x) => ({ id: x.id, label: x.label, desc: x.label }))]
    const list = q ? filterBy(opts, q, (o) => [o.id, o.label]) : opts
    if (!list.length) return { items: [], empty: 'Not a listed model. Enter still sets it as typed.' }
    return { items: list.map((o) => ({ id: o.id, label: o.id, desc: o.desc, insert: `/model ${o.id}`, kind: 'model' as const })) }
  }

  if (name === 'effort' && ctx.efforts.length) {
    const q = args.toLowerCase()
    const opts = ['default', ...ctx.efforts]
    const list = q ? filterBy(opts, q, (o) => [o]) : opts
    if (!list.length) return { items: [], empty: `Effort must be one of ${ctx.efforts.join(', ')}` }
    return { items: list.map((o) => ({ id: o, label: o, desc: o === 'default' ? 'No explicit effort flag' : `Reasoning effort: ${o}`, insert: `/effort ${o}`, kind: 'effort' as const })) }
  }

  return null
}
