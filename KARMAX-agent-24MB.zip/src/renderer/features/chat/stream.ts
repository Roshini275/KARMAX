/**
 * Pure functions that turn the daemon's NDJSON events (and stored history) into thread blocks.
 * No React, no store: easy to reason about and to test.
 *
 * Contract (KARMAX/internal/api/chat.go + runtime/chathost.go):
 *  - message / thought carry DELTAS; tool / tool_update are merged by tool.id (an update only carries id/status/output);
 *  - plan is the whole plan each time (replace in place); ticket is announced once per background job;
 *  - meta arrives before done; error may arrive mid-turn or terminate it.
 */
import type { ChatEvent, HistoryMessage, ToolCall } from '@/lib/api/schemas'
import type { AssistantTurn, Block, Turn } from './types'

let counter = 0
export const uid = (prefix = 'x') => `${prefix}${Date.now().toString(36)}${(counter++).toString(36)}`

const isNonEmptyArray = (v: unknown): v is unknown[] => Array.isArray(v) && v.length > 0

/** Merge a tool_update onto an existing tool call: only fields the update actually carries overwrite. */
export function mergeTool(base: ToolCall, patch: Partial<ToolCall>): ToolCall {
  const next: ToolCall = { ...base }
  if (typeof patch.title === 'string' && patch.title) next.title = patch.title
  if (typeof patch.kind === 'string' && patch.kind) next.kind = patch.kind
  if (typeof patch.status === 'string' && patch.status) next.status = patch.status
  if (typeof patch.output === 'string') next.output = patch.output
  if (patch.input !== undefined && patch.input !== null) next.input = patch.input
  if (isNonEmptyArray(patch.locations)) next.locations = patch.locations as ToolCall['locations']
  return next
}

/** Apply a batch of events to an assistant turn. Copy-on-write so unchanged blocks keep their identity (React.memo). */
export function applyEvents(turn: AssistantTurn, events: ChatEvent[], now: number = Date.now()): AssistantTurn {
  const blocks: Block[] = turn.blocks.slice()
  let meta = turn.meta

  const closeThought = () => {
    const last = blocks[blocks.length - 1]
    if (last && last.kind === 'thought' && !last.done) blocks[blocks.length - 1] = { ...last, done: true, endedAt: now }
  }
  const indexOfTool = (id: string) => blocks.findIndex((b) => b.kind === 'tool' && b.tool.id === id)

  for (const e of events) {
    switch (e.kind) {
      case 'message': {
        if (!e.text) break
        closeThought()
        const last = blocks[blocks.length - 1]
        if (last && last.kind === 'text') blocks[blocks.length - 1] = { ...last, text: last.text + e.text }
        else blocks.push({ kind: 'text', id: uid('t'), text: e.text })
        break
      }
      case 'thought': {
        if (!e.text) break
        const last = blocks[blocks.length - 1]
        if (last && last.kind === 'thought' && !last.done) blocks[blocks.length - 1] = { ...last, text: last.text + e.text }
        else blocks.push({ kind: 'thought', id: uid('h'), text: e.text, done: false, startedAt: now })
        break
      }
      case 'tool': {
        closeThought()
        const i = indexOfTool(e.tool.id)
        if (i >= 0) {
          const b = blocks[i] as Extract<Block, { kind: 'tool' }>
          blocks[i] = { ...b, tool: mergeTool(b.tool, e.tool) }
        } else blocks.push({ kind: 'tool', id: `tool:${e.tool.id}`, tool: e.tool })
        break
      }
      case 'tool_update': {
        const i = indexOfTool(e.tool.id)
        if (i >= 0) {
          const b = blocks[i] as Extract<Block, { kind: 'tool' }>
          blocks[i] = { ...b, tool: mergeTool(b.tool, e.tool) }
        } else {
          // An update for a call we never saw start (stream joined late): show it rather than dropping it.
          const seed: ToolCall = { id: e.tool.id, status: 'in_progress', locations: [] }
          blocks.push({ kind: 'tool', id: `tool:${e.tool.id}`, tool: mergeTool(seed, e.tool) })
        }
        break
      }
      case 'plan': {
        closeThought()
        const i = blocks.findIndex((b) => b.kind === 'plan')
        if (i >= 0) blocks[i] = { ...(blocks[i] as Extract<Block, { kind: 'plan' }>), plan: e.plan }
        else if (e.plan.length) blocks.push({ kind: 'plan', id: uid('p'), plan: e.plan })
        break
      }
      case 'ticket': {
        if (!e.jobId) break
        closeThought()
        if (!blocks.some((b) => b.kind === 'ticket' && b.jobId === e.jobId)) blocks.push({ kind: 'ticket', id: uid('k'), jobId: e.jobId, title: e.title })
        break
      }
      case 'error': {
        closeThought()
        blocks.push({ kind: 'error', id: uid('e'), text: e.text || 'The turn failed.' })
        break
      }
      case 'meta': {
        meta = { model: e.model, durationMs: e.durationMs, costUsd: e.costUsd }
        break
      }
      case 'done': {
        closeThought()
        const hasText = blocks.some((b) => b.kind === 'text' && b.text.trim())
        if (!hasText && e.text.trim()) blocks.push({ kind: 'text', id: uid('t'), text: e.text })
        break
      }
      case 'conversation':
        break
    }
  }
  return { ...turn, blocks, meta }
}

/** Close any thought still marked live (used when a stream ends without further events). */
export function settle(turn: AssistantTurn, now: number = Date.now()): AssistantTurn {
  if (!turn.blocks.some((b) => b.kind === 'thought' && !b.done)) return turn
  return { ...turn, blocks: turn.blocks.map((b) => (b.kind === 'thought' && !b.done ? { ...b, done: true, endedAt: now } : b)) }
}

export function historyToTurns(messages: HistoryMessage[]): Turn[] {
  const out: Turn[] = []
  messages.forEach((m, i) => {
    const id = `h${i}-${uid('m')}`
    if (m.role === 'user') {
      if (m.text.trim()) out.push({ id, role: 'user', text: m.text, at: m.at })
      return
    }
    const blocks: Block[] = m.toolCalls.map((t) => ({ kind: 'tool' as const, id: `tool:${t.id}:${i}`, tool: t }))
    if (m.text.trim()) blocks.push({ kind: 'text', id: uid('t'), text: m.text })
    if (blocks.length) out.push({ id, role: 'assistant', blocks, status: 'done', at: m.at })
  })
  return out
}

/** All prose of an assistant turn, for the copy action. */
export function turnText(turn: Turn): string {
  if (turn.role === 'user') return turn.text
  if (turn.role === 'assistant') return turn.blocks.filter((b): b is Extract<Block, { kind: 'text' }> => b.kind === 'text').map((b) => b.text).join('\n\n')
  return ''
}

/** Turn a transport failure into something a person can act on. */
export function friendlyError(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e)
  if (/failed to fetch|networkerror|load failed|network error|econnrefused|cannot reach|fetch failed|socket hang up|terminated/i.test(raw)) {
    return `Lost the connection to KARMAX (${raw.replace(/^(TypeError|Error):\s*/, '')}).`
  }
  return raw || 'The request failed.'
}

/** A short title for a conversation that has no server title yet. */
export function firstUserText(turns: Turn[]): string {
  const t = turns.find((x): x is Extract<Turn, { role: 'user' }> => x.role === 'user')
  return t ? t.text.trim().replace(/\s+/g, ' ') : ''
}
