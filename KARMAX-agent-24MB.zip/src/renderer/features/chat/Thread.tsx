import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowDown, MessageSquareOff } from 'lucide-react'
import { Button, EmptyState, ErrorNote, Skeleton } from '@/design/primitives'
import { fast } from '@/design/motion'
import { TurnView } from './Message'
import { NEW_KEY, useChat } from './store'
import type { Thread as ThreadModel } from './types'

/**
 * The scrolling transcript. Auto-scroll follows the stream only while the reader is at the bottom; scrolling up
 * releases it and a "Jump to latest" pill offers the way back. Remounted per conversation (key) so each opens at the end.
 */
export function Thread({ thread, hero }: { thread: ThreadModel | undefined; hero: ReactNode }) {
  const scroller = useRef<HTMLDivElement>(null)
  const inner = useRef<HTMLDivElement>(null)
  const stick = useRef(true)
  const lastTop = useRef(0)
  const [away, setAway] = useState(false)
  const retry = useChat((s) => s.retry)
  const loadHistory = useChat((s) => s.loadHistory)
  const newChat = useChat((s) => s.newChat)

  const turns = thread?.turns ?? []
  const streaming = !!thread?.streaming

  const toBottom = useCallback((smooth = false) => {
    const el = scroller.current
    if (!el) return
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
  }, [])

  useLayoutEffect(() => {
    toBottom()
  }, [toBottom])

  useEffect(() => {
    const el = inner.current
    if (!el || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(() => {
      if (stick.current) toBottom()
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [toBottom])

  // Something the reader just did (their message, an assigned task, a command result) always brings them to the end.
  const last = turns[turns.length - 1]
  useEffect(() => {
    if (last && last.role !== 'assistant' && last.fresh) {
      stick.current = true
      setAway(false)
      toBottom(true)
    }
  }, [turns.length, last, toBottom])

  const onScroll = () => {
    const el = scroller.current
    if (!el) return
    const dist = el.scrollHeight - el.scrollTop - el.clientHeight
    if (dist < 48) {
      stick.current = true
      setAway(false)
    } else if (el.scrollTop < lastTop.current - 2) {
      stick.current = false
      setAway(dist > 140)
    } else if (!stick.current) setAway(dist > 140)
    lastTop.current = el.scrollTop
  }

  const lastAssistantIdx = (() => {
    for (let i = turns.length - 1; i >= 0; i--) if (turns[i].role === 'assistant') return i
    return -1
  })()

  let body: ReactNode
  if (thread?.history === 'loading' || thread?.history === 'idle') {
    body = (
      <div className="space-y-6 py-2" aria-busy="true" aria-label="Loading conversation">
        <div className="flex justify-end"><Skeleton className="h-10 w-2/5 rounded-2xl" /></div>
        <div className="flex gap-3.5"><Skeleton className="size-[22px] shrink-0 rounded-md" /><div className="flex-1 space-y-2.5"><Skeleton className="h-4 w-11/12" /><Skeleton className="h-4 w-4/5" /><Skeleton className="h-4 w-3/5" /></div></div>
        <div className="flex justify-end"><Skeleton className="h-10 w-1/3 rounded-2xl" /></div>
      </div>
    )
  } else if (thread?.history === 'error') {
    const missing = thread.historyStatus === 404
    body = missing ? (
      <EmptyState
        icon={<MessageSquareOff className="size-5" />}
        title="That conversation no longer exists"
        body="It may have been deleted, or it lives with a different brain."
        action={<Button variant="primary" onClick={newChat}>Start a new chat</Button>}
      />
    ) : (
      <div className="py-6"><ErrorNote error={thread.historyError} onRetry={() => void loadHistory(thread.key, true)} /></div>
    )
  } else if (turns.length === 0) {
    body = hero
  } else {
    body = (
      <div className="flex flex-col gap-6 pb-1">
        {turns.map((t, i) => (
          <TurnView key={t.id} turn={t} canRetry={i === lastAssistantIdx && !streaming} onRetry={retry} />
        ))}
      </div>
    )
  }

  const announce = streaming ? 'KARMAX is replying' : ''

  return (
    <div className="relative min-h-0 flex-1">
      <div ref={scroller} onScroll={onScroll} className="scroll-thin absolute inset-0 overflow-y-auto overflow-x-hidden" role="log" aria-label="Conversation" aria-live="off">
        <div ref={inner} className="mx-auto flex min-h-full w-full max-w-[820px] flex-col px-6 pb-8 pt-6">
          {body}
        </div>
      </div>
      <span className="sr-only" role="status" aria-live="polite">{announce}</span>
      <AnimatePresence>
        {away && turns.length > 0 && thread?.key !== NEW_KEY && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={fast} className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center">
            <button
              type="button"
              onClick={() => {
                stick.current = true
                setAway(false)
                toBottom(true)
              }}
              className="app-no-drag pointer-events-auto inline-flex h-8 items-center gap-1.5 rounded-full bg-surface-3/95 px-3.5 text-[12px] font-medium text-ink shadow-pop ring-1 ring-line-strong backdrop-blur transition-colors hover:bg-surface-3"
            >
              <ArrowDown className="size-3.5" />
              {streaming ? 'Jump to latest' : 'Jump to bottom'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
