import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import { Check, ChevronDown } from 'lucide-react'
import { cn } from '@/design/cn'

export interface PickerOption {
  value: string
  label: string
  hint?: string
}

/** Compact dropdown (listbox) opening upwards: used for the model and effort pickers in the composer. */
export function Picker({ label, icon, display, dim, options, value, onChange, disabled }: {
  label: string
  icon?: ReactNode
  display: string
  /** Render the display text muted (i.e. showing a default, not a choice). */
  dim?: boolean
  options: PickerOption[]
  value: string
  onChange: (v: string) => void
  disabled?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [idx, setIdx] = useState(0)
  const root = useRef<HTMLDivElement>(null)
  const btn = useRef<HTMLButtonElement>(null)
  const id = useId()

  useEffect(() => {
    if (!open) return
    const down = (e: MouseEvent) => !root.current?.contains(e.target as Node) && setOpen(false)
    document.addEventListener('mousedown', down)
    return () => document.removeEventListener('mousedown', down)
  }, [open])

  const openMenu = () => {
    setIdx(Math.max(0, options.findIndex((o) => o.value === value)))
    setOpen(true)
  }
  const pick = (v: string) => {
    onChange(v)
    setOpen(false)
    btn.current?.focus()
  }

  const onKey = (e: React.KeyboardEvent) => {
    if (!open) {
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault()
        openMenu()
      }
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setIdx((i) => (i + 1) % options.length)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setIdx((i) => (i - 1 + options.length) % options.length)
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      pick(options[idx].value)
    } else if (e.key === 'Escape') {
      e.preventDefault()
      e.stopPropagation()
      setOpen(false)
    } else if (e.key === 'Tab') setOpen(false)
  }

  return (
    <div ref={root} className="relative" onKeyDown={onKey}>
      <button
        ref={btn}
        type="button"
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? id : undefined}
        aria-label={`${label}: ${display}`}
        onClick={() => (open ? setOpen(false) : openMenu())}
        className={cn(
          'app-no-drag inline-flex h-7 items-center gap-1.5 rounded-md px-2 text-[12px] font-medium transition-colors hover:bg-surface-3 disabled:opacity-45',
          open ? 'bg-surface-3 text-ink' : dim ? 'text-ink-3 hover:text-ink-2' : 'text-ink-2'
        )}
      >
        {icon}
        <span className="max-w-[140px] truncate">{display}</span>
        <ChevronDown className={cn('size-3 text-ink-3 transition-transform', open && 'rotate-180')} />
      </button>
      {open && (
        <div
          id={id}
          role="listbox"
          aria-label={label}
          aria-activedescendant={`${id}-${idx}`}
          className="glass absolute bottom-full right-0 z-30 mb-2 min-w-[190px] max-w-[280px] overflow-hidden rounded-xl p-1 shadow-pop"
          style={{ background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
        >
          <div className="label-micro px-2.5 pb-1 pt-1.5">{label}</div>
          {options.map((o, i) => (
            <div
              key={o.value}
              id={`${id}-${i}`}
              role="option"
              aria-selected={o.value === value}
              onMouseEnter={() => setIdx(i)}
              onMouseDown={(e) => {
                e.preventDefault()
                pick(o.value)
              }}
              className={cn('flex cursor-pointer items-center gap-2 rounded-lg px-2.5 py-1.5 text-[12.5px]', i === idx ? 'bg-accent-soft text-ink' : 'text-ink-2')}
            >
              <span className="min-w-0 flex-1">
                <span className="block truncate">{o.label}</span>
                {o.hint && <span className="block truncate text-[11px] text-ink-3">{o.hint}</span>}
              </span>
              {o.value === value && <Check className="size-3.5 shrink-0 text-accent" strokeWidth={2.6} />}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
