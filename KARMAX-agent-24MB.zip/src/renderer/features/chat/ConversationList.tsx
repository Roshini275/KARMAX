import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { MessageSquarePlus, Search, Trash2, X } from 'lucide-react'
import { cn } from '@/design/cn'
import { fast } from '@/design/motion'
import { Button, Input, Skeleton } from '@/design/primitives'
import { StatusDot } from '@/design/status'
import { useConversations } from '@/lib/api/hooks'
import { timeAgo, truncate } from '@/lib/format'
import { firstUserText, friendlyError } from './stream'
import { NEW_KEY, isPendingKey, useChat } from './store'

interface Row {
  key: string
  /** Set only when the daemon knows this conversation (so it can be deleted). */
  serverId?: string
  title: string
  preview: string
  updated: number
  streaming: boolean
}

const DAY = 86_400_000
function bucket(t: number, now: number): string {
  const start = new Date(now)
  start.setHours(0, 0, 0, 0)
  const d = start.getTime()
  if (t >= d) return 'Today'
  if (t >= d - DAY) return 'Yesterday'
  if (t >= d - 6 * DAY) return 'Previous 7 days'
  return 'Older'
}

export function ConversationList() {
  const q = useConversations()
  const threads = useChat((s) => s.threads)
  const activeKey = useChat((s) => s.activeKey)
  const select = useChat((s) => s.selectConversation)
  const newChat = useChat((s) => s.newChat)
  const remove = useChat((s) => s.removeConversation)
  const [query, setQuery] = useState('')
  const [confirming, setConfirming] = useState<string | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [delError, setDelError] = useState<string | null>(null)

  const rows = useMemo<Row[]>(() => {
    const server = q.data?.conversations ?? []
    const out: Row[] = server.map((c) => ({
      key: c.id,
      serverId: c.id,
      title: c.title || truncate(c.opening, 70) || 'Untitled conversation',
      preview: c.opening,
      updated: Date.parse(c.updated) || 0,
      streaming: !!threads[c.id]?.streaming
    }))
    const known = new Set(server.map((c) => c.id))
    // Conversations this session started that the daemon has not listed yet (or never will, if it failed early).
    for (const t of Object.values(threads)) {
      if (t.key === NEW_KEY || known.has(t.key)) continue
      const first = firstUserText(t.turns)
      if (!first) continue
      const lastAt = [...t.turns].reverse().find((x) => x.at != null)?.at
      out.push({
        key: t.key,
        serverId: isPendingKey(t.key) ? undefined : t.key,
        title: truncate(first, 70),
        preview: first,
        updated: typeof lastAt === 'number' ? lastAt : lastAt ? Date.parse(lastAt) || Date.now() : Date.now(),
        streaming: t.streaming
      })
    }
    return out.sort((a, b) => b.updated - a.updated)
  }, [q.data, threads])

  const filtered = useMemo(() => {
    const s = query.trim().toLowerCase()
    return s ? rows.filter((r) => r.title.toLowerCase().includes(s) || r.preview.toLowerCase().includes(s)) : rows
  }, [rows, query])

  const groups = useMemo(() => {
    const now = Date.now()
    const m = new Map<string, Row[]>()
    for (const r of filtered) {
      const b = bucket(r.updated, now)
      m.set(b, [...(m.get(b) ?? []), r])
    }
    return [...m.entries()]
  }, [filtered])

  const doDelete = async (r: Row) => {
    if (!r.serverId) return
    setDeleting(r.key)
    setDelError(null)
    try {
      await remove(r.serverId)
      setConfirming(null)
    } catch (e) {
      setDelError(friendlyError(e))
    } finally {
      setDeleting(null)
    }
  }

  const brain = q.data?.brain

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="space-y-2 px-3 pb-2 pt-4">
        <Button variant="subtle" className="w-full justify-start" icon={<MessageSquarePlus className="size-4 text-accent" />} onClick={newChat} aria-label="New chat">
          New chat
        </Button>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search conversations" aria-label="Search conversations" className="h-8 pl-8 pr-7 text-[12.5px]" />
          {query && (
            <button type="button" aria-label="Clear search" onClick={() => setQuery('')} className="absolute right-1.5 top-1/2 grid size-5 -translate-y-1/2 place-items-center rounded text-ink-3 hover:text-ink">
              <X className="size-3" />
            </button>
          )}
        </div>
      </div>

      <nav aria-label="Conversations" className="scroll-thin min-h-0 flex-1 overflow-y-auto px-2 pb-3">
        {q.isLoading && rows.length === 0 ? (
          <div className="space-y-2 px-1 pt-2" aria-busy="true">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="space-y-1.5 rounded-lg px-2 py-1.5">
                <Skeleton className="h-3.5 w-3/4" />
                <Skeleton className="h-3 w-11/12" />
              </div>
            ))}
          </div>
        ) : q.isError && rows.length === 0 ? (
          <div className="mx-1 mt-2 rounded-xl border border-[color-mix(in_oklab,var(--crit)_35%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-3 py-2.5">
            <div className="text-[12.5px] font-semibold text-crit">Can't load conversations</div>
            <div className="selectable mt-0.5 line-clamp-2 text-[12px] text-ink-3">{q.error instanceof Error ? q.error.message : String(q.error)}</div>
            <Button size="sm" variant="subtle" className="mt-2" onClick={() => void q.refetch()}>Retry</Button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="px-4 py-10 text-center text-[12.5px] leading-relaxed text-ink-3">
            {query ? (
              <>No conversations match “{query}”.</>
            ) : brain && brain !== 'claude' ? (
              <>KARMAX is running the <span className="font-medium text-ink-2">{brain}</span> brain, which keeps its sessions elsewhere, so past conversations can't be listed here. New ones still work.</>
            ) : (
              <>No conversations yet. Start one and it will show up here.</>
            )}
          </div>
        ) : (
          groups.map(([label, list]) => (
            <div key={label} className="mb-2">
              <div className="label-micro px-2.5 pb-1 pt-2.5">{label}</div>
              <ul className="m-0 list-none space-y-0.5 p-0">
                {list.map((r) => {
                  const active = r.key === activeKey
                  const isConfirm = confirming === r.key
                  return (
                    <li key={r.key} className="group/row relative">
                      <AnimatePresence mode="wait" initial={false}>
                        {isConfirm ? (
                          <motion.div key="confirm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={fast} className="rounded-lg border border-[color-mix(in_oklab,var(--crit)_40%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-2.5 py-2">
                            <div className="truncate text-[12px] font-medium text-ink">Delete “{truncate(r.title, 34)}”?</div>
                            <div className="mt-0.5 text-[11.5px] text-ink-3">This removes the transcript from KARMAX.</div>
                            {delError && <div className="mt-1 text-[11.5px] text-crit">{delError}</div>}
                            <div className="mt-2 flex gap-1.5">
                              <Button size="sm" variant="danger" loading={deleting === r.key} onClick={() => void doDelete(r)} icon={<Trash2 className="size-3" />}>Delete</Button>
                              <Button size="sm" variant="ghost" onClick={() => { setConfirming(null); setDelError(null) }}>Cancel</Button>
                            </div>
                          </motion.div>
                        ) : (
                          <motion.div key="row" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={fast}>
                            <button
                              type="button"
                              aria-current={active ? 'true' : undefined}
                              onClick={() => select(r.key)}
                              className={cn(
                                'app-no-drag relative w-full rounded-lg px-2.5 py-1.5 text-left transition-colors',
                                active ? 'bg-accent-soft' : 'hover:bg-surface-2/70'
                              )}
                            >
                              {active && <span className="absolute -left-2 top-2 h-5 w-[3px] rounded-r-full bg-accent shadow-[0_0_12px_var(--accent)]" />}
                              <span className="flex items-center gap-2">
                                {r.streaming && <StatusDot tone="accent" pulse size={7} />}
                                <span className={cn('min-w-0 flex-1 truncate text-[13px] font-medium', active ? 'text-ink' : 'text-ink')}>{r.title}</span>
                                <span className={cn('shrink-0 text-[11px] text-ink-3 transition-opacity', r.serverId && 'group-hover/row:opacity-0 group-focus-within/row:opacity-0')}>{r.streaming ? 'live' : timeAgo(r.updated)}</span>
                              </span>
                              {r.preview && r.preview !== r.title && <span className="mt-0.5 block truncate text-[12px] text-ink-3">{r.preview}</span>}
                              {r.streaming && <span className="sr-only">Replying</span>}
                            </button>
                            {r.serverId && (
                              <button
                                type="button"
                                aria-label={`Delete conversation ${r.title}`}
                                title="Delete"
                                onClick={() => { setConfirming(r.key); setDelError(null) }}
                                className="app-no-drag absolute right-1.5 top-1.5 grid size-6 place-items-center rounded-md text-ink-3 opacity-0 transition-[opacity,background,color] hover:bg-[color-mix(in_oklab,var(--crit)_15%,transparent)] hover:text-crit focus-visible:opacity-100 group-hover/row:opacity-100"
                              >
                                <Trash2 className="size-3.5" />
                              </button>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))
        )}
      </nav>
    </div>
  )
}
