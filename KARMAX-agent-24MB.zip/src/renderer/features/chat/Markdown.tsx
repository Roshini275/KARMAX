/**
 * Markdown for assistant prose. react-markdown renders to React elements (no innerHTML) and raw HTML in the source is
 * NOT interpreted (no rehype-raw), so model output cannot inject markup. Links go through the bridge's openExternal.
 */
import { Children, isValidElement, memo, useState, type ReactElement, type ReactNode } from 'react'
import ReactMarkdown, { type Components } from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { ExternalLink } from 'lucide-react'
import { getBridge } from '@/lib/bridge'
import { CopyButton } from './clipboard'
import './chat.css'

interface MNode {
  type: string
  children?: MNode[]
  [k: string]: unknown
}

const caretNode = (): MNode => ({ type: 'kmCaret', data: { hName: 'span', hProperties: { className: ['km-caret'], ariaHidden: 'true' } } })

/** Appends the streaming caret INLINE at the end of the last paragraph/heading (or after a trailing block). */
function remarkCaret() {
  return (tree: MNode) => {
    let node = tree
    for (;;) {
      const last = node.children?.[node.children.length - 1]
      if (!last) break
      if ((last.type === 'paragraph' || last.type === 'heading') && last.children) {
        last.children.push(caretNode())
        return
      }
      if (last.type === 'list' || last.type === 'listItem' || last.type === 'blockquote') {
        node = last
        continue
      }
      break
    }
    ;(tree.children ??= []).push({ type: 'paragraph', children: [caretNode()] })
  }
}

const PLUGINS = [remarkGfm]
const PLUGINS_STREAMING = [remarkGfm, remarkCaret]

const safeHref = (href?: string) => (href && /^(https?:|mailto:)/i.test(href) ? href : undefined)

function textOf(node: ReactNode): string {
  if (node == null || typeof node === 'boolean') return ''
  if (typeof node === 'string' || typeof node === 'number') return String(node)
  if (Array.isArray(node)) return node.map(textOf).join('')
  if (isValidElement(node)) return textOf((node.props as { children?: ReactNode }).children)
  return ''
}

const CLAMP_LINES = 32

function CodeBlock({ children }: { children?: ReactNode }) {
  const [open, setOpen] = useState(false)
  const child = Children.toArray(children)[0] as ReactElement<{ className?: string; children?: ReactNode }> | undefined
  const cls = isValidElement(child) ? child.props.className ?? '' : ''
  const lang = /language-([\w+#.-]+)/.exec(cls)?.[1] ?? ''
  const code = textOf(isValidElement(child) ? child.props.children : children).replace(/\n$/, '')
  const lines = code.split('\n')
  const clamped = !open && lines.length > CLAMP_LINES
  const shown = clamped ? lines.slice(0, CLAMP_LINES).join('\n') : code
  return (
    <div className="group/code my-3 overflow-hidden rounded-xl border border-line bg-[color-mix(in_oklab,var(--page)_55%,var(--surface))]">
      <div className="flex h-8 items-center justify-between border-b border-line bg-surface-2/50 pl-3 pr-1.5">
        <span className="font-[family-name:var(--font-mono)] text-[10.5px] font-semibold uppercase tracking-[0.09em] text-ink-3">{lang || 'text'}</span>
        <CopyButton text={code} label={`Copy ${lang || 'code'}`}>Copy</CopyButton>
      </div>
      <pre className="scroll-thin selectable m-0 overflow-x-auto px-3.5 py-3 font-[family-name:var(--font-mono)] text-[12.5px] leading-[1.6] text-ink">
        <code>{shown}</code>
      </pre>
      {lines.length > CLAMP_LINES && (
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="w-full border-t border-line bg-surface-2/40 py-1.5 text-[11.5px] font-medium text-ink-3 transition-colors hover:text-ink"
        >
          {open ? 'Show less' : `Show ${lines.length - CLAMP_LINES} more lines`}
        </button>
      )}
    </div>
  )
}

const components: Components = {
  a: ({ href, children }) => {
    const h = safeHref(href)
    if (!h) return <span>{children}</span>
    return (
      <a
        href={h}
        title={h}
        rel="noreferrer noopener"
        onClick={(e) => {
          e.preventDefault()
          void getBridge().app.openExternal(h)
        }}
      >
        {children}
      </a>
    )
  },
  pre: ({ children }) => <CodeBlock>{children}</CodeBlock>,
  table: ({ children }) => (
    <div className="md-table scroll-thin">
      <table>{children}</table>
    </div>
  ),
  // Remote images would fetch on render; show them as a link instead.
  img: ({ src, alt }) => {
    const h = safeHref(typeof src === 'string' ? src : undefined)
    if (!h) return <span className="text-ink-3">[image: {alt || 'unavailable'}]</span>
    return (
      <a
        href={h}
        rel="noreferrer noopener"
        onClick={(e) => {
          e.preventDefault()
          void getBridge().app.openExternal(h)
        }}
      >
        <ExternalLink className="mr-1 inline size-3 align-[-1px]" />
        {alt || 'image'}
      </a>
    )
  }
}

export const Markdown = memo(function Markdown({ text, streaming = false }: { text: string; streaming?: boolean }) {
  return (
    <div className="md selectable">
      <ReactMarkdown remarkPlugins={streaming ? PLUGINS_STREAMING : PLUGINS} components={components}>
        {text}
      </ReactMarkdown>
    </div>
  )
})
