import { memo, useState } from 'react'
import { motion } from 'framer-motion'
import { OctagonMinus } from 'lucide-react'
import { cn } from '@/design/cn'
import { Logo } from '@/shell/Logo'
import { formatCost, formatDuration, timeAgo } from '@/lib/format'
import { base } from '@/design/motion'
import { StatusPill } from '@/design/status'
import { ErrorCard, PlanCard, ThoughtBlock, TicketCard, ToolCard } from './Cards'
import { CopyButton } from './clipboard'
import { LoopCard, NoticeCard, TaskCard } from './LocalCards'
import { Markdown } from './Markdown'
import { turnText } from './stream'
import type { AssistantTurn, Block, LocalTurn, Turn, UserTurn } from './types'

const appear = (fresh?: boolean) => ({ initial: fresh ? { opacity: 0, y: 10 } : false, animate: { opacity: 1, y: 0 }, transition: base }) as const

/** Very long prose is folded behind "Show more" (never while it is still streaming). */
const CLAMP_CHARS = 9000
function LongProse({ text, streaming }: { text: string; streaming: boolean }) {
  const [open, setOpen] = useState(false)
  const long = !streaming && text.length > CLAMP_CHARS
  if (!long) return <Markdown text={text} streaming={streaming} />
  return (
    <div>
      <div className={cn(!open && 'chat-clamp-fade max-h-[520px] overflow-hidden')}>
        <Markdown text={text} />
      </div>
      <button type="button" onClick={() => setOpen((v) => !v)} className="mt-1 text-[12px] font-medium text-accent hover:underline">
        {open ? 'Show less' : `Show full reply (${Math.round(text.length / 1000)}k characters)`}
      </button>
    </div>
  )
}

/* ── user ────────────────────────────────────────────────────────────────── */

const USER_CLAMP = 1400
const UserMessage = memo(function UserMessage({ turn }: { turn: UserTurn }) {
  const [open, setOpen] = useState(false)
  const long = turn.text.length > USER_CLAMP || turn.text.split('\n').length > 16
  return (
    <motion.div {...appear(turn.fresh)} className="group relative flex flex-col items-end">
      <div className="max-w-[86%] rounded-2xl rounded-br-md border border-line bg-surface-2/80 px-4 py-2.5 shadow-[0_1px_0_color-mix(in_oklab,var(--ink)_5%,transparent)_inset]">
        <p className={cn('selectable m-0 whitespace-pre-wrap break-words text-[14px] leading-[1.6] text-ink', long && !open && 'line-clamp-[12]')}>{turn.text}</p>
        {long && (
          <button type="button" onClick={() => setOpen((v) => !v)} className="mt-1 text-[11.5px] font-medium text-accent hover:underline">
            {open ? 'Show less' : 'Show more'}
          </button>
        )}
      </div>
      <div className="absolute right-1 top-full z-10 mt-0.5 flex items-center gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
        {turn.at != null && <span className="text-[11px] text-ink-3" title={new Date(turn.at).toLocaleString()}>{timeAgo(turn.at)}</span>}
        <CopyButton text={turn.text} label="Copy message" />
      </div>
    </motion.div>
  )
})

/* ── assistant ───────────────────────────────────────────────────────────── */

type Group = { kind: 'tools'; id: string; blocks: Extract<Block, { kind: 'tool' }>[] } | { kind: 'block'; block: Block }

function group(blocks: Block[]): Group[] {
  const out: Group[] = []
  for (const b of blocks) {
    const last = out[out.length - 1]
    if (b.kind === 'tool') {
      if (last && last.kind === 'tools') last.blocks.push(b)
      else out.push({ kind: 'tools', id: b.id, blocks: [b] })
    } else out.push({ kind: 'block', block: b })
  }
  return out
}

const AssistantMessage = memo(function AssistantMessage({ turn, canRetry, onRetry }: { turn: AssistantTurn; canRetry: boolean; onRetry: () => void }) {
  const streaming = turn.status === 'streaming'
  const groups = group(turn.blocks)
  const lastBlock = turn.blocks[turn.blocks.length - 1]
  const lastTextId = [...turn.blocks].reverse().find((b) => b.kind === 'text')?.id
  const working = streaming && (!lastBlock || (lastBlock.kind !== 'text' && !(lastBlock.kind === 'thought' && !lastBlock.done)))
  const text = turnText(turn)
  const m = turn.meta
  return (
    <motion.div {...appear(turn.fresh)} className="group flex gap-3.5">
      <div className="mt-0.5 shrink-0"><Logo size={22} /></div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-col gap-3">
          {groups.map((g) => {
            if (g.kind === 'tools')
              return (
                <div key={g.id} className="flex flex-col gap-1.5">
                  {g.blocks.map((b) => <ToolCard key={b.id} tool={b.tool} />)}
                </div>
              )
            const b = g.block
            switch (b.kind) {
              case 'text':
                return <LongProse key={b.id} text={b.text} streaming={streaming && b.id === lastTextId && b === lastBlock} />
              case 'thought':
                return <ThoughtBlock key={b.id} block={b} />
              case 'plan':
                return <PlanCard key={b.id} plan={b.plan} />
              case 'ticket':
                return <TicketCard key={b.id} jobId={b.jobId} title={b.title} />
              case 'error':
                return <ErrorCard key={b.id} text={b.text} onRetry={canRetry && b === lastBlock && turn.status === 'error' ? onRetry : undefined} />
              default:
                return null
            }
          })}
          {working && (
            <div className="flex items-center gap-2 text-[12.5px] text-ink-3" role="status">
              <span className="chat-dots" aria-hidden="true"><i /><i /><i /></span>
              <span>{turn.blocks.length ? 'Working…' : 'Waiting for KARMAX…'}</span>
            </div>
          )}
          {turn.status === 'stopped' && (
            <div><StatusPill tone="muted" label="Stopped" icon={<OctagonMinus className="size-3" strokeWidth={2.5} />} /></div>
          )}
        </div>

        {!streaming && (m || text) && (
          <div className="mt-2 flex min-h-6 flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-ink-3">
            {m && (m.model || m.durationMs > 0 || m.costUsd > 0) && (
              <span className="tnum flex items-center gap-1.5">
                {[m.model || null, m.durationMs > 0 ? formatDuration(m.durationMs) : null, m.costUsd > 0 ? formatCost(m.costUsd) : null].filter(Boolean).map((p, i, a) => (
                  <span key={i} className="flex items-center gap-1.5">
                    <span className={i === 0 && m.model ? 'font-[family-name:var(--font-mono)]' : undefined}>{p}</span>
                    {i < a.length - 1 && <span aria-hidden="true" className="text-ink-3/50">·</span>}
                  </span>
                ))}
              </span>
            )}
            {!m && turn.at != null && <span title={new Date(turn.at).toLocaleString()}>{timeAgo(turn.at)}</span>}
            {text && (
              <span className="opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
                <CopyButton text={text} label="Copy reply" />
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  )
})

/* ── local ───────────────────────────────────────────────────────────────── */

function LocalMessage({ turn }: { turn: LocalTurn }) {
  const c = turn.card
  return (
    <motion.div {...appear(turn.fresh)} className="pl-[36px]">
      {c.type === 'task' ? <TaskCard turnId={turn.id} card={c} /> : c.type === 'loop' ? <LoopCard card={c} /> : <NoticeCard card={c} />}
    </motion.div>
  )
}

export function TurnView({ turn, canRetry, onRetry }: { turn: Turn; canRetry: boolean; onRetry: () => void }) {
  if (turn.role === 'user') return <UserMessage turn={turn} />
  if (turn.role === 'assistant') return <AssistantMessage turn={turn} canRetry={canRetry} onRetry={onRetry} />
  return <LocalMessage turn={turn} />
}
