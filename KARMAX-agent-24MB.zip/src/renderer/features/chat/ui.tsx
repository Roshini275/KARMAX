/** Small building blocks shared by the thread cards. */
import { useEffect, useState, type ReactNode } from 'react'
import { cn } from '@/design/cn'

/** Height-animating disclosure without measuring: grid rows 0fr <-> 1fr. */
export function Collapse({ open, children, className }: { open: boolean; children: ReactNode; className?: string }) {
  return (
    <div className={cn('grid transition-[grid-template-rows] duration-200 ease-out', open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]', className)} aria-hidden={!open}>
      <div className="min-h-0 overflow-hidden">{children}</div>
    </div>
  )
}

/** Re-renders the caller every `ms` while `active` (for live elapsed timers). */
export function useTick(active: boolean, ms = 1000): number {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (!active) return
    setNow(Date.now())
    const t = setInterval(() => setNow(Date.now()), ms)
    return () => clearInterval(t)
  }, [active, ms])
  return now
}

/** Monospace block that shows the first N chars/lines and a "Show more" toggle: tool output can be enormous. */
export function ClampedPre({ text, maxChars = 1800, maxLines = 22, className }: { text: string; maxChars?: number; maxLines?: number; className?: string }) {
  const [open, setOpen] = useState(false)
  const lines = text.split('\n')
  const tooLong = text.length > maxChars || lines.length > maxLines
  let shown = text
  let hidden = ''
  if (tooLong && !open) {
    shown = lines.slice(0, maxLines).join('\n')
    if (shown.length > maxChars) shown = shown.slice(0, maxChars)
    const rest = text.length - shown.length
    hidden = `${rest.toLocaleString()} more characters`
  }
  return (
    <div className={className}>
      <pre className="scroll-thin selectable m-0 max-h-[420px] overflow-auto whitespace-pre-wrap break-words font-[family-name:var(--font-mono)] text-[12px] leading-[1.6] text-ink-2">{shown}</pre>
      {tooLong && (
        <button type="button" onClick={() => setOpen((v) => !v)} className="mt-1.5 text-[11.5px] font-medium text-accent hover:underline">
          {open ? 'Show less' : `Show more (${hidden})`}
        </button>
      )}
    </div>
  )
}

/** Fixed-width label + value rows used in card details. */
export function KV({ k, children }: { k: string; children: ReactNode }) {
  return (
    <div className="flex items-baseline gap-3 text-[12px]">
      <span className="w-[74px] shrink-0 text-ink-3">{k}</span>
      <span className="min-w-0 flex-1 text-ink-2">{children}</span>
    </div>
  )
}
