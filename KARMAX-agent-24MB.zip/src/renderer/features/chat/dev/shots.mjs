// Interaction screenshots for the Conversation screen (typing, streaming, stopping, assigning, slash popover...).
//   node src/renderer/features/chat/dev/shots.mjs [scenario ...]
// Env: THEME=dark|light  W=1440 H=900  DAEMON=http://127.0.0.1:9102 (the rich dev mock)  WACLI=...  OUT=shots/chat  BASE=http://127.0.0.1:5173
// Needs: vite dev server, `node fixtures/mock-daemon/server.mjs` on MOCK_KARMAX_PORT, and dev/rich-mock.mjs in front of it.
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const OUT = process.env.OUT || 'shots/chat'
const THEME = process.env.THEME || 'dark'
const W = Number(process.env.W || 1440)
const H = Number(process.env.H || 900)
const DAEMON = process.env.DAEMON || 'http://127.0.0.1:9102'
const WACLI = process.env.WACLI || 'http://127.0.0.1:8801'
const tag = `${THEME}${W < 1200 ? '-narrow' : ''}`

function chromePath() {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}

mkdirSync(OUT, { recursive: true })
const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] })
const errors = []

async function open(route = '/chat', daemon = DAEMON) {
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, colorScheme: THEME === 'light' ? 'light' : 'dark' })
  await ctx.addInitScript((theme) => { try { localStorage.setItem('km.theme', theme) } catch {} }, THEME)
  await ctx.grantPermissions(['clipboard-read', 'clipboard-write']).catch(() => {})
  const page = await ctx.newPage()
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
  page.on('console', (m) => m.type() === 'error' && errors.push(`console.error: ${m.text()}`))
  await page.goto(`${BASE}/?daemon=${daemon}&wacli=${WACLI}#${route}`, { waitUntil: 'networkidle' }).catch(() => {})
  await page.waitForTimeout(1200)
  return { page, ctx }
}
const shot = async (page, name) => { await page.screenshot({ path: `${OUT}/${name}-${tag}.png` }); console.log('saved', `${OUT}/${name}-${tag}.png`) }
const composer = (page) => page.getByLabel('Message KARMAX')
const scrollTop = (page) => page.evaluate(() => { const el = document.querySelector('[role=log]'); if (el) el.scrollTop = 0 })

const scenarios = {
  async empty() {
    const { page, ctx } = await open()
    await shot(page, 'empty')
    await ctx.close()
  },

  async stream() {
    const { page, ctx } = await open()
    await composer(page).fill('Plan the Stripe migration, rich markdown please')
    await composer(page).press('Enter')
    await page.waitForTimeout(1300)
    await shot(page, 'mid-thinking')
    await page.waitForTimeout(1800)
    await shot(page, 'mid-tools')
    await page.waitForTimeout(3500)
    await shot(page, 'mid-text')
    await page.waitForSelector('text=claude-sonnet-4-6', { timeout: 20000 })
    await page.waitForTimeout(600)
    await shot(page, 'done-bottom')
    await scrollTop(page)
    await page.waitForTimeout(300)
    await shot(page, 'done-top')
    console.log('url after stream:', await page.evaluate(() => location.hash))
    await ctx.close()
  },

  async slash() {
    const { page, ctx } = await open()
    await composer(page).click()
    await composer(page).pressSequentially('/')
    await page.waitForTimeout(400)
    await shot(page, 'slash-commands')
    await composer(page).pressSequentially('loop run te')
    await page.waitForTimeout(400)
    await shot(page, 'slash-loops')
    await composer(page).fill('/model ')
    await page.waitForTimeout(400)
    await shot(page, 'slash-model')
    await composer(page).fill('/loop run tech-news')
    await composer(page).press('Enter')
    await page.waitForTimeout(1500)
    await shot(page, 'slash-loop-running')
    await page.waitForTimeout(4500)
    await shot(page, 'slash-loop-done')
    await composer(page).fill('/model opus')
    await composer(page).press('Enter')
    await composer(page).fill('/bogus')
    await composer(page).press('Enter')
    await page.waitForTimeout(500)
    await shot(page, 'slash-notices')
    await ctx.close()
  },

  async assign() {
    const { page, ctx } = await open()
    await page.getByRole('tab', { name: /Assign task/ }).click()
    await page.getByLabel('Task goal').fill('Migrate the billing service to the new Stripe PaymentIntents API in MelloB1989/lyzn.\n\nAcceptance: all 14 call sites converted behind the STRIPE_V2 flag, tests green, PR opened.')
    await page.getByPlaceholder('Defaults to the first line').fill('Stripe PaymentIntents migration')
    await page.getByPlaceholder(/projects.repo/).fill('C:\\Users\\rosh\\code\\lyzn')
    await page.getByRole('button', { name: '15 min' }).click()
    await page.waitForTimeout(300)
    await shot(page, 'assign-form')
    await page.getByRole('button', { name: 'Assign task' }).click()
    await page.waitForTimeout(1200)
    await shot(page, 'assign-confirmed')
    // harness-disabled warning
    await page.getByLabel('Task goal').fill('Investigate why the harness flag is off')
    await page.getByLabel('Task goal').press('Control+Enter')
    await page.waitForTimeout(1000)
    await shot(page, 'assign-warning')
    await page.getByLabel('Task goal').fill('This one will fail hard')
    await page.getByLabel('Task goal').press('Control+Enter')
    await page.waitForTimeout(1000)
    await shot(page, 'assign-error')
    await ctx.close()
  },

  async stop() {
    const { page, ctx } = await open()
    await composer(page).fill('please stop this slow reply')
    await composer(page).press('Enter')
    await page.waitForTimeout(1500)
    await shot(page, 'stopping')
    await composer(page).press('Escape')
    await page.waitForTimeout(600)
    await shot(page, 'stopped')
    await ctx.close()
  },

  async errors() {
    const { page, ctx } = await open()
    await composer(page).fill('trigger an error please')
    await composer(page).press('Enter')
    await page.waitForTimeout(1500)
    await shot(page, 'error-event')
    await composer(page).fill('what about hang')
    await composer(page).press('Enter')
    await page.waitForTimeout(2000)
    await shot(page, 'error-transport')
    await composer(page).fill('and a 503 response')
    await composer(page).press('Enter')
    await page.waitForTimeout(1200)
    await shot(page, 'error-503')
    await ctx.close()
  },

  async history() {
    const { page, ctx } = await open('/chat/c-rich')
    await page.waitForTimeout(800)
    await shot(page, 'history')
    await scrollTop(page)
    await page.waitForTimeout(300)
    await shot(page, 'history-top')
    await page.getByText('Grep "stripe."').first().click()
    await page.getByText('Bash: go test ./...').first().click()
    await page.waitForTimeout(400)
    await scrollTop(page)
    await page.waitForTimeout(300)
    await shot(page, 'history-tools-open')
    for (const y of [560, 1180]) {
      await page.evaluate((y) => { const el = document.querySelector('[role=log]'); if (el) el.scrollTop = y }, y)
      await page.waitForTimeout(250)
      await shot(page, `history-y${y}`)
    }
    await ctx.close()
  },

  async existing() {
    const { page, ctx } = await open()
    await page.getByRole('button', { name: /^Plan the billing migration/ }).click()
    await page.waitForTimeout(900)
    await shot(page, 'existing')
    // delete confirm
    await page.getByRole('button', { name: /Delete conversation LYZN/ }).click({ force: true })
    await page.waitForTimeout(400)
    await shot(page, 'delete-confirm')
    await ctx.close()
  },

  async long() {
    const { page, ctx } = await open()
    await composer(page).fill('give me a long answer')
    await composer(page).press('Enter')
    await page.waitForTimeout(2500)
    await scrollTop(page)
    await page.waitForTimeout(300)
    await shot(page, 'long')
    await ctx.close()
  },

  async behaviour() {
    const { page, ctx } = await open()
    const check = (name, ok, extra = '') => console.log(`${ok ? 'PASS' : 'FAIL'}  ${name} ${extra}`)
    const hash = () => page.evaluate(() => location.hash)
    const log = () => page.locator('[role=log]')

    // 1. a new chat gets its conversation id WITHOUT remounting the thread
    await page.evaluate(() => { const el = document.querySelector('[role=log]'); if (el) el.dataset.marker = 'same' })
    await composer(page).fill('delayed slow thing please')
    await composer(page).press('Enter')
    await page.waitForTimeout(600)
    check('URL still /chat before the conversation event', (await hash()) === '#/chat', await hash())
    await page.waitForTimeout(2200)
    check('thread element survives the conversation event (no remount)', await page.evaluate(() => document.querySelector('[role=log]')?.dataset.marker === 'same'))
    check('URL updated to the new conversation id', /#\/chat\/c-slow-/.test(await hash()), await hash())
    check('conversation list shows it as live', (await page.locator('nav[aria-label=Conversations]').innerText()).includes('live'))

    // 2. leave mid-stream and come back: the reply is still there and still streaming
    await page.getByRole('link', { name: 'Loops' }).click()
    await page.waitForTimeout(900)
    check('navigated to /loops', (await hash()).includes('/loops'))
    await page.getByRole('link', { name: 'Conversation' }).click()
    await page.waitForTimeout(1200)
    check('streaming reply restored after leaving and returning', (await page.getByRole('button', { name: 'Stop the reply' }).count()) === 1 && (await log().innerText()).includes('word'))

    // 3. Ctrl+K focuses the composer
    await page.locator('h1').click()
    await page.keyboard.press('Control+k')
    check('Ctrl+K focuses the composer', await page.evaluate(() => document.activeElement?.getAttribute('aria-label') === 'Message KARMAX'))

    // 4. scrolling up mid-stream releases auto-scroll and shows the jump pill
    await page.waitForTimeout(2500)
    await page.evaluate(() => { const el = document.querySelector('[role=log]'); el.scrollTop = Math.max(0, el.scrollTop - 240) })
    await page.waitForTimeout(300)
    const y0 = await page.evaluate(() => document.querySelector('[role=log]').scrollTop)
    await page.waitForTimeout(1500)
    const y1 = await page.evaluate(() => document.querySelector('[role=log]').scrollTop)
    check('scroll position is NOT yanked while the reader is scrolled up', Math.abs(y1 - y0) < 4, `(${y0} -> ${y1})`)
    check('"Jump to latest" pill is shown', (await page.getByRole('button', { name: /Jump to/ }).count()) === 1)
    await shot(page, 'jump-pill')
    await page.getByRole('button', { name: /Jump to/ }).click()
    await page.waitForTimeout(900)
    const atBottom = await page.evaluate(() => { const el = document.querySelector('[role=log]'); return el.scrollHeight - el.scrollTop - el.clientHeight < 60 })
    check('pill returns to the bottom and follows again', atBottom)

    // 5. drafts are kept per conversation
    await composer(page).fill('draft for the slow chat')
    await page.getByRole('button', { name: /^Weekly review/ }).click()
    await page.waitForTimeout(700)
    check('other conversation has its own (empty) draft', (await composer(page).inputValue()) === '')
    await composer(page).fill('draft for weekly review')
    await page.getByRole('button', { name: /^delayed slow thing please/ }).click()
    await page.waitForTimeout(500)
    check('first conversation draft restored', (await composer(page).inputValue()) === 'draft for the slow chat')
    check('background reply kept streaming while viewing another conversation', (await page.getByRole('button', { name: 'Stop the reply' }).count()) === 1)

    // 6. Esc stops it
    await composer(page).press('Escape')
    await page.waitForTimeout(500)
    check('Esc stops the reply', (await page.getByText('Stopped', { exact: true }).count()) >= 1)

    // 7. retry after an error does not duplicate the user message
    await page.getByRole('button', { name: 'New chat' }).first().click()
    await page.waitForTimeout(400)
    await composer(page).fill('force an error now')
    await composer(page).press('Enter')
    await page.waitForTimeout(1500)
    await page.getByRole('button', { name: 'Retry' }).click()
    await page.waitForTimeout(1500)
    check('retry keeps a single user bubble', (await page.getByText('force an error now', { exact: true }).count()) >= 1 && (await page.locator('[role=log] .selectable', { hasText: 'force an error now' }).count()) === 1)
    check('retry shows one error card', (await page.getByRole('alert').count()) === 1)

    // 8. clicking a conversation from the list opens it (history)
    await page.getByRole('button', { name: /^Plan the billing migration/ }).click()
    await page.waitForTimeout(900)
    check('history loads with a tool card', (await page.getByText('Grep "stripe." in billing/').count()) === 1)
    check('URL reflects the opened conversation', (await hash()).endsWith('/chat/c-1'), await hash())
    await ctx.close()
  },

  async offline() {
    const { page, ctx } = await open('/chat', 'http://127.0.0.1:1')
    await page.waitForTimeout(1500)
    await shot(page, 'offline')
    await ctx.close()
  }
}

const want = process.argv.slice(2)
for (const [name, fn] of Object.entries(scenarios)) {
  if (want.length && !want.includes(name)) continue
  try { await fn() } catch (e) { console.log(`scenario ${name} FAILED:`, e.message.split('\n')[0]) }
}
if (errors.length) { console.log('\nBROWSER ERRORS:'); for (const e of [...new Set(errors)]) console.log(' -', e) }
await browser.close()
