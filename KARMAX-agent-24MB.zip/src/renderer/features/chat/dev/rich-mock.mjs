// Dev-only proxy in front of the standard mock daemon (fixtures/mock-daemon/server.mjs).
// It overrides the chat stream / history / task.create for specific trigger words so the UI can be exercised with
// rich markdown, long output, failures and tickets, which the stock mock does not produce. Everything else is proxied.
//   MOCK_UP=http://127.0.0.1:9101 PORT=9102 node src/renderer/features/chat/dev/rich-mock.mjs
import http from 'node:http'

const UP = new URL(process.env.MOCK_UP || 'http://127.0.0.1:9101')
const PORT = Number(process.env.PORT || 9102)
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS' }
const readBody = (req) => new Promise((ok) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}) } catch { ok({}) } }) })

const RICH = `Here's the plan for the **Stripe migration**, based on what I found in \`billing/\` and \`webhooks/\`.

## What I found

There are **14 call sites** across 6 files. The riskiest one is the charge path:

\`\`\`go
func (s *Service) Charge(ctx context.Context, req ChargeRequest) (*Charge, error) {
    // legacy: stripe.Charges.New
    params := &stripe.PaymentIntentParams{
        Amount:   stripe.Int64(req.AmountMinor),
        Currency: stripe.String(string(req.Currency)),
    }
    pi, err := s.client.PaymentIntents.New(params)
    if err != nil {
        return nil, fmt.Errorf("charge: %w", err)
    }
    return toCharge(pi), nil
}
\`\`\`

### Rollout

| Phase | Scope | Risk | Owner |
|-------|-------|------|-------|
| 1 | Adapter + feature flag | Low | KARMAX |
| 2 | Convert call sites behind the flag | Medium | KARMAX |
| 3 | Backfill and verify against prod data | **High** | You + KARMAX |

1. Introduce a thin adapter so both APIs can coexist
2. Convert call sites one file at a time
   - start with \`billing/charge.go\`
   - then \`billing/refund.go\`
3. Backfill and verify

> The deadline in memory is *end of month*, so phase 3 needs to start next week.

- [x] Inventory call sites
- [ ] Write the adapter
- [ ] Flip the flag in staging

See the [Stripe migration guide](https://stripe.com/docs/payments/payment-intents/migration) for the API differences. Inline HTML like <b>this</b> must not render.
`

const LONG_OUT = Array.from({ length: 80 }, (_, i) => `billing/file_${i}.go:${10 + i}: stripe.Charges.New(params) // legacy call site ${i}`).join('\n')

async function richStream(res, body) {
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store', ...cors })
  const send = (o) => res.write(JSON.stringify(o) + '\n')
  if (!body.conversationId) send({ kind: 'conversation', id: 'c-rich-' + Math.random().toString(36).slice(2, 7) })
  const msg = String(body.message || '')
  const slow = /slow|stop/i.test(msg)
  const t = slow ? 260 : 1
  send({ kind: 'thought', text: 'The operator wants a migration plan. I should scan billing/ and webhooks/ for Stripe usage first, ' })
  await sleep(500 * t)
  send({ kind: 'thought', text: 'then check memory for the deadline before proposing phases. The charge path is the riskiest so I will look at it closely.' })
  await sleep(500 * t)
  send({ kind: 'tool', tool: { id: 'g1', title: 'Grep "stripe\\." in billing/', kind: 'search', status: 'in_progress', input: { pattern: 'stripe\\.', path: 'billing/' } } })
  send({ kind: 'plan', plan: [{ content: 'Scan the repo for Stripe usage', status: 'in_progress', activeForm: 'Scanning the repo' }, { content: 'Check memory for deadlines', status: 'pending' }, { content: 'Draft the rollout plan', status: 'pending' }] })
  await sleep(700 * t)
  send({ kind: 'tool_update', tool: { id: 'g1', status: 'completed', output: LONG_OUT } })
  send({ kind: 'tool', tool: { id: 'r1', title: 'Read billing/charge.go', kind: 'read', status: 'in_progress', locations: [{ path: 'billing/charge.go', line: 41 }, { path: 'billing/refund.go', line: 12 }] } })
  await sleep(500 * t)
  send({ kind: 'tool_update', tool: { id: 'r1', status: 'completed', output: 'package billing\n\nfunc (s *Service) Charge(...) {\n  // 212 lines\n}' } })
  send({ kind: 'tool', tool: { id: 'x1', title: 'go test ./billing/...', kind: 'execute', status: 'in_progress', input: { command: 'go test ./billing/... -run Charge -count=1' } } })
  await sleep(600 * t)
  send({ kind: 'tool_update', tool: { id: 'x1', status: 'failed', output: '--- FAIL: TestCharge (0.02s)\n    charge_test.go:57: expected status "succeeded", got "requires_action"\nFAIL\nFAIL\tgithub.com/acme/billing\t0.412s' } })
  send({ kind: 'plan', plan: [{ content: 'Scan the repo for Stripe usage', status: 'completed' }, { content: 'Check memory for deadlines', status: 'in_progress', activeForm: 'Checking memory for deadlines' }, { content: 'Draft the rollout plan', status: 'pending' }] })
  await sleep(400 * t)
  const words = RICH.split(/(\s+)/)
  for (const w of words) { send({ kind: 'message', text: w }); await sleep(slow ? 90 : 6) }
  send({ kind: 'tool', tool: { id: 'tk1', title: 'task.create', kind: 'other', status: 'in_progress', input: { goal: 'Migrate billing to PaymentIntents' } } })
  await sleep(300)
  send({ kind: 'tool_update', tool: { id: 'tk1', status: 'completed', output: '{"task_id":"t-1001","title":"Migrate billing service to the new Stripe API","status":"open"}' } })
  send({ kind: 'ticket', jobId: 't-1001', title: 'Migrate billing service to the new Stripe API' })
  send({ kind: 'ticket', jobId: '0b6f4d0a-7c1e-4d0e-9a55-6f0d2f8c9e11', title: 'Backfill Stripe customers (claude_code background)' })
  send({ kind: 'plan', plan: [{ content: 'Scan the repo for Stripe usage', status: 'completed' }, { content: 'Check memory for deadlines', status: 'completed' }, { content: 'Draft the rollout plan', status: 'completed' }] })
  send({ kind: 'meta', model: 'claude-sonnet-4-6', durationMs: 18400, costUsd: 0.0731 })
  send({ kind: 'done', text: RICH })
  res.end()
}

async function slowForever(res, body) {
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-store', ...cors })
  if (/delayed/i.test(String(body.message))) await sleep(1800)
  const send = (o) => res.write(JSON.stringify(o) + '\n')
  if (!body.conversationId) send({ kind: 'conversation', id: 'c-slow-' + Math.random().toString(36).slice(2, 7) })
  let closed = false
  res.on('close', () => (closed = true))
  for (let i = 0; i < 400 && !closed; i++) {
    send({ kind: 'message', text: (i % 5 === 4 ? '\n\n' : '') + Array.from({ length: 8 }, (_, k) => `word${i * 8 + k}`).join(' ') + ' ' })
    await sleep(110)
  }
  if (!closed) res.end()
}

function longText(res, body) {
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson', ...cors })
  const send = (o) => res.write(JSON.stringify(o) + '\n')
  if (!body.conversationId) send({ kind: 'conversation', id: 'c-long-' + Math.random().toString(36).slice(2, 7) })
  const text = Array.from({ length: 60 }, (_, i) => `### Section ${i + 1}\n\nParagraph ${i + 1}: ` + 'lorem ipsum dolor sit amet, consectetur adipiscing elit. '.repeat(4)).join('\n\n')
  send({ kind: 'message', text })
  send({ kind: 'meta', model: 'claude-opus-4', durationMs: 91000, costUsd: 0.31 })
  send({ kind: 'done', text })
  res.end()
}

function proxy(req, res, bodyBuf) {
  const p = http.request({ hostname: UP.hostname, port: UP.port, path: req.url, method: req.method, headers: req.headers }, (r) => {
    const h = Object.fromEntries(Object.entries(r.headers).filter(([k]) => !k.toLowerCase().startsWith('access-control-')))
    res.writeHead(r.statusCode || 502, { ...h, ...cors })
    r.pipe(res)
  })
  p.on('error', () => { res.writeHead(502, cors); res.end('{"error":"upstream down"}') })
  p.end(bodyBuf)
}

http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end() }
  const chunks = []
  for await (const c of req) chunks.push(c)
  const buf = Buffer.concat(chunks)
  let body = {}
  try { body = buf.length ? JSON.parse(buf.toString()) : {} } catch {}
  const url = new URL(req.url, 'http://x')
  if (url.pathname === '/api/chat/stream' && req.method === 'POST') {
    const m = String(body.message || '')
    if (/\bhang\b/i.test(m)) { res.writeHead(200, { 'Content-Type': 'application/x-ndjson', ...cors }); res.write(JSON.stringify({ kind: 'message', text: 'Starting… ' }) + '\n'); setTimeout(() => res.destroy(), 700); return }
    if (/\b503\b/.test(m)) { res.writeHead(503, { 'Content-Type': 'application/json', ...cors }); return res.end('{"error":"the brain is not running"}') }
    if (/\blong\b/i.test(m)) return longText(res, body)
    if (/\bstop\b|\bslow\b/i.test(m) && !/\brich\b/i.test(m)) return slowForever(res, body)
    if (/\brich\b|\bmarkdown\b|\bplan\b/i.test(m)) return richStream(res, body)
  }
  if (url.pathname === '/api/chat/conversations/c-rich' && req.method === 'GET') {
    return (res.writeHead(200, { 'Content-Type': 'application/json', ...cors }), res.end(JSON.stringify({ messages: [
      { role: 'user', text: 'Plan the Stripe migration in rich markdown', at: new Date(Date.now() - 3600e3).toISOString(), toolCalls: [] },
      { role: 'assistant', text: RICH, at: new Date(Date.now() - 3590e3).toISOString(), toolCalls: [
        { id: 'a', title: 'Grep "stripe."', kind: 'search', status: 'completed', output: LONG_OUT, input: { pattern: 'stripe\\.' } },
        { id: 'b', title: 'Bash: go test ./...', kind: 'execute', status: 'failed', output: 'FAIL billing 0.41s', input: { command: 'go test ./...' } }
      ] }
    ] })))
  }
  if (url.pathname === '/api/tools/task.create' && req.method === 'POST' && /harness/i.test(String(body.goal || ''))) {
    return (res.writeHead(200, { 'Content-Type': 'application/json', ...cors }), res.end(JSON.stringify({ tool: 'task.create', ok: true, output: { task_id: 't-2001', title: body.title || 'Harness off', status: 'recorded', warning: 'the harness is disabled, so nothing will work this task until it is enabled' } })))
  }
  if (url.pathname === '/api/tools/task.create' && req.method === 'POST' && /fail/i.test(String(body.goal || ''))) {
    return (res.writeHead(200, { 'Content-Type': 'application/json', ...cors }), res.end(JSON.stringify({ tool: 'task.create', ok: false, error: 'the task store is locked (mock failure)' })))
  }
  proxy(req, res, buf)
}).listen(PORT, '127.0.0.1', () => console.log(`rich mock http://127.0.0.1:${PORT} -> ${UP.origin}`))
