/**
 * Conversation state lives OUTSIDE React (a module-level zustand store) so that:
 *  - a reply keeps streaming while you look at another screen and is all there when you come back;
 *  - the first `conversation` event of a new chat can rename its thread in place (no remount, no flicker);
 *  - drafts survive switching conversations.
 *
 * Thread keys: 'new' (an empty, not-yet-started chat) → 'pending-N' (streaming, id not known yet) → the daemon's
 * conversation id. Real conversations are keyed by their id from the start.
 */
import { create } from 'zustand'
import type { StreamHandle } from '@shared/ipc'
import { ApiError, api, streamChat } from '@/lib/api/client'
import type { ChatEvent, TaskCreateOutput } from '@/lib/api/schemas'
import { applyEvents, firstUserText, friendlyError, historyToTurns, settle, uid } from './stream'
import { emptyDraft, type AssistantTurn, type ComposerMode, type Draft, type LocalCard, type Thread, type Turn, type UserTurn } from './types'

export const NEW_KEY = 'new'
export const isPendingKey = (k: string) => k.startsWith('pending-')

/* ── side effects the React layer (query cache) subscribes to ───────────── */

export type ChatEffect = 'conversations' | 'tasks'
const listeners = new Set<(e: ChatEffect) => void>()
export function onChatEffect(fn: (e: ChatEffect) => void): () => void {
  listeners.add(fn)
  return () => void listeners.delete(fn)
}
const emit = (e: ChatEffect) => listeners.forEach((f) => f(e))

/* ── persisted, per-viewer prefs (never state that must be reliable) ─────── */

const PREFS_KEY = 'km.chat.prefs'
interface Prefs {
  model?: string
  effort?: string
  listCollapsed?: boolean
}
function readPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY)
    return raw ? (JSON.parse(raw) as Prefs) : {}
  } catch {
    return {}
  }
}
function writePrefs(p: Prefs) {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(p))
  } catch {
    /* storage unavailable: preference just won't persist */
  }
}

/* ── URL: the router is not told (Shell re-keys its page transition on pathname, which would flash) ─────────────── */

export function setChatUrl(id: string | null) {
  try {
    const u = new URL(window.location.href)
    u.hash = id ? `#/chat/${encodeURIComponent(id)}` : '#/chat'
    window.history.replaceState(window.history.state, '', u)
  } catch {
    /* non-browser context */
  }
}

/* ── stream bookkeeping (not reactive) ──────────────────────────────────── */

interface StreamCtx {
  key: string
  asstId: string
  queue: ChatEvent[]
  handle?: StreamHandle
  stopped: boolean
  sawDone: boolean
  finished: boolean
  raf: number
  timer: ReturnType<typeof setTimeout> | 0
}
const streams = new Map<string, StreamCtx>()
let pendingSeq = 0

/* ── state ──────────────────────────────────────────────────────────────── */

interface ChatState {
  threads: Record<string, Thread>
  activeKey: string
  mode: ComposerMode
  drafts: Record<string, Draft>
  model?: string
  effort?: string
  listCollapsed: boolean
  /** View identity of the blank 'new' chat, so it does not remount when its first message turns it into a thread. */
  newVid: string

  selectConversation(id: string): void
  newChat(): void
  loadHistory(id: string, force?: boolean): Promise<void>
  send(text: string): void
  retry(): void
  stop(key?: string): void
  removeConversation(id: string): Promise<void>
  setMode(m: ComposerMode): void
  setDraft(key: string, patch: Partial<Draft>): void
  setModel(id: string | undefined): void
  setEffort(level: string | undefined): void
  toggleList(): void
  notice(text: string, tone?: 'info' | 'warn' | 'error'): void
  assignTask(input: { goal: string; title?: string; workdir?: string; start_in_minutes?: number }): Promise<boolean>
  retryTask(turnId: string): Promise<void>
  runLoop(name: string): Promise<void>
}

const prefs0 = readPrefs()

export const useChat = create<ChatState>((set, get) => {
  /* helpers over `set` ------------------------------------------------- */

  const withThread = (key: string, fn: (t: Thread) => Thread, make = false) =>
    set((s) => {
      let t = s.threads[key]
      if (!t) {
        if (!make) return s
        t = { key, vid: key === NEW_KEY ? get().newVid : uid('v'), turns: [], history: 'ready', streaming: false }
      }
      return { threads: { ...s.threads, [key]: fn(t) } }
    })

  /** Patch one turn by id wherever it lives (its thread may have been renamed since the caller captured a key). */
  const patchTurn = (turnId: string, fn: (t: Turn) => Turn) =>
    set((s) => {
      for (const [k, th] of Object.entries(s.threads)) {
        const i = th.turns.findIndex((t) => t.id === turnId)
        if (i < 0) continue
        const turns = th.turns.slice()
        turns[i] = fn(turns[i])
        return { threads: { ...s.threads, [k]: { ...th, turns } } }
      }
      return s
    })
  const hasTurn = (turnId: string) => Object.values(get().threads).some((th) => th.turns.some((t) => t.id === turnId))

  const pushLocal = (card: LocalCard, key = get().activeKey): string => {
    const id = uid('l')
    withThread(key, (t) => ({ ...t, turns: [...t.turns, { id, role: 'local', card, at: Date.now(), fresh: true }] }), true)
    return id
  }

  /* streaming ---------------------------------------------------------- */

  const flush = (ctx: StreamCtx) => {
    if (ctx.raf) cancelAnimationFrame(ctx.raf)
    if (ctx.timer) clearTimeout(ctx.timer)
    ctx.raf = 0
    ctx.timer = 0
    if (!ctx.queue.length) return
    const evs = ctx.queue
    ctx.queue = []
    set((s) => {
      const th = s.threads[ctx.key]
      if (!th) return s
      let i = th.turns.length - 1
      while (i >= 0 && th.turns[i].id !== ctx.asstId) i--
      if (i < 0) return s
      const turns = th.turns.slice()
      turns[i] = applyEvents(turns[i] as AssistantTurn, evs)
      return { threads: { ...s.threads, [ctx.key]: { ...th, turns } } }
    })
  }

  const schedule = (ctx: StreamCtx) => {
    if (ctx.raf || ctx.timer) return
    ctx.raf = requestAnimationFrame(() => flush(ctx))
    // requestAnimationFrame does not fire while the window is hidden (minimised to tray): don't let the queue sit.
    ctx.timer = setTimeout(() => flush(ctx), 250)
  }

  const adopt = (ctx: StreamCtx, id: string) => {
    const old = ctx.key
    if (old === id) return
    const wasActive = get().activeKey === old
    set((s) => {
      const th = s.threads[old]
      if (!th) return s
      const threads = { ...s.threads }
      delete threads[old]
      threads[id] = { ...th, key: id, conversationId: id }
      const drafts = { ...s.drafts }
      if (drafts[old]) {
        drafts[id] = drafts[old]
        delete drafts[old]
      }
      return { threads, drafts, activeKey: s.activeKey === old ? id : s.activeKey }
    })
    streams.delete(old)
    ctx.key = id
    streams.set(id, ctx)
    if (wasActive) setChatUrl(id)
    emit('conversations')
  }

  const finish = (ctx: StreamCtx, err?: unknown) => {
    if (ctx.finished) return
    ctx.finished = true
    flush(ctx)
    if (streams.get(ctx.key) === ctx) streams.delete(ctx.key)
    set((s) => {
      const th = s.threads[ctx.key]
      if (!th) return s
      const turns = th.turns.map((t): Turn => {
        if (t.id !== ctx.asstId || t.role !== 'assistant') return t
        let next = settle(t)
        const hasError = next.blocks.some((b) => b.kind === 'error')
        if (ctx.sawDone) return { ...next, status: 'done' }
        if (ctx.stopped) return { ...next, status: 'stopped' }
        if (err) next = { ...next, blocks: [...next.blocks, { kind: 'error', id: uid('e'), text: friendlyError(err) }] }
        else if (!hasError)
          next = { ...next, blocks: [...next.blocks, { kind: 'error', id: uid('e'), text: 'The reply ended before KARMAX finished. The connection may have dropped.' }] }
        return { ...next, status: 'error' }
      })
      return { threads: { ...s.threads, [ctx.key]: { ...th, turns, streaming: false } } }
    })
    emit('conversations')
  }

  const onEvent = (ctx: StreamCtx, ev: ChatEvent) => {
    if (ev.kind === 'conversation') {
      flush(ctx)
      adopt(ctx, ev.id)
      return
    }
    if (ev.kind === 'done') ctx.sawDone = true
    if (ev.kind === 'ticket') emit('tasks')
    ctx.queue.push(ev)
    schedule(ctx)
  }

  /** Start streaming a reply on `key`. The user turn (if any) has already been appended by the caller. */
  const run = (key: string, message: string, asstId: string) => {
    const s = get()
    const ctx: StreamCtx = { key, asstId, queue: [], stopped: false, sawDone: false, finished: false, raf: 0, timer: 0 }
    streams.set(key, ctx)
    try {
      ctx.handle = streamChat({ message, conversationId: s.threads[key]?.conversationId, model: s.model, effort: s.effort }, (e) => onEvent(ctx, e))
      ctx.handle.done.then(
        () => finish(ctx),
        (e) => finish(ctx, e)
      )
    } catch (e) {
      finish(ctx, e)
    }
  }

  /** Opens a fresh assistant turn (and the user's, unless retrying) and starts streaming. */
  const startTurn = (message: string, opts: { echoUser: boolean }) => {
    const s = get()
    let key = s.activeKey
    const existing = s.threads[key]
    if (existing?.streaming) return
    const threads = { ...s.threads }
    const drafts = { ...s.drafts }
    let newVid = s.newVid
    if (key === NEW_KEY) {
      // A brand new chat: give it a private key so 'new' is immediately free for the next "New chat".
      const pk = `pending-${++pendingSeq}`
      threads[pk] = { ...(existing ?? { vid: s.newVid, turns: [], history: 'ready' as const, streaming: false }), key: pk }
      delete threads[NEW_KEY]
      drafts[pk] = { ...emptyDraft }
      drafts[NEW_KEY] = { ...(s.drafts[NEW_KEY] ?? emptyDraft), text: '' }
      key = pk
      newVid = uid('v')
    } else {
      if (!existing) threads[key] = { key, vid: uid('v'), conversationId: isPendingKey(key) ? undefined : key, turns: [], history: 'ready', streaming: false }
      drafts[key] = { ...(drafts[key] ?? emptyDraft), text: '' }
    }
    const asstId = uid('a')
    const now = Date.now()
    const user: UserTurn = { id: uid('u'), role: 'user', text: message, at: now, fresh: true }
    const asst: AssistantTurn = { id: asstId, role: 'assistant', blocks: [], status: 'streaming', startedAt: now, fresh: true }
    const th = threads[key]
    threads[key] = { ...th, streaming: true, turns: [...th.turns, ...(opts.echoUser ? [user] : []), asst] }
    set({ threads, drafts, activeKey: key, newVid })
    run(key, message, asstId)
  }

  return {
    threads: {},
    activeKey: NEW_KEY,
    mode: 'chat',
    drafts: {},
    model: prefs0.model,
    effort: prefs0.effort,
    listCollapsed: !!prefs0.listCollapsed,
    newVid: uid('v'),

    selectConversation(id) {
      set({ activeKey: id })
      setChatUrl(isPendingKey(id) || id === NEW_KEY ? null : id)
      void get().loadHistory(id)
    },

    newChat() {
      set({ activeKey: NEW_KEY })
      setChatUrl(null)
    },

    async loadHistory(id, force = false) {
      if (id === NEW_KEY || isPendingKey(id)) return
      const th = get().threads[id]
      if (th && !force && (th.history === 'ready' || th.history === 'loading' || th.streaming)) return
      set((s) => {
        const cur = s.threads[id] ?? { key: id, vid: uid('v'), turns: [], history: 'idle' as const, streaming: false }
        return { threads: { ...s.threads, [id]: { ...cur, conversationId: id, history: 'loading' as const, historyError: undefined, historyStatus: undefined } } }
      })
      try {
        const r = await api.chat.history(id)
        // Anything already in the thread was created in this session while history was loading: keep it after the history.
        withThread(id, (t) => ({ ...t, history: 'ready', turns: [...historyToTurns(r.messages), ...t.turns.filter((x) => x.fresh)] }))
      } catch (e) {
        withThread(id, (t) => ({ ...t, history: 'error', historyError: friendlyError(e), historyStatus: e instanceof ApiError ? e.status : undefined }))
      }
    },

    send(text) {
      const message = text.trim()
      if (!message) return
      startTurn(message, { echoUser: true })
    },

    retry() {
      const s = get()
      const th = s.threads[s.activeKey]
      if (!th || th.streaming) return
      let i = th.turns.length - 1
      while (i >= 0 && !(th.turns[i].role === 'assistant' && (th.turns[i] as AssistantTurn).status === 'error')) i--
      if (i < 0) return
      let u = i - 1
      while (u >= 0 && th.turns[u].role !== 'user') u--
      if (u < 0) return
      const message = (th.turns[u] as UserTurn).text
      // Drop the failed attempt; the user's message stays, and the new attempt streams below it.
      withThread(s.activeKey, (t) => ({ ...t, turns: t.turns.filter((_, idx) => idx !== i) }))
      startTurn(message, { echoUser: false })
    },

    stop(key) {
      const k = key ?? get().activeKey
      const ctx = streams.get(k)
      if (!ctx) return
      ctx.stopped = true
      try {
        ctx.handle?.abort()
      } catch {
        /* already closed */
      }
      finish(ctx)
    },

    async removeConversation(id) {
      get().stop(id)
      await api.chat.remove(id)
      set((s) => {
        const threads = { ...s.threads }
        delete threads[id]
        const drafts = { ...s.drafts }
        delete drafts[id]
        return { threads, drafts }
      })
      if (get().activeKey === id) get().newChat()
      emit('conversations')
    },

    setMode: (mode) => set({ mode }),
    setDraft: (key, patch) => set((s) => ({ drafts: { ...s.drafts, [key]: { ...(s.drafts[key] ?? emptyDraft), ...patch } } })),
    setModel(model) {
      set({ model })
      writePrefs({ ...readPrefs(), model })
    },
    setEffort(effort) {
      set({ effort })
      writePrefs({ ...readPrefs(), effort })
    },
    toggleList() {
      const listCollapsed = !get().listCollapsed
      set({ listCollapsed })
      writePrefs({ ...readPrefs(), listCollapsed })
    },

    notice(text, tone = 'info') {
      pushLocal({ type: 'notice', tone, text })
    },

    async assignTask(input) {
      const card: LocalCard = { type: 'task', state: 'pending', goal: input.goal, title: input.title, workdir: input.workdir, startInMinutes: input.start_in_minutes }
      const id = pushLocal(card)
      try {
        const out: TaskCreateOutput = await api.tasks.create(input)
        patchTurn(id, (t) => (t.role === 'local' && t.card.type === 'task' ? { ...t, card: { ...t.card, state: 'ok', result: out } } : t))
        emit('tasks')
        return true
      } catch (e) {
        patchTurn(id, (t) => (t.role === 'local' && t.card.type === 'task' ? { ...t, card: { ...t.card, state: 'error', error: friendlyError(e) } } : t))
        return false
      }
    },

    async retryTask(turnId) {
      let input: { goal: string; title?: string; workdir?: string; start_in_minutes?: number } | undefined
      patchTurn(turnId, (t) => {
        if (t.role === 'local' && t.card.type === 'task') {
          input = { goal: t.card.goal, title: t.card.title, workdir: t.card.workdir, start_in_minutes: t.card.startInMinutes }
          return { ...t, card: { ...t.card, state: 'pending', error: undefined } }
        }
        return t
      })
      if (!input) return
      try {
        const out = await api.tasks.create(input)
        patchTurn(turnId, (t) => (t.role === 'local' && t.card.type === 'task' ? { ...t, card: { ...t.card, state: 'ok', result: out } } : t))
        emit('tasks')
      } catch (e) {
        patchTurn(turnId, (t) => (t.role === 'local' && t.card.type === 'task' ? { ...t, card: { ...t.card, state: 'error', error: friendlyError(e) } } : t))
      }
    },

    async runLoop(name) {
      const startedAt = Date.now()
      const id = pushLocal({ type: 'loop', name, state: 'starting', startedAt })
      const setCard = (patch: Partial<Extract<LocalCard, { type: 'loop' }>>) =>
        patchTurn(id, (t) => (t.role === 'local' && t.card.type === 'loop' ? { ...t, card: { ...t.card, ...patch } } : t))
      try {
        await api.loops.run(name)
      } catch (e) {
        setCard({ state: 'error', detail: friendlyError(e) })
        return
      }
      setCard({ state: 'running' })
      // POST /api/loops/{name}/run only STARTS the run (runtime.RunLoopByName launches a goroutine), so the result
      // is read from /api/loops/health: a success/failure timestamp newer than the click means it finished.
      const same = (n: string) => n === name || n.replace(/^recipe:/, '') === name.replace(/^recipe:/, '')
      for (let i = 0; i < 45 && hasTurn(id); i++) {
        await new Promise((r) => setTimeout(r, i === 0 ? 900 : 2000))
        try {
          const h = await api.loops.health()
          const row = h.loops.find((l) => same(l.name))
          if (!row) continue
          if (row.running) {
            setCard({ state: 'running' })
            continue
          }
          const okAt = row.last_success ? Date.parse(row.last_success) : 0
          const failAt = row.last_failure ? Date.parse(row.last_failure) : 0
          const since = startedAt - 2000
          if (failAt >= since && failAt >= okAt) return setCard({ state: 'failed', detail: row.last_error || 'The run failed.', finishedAt: failAt })
          if (okAt >= since) return setCard({ state: 'ok', finishedAt: okAt })
        } catch {
          /* transient: keep polling */
        }
      }
      if (hasTurn(id)) setCard({ state: 'unknown' })
    }
  }
})

/** Convenience: a thread's display title before the server has one. */
export const localTitle = (t: Thread) => firstUserText(t.turns)
