import { motion } from 'framer-motion'
import { CircleDashed, ListTodo, Orbit, Rocket, type LucideIcon } from 'lucide-react'
import { fadeUp, stagger } from '@/design/motion'
import { Logo } from '@/shell/Logo'
import { useLoops } from '@/lib/api/hooks'
import { useChat } from './store'

interface Chip {
  icon: LucideIcon
  title: string
  sub: string
  run: () => void
}

/** Empty state: what KARMAX is for, and four one-click ways in. */
export function Hero({ disabled, onFocusComposer }: { disabled: boolean; onFocusComposer: () => void }) {
  const loops = useLoops()
  const { send, setMode, runLoop } = useChat.getState()

  const list = loops.data?.loops ?? []
  const techNews = list.find((l) => l.name === 'tech-news' && l.enabled)
  const loopPick = techNews ?? list.find((l) => l.enabled)

  const chips: Chip[] = [
    { icon: ListTodo, title: "What's on my plate?", sub: 'Open tasks, approvals and loose ends', run: () => send("What's on my plate?") },
    { icon: CircleDashed, title: "Summarise what's unfinished", sub: 'Threads and tasks still hanging', run: () => send("Summarise what's unfinished.") },
    ...(loopPick
      ? [{ icon: Orbit, title: `Run ${loopPick.name} now`, sub: 'Triggers the loop and shows the result here', run: () => void runLoop(loopPick.name) } as Chip]
      : []),
    {
      icon: Rocket,
      title: 'Assign a task',
      sub: 'Hand off work KARMAX finishes on its own',
      run: () => {
        setMode('task')
        requestAnimationFrame(onFocusComposer)
      }
    }
  ]

  return (
    <motion.div variants={stagger(0.06)} initial="hidden" animate="show" className="flex flex-1 flex-col items-center justify-center py-6 text-center">
      <motion.div variants={fadeUp} className="relative mb-5">
        <div aria-hidden="true" className="absolute inset-[-26px] rounded-full opacity-70 blur-2xl" style={{ background: 'radial-gradient(closest-side, color-mix(in oklab, var(--accent) 45%, transparent), transparent)' }} />
        <Logo size={52} />
      </motion.div>
      <motion.h2 variants={fadeUp} className="m-0 font-[family-name:var(--font-display)] text-[26px] font-semibold tracking-tight text-ink">
        What should KARMAX work on?
      </motion.h2>
      <motion.p variants={fadeUp} className="m-0 mt-2 max-w-[460px] text-[13.5px] leading-relaxed text-ink-3">
        Ask a question, or hand over a task. Tasks keep going after you close this window, and KARMAX messages you on WhatsApp when they finish or get stuck.
      </motion.p>
      <motion.div variants={fadeUp} className="mt-7 grid w-full max-w-[640px] grid-cols-1 gap-2.5 sm:grid-cols-2">
        {chips.map((c) => (
          <button
            key={c.title}
            type="button"
            disabled={disabled}
            onClick={c.run}
            className="app-no-drag group flex items-center gap-3 rounded-2xl border border-line bg-surface-2/40 px-3.5 py-3 text-left transition-[background,border-color,transform] hover:border-line-strong hover:bg-surface-2/80 active:translate-y-px disabled:pointer-events-none disabled:opacity-45"
          >
            <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-surface-3/70 text-ink-2 transition-colors group-hover:bg-accent-soft group-hover:text-accent">
              <c.icon className="size-[18px]" />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-medium text-ink">{c.title}</span>
              <span className="block truncate text-[12px] text-ink-3">{c.sub}</span>
            </span>
          </button>
        ))}
      </motion.div>
    </motion.div>
  )
}
