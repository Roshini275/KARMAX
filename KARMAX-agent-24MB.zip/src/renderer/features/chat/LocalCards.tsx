/**
 * Cards for things the desktop app did locally (they are not part of the daemon's transcript):
 * a directly assigned task, a manually run loop, and command feedback.
 */
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowUpRight, CalendarClock, CircleAlert, Clock, FolderOpen, Info, LoaderCircle, MessageCircle, OctagonX, Orbit, RotateCw, SquareKanban, TriangleAlert } from 'lucide-react'
import { cn } from '@/design/cn'
import { Button } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { formatDuration } from '@/lib/format'
import { taskStatus } from './Cards'
import { CopyButton } from './clipboard'
import { useChat } from './store'
import type { LocalCard } from './types'

const shell = 'rounded-2xl border bg-surface-2/40'

/* ── assigned task ───────────────────────────────────────────────────────── */

export function TaskCard({ turnId, card }: { turnId: string; card: Extract<LocalCard, { type: 'task' }> }) {
  const retry = useChat((s) => s.retryTask)
  const [more, setMore] = useState(false)
  const r = card.result
  const st = r ? taskStatus(r.status) : undefined
  const long = card.goal.length > 260 || card.goal.split('\n').length > 4
  const title = r?.title || card.title || card.goal.split('\n')[0].slice(0, 90)

  if (card.state === 'error') {
    return (
      <div role="alert" className={cn(shell, 'border-[color-mix(in_oklab,var(--crit)_38%,transparent)] bg-[color-mix(in_oklab,var(--crit)_8%,transparent)] px-4 py-3.5')}>
        <div className="flex items-start gap-3">
          <OctagonX className="mt-0.5 size-4 shrink-0 text-crit" strokeWidth={2.4} />
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-semibold text-crit">Couldn't assign the task</div>
            <p className="selectable m-0 mt-0.5 break-words text-[12.5px] leading-relaxed text-ink-2">{card.error}</p>
            <p className="m-0 mt-1.5 truncate text-[12px] text-ink-3">{title}</p>
          </div>
          <Button size="sm" variant="subtle" icon={<RotateCw className="size-3.5" />} onClick={() => void retry(turnId)}>Retry</Button>
        </div>
      </div>
    )
  }

  const pending = card.state === 'pending'
  return (
    <div className={cn(shell, 'relative overflow-hidden border-line')} style={{ boxShadow: pending ? undefined : '0 0 0 1px color-mix(in oklab, var(--accent) 18%, transparent), 0 16px 40px -30px var(--accent)' }}>
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/70 to-transparent" />
      <div className="px-4 pb-3.5 pt-3.5">
        <div className="flex items-center gap-3">
          <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent">
            {pending ? <LoaderCircle className="size-[18px] animate-[km-spin_0.9s_linear_infinite]" /> : <SquareKanban className="size-[18px]" />}
          </span>
          <div className="min-w-0 flex-1">
            <div className="label-micro">{pending ? 'Assigning task…' : r?.warning ? 'Task recorded' : 'Task assigned'}</div>
            <div className="truncate text-[14px] font-semibold tracking-tight text-ink">{title}</div>
          </div>
          {st && <StatusPill tone={st.tone} label={st.label} icon={st.icon} />}
        </div>

        <p className={cn('selectable m-0 mt-3 whitespace-pre-wrap break-words text-[13px] leading-relaxed text-ink-2', long && !more && 'line-clamp-4')}>{card.goal}</p>
        {long && (
          <button type="button" onClick={() => setMore((v) => !v)} className="mt-1 text-[11.5px] font-medium text-accent hover:underline">
            {more ? 'Show less' : 'Show full goal'}
          </button>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          {r && (
            <span className="inline-flex items-center gap-1 rounded-md bg-surface-3/60 py-0.5 pl-1.5 pr-0.5 font-[family-name:var(--font-mono)] text-[11px] text-ink-2 ring-1 ring-line">
              {r.task_id}
              <CopyButton text={r.task_id} label="Copy task id" className="!h-5 !px-1" />
            </span>
          )}
          {card.workdir && (
            <span className="inline-flex max-w-[320px] items-center gap-1 rounded-md bg-surface-3/60 px-1.5 py-0.5 font-[family-name:var(--font-mono)] text-[11px] text-ink-2 ring-1 ring-line" title={card.workdir}>
              <FolderOpen className="size-3 shrink-0 text-ink-3" />
              <span className="truncate">{card.workdir}</span>
            </span>
          )}
          {card.startInMinutes ? (
            <span className="inline-flex items-center gap-1 rounded-md bg-surface-3/60 px-1.5 py-0.5 text-[11px] text-ink-2 ring-1 ring-line">
              <CalendarClock className="size-3 text-ink-3" />
              First round in {card.startInMinutes} min
            </span>
          ) : null}
        </div>
      </div>

      {r?.warning && (
        <div role="alert" className="mx-4 mb-3.5 flex items-start gap-2.5 rounded-xl border border-[color-mix(in_oklab,var(--warn)_45%,transparent)] bg-[color-mix(in_oklab,var(--warn)_11%,transparent)] px-3 py-2.5">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warn" strokeWidth={2.4} />
          <div className="min-w-0 text-[12.5px] leading-relaxed">
            <span className="font-semibold text-warn">Recorded, but nothing will work it yet. </span>
            <span className="text-ink-2">{r.warning.charAt(0).toUpperCase() + r.warning.slice(1)}{/[.!]$/.test(r.warning) ? '' : '.'}</span>
          </div>
        </div>
      )}

      {r && (
        <div className="flex items-center justify-between gap-3 border-t border-line bg-surface-2/40 px-4 py-2.5">
          <span className="flex min-w-0 items-center gap-2 text-[12px] text-ink-3">
            <MessageCircle className="size-3.5 shrink-0" />
            <span className="truncate">{r.warning ? 'Enable the harness in the KARMAX config to start it.' : "KARMAX will message you on WhatsApp when it's done or stuck."}</span>
          </span>
          <Link
            to={`/tasks/${encodeURIComponent(r.task_id)}`}
            className="app-no-drag inline-flex h-7 shrink-0 items-center gap-1 rounded-md bg-surface-3 px-2.5 text-[12px] font-medium text-ink ring-1 ring-line transition-colors hover:bg-[color-mix(in_oklab,var(--surface-3)_70%,var(--accent))]"
          >
            View task <ArrowUpRight className="size-3.5" />
          </Link>
        </div>
      )}
    </div>
  )
}

/* ── loop run ────────────────────────────────────────────────────────────── */

export function LoopCard({ card }: { card: Extract<LocalCard, { type: 'loop' }> }) {
  const s = card.state
  const pill =
    s === 'ok' ? <StatusPill tone="good" label="Succeeded" />
    : s === 'failed' ? <StatusPill tone="crit" label="Failed" />
    : s === 'error' ? <StatusPill tone="crit" label="Not started" />
    : s === 'unknown' ? <StatusPill tone="muted" label="Started" icon={<Clock className="size-3" strokeWidth={2.5} />} />
    : <StatusPill tone="accent" label={s === 'starting' ? 'Starting' : 'Running'} />
  const took = card.finishedAt ? formatDuration(Math.max(0, card.finishedAt - card.startedAt)) : undefined
  return (
    <div className={cn(shell, 'flex items-start gap-3 border-line px-4 py-3')}>
      <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-surface-3/70 text-ink-2"><Orbit className="size-[18px]" /></span>
      <div className="min-w-0 flex-1">
        <div className="label-micro">Loop run</div>
        <div className="truncate font-[family-name:var(--font-mono)] text-[13.5px] font-semibold text-ink">{card.name}</div>
        {s === 'ok' && <p className="m-0 mt-0.5 text-[12.5px] text-ink-3">Finished{took ? ` in about ${took}` : ''}. Details are in Loops and Logs.</p>}
        {s === 'failed' && <p className="selectable m-0 mt-0.5 break-words text-[12.5px] text-ink-2">{card.detail}</p>}
        {s === 'error' && <p className="selectable m-0 mt-0.5 break-words text-[12.5px] text-ink-2">{card.detail}</p>}
        {s === 'running' && <p className="m-0 mt-0.5 text-[12.5px] text-ink-3">Triggered. Waiting for the run to finish…</p>}
        {s === 'unknown' && <p className="m-0 mt-0.5 text-[12.5px] text-ink-3">KARMAX accepted the run, but no result showed up yet. Check Loops for the outcome.</p>}
      </div>
      <div className="flex shrink-0 flex-col items-end gap-2">
        {pill}
        <Link to="/loops" className="inline-flex items-center gap-0.5 text-[11.5px] font-medium text-ink-3 transition-colors hover:text-ink">
          Open Loops <ArrowUpRight className="size-3" />
        </Link>
      </div>
    </div>
  )
}

/* ── command feedback ────────────────────────────────────────────────────── */

export function NoticeCard({ card }: { card: Extract<LocalCard, { type: 'notice' }> }) {
  const Icon = card.tone === 'error' ? OctagonX : card.tone === 'warn' ? TriangleAlert : card.tone === 'info' ? Info : CircleAlert
  return (
    <div role="status" className="flex w-fit max-w-full items-center gap-2 rounded-full border border-line bg-surface-2/50 px-3 py-1.5 text-[12px] text-ink-2">
      <Icon className={cn('size-3.5 shrink-0', card.tone === 'error' ? 'text-crit' : card.tone === 'warn' ? 'text-warn' : 'text-ink-3')} strokeWidth={2.3} />
      <span className="selectable min-w-0 break-words">{card.text}</span>
    </div>
  )
}
