import { useEffect, useRef, useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { cn } from '@/design/cn'

/** Clipboard write that also works where `navigator.clipboard` is unavailable (insecure context, older shells). */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    /* fall through to the legacy path */
  }
  try {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.setAttribute('readonly', '')
    ta.style.cssText = 'position:fixed;top:-1000px;opacity:0'
    document.body.appendChild(ta)
    ta.select()
    const ok = document.execCommand('copy')
    ta.remove()
    return ok
  } catch {
    return false
  }
}

/** Icon button that flips to a check for a moment after copying. */
export function CopyButton({ text, label = 'Copy', className, children }: { text: string | (() => string); label?: string; className?: string; children?: React.ReactNode }) {
  const [done, setDone] = useState<'idle' | 'ok' | 'fail'>('idle')
  const t = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  useEffect(() => () => clearTimeout(t.current), [])
  return (
    <button
      type="button"
      aria-label={done === 'ok' ? 'Copied' : label}
      title={done === 'ok' ? 'Copied' : label}
      onClick={async () => {
        const ok = await copyText(typeof text === 'function' ? text() : text)
        setDone(ok ? 'ok' : 'fail')
        clearTimeout(t.current)
        t.current = setTimeout(() => setDone('idle'), 1500)
      }}
      className={cn(
        'app-no-drag inline-flex h-6 items-center gap-1 rounded-md px-1.5 text-[11px] font-medium text-ink-3 transition-colors hover:bg-surface-3 hover:text-ink',
        done === 'ok' && 'text-good hover:text-good',
        className
      )}
    >
      {done === 'ok' ? <Check className="size-3.5" strokeWidth={2.5} /> : <Copy className="size-3.5" />}
      {children && <span>{done === 'ok' ? 'Copied' : children}</span>}
      <span className="sr-only" aria-live="polite">{done === 'ok' ? 'Copied to clipboard' : done === 'fail' ? 'Copy failed' : ''}</span>
    </button>
  )
}
