/**
 * The renderer's model of a conversation thread.
 *
 * An assistant turn is an ordered list of BLOCKS (text / thought / tool / plan / ticket / error) in the order the
 * daemon streamed them, which is what makes the thread read like a document: prose, then the tool call that
 * produced the next paragraph, then the plan tick, then more prose.
 */
import type { PlanEntry, ToolCall, TaskCreateOutput } from '@/lib/api/schemas'

export type Block =
  | { kind: 'text'; id: string; text: string }
  | { kind: 'thought'; id: string; text: string; done: boolean; startedAt: number; endedAt?: number }
  | { kind: 'tool'; id: string; tool: ToolCall }
  | { kind: 'plan'; id: string; plan: PlanEntry[] }
  /** A background job announced by the daemon. See TicketCard for what it can and cannot link to. */
  | { kind: 'ticket'; id: string; jobId: string; title: string }
  | { kind: 'error'; id: string; text: string }

export interface TurnMeta {
  model: string
  durationMs: number
  costUsd: number
}

export type TurnStatus = 'streaming' | 'done' | 'error' | 'stopped'

export interface UserTurn {
  id: string
  role: 'user'
  text: string
  at?: string | number
  /** True for turns created in this session (they animate in; history does not). */
  fresh?: boolean
}

export interface AssistantTurn {
  id: string
  role: 'assistant'
  blocks: Block[]
  status: TurnStatus
  meta?: TurnMeta
  at?: string | number
  startedAt?: number
  fresh?: boolean
}

/** Things the desktop did locally (task assignment, loop runs, command feedback). Not part of the daemon's transcript. */
export type LocalCard =
  | {
      type: 'task'
      state: 'pending' | 'ok' | 'error'
      goal: string
      title?: string
      workdir?: string
      startInMinutes?: number
      result?: TaskCreateOutput
      error?: string
    }
  | {
      type: 'loop'
      name: string
      state: 'starting' | 'running' | 'ok' | 'failed' | 'error' | 'unknown'
      startedAt: number
      detail?: string
      finishedAt?: number
    }
  | { type: 'notice'; tone: 'info' | 'warn' | 'error'; text: string }

export interface LocalTurn {
  id: string
  role: 'local'
  card: LocalCard
  at: number
  fresh?: boolean
}

export type Turn = UserTurn | AssistantTurn | LocalTurn

export type HistoryState = 'idle' | 'loading' | 'ready' | 'error'

export interface Thread {
  key: string
  /** Stable identity of the VIEW: unlike `key` it survives the pending-N -> conversation-id rename, so the thread does not remount. */
  vid: string
  /** The daemon's conversation id. Absent until the first `conversation` event of a brand new chat. */
  conversationId?: string
  turns: Turn[]
  history: HistoryState
  historyError?: string
  historyStatus?: number
  streaming: boolean
}

export interface Draft {
  text: string
  goal: string
  title: string
  workdir: string
  startIn: string
}

export const emptyDraft: Draft = { text: '', goal: '', title: '', workdir: '', startIn: '' }

export type ComposerMode = 'chat' | 'task'
