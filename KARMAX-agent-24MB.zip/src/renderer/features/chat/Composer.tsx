import { forwardRef, useCallback, useEffect, useId, useImperativeHandle, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUp, Bot, Cpu, FolderOpen, Gauge, Hash, MessageSquare, Orbit, Rocket, Square, SquareKanban, Terminal, WifiOff } from 'lucide-react'
import { cn } from '@/design/cn'
import { fast } from '@/design/motion'
import { Button, Input, Kbd, Segmented, Textarea } from '@/design/primitives'
import { useChatOptions, useLoops } from '@/lib/api/hooks'
import { Picker } from './Picker'
import { isKnownCommand, parseCommand, suggest, type SlashCtx, type Suggestion } from './slash'
import { useChat } from './store'
import { emptyDraft, type ComposerMode } from './types'

export interface ComposerHandle {
  focus(): void
}

const MAX_CHARS = 250_000
const START_PRESETS = [
  { label: 'Now', v: '' },
  { label: '5 min', v: '5' },
  { label: '15 min', v: '15' },
  { label: '1 hour', v: '60' }
]

const sugIcon = { command: Terminal, loop: Orbit, model: Cpu, effort: Gauge } as const

export const Composer = forwardRef<ComposerHandle, { disabledReason?: string }>(function Composer({ disabledReason }, ref) {
  const key = useChat((s) => s.activeKey)
  const draft = useChat((s) => s.drafts[s.activeKey]) ?? emptyDraft
  const mode = useChat((s) => s.mode)
  const thread = useChat((s) => s.threads[s.activeKey])
  const model = useChat((s) => s.model)
  const effort = useChat((s) => s.effort)
  const { setDraft, setMode, send, stop, assignTask, runLoop, newChat, setModel, setEffort, notice } = useChat.getState()

  const options = useChatOptions().data
  const loopsQ = useLoops()
  const models = useMemo(() => options?.models ?? [], [options])
  const efforts = useMemo(() => options?.efforts ?? [], [options])
  const streaming = !!thread?.streaming
  const loadingHistory = thread?.history === 'loading'
  const disabled = !!disabledReason

  const chatRef = useRef<HTMLTextAreaElement>(null)
  const goalRef = useRef<HTMLTextAreaElement>(null)
  const listId = useId()
  const [dismissed, setDismissed] = useState<string | null>(null)
  const [sel, setSel] = useState(0)

  useImperativeHandle(ref, () => ({ focus: () => (mode === 'chat' ? chatRef : goalRef).current?.focus() }), [mode])

  // Autosize the textareas to their content (capped).
  const fit = (el: HTMLTextAreaElement | null, max: number) => {
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, max)}px`
  }
  useLayoutEffect(() => fit(chatRef.current, 220), [draft.text, mode])
  useLayoutEffect(() => fit(goalRef.current, 260), [draft.goal, mode])

  // Move focus into the composer whenever the conversation changes.
  useEffect(() => {
    ;(mode === 'chat' ? chatRef : goalRef).current?.focus({ preventScroll: true })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  /* ── slash commands ─────────────────────────────────────────────────── */

  const slashCtx: SlashCtx = useMemo(
    () => ({
      loops: (loopsQ.data?.loops ?? []).map((l) => ({ name: l.name, enabled: l.enabled, description: l.description })),
      loopsLoaded: !!loopsQ.data,
      models,
      efforts,
      defaultModel: options?.defaultModel
    }),
    [loopsQ.data, models, efforts, options?.defaultModel]
  )
  const sug = mode === 'chat' && !disabled ? suggest(draft.text, slashCtx) : null
  const popOpen = !!sug && dismissed !== draft.text
  const items = sug?.items ?? []
  const active = Math.min(sel, Math.max(0, items.length - 1))

  const accept = (s: Suggestion) => {
    setDraft(key, { text: s.insert })
    setDismissed(null)
    requestAnimationFrame(() => {
      const el = chatRef.current
      if (el) {
        el.focus()
        el.setSelectionRange(s.insert.length, s.insert.length)
      }
    })
  }

  const runCommand = (text: string): boolean => {
    const c = parseCommand(text)
    if (!c) return false
    switch (c.cmd) {
      case 'task':
        if (!c.args) notice('Usage: /task <goal>. Describe what must be true for the task to be finished.', 'error')
        else void assignTask({ goal: c.args })
        return true
      case 'loop': {
        const m = /^run\s+(\S[\s\S]*)$/i.exec(c.args)
        if (!m) {
          notice('Usage: /loop run <name>', 'error')
          return true
        }
        const want = m[1].trim().toLowerCase()
        const found = slashCtx.loops.find((l) => l.name.toLowerCase() === want)
        if (slashCtx.loopsLoaded && !found) notice(`No loop named "${m[1].trim()}". Type /loop run to see the list.`, 'error')
        else void runLoop(found?.name ?? m[1].trim())
        return true
      }
      case 'reset':
        newChat()
        return true
      case 'model': {
        if (!models.length) {
          notice("This brain doesn't offer a model choice, so /model has nothing to change.", 'warn')
          return true
        }
        if (!c.args) {
          notice(`Model: ${model ?? `default${options?.defaultModel ? ` (${options.defaultModel})` : ''}`}. Options: ${models.map((m) => m.id).join(', ')}.`)
          return true
        }
        if (/^(default|reset|none)$/i.test(c.args)) {
          setModel(undefined)
          notice(`Model reset to the default${options?.defaultModel ? ` (${options.defaultModel})` : ''}.`)
          return true
        }
        const hit = models.find((m) => m.id.toLowerCase() === c.args.toLowerCase() || m.label.toLowerCase() === c.args.toLowerCase())
        if (!hit && !/^[A-Za-z0-9._:-]{1,100}$/.test(c.args)) {
          notice('A model id may only contain letters, digits, ".", "_", ":" and "-".', 'error')
          return true
        }
        setModel(hit?.id ?? c.args)
        notice(hit ? `Model set to ${hit.label} for the next messages.` : `Model set to "${c.args}". It is not in the list, so KARMAX will pass it to the CLI as typed.`, hit ? 'info' : 'warn')
        return true
      }
      case 'effort': {
        if (!efforts.length) {
          notice("This brain doesn't offer an effort setting.", 'warn')
          return true
        }
        if (!c.args) {
          notice(`Effort: ${effort ?? 'default'}. Options: ${efforts.join(', ')}.`)
          return true
        }
        if (/^(default|reset|none)$/i.test(c.args)) {
          setEffort(undefined)
          notice('Effort reset to the default.')
          return true
        }
        const hit = efforts.find((e) => e === c.args.toLowerCase())
        if (!hit) notice(`Effort must be one of ${efforts.join(', ')}.`, 'error')
        else {
          setEffort(hit)
          notice(`Effort set to ${hit} for the next messages.`)
        }
        return true
      }
      default:
        // "/usr/bin/foo" or "/etc/hosts" is a path in a message, not a command.
        if (/^\/[A-Za-z][\w-]*$/.test(text.trim()) && !isKnownCommand(c.cmd)) {
          notice(`Unknown command /${c.cmd}. Try /task, /loop run, /reset, /model or /effort.`, 'error')
          return true
        }
        return false
    }
  }

  /* ── submit ─────────────────────────────────────────────────────────── */

  const canSendChat = !disabled && !loadingHistory && !streaming && draft.text.trim().length > 0 && draft.text.length <= MAX_CHARS
  const submitChat = () => {
    const text = draft.text.trim()
    if (!text || disabled || streaming || loadingHistory || text.length > MAX_CHARS) return
    if (text.startsWith('/') && runCommand(text)) {
      setDraft(key, { text: '' })
      return
    }
    send(text)
  }

  const mins = draft.startIn.trim() === '' ? 0 : Number(draft.startIn)
  const minsOk = Number.isInteger(mins) && mins >= 0 && mins <= 10_080
  const canAssign = !disabled && draft.goal.trim().length > 0 && minsOk
  const submitTask = useCallback(() => {
    const goal = draft.goal.trim()
    if (!goal || disabled || !minsOk) return
    void assignTask({ goal, title: draft.title.trim() || undefined, workdir: draft.workdir.trim() || undefined, start_in_minutes: mins > 0 ? mins : undefined })
    setDraft(key, { goal: '', title: '', startIn: '' }) // the working directory is usually reused: keep it
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft, disabled, minsOk, mins, key])

  const onChatKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.nativeEvent.isComposing) return
    if (popOpen && items.length) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setSel((active + 1) % items.length)
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setSel((active - 1 + items.length) % items.length)
        return
      }
      if (e.key === 'Tab') {
        e.preventDefault()
        accept(items[active])
        return
      }
      if (e.key === 'Enter' && !e.shiftKey && items[active].insert.trim() !== draft.text.trim()) {
        e.preventDefault()
        accept(items[active])
        return
      }
    }
    if (e.key === 'Escape') {
      e.preventDefault()
      e.stopPropagation()
      if (popOpen) setDismissed(draft.text)
      else if (streaming) stop()
      else if (draft.text) setDraft(key, { text: '' })
      return
    }
    if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault()
      submitChat()
    }
  }

  const onTaskKey = (e: React.KeyboardEvent) => {
    if (e.nativeEvent.isComposing) return
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault()
      submitTask()
    } else if (e.key === 'Escape') {
      e.preventDefault()
      e.stopPropagation()
      if (draft.goal) setDraft(key, { goal: '' })
    }
  }

  /* ── model / effort pickers ─────────────────────────────────────────── */

  const defaultModelLabel = models.find((m) => m.id === options?.defaultModel)?.label ?? options?.defaultModel
  const modelPicker =
    models.length > 0 ? (
      <Picker
        label="Model"
        icon={<Cpu className="size-3.5 text-ink-3" />}
        display={model ? models.find((m) => m.id === model)?.label ?? model : defaultModelLabel ? `${defaultModelLabel} (default)` : 'Default model'}
        dim={!model}
        value={model ?? ''}
        onChange={(v) => setModel(v || undefined)}
        options={[{ value: '', label: 'Default', hint: defaultModelLabel ? `Currently ${defaultModelLabel}` : 'Whatever KARMAX is configured to use' }, ...models.map((m) => ({ value: m.id, label: m.label, hint: m.id }))]}
      />
    ) : null
  const effortPicker =
    efforts.length > 0 ? (
      <Picker
        label="Effort"
        icon={<Gauge className="size-3.5 text-ink-3" />}
        display={effort ? `${effort[0].toUpperCase()}${effort.slice(1)}` : 'Effort'}
        dim={!effort}
        value={effort ?? ''}
        onChange={(v) => setEffort(v || undefined)}
        options={[{ value: '', label: 'Default', hint: 'No explicit effort flag' }, ...efforts.map((e) => ({ value: e, label: e[0].toUpperCase() + e.slice(1) }))]}
      />
    ) : null

  const offlineHint = disabledReason && (
    <div className="mb-2 flex items-center gap-2 rounded-lg border border-line bg-surface-2/60 px-3 py-1.5 text-[12px] text-ink-3" role="status">
      <WifiOff className="size-3.5 shrink-0" />
      {disabledReason}
    </div>
  )

  return (
    <div className="shrink-0 px-6 pb-5 pt-1">
      <div className="relative mx-auto w-full max-w-[820px]">
        {offlineHint}

        <AnimatePresence>
          {popOpen && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              transition={fast}
              className="glass absolute inset-x-0 bottom-full z-30 mb-2 overflow-hidden rounded-2xl p-1.5 shadow-pop"
              style={{ background: 'color-mix(in oklab, var(--panel) 95%, transparent)' }}
            >
              <div className="label-micro flex items-center justify-between px-2.5 pb-1.5 pt-1">
                <span>{items[0]?.kind === 'loop' ? 'Loops' : items[0]?.kind === 'model' ? 'Models' : items[0]?.kind === 'effort' ? 'Effort' : 'Commands'}</span>
                <span className="flex items-center gap-1.5 normal-case tracking-normal"><Kbd>↑</Kbd><Kbd>↓</Kbd> navigate <Kbd>Tab</Kbd> complete</span>
              </div>
              {items.length === 0 ? (
                <div className="px-2.5 pb-2 pt-1 text-[12.5px] text-ink-3">{sug?.empty}</div>
              ) : (
                <div id={listId} role="listbox" aria-label="Slash commands" className="scroll-thin max-h-[260px] overflow-auto">
                  {items.map((s, i) => {
                    const Icon = sugIcon[s.kind]
                    return (
                      <div
                        key={s.id}
                        id={`${listId}-${i}`}
                        role="option"
                        aria-selected={i === active}
                        onMouseEnter={() => setSel(i)}
                        onMouseDown={(e) => {
                          e.preventDefault()
                          accept(s)
                        }}
                        className={cn('flex cursor-pointer items-center gap-3 rounded-xl px-2.5 py-2', i === active ? 'bg-accent-soft' : 'hover:bg-surface-2/60', s.muted && 'opacity-60')}
                      >
                        <span className={cn('grid size-7 shrink-0 place-items-center rounded-lg', i === active ? 'bg-accent text-white' : 'bg-surface-3/70 text-ink-2')}><Icon className="size-3.5" /></span>
                        <span className="min-w-0 flex-1">
                          <span className="flex items-baseline gap-2">
                            <span className="font-[family-name:var(--font-mono)] text-[13px] font-medium text-ink">{s.label}</span>
                            {s.hint && <span className="font-[family-name:var(--font-mono)] text-[12px] text-ink-3">{s.hint}</span>}
                          </span>
                          <span className="block truncate text-[12px] text-ink-3">{s.desc}</span>
                        </span>
                      </div>
                    )
                  })}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <div className={cn('chat-composer glass rounded-2xl border border-line', disabled && 'opacity-70')}>
          <div className="flex items-center justify-between gap-2 px-2.5 pt-2.5">
            <Segmented<ComposerMode>
              value={mode}
              onChange={(m) => {
                setMode(m)
                requestAnimationFrame(() => (m === 'chat' ? chatRef : goalRef).current?.focus())
              }}
              options={[
                { value: 'chat', label: <><MessageSquare className="size-3.5" />Chat</> },
                { value: 'task', label: <><SquareKanban className="size-3.5" />Assign task</> }
              ]}
            />
            {mode === 'chat' && (modelPicker || effortPicker) && (
              <div className="flex items-center gap-0.5">
                {modelPicker}
                {effortPicker}
              </div>
            )}
          </div>

          {mode === 'chat' ? (
            <>
              <textarea
                ref={chatRef}
                value={draft.text}
                rows={1}
                disabled={disabled}
                aria-label="Message KARMAX"
                aria-autocomplete="list"
                aria-controls={popOpen ? listId : undefined}
                aria-expanded={popOpen}
                aria-activedescendant={popOpen && items.length ? `${listId}-${active}` : undefined}
                placeholder={disabled ? 'KARMAX is offline' : streaming ? 'KARMAX is replying. Stop it to send another message…' : 'Ask KARMAX anything, or type / for commands'}
                onChange={(e) => {
                  setDraft(key, { text: e.target.value })
                  setSel(0)
                }}
                onKeyDown={onChatKey}
                className="selectable block max-h-[220px] w-full resize-none bg-transparent px-4 pb-1 pt-3 text-[14px] leading-[1.6] text-ink placeholder:text-ink-3 focus:outline-none disabled:cursor-not-allowed"
              />
              <div className="flex items-center justify-between gap-3 px-3 pb-2.5 pt-1">
                <div className="hidden items-center gap-3 text-[11.5px] text-ink-3 sm:flex">
                  <span className="flex items-center gap-1"><Kbd>Enter</Kbd> send</span>
                  <span className="flex items-center gap-1"><Kbd>Shift</Kbd>+<Kbd>Enter</Kbd> newline</span>
                  <span className="flex items-center gap-1"><Kbd>/</Kbd> commands</span>
                </div>
                <div className="ml-auto flex items-center gap-2">
                  {draft.text.length > MAX_CHARS && <span className="text-[11.5px] text-crit">Too long ({draft.text.length.toLocaleString()} / {MAX_CHARS.toLocaleString()})</span>}
                  {streaming ? (
                    <Button variant="subtle" size="md" onClick={() => stop()} icon={<Square className="size-3 fill-current" />} aria-label="Stop the reply">
                      Stop <Kbd>Esc</Kbd>
                    </Button>
                  ) : (
                    <button
                      type="button"
                      onClick={submitChat}
                      disabled={!canSendChat}
                      aria-label="Send message"
                      title="Send (Enter)"
                      className="app-no-drag grid size-8 place-items-center rounded-full bg-accent text-white shadow-[0_6px_18px_-8px_var(--accent)] transition-[filter,opacity,transform] hover:brightness-110 active:scale-95 disabled:bg-surface-3 disabled:text-ink-3 disabled:shadow-none"
                    >
                      <ArrowUp className="size-4" strokeWidth={2.6} />
                    </button>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="px-3 pb-3 pt-2.5">
              <Textarea
                ref={goalRef}
                value={draft.goal}
                rows={3}
                disabled={disabled}
                aria-label="Task goal"
                placeholder="What must be true for this to be finished? Include the repo, names, constraints and acceptance criteria. The session that works on it starts from this alone."
                onChange={(e) => setDraft(key, { goal: e.target.value })}
                onKeyDown={onTaskKey}
                className="max-h-[260px] min-h-[84px] bg-surface-2/50"
              />
              <div className="mt-2.5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                <label className="block">
                  <span className="label-micro mb-1 flex items-center gap-1.5"><Hash className="size-3" />Title <span className="normal-case tracking-normal text-ink-3/80">(optional)</span></span>
                  <Input value={draft.title} disabled={disabled} maxLength={140} placeholder="Defaults to the first line of the goal" onChange={(e) => setDraft(key, { title: e.target.value })} onKeyDown={onTaskKey} />
                </label>
                <label className="block">
                  <span className="label-micro mb-1 flex items-center gap-1.5"><FolderOpen className="size-3" />Working directory <span className="normal-case tracking-normal text-ink-3/80">(optional)</span></span>
                  <Input value={draft.workdir} disabled={disabled} placeholder="C:\Users\you\projects\repo" className="font-[family-name:var(--font-mono)] text-[12.5px]" spellCheck={false} onChange={(e) => setDraft(key, { workdir: e.target.value })} onKeyDown={onTaskKey} />
                </label>
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-2.5">
                <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Start time">
                  <span className="label-micro mr-1">Start</span>
                  {START_PRESETS.map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      aria-pressed={draft.startIn === p.v}
                      onClick={() => setDraft(key, { startIn: p.v })}
                      className={cn(
                        'app-no-drag h-7 rounded-full px-2.5 text-[12px] font-medium ring-1 transition-colors',
                        draft.startIn === p.v ? 'bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_45%,transparent)]' : 'bg-surface-2/60 text-ink-2 ring-line hover:text-ink'
                      )}
                    >
                      {p.label}
                    </button>
                  ))}
                  <span className="flex items-center gap-1.5 whitespace-nowrap text-[12px] text-ink-3">
                    or in
                    <Input
                      value={draft.startIn}
                      inputMode="numeric"
                      aria-label="Start in minutes"
                      aria-invalid={!minsOk}
                      disabled={disabled}
                      placeholder="0"
                      className={cn('!h-7 !w-14 px-2 text-center tnum', !minsOk && 'border-crit')}
                      onChange={(e) => setDraft(key, { startIn: e.target.value.replace(/[^\d]/g, '').slice(0, 5) })}
                      onKeyDown={onTaskKey}
                    />
                    min
                  </span>
                </div>
                <div className="ml-auto flex items-center gap-3">
                  <span className="hidden items-center gap-1 text-[11.5px] text-ink-3 md:flex"><Kbd>Ctrl</Kbd>+<Kbd>Enter</Kbd></span>
                  <Button variant="primary" size="md" disabled={!canAssign} onClick={submitTask} icon={<Rocket className="size-3.5" />}>Assign task</Button>
                </div>
              </div>
              <p className="m-0 mt-2.5 flex items-center gap-1.5 text-[11.5px] leading-snug text-ink-3">
                <Bot className="size-3.5 shrink-0" />
                Recorded directly as a durable task. KARMAX works it in its own session, not in this chat, and reports back on WhatsApp.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
})
