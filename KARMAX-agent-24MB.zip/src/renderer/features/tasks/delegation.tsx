import { Bot, Code2, Terminal } from 'lucide-react'
import { StatusPill, type Tone } from '@/design/status'

export type Session = { id: string | number; tool: string; description: string; status: string; session_id: string; updated_at: string }

export function toolIcon(tool: string) {
  const t = tool.toLowerCase()
  if (t.includes('codex')) return Code2
  if (t.includes('claude')) return Bot
  return Terminal
}
export function toolLabel(tool: string) {
  const t = tool.toLowerCase()
  if (t === 'claude_code' || t === 'claude') return 'Claude Code'
  if (t === 'codex') return 'Codex'
  return tool || 'Agent'
}

/** Sessions report free-form status strings; map the ones we know, show the rest muted with their own label. */
export function sessionTone(status: string): { tone: Tone; label: string } {
  const s = status.toLowerCase()
  if (['running', 'active', 'in_progress', 'working'].includes(s)) return { tone: 'accent', label: 'Running' }
  if (['completed', 'done', 'succeeded', 'success', 'idle'].includes(s)) return { tone: 'good', label: s === 'idle' ? 'Idle' : 'Completed' }
  if (['failed', 'error', 'errored', 'crashed'].includes(s)) return { tone: 'crit', label: 'Failed' }
  if (['blocked', 'waiting'].includes(s)) return { tone: 'warn', label: 'Waiting' }
  return { tone: 'muted', label: status ? status[0].toUpperCase() + status.slice(1) : 'Unknown' }
}

export function SessionPill({ status }: { status: string }) {
  const { tone, label } = sessionTone(status)
  return <StatusPill tone={tone} label={label} />
}
