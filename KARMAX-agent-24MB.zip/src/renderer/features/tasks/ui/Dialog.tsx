/**
 * Modal dialog used by Tasks and Approvals (the design kit has no modal yet; see report).
 * Portalled, focus-trapped, Esc closes (captured so it doesn't also close a Drawer underneath), Ctrl+Enter submits.
 */
import { useEffect, useId, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { Button, IconButton } from '@/design/primitives'
import { ease } from '@/design/motion'
import type { Tone } from '@/design/status'
import { cn } from '@/design/cn'

const FOCUSABLE = 'a[href],button:not([disabled]),textarea:not([disabled]),input:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'

export function Dialog({
  open,
  onClose,
  title,
  description,
  icon,
  tone = 'accent',
  children,
  footer,
  width = 480,
  onSubmit
}: {
  open: boolean
  onClose: () => void
  title: ReactNode
  description?: ReactNode
  icon?: ReactNode
  tone?: Tone
  children?: ReactNode
  footer?: ReactNode
  width?: number
  /** Called on Ctrl/Cmd+Enter. */
  onSubmit?: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const titleId = useId()
  const descId = useId()
  const onCloseRef = useRef(onClose)
  const onSubmitRef = useRef(onSubmit)
  onCloseRef.current = onClose
  onSubmitRef.current = onSubmit

  useEffect(() => {
    if (!open) return
    const opener = document.activeElement as HTMLElement | null
    const raf = requestAnimationFrame(() => {
      const el = ref.current
      if (!el) return
      const target = el.querySelector<HTMLElement>('[data-autofocus]') ?? el.querySelector<HTMLElement>('textarea,input,select') ?? el.querySelector<HTMLElement>('button:not([aria-label="Close"])')
      target?.focus()
    })
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        e.preventDefault()
        onCloseRef.current()
      } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && onSubmitRef.current) {
        e.preventDefault()
        e.stopPropagation()
        onSubmitRef.current()
      } else if (e.key === 'Tab' && ref.current) {
        const f = [...ref.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((n) => n.offsetParent !== null)
        if (!f.length) return
        const first = f[0]
        const last = f[f.length - 1]
        const active = document.activeElement
        if (e.shiftKey && (active === first || !ref.current.contains(active))) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && (active === last || !ref.current.contains(active))) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    // Capture phase on window: runs before any bubble-phase Escape handler (e.g. Drawer's).
    window.addEventListener('keydown', onKey, true)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('keydown', onKey, true)
      opener?.focus?.()
    }
  }, [open])

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <motion.div
            className="absolute inset-0 bg-black/55 backdrop-blur-[3px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.12 } }}
            onClick={onClose}
          />
          <motion.div
            ref={ref}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={description ? descId : undefined}
            className="glass relative flex max-h-[calc(100vh-48px)] w-full flex-col overflow-hidden rounded-2xl shadow-pop"
            style={{ maxWidth: width, background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
            initial={{ opacity: 0, y: 12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: { duration: 0.22, ease } }}
            exit={{ opacity: 0, y: 6, scale: 0.99, transition: { duration: 0.12 } }}
          >
            <div className="flex items-start gap-3 px-5 pb-3 pt-5">
              {icon && (
                <span
                  className={cn('mt-0.5 grid size-9 shrink-0 place-items-center rounded-xl ring-1')}
                  style={{
                    color: tone === 'accent' ? 'var(--accent)' : tone === 'crit' ? 'var(--crit)' : tone === 'warn' ? 'var(--warn)' : tone === 'good' ? 'var(--good)' : 'var(--ink-2)',
                    background: `color-mix(in oklab, ${tone === 'accent' ? 'var(--accent)' : tone === 'crit' ? 'var(--crit-mark)' : tone === 'warn' ? 'var(--warn)' : tone === 'good' ? 'var(--good)' : 'var(--ink-3)'} 14%, transparent)`,
                    ['--tw-ring-color' as string]: 'var(--line)'
                  }}
                >
                  {icon}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <h2 id={titleId} className="text-[15px] font-semibold tracking-tight">
                  {title}
                </h2>
                {description && (
                  <p id={descId} className="mt-1 text-[12.5px] leading-relaxed text-ink-3">
                    {description}
                  </p>
                )}
              </div>
              <IconButton label="Close" onClick={onClose} className="-mr-1.5 -mt-1 size-7">
                <X className="size-4" />
              </IconButton>
            </div>
            {children && <div className="scroll-thin min-h-0 flex-1 overflow-auto px-5 pb-4">{children}</div>}
            {footer && <div className="flex items-center justify-end gap-2 border-t border-line bg-surface-2/30 px-5 py-3">{footer}</div>}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  )
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  body,
  confirmLabel,
  cancelLabel = 'Cancel',
  danger,
  loading,
  icon,
  tone,
  children
}: {
  open: boolean
  onClose: () => void
  onConfirm: () => void
  title: ReactNode
  body?: ReactNode
  confirmLabel: string
  cancelLabel?: string
  danger?: boolean
  loading?: boolean
  icon?: ReactNode
  tone?: Tone
  children?: ReactNode
}) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={title}
      description={body}
      icon={icon}
      tone={tone ?? (danger ? 'crit' : 'accent')}
      width={440}
      onSubmit={onConfirm}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} {...(danger ? { 'data-autofocus': true } : {})}>
            {cancelLabel}
          </Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={loading} {...(danger || children ? {} : { 'data-autofocus': true })}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      {children}
    </Dialog>
  )
}
