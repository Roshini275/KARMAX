import { useCallback, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, OctagonX, Info, X } from 'lucide-react'
import { IconButton } from '@/design/primitives'
import { spring } from '@/design/motion'

export interface ToastInput {
  tone: 'good' | 'crit' | 'muted'
  title: string
  body?: string
  /** ms before auto-dismiss (errors linger). */
  ttl?: number
}
interface ToastItem extends ToastInput {
  id: number
}

const iconFor = { good: <Check className="size-3.5" strokeWidth={3} />, crit: <OctagonX className="size-3.5" strokeWidth={2.5} />, muted: <Info className="size-3.5" /> }
const colorFor = { good: 'var(--good)', crit: 'var(--crit)', muted: 'var(--ink-2)' }

/** Tiny toast host: `const { push, node } = useToasts()`, render `{node}` once in the page. */
export function useToasts(): { push: (t: ToastInput) => void; node: ReactNode } {
  const [items, setItems] = useState<ToastItem[]>([])
  const next = useRef(1)
  const dismiss = useCallback((id: number) => setItems((xs) => xs.filter((x) => x.id !== id)), [])
  const push = useCallback(
    (t: ToastInput) => {
      const id = next.current++
      setItems((xs) => [...xs.slice(-3), { ...t, id }])
      window.setTimeout(() => dismiss(id), t.ttl ?? (t.tone === 'crit' ? 8000 : 4200))
    },
    [dismiss]
  )
  const node = createPortal(
    <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex w-[340px] max-w-[calc(100vw-32px)] flex-col gap-2" role="status" aria-live="polite">
      <AnimatePresence initial={false}>
        {items.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: 12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: spring }}
            exit={{ opacity: 0, x: 24, transition: { duration: 0.14 } }}
            className="glass pointer-events-auto flex items-start gap-3 rounded-xl px-3.5 py-3 shadow-pop"
            style={{ background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
          >
            <span
              className="mt-px grid size-6 shrink-0 place-items-center rounded-full"
              style={{ color: colorFor[t.tone], background: `color-mix(in oklab, ${colorFor[t.tone]} 16%, transparent)` }}
            >
              {iconFor[t.tone]}
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-semibold leading-tight">{t.title}</div>
              {t.body && <div className="selectable mt-0.5 break-words text-[12px] leading-snug text-ink-3">{t.body}</div>}
            </div>
            <IconButton label="Dismiss" onClick={() => dismiss(t.id)} className="-mr-1.5 -mt-1 size-6">
              <X className="size-3.5" />
            </IconButton>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>,
    document.body
  )
  return { push, node }
}
