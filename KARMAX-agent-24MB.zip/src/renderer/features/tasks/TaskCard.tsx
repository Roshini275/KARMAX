import { memo } from 'react'
import { motion } from 'framer-motion'
import { MessageSquare } from 'lucide-react'
import { cn } from '@/design/cn'
import { StatusDot, toneVar } from '@/design/status'
import { spring } from '@/design/motion'
import { timeAgo, truncate } from '@/lib/format'
import type { Task } from '@/lib/api/schemas'
import { columnById, columnOf, shortId } from './taskModel'

const MAX_PIPS = 10

export const TaskCard = memo(function TaskCard({ task, now, active, onOpen, delegated }: { task: Task; now: number; active: boolean; onOpen: (id: string) => void; delegated?: boolean }) {
  const col = columnById[columnOf(task.status)]
  const Icon = col.icon
  const working = col.id === 'working'
  const blocked = col.id === 'blocked'
  const tone = toneVar[col.tone]
  const rounds = Math.max(0, task.rounds)
  const firstErrLine = task.last_error?.split('\n')[0]

  return (
    <motion.button
      layout="position"
      layoutId={`task-${task.task_id}`}
      transition={spring}
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97, transition: { duration: 0.12 } }}
      onClick={() => onOpen(task.task_id)}
      aria-label={`${task.title || task.task_id}. ${col.title}. Updated ${timeAgo(task.updated, now)}`}
      aria-current={active || undefined}
      className={cn(
        'app-no-drag group relative w-full overflow-hidden rounded-xl border p-3 text-left transition-[background,border-color,box-shadow] duration-150',
        'bg-[color-mix(in_oklab,var(--surface)_86%,transparent)] hover:bg-surface-2 hover:border-line-strong',
        active ? 'border-[color-mix(in_oklab,var(--accent)_60%,transparent)] shadow-[var(--glow-accent)]' : 'border-line',
        blocked && !active && 'border-[color-mix(in_oklab,var(--warn)_38%,transparent)]'
      )}
    >
      {/* live edge for running tasks */}
      {working && (
        <span className="pointer-events-none absolute inset-x-0 top-0 h-px overflow-hidden" aria-hidden>
          <motion.span
            className="block h-px w-1/3"
            style={{ background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }}
            animate={{ x: ['-100%', '320%'] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'linear' }}
          />
        </span>
      )}
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-1.5">
          <span
            className="grid size-[18px] shrink-0 place-items-center rounded-full"
            style={{ color: tone, background: `color-mix(in oklab, ${tone} 15%, transparent)` }}
            title={col.title}
            aria-hidden
          >
            <Icon className="size-[11px]" strokeWidth={2.6} />
          </span>
          <span className="truncate font-[family-name:var(--font-mono)] text-[11px] text-ink-3" title={task.task_id}>
            {shortId(task.task_id)}
          </span>
        </div>
        <span className="tnum shrink-0 text-[11px] text-ink-3" title={task.updated ? new Date(task.updated).toLocaleString() : undefined}>
          {timeAgo(task.updated, now)}
        </span>
      </div>

      <div className="mt-2 line-clamp-2 text-[13px] font-medium leading-snug text-ink">{task.title || 'Untitled task'}</div>

      <div className="mt-2.5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2" title={`${rounds} round${rounds === 1 ? '' : 's'}`}>
          <span className="flex items-center gap-[3px]" aria-hidden>
            {rounds === 0 ? (
              <span className="size-[5px] rounded-full border border-ink-3/70" />
            ) : (
              Array.from({ length: Math.min(rounds, MAX_PIPS) }).map((_, i) => {
                const last = i === Math.min(rounds, MAX_PIPS) - 1
                return <span key={i} className={cn('size-[5px] rounded-full', working && last ? 'bg-accent shadow-[0_0_6px_var(--accent)]' : 'bg-ink-3')} />
              })
            )}
            {rounds > MAX_PIPS && <span className="tnum ml-0.5 text-[10px] text-ink-3">+{rounds - MAX_PIPS}</span>}
          </span>
          <span className="tnum text-[11px] text-ink-3">{rounds === 0 ? 'not started' : `${rounds} round${rounds === 1 ? '' : 's'}`}</span>
        </div>
        {working && (
          <span className="flex items-center gap-1.5 text-[11px] font-medium text-accent" title={delegated ? 'A Claude Code / Codex run is attached' : undefined}>
            <StatusDot tone="accent" pulse size={6} />
            Working
          </span>
        )}
        {blocked && <span className="text-[11px] font-semibold text-warn">Your call</span>}
      </div>

      {task.last_told_operator && (
        <div className="mt-2.5 flex gap-1.5 rounded-lg bg-surface-2/70 px-2 py-1.5 text-[11.5px] leading-snug text-ink-2">
          <MessageSquare className="mt-[2px] size-3 shrink-0 text-ink-3" aria-label="Last told the operator" />
          <span className="line-clamp-2">{truncate(task.last_told_operator, 160)}</span>
        </div>
      )}
      {firstErrLine && (
        <div className="mt-2 flex gap-1.5 rounded-lg px-2 py-1.5 font-[family-name:var(--font-mono)] text-[10.5px] leading-snug text-crit" style={{ background: 'color-mix(in oklab, var(--crit-mark) 10%, transparent)' }}>
          <span className="shrink-0 font-sans font-bold uppercase tracking-wide">Err</span>
          <span className="line-clamp-2 break-all">{truncate(firstErrLine, 140)}</span>
        </div>
      )}
    </motion.button>
  )
})
