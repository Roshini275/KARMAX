/**
 * Task board model. Contract (verified in KARMAX/internal/runtime/tasktools.go): task.list returns
 * {task_id, title, status, rounds, updated, last_error?, last_told_operator?} where status is one of
 * open (queued) / working / blocked (needs the operator; resumes when set back to working) / done / failed.
 */
import { useEffect, useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Activity, Check, Clock, OctagonX, TriangleAlert, type LucideIcon } from 'lucide-react'
import { api } from '@/lib/api/client'
import type { Task } from '@/lib/api/schemas'
import type { Tone } from '@/design/status'

export type ColumnId = 'open' | 'working' | 'blocked' | 'done' | 'failed'
export type TaskList = Awaited<ReturnType<typeof api.tasks.list>>

export interface ColumnDef {
  id: ColumnId
  title: string
  short: string
  tone: Tone
  icon: LucideIcon
  empty: string
}

export const COLUMNS: ColumnDef[] = [
  { id: 'open', title: 'Queued', short: 'Queued', tone: 'muted', icon: Clock, empty: 'Nothing is waiting to start.' },
  { id: 'working', title: 'Running', short: 'Running', tone: 'accent', icon: Activity, empty: 'No task is being worked on right now.' },
  { id: 'blocked', title: 'Needs you', short: 'Needs you', tone: 'warn', icon: TriangleAlert, empty: 'Nothing is waiting on you.' },
  { id: 'done', title: 'Done', short: 'Done', tone: 'good', icon: Check, empty: 'Finished tasks land here.' },
  { id: 'failed', title: 'Failed', short: 'Failed', tone: 'crit', icon: OctagonX, empty: 'No failures. Nice.' }
]
export const columnById = Object.fromEntries(COLUMNS.map((c) => [c.id, c])) as Record<ColumnId, ColumnDef>

/** Statuses the daemon may add later fall back sensibly instead of vanishing from the board. */
export function columnOf(status: string): ColumnId {
  switch (status) {
    case 'working':
    case 'running':
    case 'in_progress':
      return 'working'
    case 'blocked':
      return 'blocked'
    case 'done':
    case 'completed':
      return 'done'
    case 'failed':
    case 'cancelled':
    case 'canceled':
      return 'failed'
    default:
      return 'open'
  }
}

export const shortId = (id: string) => (id.length > 14 ? `${id.slice(0, 13)}…` : id)
export const updatedMs = (t: Task) => (t.updated ? Date.parse(t.updated) || 0 : 0)
export const byUpdatedDesc = (a: Task, b: Task) => updatedMs(b) - updatedMs(a)

/** Delegations for generic tasks record `session_id = "task:<task_id>"`; LYZN tasks use `lyzn:<id>`. */
export function sessionMatchesTask(sessionId: string, taskId: string): boolean {
  return sessionId === `task:${taskId}` || sessionId === `lyzn:${taskId}`
}

export function taskIdFromSession(sessionId: string): string | null {
  const m = /^(?:task|lyzn):(.+)$/.exec(sessionId)
  return m ? m[1] : null
}

export function matchesSearch(t: Task, q: string): boolean {
  if (!q) return true
  const s = q.toLowerCase()
  return [t.task_id, t.title, t.last_told_operator, t.last_error].some((v) => !!v && v.toLowerCase().includes(s))
}

/** Re-render on an interval so "3m ago" stays true without a refetch. */
export function useNow(ms = 15_000): number {
  const [n, setN] = useState(() => Date.now())
  useEffect(() => {
    const t = setInterval(() => setN(Date.now()), ms)
    return () => clearInterval(t)
  }, [ms])
  return n
}

export type UpdateVars = { task_id: string; status: 'working' | 'blocked' | 'done' | 'failed'; note?: string }

/**
 * task.update with an optimistic cache write (every ['tasks', …] query), rollback on error and invalidation on settle.
 */
export function useUpdateTask() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (v: UpdateVars) => api.tasks.update(v),
    onMutate: async (v) => {
      await qc.cancelQueries({ queryKey: ['tasks'] })
      const snapshot = qc.getQueriesData<TaskList>({ queryKey: ['tasks'] })
      const now = new Date().toISOString()
      qc.setQueriesData<TaskList>({ queryKey: ['tasks'] }, (old) =>
        old ? { ...old, tasks: old.tasks.map((t) => (t.task_id === v.task_id ? { ...t, status: v.status, updated: now } : t)) } : old
      )
      return { snapshot }
    },
    onError: (_e, _v, ctx) => {
      ctx?.snapshot.forEach(([key, data]) => qc.setQueryData(key, data))
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: ['tasks'] })
    }
  })
}

export const actionCopy: Record<UpdateVars['status'], { title: string; verb: string; body: string; notePlaceholder: string; danger?: boolean }> = {
  working: {
    title: 'Resume this task',
    verb: 'Resume',
    body: 'Sets the task back to working so KARMAX picks it up again on its next round. Blocked tasks stay untouched until someone does this.',
    notePlaceholder: 'Optional: what did you decide? Recorded for the next round to read.'
  },
  blocked: { title: 'Block this task', verb: 'Block', body: 'Pauses the task until you resume it.', notePlaceholder: 'Optional: why is it blocked?' },
  done: {
    title: 'Mark as done',
    verb: 'Mark done',
    body: 'Closes the task. KARMAX stops working on it.',
    notePlaceholder: 'Optional: anything the record should say?'
  },
  failed: {
    title: 'Mark as failed',
    verb: 'Mark failed',
    body: 'Cancels the task and records it as failed. KARMAX stops working on it.',
    notePlaceholder: 'Optional: why are you stopping it?',
    danger: true
  }
}
