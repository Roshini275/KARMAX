import { useEffect, useState } from 'react'
import { Plus } from 'lucide-react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Button, ErrorNote, Input, Kbd, Textarea } from '@/design/primitives'
import { api } from '@/lib/api/client'
import { Dialog } from './ui/Dialog'

export function NewTaskDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (t: { task_id: string; title: string; warning?: string }) => void }) {
  const qc = useQueryClient()
  const [goal, setGoal] = useState('')
  const [title, setTitle] = useState('')
  const [workdir, setWorkdir] = useState('')
  const [minutes, setMinutes] = useState('')

  useEffect(() => {
    if (open) {
      setGoal('')
      setTitle('')
      setWorkdir('')
      setMinutes('')
      create.reset()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const create = useMutation({
    mutationFn: () => {
      const m = minutes.trim() === '' ? undefined : Number(minutes)
      return api.tasks.create({
        goal: goal.trim(),
        title: title.trim() || undefined,
        workdir: workdir.trim() || undefined,
        start_in_minutes: m != null && Number.isFinite(m) && m > 0 ? m : undefined
      })
    },
    onSuccess: async (out) => {
      await qc.invalidateQueries({ queryKey: ['tasks'] })
      onCreated({ task_id: out.task_id, title: out.title, warning: out.warning })
      onClose()
    }
  })

  const minutesInvalid = minutes.trim() !== '' && (!Number.isFinite(Number(minutes)) || Number(minutes) < 0)
  const canSubmit = goal.trim().length > 0 && !minutesInvalid && !create.isPending
  const submit = () => canSubmit && create.mutate()

  return (
    <Dialog
      open={open}
      onClose={onClose}
      icon={<Plus className="size-[18px]" />}
      title="New task"
      description="KARMAX takes ownership: it works the task in its own session, retries its own failures, and messages the operator when it is done or stuck."
      width={540}
      onSubmit={submit}
      footer={
        <>
          <span className="mr-auto hidden items-center gap-1 text-[11.5px] text-ink-3 sm:flex">
            <Kbd>Ctrl</Kbd>
            <Kbd>Enter</Kbd> to create
          </span>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" onClick={submit} disabled={!canSubmit} loading={create.isPending}>
            Create task
          </Button>
        </>
      }
    >
      <div className="space-y-3.5">
        <Field label="Goal" hint="What must be true for this to be finished. Include repo, names, constraints and acceptance criteria: the task session starts from this, not from your conversation.">
          <Textarea data-autofocus rows={5} value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="e.g. Migrate billing/ to the new Stripe API behind FEATURE_STRIPE_V2, keep the tests green, and open a PR." />
        </Field>
        <Field label="Title" hint="Optional. Defaults to the first line of the goal.">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Short label for lists" />
        </Field>
        <div className="grid grid-cols-[1fr_140px] gap-3 max-[520px]:grid-cols-1">
          <Field label="Working directory" hint="Optional. e.g. a repo checkout.">
            <Input value={workdir} onChange={(e) => setWorkdir(e.target.value)} placeholder="C:\Users\you\code\lyzn" className="font-[family-name:var(--font-mono)] text-[12px]" />
          </Field>
          <Field label="Start in (min)" hint="Optional delay.">
            <Input inputMode="numeric" value={minutes} onChange={(e) => setMinutes(e.target.value)} placeholder="now" aria-invalid={minutesInvalid} className="tnum" />
          </Field>
        </div>
        {create.isError && <ErrorNote error={create.error} />}
      </div>
    </Dialog>
  )
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[12px] font-semibold text-ink-2">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[11.5px] leading-snug text-ink-3">{hint}</span>}
    </label>
  )
}
