import { useCallback, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { AlertTriangle, Check, Copy, ExternalLink, FileText, MessageSquare, OctagonX, Play, ScrollText, Wrench } from 'lucide-react'
import { Drawer } from '@/design/Drawer'
import { Button, ErrorNote, Skeleton, Textarea } from '@/design/primitives'
import { StatusPill, StatusDot } from '@/design/status'
import { cn } from '@/design/cn'
import { ApiError, api } from '@/lib/api/client'
import { useActivity } from '@/lib/api/hooks'
import type { HistoryMessage, Task } from '@/lib/api/schemas'
import { formatClock, timeAgo } from '@/lib/format'
import { LevelBadge } from '../logs/LevelBadge'
import { useLogStream, type LogEntry } from '../logs/useLogStream'
import { SessionPill, toolIcon, toolLabel } from './delegation'
import { ConfirmDialog } from './ui/Dialog'
import { actionCopy, columnById, columnOf, sessionMatchesTask, useNow, useUpdateTask, type UpdateVars } from './taskModel'
import type { ToastInput } from './ui/Toast'

export function TaskDrawer({ taskId, task, loading, listError, onClose, toast }: { taskId: string | null; task: Task | undefined; loading: boolean; listError: boolean; onClose: () => void; toast: (t: ToastInput) => void }) {
  // Keep the last task on screen while the drawer animates out.
  const lastTask = useRef<Task | undefined>(undefined)
  const lastId = useRef<string | null>(null)
  if (task) lastTask.current = task
  if (taskId) lastId.current = taskId
  const shown = task ?? (taskId && lastTask.current?.task_id === taskId ? lastTask.current : undefined)
  const id = taskId ?? lastId.current

  const col = shown ? columnById[columnOf(shown.status)] : undefined
  const now = useNow(10_000)

  // Portalled to <body>: the shell's top bar (z-20) would otherwise paint over the drawer's header.
  return createPortal(
    <Drawer
      open={!!taskId}
      onClose={onClose}
      width={580}
      title={shown ? shown.title || 'Untitled task' : id ? `Task ${id}` : 'Task'}
      subtitle={
        shown ? (
          <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-[family-name:var(--font-mono)]">{shown.task_id}</span>
            {col && <StatusPill tone={col.tone} label={col.title} icon={<col.icon className="size-3" strokeWidth={2.6} />} />}
            <span>updated {timeAgo(shown.updated, now)}</span>
          </span>
        ) : undefined
      }
      footer={shown && <Actions task={shown} toast={toast} />}
    >
      {shown ? (
        <Body task={shown} now={now} />
      ) : loading ? (
        <div className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-28 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-line-strong px-4 py-8 text-center text-[13px] text-ink-3">
          {listError ? 'Could not load tasks from the daemon.' : `No task ${id ?? ''} in the latest 100 tasks the daemon returned. It may be older, or it was removed.`}
        </div>
      )}
    </Drawer>,
    document.body
  )
}

/* ── body ─────────────────────────────────────────────────────────────────── */

function Body({ task, now }: { task: Task; now: number }) {
  const col = columnById[columnOf(task.status)]
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(task.task_id)
      setCopied(true)
      setTimeout(() => setCopied(false), 1400)
    } catch {
      /* clipboard unavailable */
    }
  }
  return (
    <div className="space-y-5 pb-2">
      {/* key facts */}
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line text-[12.5px]">
        <Fact label="Task ID">
          <span className="flex items-center gap-1.5">
            <span className="selectable min-w-0 truncate font-[family-name:var(--font-mono)]">{task.task_id}</span>
            <button onClick={() => void copy()} aria-label="Copy task id" className="app-no-drag grid size-5 shrink-0 place-items-center rounded text-ink-3 hover:bg-surface-3 hover:text-ink">
              {copied ? <Check className="size-3 text-good" /> : <Copy className="size-3" />}
            </button>
          </span>
        </Fact>
        <Fact label="Status">
          <StatusPill tone={col.tone} label={col.title} icon={<col.icon className="size-3" strokeWidth={2.6} />} />
        </Fact>
        <Fact label="Rounds">
          <span className="tnum font-medium">{task.rounds}</span>
          <span className="ml-1.5 text-ink-3">{task.rounds === 1 ? 'work session so far' : 'work sessions so far'}</span>
        </Fact>
        <Fact label="Last update">
          <span className="tnum" title={task.updated}>
            {timeAgo(task.updated, now)}
          </span>
          {task.updated && <span className="tnum ml-1.5 text-ink-3">{new Date(task.updated).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>}
        </Fact>
      </dl>

      {task.last_error && (
        <Section icon={<AlertTriangle className="size-3.5" />} title="Last error" tone="crit">
          <pre className="selectable scroll-thin max-h-44 overflow-auto whitespace-pre-wrap break-words rounded-xl px-3.5 py-3 font-[family-name:var(--font-mono)] text-[11.5px] leading-relaxed text-crit" style={{ background: 'color-mix(in oklab, var(--crit-mark) 10%, transparent)', boxShadow: 'inset 0 0 0 1px color-mix(in oklab, var(--crit-mark) 30%, transparent)' }}>
            {task.last_error}
          </pre>
        </Section>
      )}

      <Section icon={<MessageSquare className="size-3.5" />} title="Told the operator" hint="The last update KARMAX sent about this task.">
        {task.last_told_operator ? (
          <div className="relative rounded-2xl rounded-tl-md border border-line bg-surface-2/70 px-4 py-3">
            <p className="selectable whitespace-pre-wrap break-words text-[13px] leading-relaxed text-ink">{task.last_told_operator}</p>
          </div>
        ) : (
          <Note>KARMAX hasn't sent the operator anything about this task yet.</Note>
        )}
      </Section>

      <Delegation taskId={task.task_id} now={now} />
      <RelatedLogs taskId={task.task_id} />
      <Transcript taskId={task.task_id} />
    </div>
  )
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="bg-[color-mix(in_oklab,var(--panel)_96%,transparent)] px-3.5 py-2.5">
      <dt className="label-micro mb-1">{label}</dt>
      <dd className="min-w-0">{children}</dd>
    </div>
  )
}

function Section({ icon, title, hint, right, tone, children }: { icon: React.ReactNode; title: string; hint?: string; right?: React.ReactNode; tone?: 'crit'; children: React.ReactNode }) {
  return (
    <section>
      <div className="mb-2 flex items-center justify-between gap-3">
        <h3 className={cn('flex items-center gap-1.5 text-[12px] font-semibold', tone === 'crit' ? 'text-crit' : 'text-ink-2')}>
          <span className={tone === 'crit' ? 'text-crit' : 'text-ink-3'}>{icon}</span>
          {title}
          {hint && <span className="ml-1 font-normal text-ink-3">{hint}</span>}
        </h3>
        {right}
      </div>
      {children}
    </section>
  )
}

function Note({ children }: { children: React.ReactNode }) {
  return <div className="rounded-xl border border-dashed border-line-strong px-3.5 py-3 text-[12.5px] leading-relaxed text-ink-3">{children}</div>
}

/* ── delegation ───────────────────────────────────────────────────────────── */

function Delegation({ taskId, now }: { taskId: string; now: number }) {
  const act = useActivity()
  const matches = (act.data?.coding_sessions ?? []).filter((s) => sessionMatchesTask(s.session_id, taskId))
  return (
    <Section icon={<Wrench className="size-3.5" />} title="Related delegation" hint="Claude Code / Codex run for this task">
      {act.isPending ? (
        <Skeleton className="h-14 w-full rounded-xl" />
      ) : act.isError ? (
        <Note>Couldn't read delegations: {act.error instanceof Error ? act.error.message : 'unknown error'}</Note>
      ) : matches.length === 0 ? (
        <Note>
          No coding session is linked to this task. Delegations record <code className="rounded bg-surface-3 px-1 font-[family-name:var(--font-mono)] text-[11.5px]">task:{taskId}</code> as their session, so a run appears here as soon as KARMAX starts one.
        </Note>
      ) : (
        <ul className="space-y-2">
          {matches.map((s) => {
            const Icon = toolIcon(s.tool)
            return (
              <li key={s.id} className="flex items-start gap-3 rounded-xl border border-line bg-surface-2/60 px-3.5 py-3">
                <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-surface-3 text-ink-2">
                  <Icon className="size-4" aria-hidden />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[12.5px] font-semibold">{toolLabel(s.tool)}</span>
                    <SessionPill status={s.status} />
                  </div>
                  <div className="mt-0.5 text-[12.5px] leading-snug text-ink-2">{s.description}</div>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-ink-3">
                    <span className="font-[family-name:var(--font-mono)]">{s.session_id}</span>
                    <span>·</span>
                    <span className="tnum">{timeAgo(s.updated_at, now)}</span>
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}
    </Section>
  )
}

/* ── related logs ─────────────────────────────────────────────────────────── */

function RelatedLogs({ taskId }: { taskId: string }) {
  const match = useCallback((l: LogEntry) => l.message.includes(taskId), [taskId])
  const { lines, status } = useLogStream({ match, tail: 60 })
  const newest = [...lines].reverse()
  return (
    <Section
      icon={<ScrollText className="size-3.5" />}
      title="Related logs"
      hint="Live, lines that mention this task id"
      right={
        <Link to={`/logs?q=${encodeURIComponent(taskId)}`} className="app-no-drag flex items-center gap-1 text-[11.5px] font-medium text-accent hover:underline">
          Open in Logs <ExternalLink className="size-3" />
        </Link>
      }
    >
      {newest.length === 0 ? (
        <Note>{status === 'loading' ? 'Loading log history…' : `No recent log line mentions ${taskId}. The console keeps the latest 20,000 lines.`}</Note>
      ) : (
        <div className="overflow-hidden rounded-xl border border-line bg-[color-mix(in_oklab,var(--surface)_70%,transparent)]">
          <div className="flex items-center justify-between border-b border-line px-3 py-1.5 text-[11px] text-ink-3">
            <span className="flex items-center gap-1.5">
              <StatusDot tone="good" pulse size={6} /> live · newest first
            </span>
            <span className="tnum">{lines.length} line{lines.length === 1 ? '' : 's'}</span>
          </div>
          <ul className="scroll-thin max-h-64 divide-y divide-line/60 overflow-auto font-[family-name:var(--font-mono)] text-[11px] leading-snug">
            {newest.map((l) => (
              <li key={l.id} className="grid grid-cols-[62px_44px_minmax(0,1fr)] items-start gap-x-2 px-3 py-1.5">
                <time className="tnum pt-px text-ink-3" dateTime={l.ts}>
                  {formatClock(l.t)}
                </time>
                <LevelBadge level={l.level} className="pt-px" />
                <span className="selectable line-clamp-3 break-words whitespace-pre-wrap text-ink">{l.message}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Section>
  )
}

/* ── transcript (LYZN only) ───────────────────────────────────────────────── */

function Transcript({ taskId }: { taskId: string }) {
  const q = useQuery({
    queryKey: ['task-transcript', taskId],
    queryFn: () => api.tasks.lyznTranscript(taskId),
    retry: false,
    staleTime: 4000,
    // Poll only while the daemon says the task's own claude_code call is running.
    refetchInterval: (query) => (query.state.data?.live ? 2500 : false)
  })
  const none = q.isError && q.error instanceof ApiError && q.error.status === 404
  const live = !!q.data?.live
  const bottom = useRef<HTMLDivElement>(null)
  const count = q.data?.messages.length ?? 0
  useEffect(() => {
    if (live) bottom.current?.scrollIntoView({ block: 'nearest' })
  }, [live, count])

  return (
    <Section
      icon={<FileText className="size-3.5" />}
      title="Transcript"
      hint="LYZN tasks only"
      right={
        live ? (
          <span className="flex items-center gap-1.5 text-[11px] font-medium text-accent">
            <StatusDot tone="accent" pulse size={6} /> Live · refreshing
          </span>
        ) : undefined
      }
    >
      {q.isPending ? (
        <Skeleton className="h-16 w-full rounded-xl" />
      ) : none ? (
        <Note>
          No transcript. The daemon only keeps a readable transcript for LYZN tasks (<code className="rounded bg-surface-3 px-1 font-[family-name:var(--font-mono)] text-[11.5px]">lyzn:&lt;id&gt;</code> sessions, and only once their first turn has finished). Other tasks run in a Claude Code session: use the delegation and logs above.
        </Note>
      ) : q.isError ? (
        <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
      ) : count === 0 ? (
        <Note>The transcript is empty so far.</Note>
      ) : (
        <div className="scroll-thin max-h-[380px] space-y-2.5 overflow-auto rounded-xl border border-line bg-[color-mix(in_oklab,var(--surface)_70%,transparent)] p-3">
          {q.data!.messages.map((m, i) => (
            <Message key={i} m={m} />
          ))}
          <div ref={bottom} />
        </div>
      )}
    </Section>
  )
}

function Message({ m }: { m: HistoryMessage }) {
  const user = m.role === 'user'
  return (
    <div className={cn('rounded-xl px-3 py-2.5', user ? 'bg-surface-2' : 'bg-transparent ring-1 ring-line')}>
      <div className="mb-1 flex items-center justify-between text-[10.5px] font-semibold uppercase tracking-wider text-ink-3">
        <span>{user ? 'Prompt' : 'Claude'}</span>
        {m.at && <span className="tnum font-normal normal-case tracking-normal">{formatClock(m.at)}</span>}
      </div>
      {m.text && <p className="selectable whitespace-pre-wrap break-words text-[12.5px] leading-relaxed text-ink">{m.text}</p>}
      {m.toolCalls.length > 0 && (
        <ul className="mt-2 flex flex-wrap gap-1.5">
          {m.toolCalls.map((t) => (
            <li key={t.id} className="inline-flex max-w-full items-center gap-1.5 rounded-md bg-surface-3 px-2 py-0.5 text-[11px] text-ink-2" title={t.output}>
              <Wrench className="size-3 shrink-0 text-ink-3" aria-hidden />
              <span className="truncate">{t.title || t.kind || 'tool call'}</span>
              <span className="text-ink-3">· {t.status}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

/* ── actions ──────────────────────────────────────────────────────────────── */

function Actions({ task, toast: push }: { task: Task; toast: (t: ToastInput) => void }) {
  const update = useUpdateTask()
  const [pending, setPending] = useState<UpdateVars['status'] | null>(null)
  const [note, setNote] = useState('')
  const colId = columnOf(task.status)
  const closed = colId === 'done' || colId === 'failed'

  const open = (s: UpdateVars['status']) => {
    setNote('')
    setPending(s)
  }
  const confirm = () => {
    if (!pending) return
    const vars: UpdateVars = { task_id: task.task_id, status: pending, note: note.trim() || undefined }
    const cfg = actionCopy[pending]
    setPending(null)
    update.mutate(vars, {
      onSuccess: () => push({ tone: 'good', title: pending === 'working' ? 'Task resumed' : pending === 'done' ? 'Marked done' : 'Marked failed', body: task.title || task.task_id }),
      onError: (e) => push({ tone: 'crit', title: `Couldn't ${cfg.verb.toLowerCase()}. Change rolled back.`, body: e instanceof Error ? e.message : String(e) })
    })
  }

  if (closed) {
    return (
      <p className="text-[12px] text-ink-3">This task is {colId === 'done' ? 'done' : 'closed as failed'}. There is nothing left to act on here.</p>
    )
  }
  const cfg = pending ? actionCopy[pending] : null
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        {colId === 'blocked' && (
          <Button variant="primary" icon={<Play className="size-3.5" />} onClick={() => open('working')} disabled={update.isPending}>
            Unblock &amp; resume
          </Button>
        )}
        <Button variant="subtle" icon={<Check className="size-3.5" />} onClick={() => open('done')} disabled={update.isPending}>
          Mark done
        </Button>
        <Button variant="danger" icon={<OctagonX className="size-3.5" />} onClick={() => open('failed')} disabled={update.isPending} className="ml-auto">
          Mark failed
        </Button>
      </div>
      <ConfirmDialog
        open={!!pending}
        onClose={() => setPending(null)}
        onConfirm={confirm}
        title={cfg?.title ?? ''}
        body={cfg ? `${task.title || task.task_id}. ${cfg.body}` : undefined}
        confirmLabel={cfg?.verb ?? 'Confirm'}
        danger={cfg?.danger}
        icon={pending === 'working' ? <Play className="size-4" /> : pending === 'done' ? <Check className="size-4" strokeWidth={3} /> : <OctagonX className="size-4" />}
        tone={pending === 'done' ? 'good' : pending === 'failed' ? 'crit' : 'accent'}
      >
        <Textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder={cfg?.notePlaceholder} aria-label="Note (optional)" />
      </ConfirmDialog>
    </>
  )
}
