import { memo } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { cn } from '@/design/cn'
import { Skeleton } from '@/design/primitives'
import { timeAgo } from '@/lib/format'
import { SessionPill, toolIcon, toolLabel, type Session } from './delegation'
import { taskIdFromSession } from './taskModel'

/** Recent Claude Code / Codex runs (GET /api/activity → coding_sessions), under the board. */
export const DelegationsStrip = memo(function DelegationsStrip({
  sessions,
  loading,
  error,
  now,
  knownTaskIds,
  onOpenTask
}: {
  sessions: Session[]
  loading: boolean
  error?: string
  now: number
  knownTaskIds: ReadonlySet<string>
  onOpenTask: (id: string) => void
}) {
  const running = sessions.filter((s) => ['running', 'active', 'in_progress', 'working'].includes(s.status.toLowerCase())).length
  return (
    <section aria-label="Delegations" className="shrink-0">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h2 className="text-[13px] font-semibold tracking-tight">
          Delegations
          <span className="tnum ml-2 text-[12px] font-normal text-ink-3">
            {sessions.length} recent{running ? ` · ${running} running` : ''}
          </span>
        </h2>
        <span className="hidden text-[11.5px] text-ink-3 sm:inline">Claude Code and Codex runs KARMAX started</span>
      </div>
      {loading ? (
        <div className="flex gap-2.5">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-[74px] w-[280px] shrink-0 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <div className="rounded-xl border border-line bg-surface/50 px-4 py-3 text-[12.5px] text-ink-3">Couldn't load delegations: {error}</div>
      ) : sessions.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line-strong px-4 py-3.5 text-[12.5px] text-ink-3">No coding sessions yet. When KARMAX hands work to Claude Code or Codex it shows up here.</div>
      ) : (
        <ul className="scroll-thin -mx-1 flex snap-x gap-2.5 overflow-x-auto px-1 pb-1.5">
          {sessions.map((s) => {
            const Icon = toolIcon(s.tool)
            const tid = taskIdFromSession(s.session_id)
            const linked = !!tid && knownTaskIds.has(tid)
            const Tag = linked ? 'button' : 'div'
            return (
              <li key={s.id} className="w-[290px] shrink-0 snap-start">
                <Tag
                  {...(linked ? { onClick: () => onOpenTask(tid!), 'aria-label': `Open task ${tid}` } : {})}
                  className={cn(
                    'app-no-drag group flex h-full w-full flex-col gap-1.5 rounded-xl border border-line bg-[color-mix(in_oklab,var(--surface)_80%,transparent)] p-3 text-left',
                    linked && 'cursor-pointer transition-colors hover:border-line-strong hover:bg-surface-2'
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-1.5 text-[11.5px] font-medium text-ink-2">
                      <Icon className="size-3.5 shrink-0 text-ink-3" aria-hidden />
                      <span className="truncate">{toolLabel(s.tool)}</span>
                    </span>
                    <SessionPill status={s.status} />
                  </div>
                  <div className="line-clamp-2 text-[12.5px] leading-snug text-ink">{s.description || 'No description'}</div>
                  <div className="mt-auto flex items-center justify-between gap-2 text-[11px] text-ink-3">
                    <span className="tnum" title={new Date(s.updated_at).toLocaleString()}>
                      {timeAgo(s.updated_at, now)}
                    </span>
                    {linked && (
                      <span className="flex items-center gap-0.5 font-[family-name:var(--font-mono)] text-ink-3 group-hover:text-accent">
                        {tid}
                        <ArrowUpRight className="size-3" />
                      </span>
                    )}
                  </div>
                </Tag>
              </li>
            )
          })}
        </ul>
      )}
    </section>
  )
})
