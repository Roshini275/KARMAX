import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import { AnimatePresence, LayoutGroup, MotionConfig } from 'framer-motion'
import { Plus, RefreshCw, Search, SquareKanban, X } from 'lucide-react'
import { Button, EmptyState, ErrorNote, Kbd, Page, Skeleton } from '@/design/primitives'
import { StatusDot, toneVar } from '@/design/status'
import { cn } from '@/design/cn'
import { useActivity, useTasks } from '@/lib/api/hooks'
import type { Task } from '@/lib/api/schemas'
import { DelegationsStrip } from './DelegationsStrip'
import { NewTaskDialog } from './NewTaskDialog'
import { TaskCard } from './TaskCard'
import { TaskDrawer } from './TaskDrawer'
import { COLUMNS, byUpdatedDesc, columnOf, matchesSearch, sessionMatchesTask, useNow, type ColumnDef, type ColumnId } from './taskModel'
import { useToasts } from './ui/Toast'

type Filter = ColumnId | 'all'

const isTyping = (t: EventTarget | null) => {
  const el = t as HTMLElement | null
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)
}

export default function TasksPage() {
  const routeId = useParams().taskId ?? null
  const tasksQ = useTasks('all')
  const activity = useActivity()
  const now = useNow(15_000)
  const { push, node: toasts } = useToasts()

  // The drawer is driven by local state (seeded from /tasks/:taskId) and mirrored into the URL with replaceState:
  // navigating through the router would re-key the whole page in the shell and replay its page transition.
  const [openId, setOpenId] = useState<string | null>(routeId)
  useEffect(() => setOpenId(routeId), [routeId])
  const open = useCallback((id: string | null) => {
    setOpenId(id)
    try {
      window.history.replaceState(window.history.state, '', `#/tasks${id ? `/${encodeURIComponent(id)}` : ''}`)
    } catch {
      /* history unavailable */
    }
  }, [])

  const [query, setQuery] = useState('')
  const dq = useDeferredValue(query)
  const [filter, setFilter] = useState<Filter>('all')
  const [creating, setCreating] = useState(false)
  const searchRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('[role="dialog"]')) return
      if (e.key === '/') {
        e.preventDefault()
        searchRef.current?.focus()
      } else if (e.key === 'n') {
        e.preventDefault()
        setCreating(true)
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [])

  const tasks = tasksQ.data?.tasks
  const grouped = useMemo(() => {
    const g: Record<ColumnId, Task[]> = { open: [], working: [], blocked: [], done: [], failed: [] }
    for (const t of tasks ?? []) if (matchesSearch(t, dq.trim())) g[columnOf(t.status)].push(t)
    for (const k of Object.keys(g) as ColumnId[]) g[k].sort(byUpdatedDesc)
    return g
  }, [tasks, dq])
  const totals = useMemo(() => {
    const g: Record<ColumnId, number> = { open: 0, working: 0, blocked: 0, done: 0, failed: 0 }
    for (const t of tasks ?? []) g[columnOf(t.status)]++
    return g
  }, [tasks])

  const sessions = activity.data?.coding_sessions
  const sessionsSorted = useMemo(() => [...(sessions ?? [])].sort((a, b) => Date.parse(b.updated_at) - Date.parse(a.updated_at)).slice(0, 12), [sessions])
  const delegated = useMemo(() => {
    const s = new Set<string>()
    for (const t of tasks ?? []) if ((sessions ?? []).some((x) => x.status && sessionMatchesTask(x.session_id, t.task_id))) s.add(t.task_id)
    return s
  }, [tasks, sessions])
  const knownIds = useMemo(() => new Set((tasks ?? []).map((t) => t.task_id)), [tasks])

  const openTask = tasks?.find((t) => t.task_id === openId)
  const visibleCols = filter === 'all' ? COLUMNS : COLUMNS.filter((c) => c.id === filter)
  const total = tasks?.length ?? 0
  const needsYou = totals.blocked

  return (
    <MotionConfig reducedMotion="user">
      <Page
        flush
        title="Tasks"
        subtitle={
          tasksQ.data ? `${totals.working} running · ${needsYou} need you · ${totals.open} queued · ${totals.done} done` : 'What KARMAX is working on, and what it finished'
        }
        actions={
          <>
            {tasksQ.isFetching && !tasksQ.isPending && <RefreshCw className="size-3.5 animate-[km-spin_1s_linear_infinite] text-ink-3" aria-label="Refreshing" />}
            <Button variant="primary" icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
              New task
              <Kbd>N</Kbd>
            </Button>
          </>
        }
      >
        <div className="flex h-full min-h-[640px] flex-col gap-3.5 px-7 pb-5">
          {/* filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative w-[280px] max-w-full">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setQuery('')
                    ;(e.target as HTMLInputElement).blur()
                  }
                }}
                placeholder="Search tasks"
                aria-label="Search tasks"
                className="selectable h-8 w-full rounded-lg border border-line bg-surface-2/70 pl-8 pr-8 text-[12.5px] text-ink placeholder:text-ink-3 transition-colors hover:border-line-strong focus:border-accent focus:outline-none focus:ring-2 focus:ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]"
              />
              {query ? (
                <button onClick={() => setQuery('')} aria-label="Clear search" className="absolute right-1.5 top-1/2 grid size-5 -translate-y-1/2 place-items-center rounded text-ink-3 hover:bg-surface-3 hover:text-ink">
                  <X className="size-3.5" />
                </button>
              ) : (
                <span className="absolute right-2 top-1/2 -translate-y-1/2">
                  <Kbd>/</Kbd>
                </span>
              )}
            </div>
            <div role="group" aria-label="Filter by status" className="app-no-drag inline-flex flex-wrap gap-1 rounded-lg bg-surface-2/60 p-0.5 ring-1 ring-line">
              <Chip active={filter === 'all'} onClick={() => setFilter('all')} label="All" count={total} />
              {COLUMNS.map((c) => (
                <Chip key={c.id} active={filter === c.id} onClick={() => setFilter(filter === c.id ? 'all' : c.id)} label={c.short} count={totals[c.id]} tone={c.id === 'blocked' && totals.blocked ? 'warn' : undefined} />
              ))}
            </div>
            <span className="ml-auto hidden text-[11.5px] text-ink-3 lg:inline">Sorted by last update{total >= 100 ? ' · showing the latest 100' : ''}</span>
          </div>

          {tasksQ.isError && <ErrorNote error={tasksQ.error} onRetry={() => void tasksQ.refetch()} />}

          {/* board */}
          <div className="scroll-thin -mx-1 min-h-0 flex-1 overflow-x-auto overflow-y-hidden px-1 pb-1">
            {tasksQ.isPending ? (
              <BoardSkeleton />
            ) : !tasks && tasksQ.isError ? (
              <EmptyState icon={<SquareKanban className="size-5" />} title="Can't load tasks" body="The KARMAX daemon didn't answer. The board fills in automatically once it's reachable." action={<Button onClick={() => void tasksQ.refetch()}>Retry</Button>} />
            ) : total === 0 ? (
              <EmptyState
                icon={<SquareKanban className="size-5" />}
                title="No tasks yet"
                body="Ask KARMAX for something that takes more than one turn, message it from the operator's WhatsApp, or create a task here."
                action={
                  <Button variant="primary" icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
                    New task
                  </Button>
                }
              />
            ) : (
              <LayoutGroup>
                <div
                  className={cn('grid h-full gap-3', filter === 'all' ? 'min-w-[1080px]' : '')}
                  style={{ gridTemplateColumns: filter === 'all' ? 'repeat(5, minmax(210px, 1fr))' : 'minmax(0, 1fr)' }}
                >
                  {visibleCols.map((c) => (
                    <Column key={c.id} col={c} tasks={grouped[c.id]} now={now} openId={openId} delegated={delegated} onOpen={open} wide={filter !== 'all'} searching={!!dq.trim()} total={totals[c.id]} />
                  ))}
                </div>
              </LayoutGroup>
            )}
          </div>

          <DelegationsStrip
            sessions={sessionsSorted}
            loading={activity.isPending}
            error={activity.isError ? (activity.error instanceof Error ? activity.error.message : 'unknown error') : undefined}
            now={now}
            knownTaskIds={knownIds}
            onOpenTask={open}
          />
        </div>
      </Page>

      <TaskDrawer taskId={openId} task={openTask} loading={tasksQ.isPending} listError={tasksQ.isError} onClose={() => open(null)} toast={push} />
      <NewTaskDialog
        open={creating}
        onClose={() => setCreating(false)}
        onCreated={(t) => {
          push({ tone: 'good', title: `Task ${t.task_id} created`, body: t.warning || t.title })
          open(t.task_id)
        }}
      />
      {toasts}
    </MotionConfig>
  )
}

function Chip({ active, onClick, label, count, tone }: { active: boolean; onClick: () => void; label: string; count: number; tone?: 'warn' }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'inline-flex h-7 items-center gap-1.5 rounded-md px-2.5 text-[12px] font-medium transition-colors',
        active ? 'bg-surface-3 text-ink shadow-sm' : 'text-ink-3 hover:text-ink-2'
      )}
    >
      {label}
      <span className={cn('tnum rounded px-1 text-[10.5px] font-semibold', tone === 'warn' ? 'bg-warn text-black' : 'text-ink-3')}>{count}</span>
    </button>
  )
}

function Column({
  col,
  tasks,
  now,
  openId,
  delegated,
  onOpen,
  wide,
  searching,
  total
}: {
  col: ColumnDef
  tasks: Task[]
  now: number
  openId: string | null
  delegated: ReadonlySet<string>
  onOpen: (id: string) => void
  wide: boolean
  searching: boolean
  total: number
}) {
  const Icon = col.icon
  const tone = toneVar[col.tone]
  const needs = col.id === 'blocked'
  const hot = needs && total > 0
  return (
    <section
      aria-label={`${col.title}, ${tasks.length} task${tasks.length === 1 ? '' : 's'}`}
      className={cn('flex min-h-0 flex-col overflow-hidden rounded-2xl border', hot ? 'border-[color-mix(in_oklab,var(--warn)_42%,transparent)]' : 'border-line')}
      style={{
        background: hot
          ? 'linear-gradient(180deg, color-mix(in oklab, var(--warn) 9%, var(--surface)) 0%, color-mix(in oklab, var(--surface) 55%, transparent) 60%)'
          : 'color-mix(in oklab, var(--surface) 46%, transparent)',
        boxShadow: hot ? '0 0 34px -12px color-mix(in oklab, var(--warn) 55%, transparent), inset 0 1px 0 color-mix(in oklab, var(--ink) 5%, transparent)' : 'inset 0 1px 0 color-mix(in oklab, var(--ink) 4%, transparent)'
      }}
    >
      <header className="flex items-center justify-between gap-2 px-3.5 pb-2 pt-3">
        <h2 className="flex items-center gap-2 text-[12.5px] font-semibold tracking-tight">
          <span className="grid size-[22px] place-items-center rounded-md" style={{ color: tone, background: `color-mix(in oklab, ${tone} 16%, transparent)` }} aria-hidden>
            {col.id === 'working' ? <StatusDot tone="accent" pulse size={7} /> : <Icon className="size-3.5" strokeWidth={2.4} />}
          </span>
          <span className={cn(needs && hot && 'text-warn')}>{col.title}</span>
        </h2>
        <span
          className={cn('tnum min-w-[22px] rounded-full px-1.5 text-center text-[11px] font-bold leading-[20px]', needs && hot ? 'bg-warn text-black' : 'bg-surface-3 text-ink-2')}
          aria-label={`${tasks.length} tasks`}
        >
          {tasks.length}
          {searching && tasks.length !== total ? <span className="font-normal text-ink-3">/{total}</span> : null}
        </span>
      </header>
      <div className={cn('scroll-thin min-h-0 flex-1 overflow-y-auto px-2.5 pb-2.5', wide && 'grid content-start gap-2.5 [grid-template-columns:repeat(auto-fill,minmax(260px,1fr))]')}>
        <AnimatePresence initial={false} mode="popLayout">
          {tasks.map((t) => (
            <div key={t.task_id} className={cn(!wide && 'mb-2')}>
              <TaskCard task={t} now={now} active={openId === t.task_id} onOpen={onOpen} delegated={delegated.has(t.task_id)} />
            </div>
          ))}
        </AnimatePresence>
        {tasks.length === 0 && (
          <div className="mx-1 mt-1 rounded-xl border border-dashed border-line px-3 py-6 text-center text-[12px] text-ink-3">{searching ? 'No matches.' : col.empty}</div>
        )}
      </div>
    </section>
  )
}

function BoardSkeleton() {
  return (
    <div className="grid h-full min-w-[1080px] gap-3" style={{ gridTemplateColumns: 'repeat(5, minmax(210px, 1fr))' }}>
      {COLUMNS.map((c, i) => (
        <div key={c.id} className="rounded-2xl border border-line bg-surface/40 p-3">
          <Skeleton className="mb-3 h-5 w-24" />
          <div className="space-y-2.5">
            {Array.from({ length: Math.max(1, 3 - (i % 3)) }).map((_, j) => (
              <Skeleton key={j} className="h-[110px] w-full rounded-xl" />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
