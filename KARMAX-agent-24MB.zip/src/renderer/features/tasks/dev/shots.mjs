// Interaction screenshots for workstream D (tasks / logs / approvals). Not part of the app bundle.
//   node src/renderer/features/tasks/dev/shots.mjs                       -> every scene, dark
//   SCENES=tasks-drawer,logs-paused node .../shots.mjs                    -> some scenes
//   THEME=light W=1100 H=700 OUT=shots/d node .../shots.mjs
// Env: BASE (vite, default :5173) DAEMON WACLI (mock URLs) OUT THEME W H SETTLE
import { chromium } from 'playwright'
import { mkdirSync, existsSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const DAEMON = process.env.DAEMON || 'http://127.0.0.1:9103'
const WACLI = process.env.WACLI || 'http://127.0.0.1:8803'
const OUT = process.env.OUT || 'shots/d'
const THEME = process.env.THEME || 'dark'
const W = Number(process.env.W || 1440)
const H = Number(process.env.H || 900)
const SETTLE = Number(process.env.SETTLE || 1600)
const only = (process.env.SCENES || '').split(',').filter(Boolean)
const tag = `${THEME}${W < 1300 ? `-${W}` : ''}`

function chromePath() {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}

mkdirSync(OUT, { recursive: true })
const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] })
const errors = []

async function fresh(route, { daemon = DAEMON, init } = {}) {
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1, colorScheme: THEME === 'light' ? 'light' : 'dark' })
  await ctx.addInitScript((theme) => { try { localStorage.setItem('km.theme', theme) } catch {} }, THEME)
  const page = await ctx.newPage()
  page.on('pageerror', (e) => errors.push(`[${route}] pageerror: ${e.message}`))
  page.on('console', (m) => m.type() === 'error' && !/status of 404/.test(m.text()) && errors.push(`[${route}] console.error: ${m.text()}`))
  if (init) await init(page, ctx)
  await page.goto(`${BASE}/?daemon=${daemon}&wacli=${WACLI}#${route}`, { waitUntil: 'networkidle' }).catch(() => {})
  await page.waitForTimeout(SETTLE)
  return { page, ctx }
}
const shot = async (page, name) => { await page.screenshot({ path: `${OUT}/${name}-${tag}.png` }); console.log('saved', `${OUT}/${name}-${tag}.png`) }
const scenes = {}
const scene = (name, fn) => (scenes[name] = fn)

/* ── tasks ───────────────────────────────────────────────────────────────── */
scene('tasks-board', async () => {
  const { page, ctx } = await fresh('/tasks')
  await shot(page, 'tasks-board')
  await ctx.close()
})
scene('tasks-drawer', async () => {
  const { page, ctx } = await fresh('/tasks')
  await page.getByRole('button', { name: /Fix flaky CI/ }).click()
  await page.waitForTimeout(900)
  await shot(page, 'tasks-drawer-blocked')
  await page.getByRole('button', { name: /Unblock/ }).click()
  await page.waitForTimeout(500)
  await page.locator('textarea[aria-label="Note (optional)"]').fill('Use windows-2022; the runner image change broke the cache paths.')
  await shot(page, 'tasks-resume-dialog')
  await page.keyboard.press('Escape')
  await page.waitForTimeout(400)
  await page.getByRole('button', { name: /Mark failed/ }).click()
  await page.waitForTimeout(500)
  await shot(page, 'tasks-failed-dialog')
  await ctx.close()
})
scene('tasks-drawer-running', async () => {
  const { page, ctx } = await fresh('/tasks/t-1001')
  await page.waitForTimeout(700)
  await shot(page, 'tasks-drawer-running')
  // scroll the drawer to the bottom to see transcript/logs
  await page.locator('aside[role="dialog"] .scroll-thin').first().evaluate((el) => (el.scrollTop = el.scrollHeight))
  await page.waitForTimeout(400)
  await shot(page, 'tasks-drawer-running-bottom')
  await ctx.close()
})
scene('tasks-drawer-failed', async () => {
  const { page, ctx } = await fresh('/tasks/t-1108')
  await shot(page, 'tasks-drawer-failed')
  await ctx.close()
})
scene('tasks-drawer-lyzn', async () => {
  const transcript = (live) => ({ live, messages: [
    { role: 'user', text: 'LYZN task lyzn-9f2c1a: add referral tracking to the signup flow.\nAcceptance: every signup carries ?ref=, stored on the user row, and emitted as an analytics event.', at: new Date(Date.now() - 6 * 60_000).toISOString(), toolCalls: [] },
    { role: 'assistant', text: 'I read the signup handler. There are two entry points (email and Google). I will thread `ref` through both and add a migration.', at: new Date(Date.now() - 5 * 60_000).toISOString(), toolCalls: [{ id: 'a', title: 'Read signup/handler.go', kind: 'read', status: 'completed', output: '212 lines' }, { id: 'b', title: 'Grep "ref" in analytics/', kind: 'search', status: 'completed', output: '3 matches' }] },
    { role: 'assistant', text: 'Migration written and applied to the dev DB. Running the signup tests now.', at: new Date(Date.now() - 60_000).toISOString(), toolCalls: [{ id: 'c', title: 'go test ./signup/...', kind: 'execute', status: 'in_progress' }] }
  ] })
  const init = async (page) => {
    await page.route('**/api/tasks/lyzn-9f2c1a/transcript', (r) => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(transcript(true)) }))
  }
  const { page, ctx } = await fresh('/tasks/lyzn-9f2c1a', { init })
  await page.locator('aside[role="dialog"] .scroll-thin').first().evaluate((el) => (el.scrollTop = el.scrollHeight))
  await page.waitForTimeout(500)
  await shot(page, 'tasks-drawer-lyzn-transcript')
  await ctx.close()
})
scene('tasks-newtask', async () => {
  const { page, ctx } = await fresh('/tasks')
  await page.keyboard.press('n')
  await page.waitForTimeout(500)
  await page.locator('textarea').first().fill('Migrate the billing service to the new Stripe API behind FEATURE_STRIPE_V2, keep the tests green and open a PR.')
  await page.getByPlaceholder('Short label for lists').fill('Stripe v2 migration')
  await shot(page, 'tasks-newtask')
  await page.keyboard.press('Control+Enter')
  await page.waitForTimeout(1600)
  await shot(page, 'tasks-newtask-created')
  await ctx.close()
})
scene('tasks-filter', async () => {
  const { page, ctx } = await fresh('/tasks')
  await page.getByPlaceholder('Search tasks').fill('stripe')
  await page.waitForTimeout(700)
  await shot(page, 'tasks-search')
  await page.getByPlaceholder('Search tasks').fill('')
  await page.getByRole('button', { name: /^Needs you/ }).first().click()
  await page.waitForTimeout(700)
  await shot(page, 'tasks-filter-needs-you')
  await ctx.close()
})
scene('tasks-rollback', async () => {
  const init = async (page) => {
    await page.route('**/api/tools/task.update', async (r) => { await new Promise((ok) => setTimeout(ok, 900)); r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ tool: 'task.update', ok: false, error: 'store: database is locked' }) }) })
  }
  const { page, ctx } = await fresh('/tasks', { init })
  await page.getByRole('button', { name: /Fix flaky CI/ }).click()
  await page.waitForTimeout(700)
  await page.getByRole('button', { name: /Unblock/ }).click()
  await page.waitForTimeout(400)
  await page.getByRole('dialog').getByRole('button', { name: 'Resume' }).click()
  await page.waitForTimeout(350)
  await shot(page, 'tasks-optimistic') // optimistic: card already moved to Running
  await page.waitForTimeout(1600)
  await shot(page, 'tasks-rolled-back') // rolled back + toast
  await ctx.close()
})
scene('tasks-empty', async () => {
  const { page, ctx } = await fresh('/tasks', { init: async (page) => { await page.route('**/api/tools/task.list', (r) => r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ tool: 'task.list', ok: true, output: { tasks: null, count: 0 } }) })) } })
  await shot(page, 'tasks-empty')
  await ctx.close()
})
scene('tasks-error', async () => {
  const { page, ctx } = await fresh('/tasks', { daemon: 'http://127.0.0.1:1' })
  await page.waitForTimeout(1500)
  await shot(page, 'tasks-error')
  await ctx.close()
})

/* ── logs ────────────────────────────────────────────────────────────────── */
scene('logs-live', async () => {
  const { page, ctx } = await fresh('/logs', { })
  await shot(page, 'logs-live')
  // pause
  await page.keyboard.press('Space')
  await page.waitForTimeout(3500)
  await shot(page, 'logs-paused')
  await page.keyboard.press('Space')
  await ctx.close()
})
scene('logs-filtered', async () => {
  const { page, ctx } = await fresh('/logs')
  await page.getByRole('button', { name: /^karmax/ }).click() // toggle karmax off
  await page.getByLabel('Minimum level').selectOption('warn')
  await page.waitForTimeout(600)
  await shot(page, 'logs-filtered-source-level')
  await ctx.close()
})
scene('logs-loop', async () => {
  const { page, ctx } = await fresh('/logs')
  await page.getByLabel('Loop', { exact: true }).selectOption('gchat-watch')
  await page.waitForTimeout(600)
  await shot(page, 'logs-loop')
  await ctx.close()
})
scene('logs-search', async () => {
  const { page, ctx } = await fresh('/logs')
  await page.keyboard.press('Control+f')
  await page.keyboard.type('t-100')
  await page.waitForTimeout(700)
  await shot(page, 'logs-search-highlight')
  await page.getByRole('button', { name: 'Use regular expression' }).click()
  await page.getByLabel('Search log messages').fill('round \\d+ (complete|failed)')
  await page.waitForTimeout(700)
  await shot(page, 'logs-search-regex')
  await page.getByLabel('Search log messages').fill('round (')
  await page.waitForTimeout(500)
  await shot(page, 'logs-search-invalid')
  await page.keyboard.press('Escape')
  await page.waitForTimeout(300)
  await ctx.close()
})
scene('logs-expand', async () => {
  const { page, ctx } = await fresh('/logs')
  await page.getByLabel('Search log messages').fill('AccessDenied')
  await page.waitForTimeout(600)
  await page.locator('[role="log"] [data-index="0"]').click()
  await page.waitForTimeout(400)
  await shot(page, 'logs-expanded')
  await ctx.close()
})
scene('logs-strip-hover', async () => {
  const { page, ctx } = await fresh('/logs')
  const g = page.getByRole('group', { name: /Activity chart/ })
  const box = await g.boundingBox()
  await page.mouse.move(box.x + box.width * 0.6, box.y + 30)
  await page.waitForTimeout(400)
  await shot(page, 'logs-strip-hover')
  await ctx.close()
})
scene('logs-comfortable-wrap', async () => {
  const { page, ctx } = await fresh('/logs')
  await page.getByRole('button', { name: /Wrap long lines/ }).click()
  await page.getByRole('button', { name: /^Density/ }).click()
  await page.waitForTimeout(800)
  await shot(page, 'logs-wrap-comfortable')
  await ctx.close()
})
scene('logs-empty', async () => {
  const { page, ctx } = await fresh('/logs', { daemon: 'http://127.0.0.1:1' })
  await shot(page, 'logs-empty-unreachable')
  await ctx.close()
})

/* ── approvals ───────────────────────────────────────────────────────────── */
const fulfill = (r, body, status = 200) => r.fulfill({ status, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(body) })
scene('approvals-pending', async () => {
  const { page, ctx } = await fresh('/approvals')
  await shot(page, 'approvals-pending')
  await page.evaluate(() => document.querySelector('.scroll-thin.min-h-0')?.scrollTo(0, 99999))
  await page.waitForTimeout(300)
  await shot(page, 'approvals-pending-scrolled')
  await ctx.close()
})
scene('approvals-decided', async () => {
  const { page, ctx } = await fresh('/approvals')
  await page.getByRole('tab', { name: /Decided/ }).click()
  await page.waitForTimeout(700)
  await shot(page, 'approvals-decided')
  await ctx.close()
})
scene('approvals-dialogs', async () => {
  const { page, ctx } = await fresh('/approvals')
  await page.keyboard.press('e')
  await page.waitForTimeout(600)
  await shot(page, 'approvals-edit')
  await page.keyboard.press('Escape')
  await page.waitForTimeout(400)
  await page.keyboard.press('r')
  await page.waitForTimeout(600)
  await shot(page, 'approvals-reject')
  await page.keyboard.press('Escape')
  await page.waitForTimeout(400)
  for (let i = 0; i < 4; i++) await page.keyboard.press('j') // -> the delete proposal
  await page.waitForTimeout(500)
  await shot(page, 'approvals-select-delete')
  await page.keyboard.press('a')
  await page.waitForTimeout(600)
  await shot(page, 'approvals-confirm-irreversible')
  await ctx.close()
})
scene('approvals-flow', async () => {
  const sent = []
  const init = async (page) => { await page.route('**/api/proposals/*/decision', async (r) => { sent.push(JSON.parse(r.request().postData() || '{}')); await r.fallback() }) }
  const { page, ctx } = await fresh('/approvals', { init })
  await page.keyboard.press('e')
  await page.waitForTimeout(500)
  await page.getByLabel('Action to execute').fill('whatsapp.send(chat="Priya", text="Thursday 11:00 works. Sending the invite now.")')
  await page.keyboard.press('Control+Enter')
  await page.waitForTimeout(450)
  await shot(page, 'approvals-optimistic') // p-9 already gone from Pending, toast visible
  console.log('decision body sent:', JSON.stringify(sent))
  await page.waitForTimeout(6500)
  await page.getByRole('tab', { name: /Decided/ }).click()
  await page.waitForTimeout(700)
  await shot(page, 'approvals-decided-after')
  await ctx.close()
})
scene('approvals-rollback', async () => {
  const init = async (page) => { await page.route('**/api/proposals/*/decision', async (r) => { await new Promise((ok) => setTimeout(ok, 1200)); fulfill(r, { error: 'already approved' }, 409) }) }
  const { page, ctx } = await fresh('/approvals', { init })
  await page.keyboard.press('a')
  await page.waitForTimeout(500)
  await shot(page, 'approvals-rollback-optimistic')
  await page.waitForTimeout(1900)
  await shot(page, 'approvals-rollback-restored')
  await ctx.close()
})
scene('approvals-empty', async () => {
  const init = async (page) => { await page.route('**/api/proposals?status=pending', (r) => fulfill(r, { proposals: null })) }
  const { page, ctx } = await fresh('/approvals', { init })
  await shot(page, 'approvals-allclear')
  await ctx.close()
})
scene('approvals-error', async () => {
  const { page, ctx } = await fresh('/approvals', { daemon: 'http://127.0.0.1:1' })
  await page.waitForTimeout(1200)
  await shot(page, 'approvals-error')
  await ctx.close()
})

const names = Object.keys(scenes).filter((n) => !only.length || only.some((o) => n === o || n.startsWith(o)))
for (const n of names) {
  try { await scenes[n]() } catch (e) { console.log(`SCENE ${n} FAILED:`, e.message.split('\n')[0]) }
}
if (errors.length) { console.log('\nBROWSER ERRORS:'); for (const e of [...new Set(errors)]) console.log(' -', e) }
await browser.close()
