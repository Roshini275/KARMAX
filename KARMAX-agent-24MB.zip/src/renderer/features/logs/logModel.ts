/**
 * Pure helpers for the log console: level/source metadata, line formatting, search matching.
 * No React in here so it can be unit-tested and reused by the Tasks drawer.
 */
import { Bug, Info, OctagonX, TriangleAlert, type LucideIcon } from 'lucide-react'
import type { LogLevel, LogSource } from '@shared/ipc'
import { formatClock } from '@/lib/format'
import type { LogEntry } from './useLogStream'

export const LEVELS: LogLevel[] = ['debug', 'info', 'warn', 'error']
export const SOURCES: LogSource[] = ['karmax', 'wacli', 'app']
export const LEVEL_RANK: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 }

/**
 * Level = state, so it is never colour alone: every level has its own icon and a short text label.
 * `text` is a Tailwind text colour class; `bar` a CSS colour for the row's leading rule.
 */
export const levelMeta: Record<LogLevel, { label: string; long: string; icon: LucideIcon; text: string; bar: string }> = {
  debug: { label: 'DBG', long: 'Debug', icon: Bug, text: 'text-ink-3', bar: 'transparent' },
  info: { label: 'INF', long: 'Info', icon: Info, text: 'text-ink-2', bar: 'transparent' },
  warn: { label: 'WRN', long: 'Warning', icon: TriangleAlert, text: 'text-warn', bar: 'var(--warn)' },
  error: { label: 'ERR', long: 'Error', icon: OctagonX, text: 'text-crit', bar: 'var(--crit-mark)' }
}

/** Source is identity (not state), so it takes categorical series slots, always with the text name beside it. */
export const sourceMeta: Record<LogSource, { label: string; color: string }> = {
  karmax: { label: 'karmax', color: 'var(--s1)' },
  wacli: { label: 'wacli', color: 'var(--s3)' },
  app: { label: 'app', color: 'var(--s7)' }
}

export const isLevel = (v: unknown): v is LogLevel => v === 'debug' || v === 'info' || v === 'warn' || v === 'error'

/** ISO timestamp + padded level + source (+ loop) + message: the format Copy and Export .log write. */
export function formatLine(l: LogEntry): string {
  const loop = l.loop ? ` loop=${l.loop}` : ''
  return `${l.ts} ${l.level.toUpperCase().padEnd(5)} ${l.source}${loop} ${l.message}`
}

export const formatTime = (l: LogEntry) => formatClock(l.t, true)

/* ── search ────────────────────────────────────────────────────────────── */

export interface Matcher {
  test(msg: string): boolean
  /** Non-overlapping [start, end) ranges to highlight (capped so a pathological regex can't stall a row). */
  ranges(msg: string): Array<[number, number]>
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

/** Returns a matcher, null for an empty query, or `{ error }` for an invalid regular expression. */
export function compileSearch(q: string, regex: boolean): Matcher | null | { error: string } {
  if (!q) return null
  let test: RegExp
  let all: RegExp
  try {
    const src = regex ? q : escapeRe(q)
    test = new RegExp(src, 'i')
    all = new RegExp(src, 'gi')
  } catch (e) {
    return { error: e instanceof Error ? e.message.replace(/^Invalid regular expression: /, '') : 'Invalid pattern' }
  }
  return {
    test: (msg) => test.test(msg),
    ranges: (msg) => {
      const out: Array<[number, number]> = []
      all.lastIndex = 0
      let m: RegExpExecArray | null
      while (out.length < 40 && (m = all.exec(msg))) {
        if (m[0] === '') {
          all.lastIndex++
          continue
        }
        out.push([m.index, m.index + m[0].length])
      }
      return out
    }
  }
}

export const isMatcherError = (m: ReturnType<typeof compileSearch>): m is { error: string } => !!m && 'error' in m

export interface Chunk {
  text: string
  hit: boolean
}

export function highlight(text: string, matcher: Matcher | null): Chunk[] {
  if (!matcher) return [{ text, hit: false }]
  const rs = matcher.ranges(text)
  if (!rs.length) return [{ text, hit: false }]
  const out: Chunk[] = []
  let at = 0
  for (const [s, e] of rs) {
    if (s > at) out.push({ text: text.slice(at, s), hit: false })
    out.push({ text: text.slice(s, e), hit: true })
    at = e
  }
  if (at < text.length) out.push({ text: text.slice(at), hit: false })
  return out
}

/* ── multi-line handling ───────────────────────────────────────────────── */

/** First line + how many lines follow, for the collapsed row. */
export function collapse(msg: string): { first: string; extra: number; long: boolean } {
  const nl = msg.indexOf('\n')
  if (nl < 0) return { first: msg, extra: 0, long: msg.length > 220 }
  const rest = msg.slice(nl + 1).split('\n').length
  return { first: msg.slice(0, nl), extra: rest, long: true }
}

/* ── activity strip buckets ────────────────────────────────────────────── */

export interface Bucket {
  start: number // epoch ms, floor to the minute
  error: number
  warn: number
}

/** `minutes` per-minute buckets ending at the minute containing `now`. Only warn/error lines are counted. */
export function bucketize(lines: readonly LogEntry[], now: number, minutes = 30, keep: (l: LogEntry) => boolean = () => true): Bucket[] {
  const MIN = 60_000
  const end = Math.floor(now / MIN) * MIN
  const first = end - (minutes - 1) * MIN
  const out: Bucket[] = Array.from({ length: minutes }, (_, i) => ({ start: first + i * MIN, error: 0, warn: 0 }))
  // Lines are (nearly) time-ordered: walk from the newest and stop once we are past the window.
  let older = 0
  for (let i = lines.length - 1; i >= 0; i--) {
    const l = lines[i]
    if (l.t < first) {
      // Tolerate a little disorder before giving up.
      if (++older > 200) break
      continue
    }
    if (l.level !== 'error' && l.level !== 'warn') continue
    if (!keep(l)) continue
    const idx = Math.floor((l.t - first) / MIN)
    if (idx < 0 || idx >= minutes) continue
    out[idx][l.level]++
  }
  return out
}
