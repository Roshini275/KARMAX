/**
 * Errors + warnings per minute for the last 30 minutes, as a tiny stacked column chart.
 * Follows the dataviz rules: thin marks (<= 24px), 2px surface gaps between stacked segments, square baseline with a
 * 4px-ish rounded data end, one legend (2 series), a direct label on the peak, hover/focus tooltip listing both
 * series, recessive hairline baseline, a single y-scale, and a screen-reader table twin.
 */
import { useEffect, useMemo, useState } from 'react'
import { Check } from 'lucide-react'
import { cn } from '@/design/cn'
import { formatClock } from '@/lib/format'
import type { Bucket } from './logModel'

const H = 46 // plot height, px
const TOP = 14 // room for the peak label
const GAP = 2

export function ActivityStrip({ buckets, scoped }: { buckets: Bucket[]; scoped: boolean }) {
  const [active, setActive] = useState<number | null>(null)
  const totals = useMemo(() => buckets.reduce((a, b) => ({ error: a.error + b.error, warn: a.warn + b.warn }), { error: 0, warn: 0 }), [buckets])
  const sums = buckets.map((b) => b.error + b.warn)
  const max = Math.max(0, ...sums)
  const peakIdx = max > 0 ? sums.indexOf(max) : -1
  const scale = (n: number) => (n <= 0 ? 0 : Math.max(3, Math.round((n / (max || 1)) * (H - TOP))))
  const n = buckets.length
  const act = active != null ? buckets[active] : null

  // keep "now" fresh even when no lines arrive (the parent recomputes buckets on its own tick)
  const [, force] = useState(0)
  useEffect(() => {
    const t = setInterval(() => force((x) => x + 1), 30_000)
    return () => clearInterval(t)
  }, [])

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') setActive((a) => Math.max(0, (a ?? n) - 1))
    else if (e.key === 'ArrowRight') setActive((a) => Math.min(n - 1, (a ?? -1) + 1))
    else if (e.key === 'Home') setActive(0)
    else if (e.key === 'End') setActive(n - 1)
    else if (e.key === 'Escape') setActive(null)
    else return
    e.preventDefault()
    e.stopPropagation()
  }

  return (
    <section aria-label="Errors and warnings per minute, last 30 minutes" className="glass grid grid-cols-[minmax(150px,210px)_1fr] items-center gap-x-5 rounded-xl px-4 py-2.5 max-[1000px]:grid-cols-[minmax(120px,150px)_1fr]">
      <div className="min-w-0">
        <div className="label-micro">Errors &amp; warnings</div>
        <div className="mt-0.5 truncate text-[11px] text-ink-3">per minute · last 30 min{scoped ? ' · filtered' : ''}</div>
        <ul className="mt-1.5 flex flex-wrap items-center gap-x-3.5 gap-y-1 text-[12px]" aria-label="Legend">
          <li className="flex items-center gap-1.5">
            <span className="size-2 rounded-[2px]" style={{ background: 'var(--crit-mark)' }} aria-hidden />
            <span className="text-ink-2">Errors</span>
            <b className="tnum font-semibold text-ink">{totals.error}</b>
          </li>
          <li className="flex items-center gap-1.5">
            <span className="size-2 rounded-[2px]" style={{ background: 'var(--warn)' }} aria-hidden />
            <span className="text-ink-2">Warnings</span>
            <b className="tnum font-semibold text-ink">{totals.warn}</b>
          </li>
        </ul>
      </div>

      <div
        className="relative min-w-0 rounded-md outline-offset-4"
        tabIndex={0}
        role="group"
        aria-label={`Activity chart. ${totals.error} errors and ${totals.warn} warnings in the last 30 minutes. Use left and right arrow keys to inspect each minute.`}
        onKeyDown={onKey}
        onBlur={() => setActive(null)}
        onPointerLeave={() => setActive(null)}
      >
        {/* tooltip: values lead, names follow; keyed with a short stroke, not a box. Sits inside the strip, beside the column. */}
        {act && active != null && (
          <div
            className="glass pointer-events-none absolute top-0 z-30 min-w-[132px] rounded-lg px-2.5 py-1.5 text-[11.5px] shadow-pop"
            style={{
              ...(active < n * 0.6 ? { left: `calc(${((active + 1) / n) * 100}% + 8px)` } : { right: `calc(${((n - active) / n) * 100}% + 8px)` }),
              background: 'color-mix(in oklab, var(--panel) 96%, transparent)'
            }}
          >
            <div className="tnum mb-0.5 font-medium text-ink-2">
              {formatClock(act.start).slice(0, 5)}–{formatClock(act.start + 60_000).slice(0, 5)}
            </div>
            <TipRow color="var(--crit-mark)" label="Errors" value={act.error} />
            <TipRow color="var(--warn)" label="Warnings" value={act.warn} />
          </div>
        )}

        <div className="relative" style={{ height: H }}>
          {max === 0 && (
            <div className="absolute inset-x-0 top-0 flex items-center justify-center gap-1.5 text-[12px] text-ink-3" style={{ height: H - 4 }}>
              <Check className="size-3.5 text-good" strokeWidth={3} aria-hidden />
              Quiet: no warnings or errors in the last 30 minutes
            </div>
          )}
          <div className="grid h-full" style={{ gridTemplateColumns: `repeat(${n}, minmax(0, 1fr))` }}>
            {buckets.map((b, i) => {
              const eh = scale(b.error)
              const wh = scale(b.warn)
              return (
                <div key={b.start} className="relative flex h-full cursor-default flex-col-reverse items-center" onPointerEnter={() => setActive(i)} onPointerMove={() => setActive(i)}>
                  {/* hit target = the whole column, lifted wash on hover/focus */}
                  <div className={cn('pointer-events-none absolute inset-y-0 inset-x-px rounded-[4px] transition-opacity', active === i ? 'opacity-100' : 'opacity-0')} style={{ background: 'color-mix(in oklab, var(--ink) 8%, transparent)' }} />
                  {eh > 0 && <div className="relative w-full max-w-[18px]" style={{ height: eh, background: 'var(--crit-mark)', borderRadius: wh > 0 ? 0 : '3px 3px 0 0' }} />}
                  {wh > 0 && <div className="relative w-full max-w-[18px]" style={{ height: wh, marginBottom: eh > 0 ? GAP : 0, background: 'var(--warn)', borderRadius: '3px 3px 0 0' }} />}
                  {i === peakIdx && (
                    <span className="tnum absolute left-1/2 -translate-x-1/2 text-[10.5px] font-semibold text-ink-2" style={{ bottom: eh + wh + (eh && wh ? GAP : 0) + 2 }}>
                      {sums[i]}
                    </span>
                  )}
                </div>
              )
            })}
          </div>
          {/* baseline: solid hairline, one step off the surface */}
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px" style={{ background: 'var(--axis)' }} />
        </div>
        <div className="tnum mt-1 flex justify-between text-[10px] text-ink-3" aria-hidden>
          <span>{formatClock(buckets[0].start).slice(0, 5)}</span>
          <span>{formatClock(buckets[Math.floor(n / 2)].start).slice(0, 5)}</span>
          <span>now</span>
        </div>

        <div className="sr-only" aria-live="polite">
          {act && `${formatClock(act.start)}: ${act.error} errors, ${act.warn} warnings`}
        </div>
        <table className="sr-only">
          <caption>Errors and warnings per minute</caption>
          <thead>
            <tr>
              <th>Minute</th>
              <th>Errors</th>
              <th>Warnings</th>
            </tr>
          </thead>
          <tbody>
            {buckets.map((b) => (
              <tr key={b.start}>
                <td>{formatClock(b.start)}</td>
                <td>{b.error}</td>
                <td>{b.warn}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

function TipRow({ color, label, value }: { color: string; label: string; value: number }) {
  return (
    <div className="flex items-center gap-2">
      <span className="h-[3px] w-3.5 rounded-full" style={{ background: color }} aria-hidden />
      <b className="tnum w-5 text-right text-[12.5px] font-semibold text-ink">{value}</b>
      <span className="text-ink-3">{label}</span>
    </div>
  )
}
