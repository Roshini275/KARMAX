import type { LogLevel } from '@shared/ipc'
import { cn } from '@/design/cn'
import { levelMeta } from './logModel'

/** Icon + 3-letter label: a level is never conveyed by colour alone. */
export function LevelBadge({ level, className }: { level: LogLevel; className?: string }) {
  const m = levelMeta[level]
  const Icon = m.icon
  return (
    <span className={cn('inline-flex items-center gap-1 text-[10px] font-bold tracking-[0.04em]', m.text, className)} title={m.long}>
      <Icon className="size-[11px] shrink-0" strokeWidth={2.5} aria-hidden />
      <span aria-label={m.long}>{m.label}</span>
    </span>
  )
}
