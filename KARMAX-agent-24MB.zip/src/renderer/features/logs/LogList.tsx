/**
 * Virtualised log view. Only the rows in (and just around) the viewport exist in the DOM, so 20k lines cost the same
 * as 50. Rows are keyed by the entry's arrival id, so measured heights survive the ring buffer trimming its head.
 */
import { memo, useCallback, useEffect, useLayoutEffect, useRef } from 'react'
import { useVirtualizer } from '@tanstack/react-virtual'
import { ArrowDownToLine, ChevronRight, ScrollText } from 'lucide-react'
import { cn } from '@/design/cn'
import { EmptyState, Kbd } from '@/design/primitives'
import { collapse, highlight, levelMeta, sourceMeta, formatTime, type Matcher } from './logModel'
import { LevelBadge } from './LevelBadge'
import type { LogEntry } from './useLogStream'

export type Density = 'compact' | 'comfortable'
const ROW_H: Record<Density, number> = { compact: 21, comfortable: 28 }

interface Props {
  lines: readonly LogEntry[]
  matcher: Matcher | null
  wrap: boolean
  density: Density
  follow: boolean
  paused: boolean
  onFollowChange: (v: boolean) => void
  expanded: ReadonlySet<number>
  onToggle: (id: number) => void
  onLoopClick: (loop: string) => void
  emptyTitle: string
  emptyBody?: string
  /** Bumped by the parent to request "scroll to the very bottom now" (End key, Jump button). */
  jumpSignal: number
}

export function LogList({ lines, matcher, wrap, density, follow, paused, onFollowChange, expanded, onToggle, onLoopClick, emptyTitle, emptyBody, jumpSignal }: Props) {
  const parent = useRef<HTMLDivElement>(null)
  const lastTop = useRef(0)
  const rowH = ROW_H[density]

  const virt = useVirtualizer({
    count: lines.length,
    getScrollElement: () => parent.current,
    estimateSize: () => rowH,
    overscan: 24,
    getItemKey: (i) => lines[i]?.id ?? i
  })

  // Row metrics change with density / wrap: drop cached measurements.
  useEffect(() => {
    virt.measure()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [density, wrap])

  const total = virt.getTotalSize()
  const stick = useCallback(() => {
    const el = parent.current
    if (el) el.scrollTop = el.scrollHeight
  }, [])

  // Follow tail: after every commit that changed the content height, pin to the bottom.
  useLayoutEffect(() => {
    if (follow) stick()
  }, [follow, lines.length, total, stick])

  useEffect(() => {
    if (jumpSignal) stick()
  }, [jumpSignal, stick])

  const onScroll = () => {
    const el = parent.current
    if (!el) return
    const dist = el.scrollHeight - el.scrollTop - el.clientHeight
    const scrolledUp = el.scrollTop < lastTop.current - 1
    lastTop.current = el.scrollTop
    if (follow && scrolledUp && dist > 8) onFollowChange(false)
    else if (!follow && dist < 4) onFollowChange(true)
  }

  const items = virt.getVirtualItems()

  return (
    <div className="relative min-h-0 flex-1">
      <div
        ref={parent}
        role="log"
        aria-label="Log output"
        aria-live="off"
        tabIndex={0}
        onScroll={onScroll}
        onWheel={(e) => e.deltaY < 0 && follow && onFollowChange(false)}
        className="scroll-thin absolute inset-0 overflow-auto font-[family-name:var(--font-mono)]"
        style={{ overflowAnchor: 'none', contain: 'strict' }}
      >
        <div style={{ height: total, width: '100%', position: 'relative' }}>
          {items.map((vi) => {
            const e = lines[vi.index]
            if (!e) return null
            return (
              <Row
                key={vi.key}
                e={e}
                index={vi.index}
                start={vi.start}
                matcher={matcher}
                wrap={wrap}
                density={density}
                open={expanded.has(e.id)}
                onToggle={onToggle}
                onLoopClick={onLoopClick}
                measure={virt.measureElement}
              />
            )
          })}
        </div>
      </div>
      {lines.length === 0 && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center font-[family-name:var(--font-sans)]">
          <EmptyState icon={<ScrollText className="size-5" />} title={emptyTitle} body={emptyBody} />
        </div>
      )}
      {!follow && !paused && lines.length > 0 && (
        <button
          onClick={() => {
            onFollowChange(true)
            stick()
          }}
          className="glass app-no-drag absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full px-3.5 py-1.5 font-[family-name:var(--font-sans)] text-[12px] font-medium text-ink shadow-pop transition-transform hover:-translate-y-px"
          style={{ boxShadow: 'var(--shadow-pop), 0 0 0 1px color-mix(in oklab, var(--accent) 40%, transparent)' }}
        >
          <ArrowDownToLine className="size-3.5 text-accent" />
          Jump to latest
          <Kbd>End</Kbd>
        </button>
      )}
    </div>
  )
}

const Row = memo(function Row({
  e,
  index,
  start,
  matcher,
  wrap,
  density,
  open,
  onToggle,
  onLoopClick,
  measure
}: {
  e: LogEntry
  index: number
  start: number
  matcher: Matcher | null
  wrap: boolean
  density: Density
  open: boolean
  onToggle: (id: number) => void
  onLoopClick: (loop: string) => void
  measure: (el: HTMLElement | null) => void
}) {
  const c = collapse(e.message)
  const expandable = !wrap && c.long
  const full = wrap || open
  const src = sourceMeta[e.source]
  const bar = levelMeta[e.level].bar
  const text = full ? e.message : c.first

  return (
    <div
      ref={measure}
      data-index={index}
      onClick={() => {
        if (expandable && !window.getSelection()?.toString()) onToggle(e.id)
      }}
      className={cn(
        'group absolute left-0 top-0 grid w-full grid-cols-[14px_86px_46px_58px_minmax(0,1fr)] items-start gap-x-2 pl-2 pr-4 transition-colors hover:bg-[color-mix(in_oklab,var(--ink)_5%,transparent)]',
        density === 'compact' ? 'py-px text-[11.5px] leading-[19px]' : 'py-[4px] text-[12.5px] leading-[20px]',
        expandable && 'cursor-pointer',
        e.level === 'error' && 'bg-[color-mix(in_oklab,var(--crit-mark)_7%,transparent)]'
      )}
      style={{ transform: `translateY(${start}px)`, boxShadow: bar === 'transparent' ? undefined : `inset 2px 0 0 ${bar}` }}
    >
      <span className="grid h-[19px] place-items-center text-ink-3" aria-hidden>
        {expandable && <ChevronRight className={cn('size-3 transition-transform', open && 'rotate-90')} />}
      </span>
      <time dateTime={e.ts} className="tnum whitespace-nowrap text-ink-3" title={e.ts}>
        {formatTime(e)}
      </time>
      <LevelBadge level={e.level} className="h-[19px]" />
      <span className="flex h-[19px] items-center gap-1.5 whitespace-nowrap text-ink-2" title={`source: ${src.label}`}>
        <span className="size-1.5 shrink-0 rounded-full" style={{ background: src.color }} aria-hidden />
        {src.label}
      </span>
      <div className={cn('selectable min-w-0 text-ink', full ? 'whitespace-pre-wrap break-words' : 'truncate')}>
        {e.loop && (
          <button
            onClick={(ev) => {
              ev.stopPropagation()
              onLoopClick(e.loop!)
            }}
            title={`Filter to loop ${e.loop}`}
            className="mr-1.5 inline-flex h-[15px] select-none items-center rounded bg-surface-3 px-1.5 align-[1px] text-[10px] font-medium leading-none text-ink-2 ring-1 ring-line hover:text-ink"
          >
            {e.loop}
          </button>
        )}
        {!full && c.extra > 0 && (
          <span className="mr-1.5 inline-flex h-[15px] select-none items-center rounded bg-surface-3 px-1.5 align-[1px] text-[10px] font-medium leading-none text-ink-3 ring-1 ring-line">+{c.extra} lines</span>
        )}
        {highlight(text, matcher).map((ch, i) =>
          ch.hit ? (
            <mark key={i} className="rounded-[3px] bg-[color-mix(in_oklab,var(--accent)_40%,transparent)] px-px text-ink">
              {ch.text}
            </mark>
          ) : (
            <span key={i}>{ch.text}</span>
          )
        )}
      </div>
    </div>
  )
})
