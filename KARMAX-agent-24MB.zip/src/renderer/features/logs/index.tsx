import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { AlignJustify, ArrowDownToLine, Copy, Download, Eraser, Pause, Play, Radio, Regex, Rows2, Search, WrapText, X } from 'lucide-react'
import type { LogLevel, LogSource } from '@shared/ipc'
import { cn } from '@/design/cn'
import { IconButton, Kbd, Page } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { useConnection, useLoops } from '@/lib/api/hooks'
import { formatClock } from '@/lib/format'
import { ActivityStrip } from './ActivityStrip'
import { LogList, type Density } from './LogList'
import { LEVELS, LEVEL_RANK, SOURCES, bucketize, compileSearch, formatLine, isLevel, isMatcherError, levelMeta, sourceMeta } from './logModel'
import { MAX_LINES, useLogStream, type LogEntry } from './useLogStream'

/* ── tiny helpers ───────────────────────────────────────────────────────── */

function usePref<T extends string | boolean>(key: string, initial: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key)
      if (raw == null) return initial
      return (typeof initial === 'boolean' ? raw === '1' : raw) as T
    } catch {
      return initial
    }
  })
  const set = useCallback(
    (n: T) => {
      setV(n)
      try {
        localStorage.setItem(key, typeof n === 'boolean' ? (n ? '1' : '0') : n)
      } catch {
        /* storage unavailable: preference just won't persist */
      }
    },
    [key]
  )
  return [v, set]
}

const isTyping = (t: EventTarget | null) => {
  const el = t as HTMLElement | null
  if (!el || !el.tagName) return false
  return el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    ta.remove()
  }
}

const stamp = () => {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`
}

const selectCls =
  'app-no-drag h-8 rounded-lg border border-line bg-surface-2/70 pl-2.5 pr-7 text-[12px] text-ink transition-colors hover:border-line-strong focus:border-accent focus:outline-none focus:ring-2 focus:ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]'

/* ── page ───────────────────────────────────────────────────────────────── */

export default function LogsPage() {
  const [params] = useSearchParams()
  const stream = useLogStream()
  const loopsQ = useLoops()
  const conn = useConnection()

  const [paused, setPaused] = useState<{ lines: readonly LogEntry[]; received: number } | null>(null)
  const [follow, setFollow] = useState(true)
  const [jump, setJump] = useState(0)
  const [wrap, setWrap] = usePref<boolean>('km.logs.wrap', false)
  const [density, setDensity] = usePref<Density>('km.logs.density', 'compact')
  const [sources, setSources] = useState<ReadonlySet<LogSource>>(() => new Set(SOURCES))
  const [minLevel, setMinLevel] = useState<LogLevel>(() => (isLevel(params.get('level')) ? (params.get('level') as LogLevel) : 'debug'))
  const [loop, setLoop] = useState(params.get('loop') ?? '')
  const [query, setQuery] = useState(params.get('q') ?? '')
  const [regex, setRegex] = useState(false)
  const [clearedBefore, setClearedBefore] = useState(0)
  const [expanded, setExpanded] = useState<ReadonlySet<number>>(() => new Set())
  const [flash, setFlash] = useState('')
  const searchRef = useRef<HTMLInputElement>(null)

  const deferredQuery = useDeferredValue(query)
  const compiled = useMemo(() => compileSearch(deferredQuery, regex), [deferredQuery, regex])
  const matcher = compiled && !isMatcherError(compiled) ? compiled : null
  const regexError = isMatcherError(compiled) ? compiled.error : null

  const src = paused ? paused.lines : stream.lines

  // Scope: source / loop / search. (Level is the chart's own dimension, so it is applied after.)
  const scoped = useMemo(() => {
    const out: LogEntry[] = []
    for (const l of src) {
      if (l.id <= clearedBefore) continue
      if (!sources.has(l.source)) continue
      if (loop && l.loop !== loop) continue
      if (matcher && !matcher.test(l.message)) continue
      out.push(l)
    }
    return out
  }, [src, sources, loop, matcher, clearedBefore])

  const visible = useMemo(() => {
    if (minLevel === 'debug') return scoped
    const min = LEVEL_RANK[minLevel]
    return scoped.filter((l) => LEVEL_RANK[l.level] >= min)
  }, [scoped, minLevel])

  // Buckets follow the same scope; recomputed per flush and once a minute.
  const [minuteTick, setMinuteTick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setMinuteTick((x) => x + 1), 20_000)
    return () => clearInterval(t)
  }, [])
  const buckets = useMemo(() => bucketize(scoped, Date.now()), [scoped, minuteTick])

  const loopOptions = useMemo(() => {
    const s = new Set<string>(stream.loops)
    for (const l of loopsQ.data?.loops ?? []) s.add(l.name)
    if (loop) s.add(loop)
    return [...s].sort()
  }, [stream.loops, loopsQ.data, loop])

  const newCount = paused ? Math.max(0, stream.received - paused.received) : 0
  const filtersActive = sources.size !== SOURCES.length || minLevel !== 'debug' || !!loop || !!query

  /* actions */
  const togglePause = useCallback(() => setPaused((p) => (p ? null : { lines: stream.lines, received: stream.received })), [stream.lines, stream.received])
  const toggleSource = (s: LogSource) =>
    setSources((prev) => {
      const n = new Set(prev)
      if (n.has(s)) n.delete(s)
      else n.add(s)
      return n
    })
  const toggleExpanded = useCallback(
    (id: number) =>
      setExpanded((prev) => {
        const n = new Set(prev)
        if (n.has(id)) n.delete(id)
        else n.add(id)
        return n
      }),
    []
  )
  const say = (m: string) => {
    setFlash(m)
    window.setTimeout(() => setFlash(''), 2200)
  }
  const copy = async () => {
    const sel = window.getSelection()?.toString() ?? ''
    if (sel.trim()) {
      await copyText(sel)
      say('Copied selection')
    } else {
      await copyText(visible.map(formatLine).join('\n'))
      say(`Copied ${visible.length.toLocaleString()} lines`)
    }
  }
  const exportLog = () => {
    const blob = new Blob([visible.map(formatLine).join('\n') + '\n'], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `karmax-logs-${stamp()}.log`
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 2000)
    say(`Exported ${visible.length.toLocaleString()} lines`)
  }
  const clearView = () => {
    const last = (src.length ? src[src.length - 1].id : stream.lines.at(-1)?.id) ?? 0
    setClearedBefore(last)
    setExpanded(new Set())
  }
  const resetFilters = () => {
    setSources(new Set(SOURCES))
    setMinLevel('debug')
    setLoop('')
    setQuery('')
  }

  /* keyboard: Ctrl+F search, Space pause, Esc clear search, End follow */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault()
        searchRef.current?.focus()
        searchRef.current?.select()
        return
      }
      if (e.key === 'Escape') {
        if (document.activeElement === searchRef.current || query) {
          setQuery('')
          if (document.activeElement === searchRef.current) searchRef.current?.blur()
        }
        return
      }
      if (isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey) return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (e.key === ' ' && tag !== 'BUTTON') {
        e.preventDefault()
        if (!e.repeat) togglePause()
      } else if (e.key === 'End') {
        e.preventDefault()
        setFollow(true)
        setJump((j) => j + 1)
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [togglePause, query])

  const emptyTitle = stream.lines.length === 0 ? (stream.status === 'loading' ? 'Loading log history…' : 'No log lines yet') : 'No lines match these filters'
  const emptyBody =
    stream.lines.length === 0
      ? conn && !conn.reachable
        ? 'The KARMAX daemon is not reachable. Lines will appear here as soon as it is back.'
        : 'New lines from karmax, wacli and the app appear here as they happen.'
      : clearedBefore && !filtersActive
        ? 'The view was cleared. New lines will appear here.'
        : 'Loosen the source, level, loop or search filters.'

  const live = !paused && stream.status !== 'error'

  return (
    <Page
      flush
      title="Logs"
      subtitle="Live output from KARMAX, wacli and the desktop supervisor"
      actions={
        <>
          {flash && (
            <span className="mr-1 text-[12px] font-medium text-good" role="status">
              {flash}
            </span>
          )}
          {paused ? (
            <StatusPill tone="warn" label={newCount ? `Paused · ${newCount.toLocaleString()} new` : 'Paused'} icon={<Pause className="size-3" strokeWidth={2.5} />} />
          ) : stream.status === 'error' ? (
            <StatusPill tone="crit" label="History failed" />
          ) : (
            <StatusPill tone="good" label={stream.status === 'loading' ? 'Connecting' : 'Live'} icon={<Radio className="size-3" strokeWidth={2.5} />} />
          )}
          <div className="mx-1 h-5 w-px bg-line" aria-hidden />
          <IconButton label={paused ? 'Resume (Space)' : 'Pause (Space)'} onClick={togglePause} active={!!paused}>
            {paused ? <Play className="size-4" /> : <Pause className="size-4" />}
          </IconButton>
          <IconButton
            label={follow ? 'Following the tail (click to stop)' : 'Follow tail (End)'}
            onClick={() => {
              const v = !follow
              setFollow(v)
              if (v) setJump((j) => j + 1)
            }}
            active={follow}
            aria-pressed={follow}
          >
            <ArrowDownToLine className="size-4" />
          </IconButton>
          <IconButton label={wrap ? 'Wrap long lines: on' : 'Wrap long lines: off'} onClick={() => setWrap(!wrap)} active={wrap} aria-pressed={wrap}>
            <WrapText className="size-4" />
          </IconButton>
          <IconButton label={density === 'compact' ? 'Density: compact (switch to comfortable)' : 'Density: comfortable (switch to compact)'} onClick={() => setDensity(density === 'compact' ? 'comfortable' : 'compact')}>
            {density === 'compact' ? <Rows2 className="size-4" /> : <AlignJustify className="size-4" />}
          </IconButton>
          <IconButton label="Clear view (buffer is kept)" onClick={clearView}>
            <Eraser className="size-4" />
          </IconButton>
          <IconButton label={window.getSelection()?.toString() ? 'Copy selection' : 'Copy visible lines'} onClick={() => void copy()}>
            <Copy className="size-4" />
          </IconButton>
          <IconButton label="Export visible lines as .log" onClick={exportLog} disabled={visible.length === 0}>
            <Download className="size-4" />
          </IconButton>
        </>
      }
    >
      <div className="flex h-full min-h-[420px] flex-col gap-2.5 px-7 pb-5">
        {/* filters (scope everything below) */}
        <div className="flex flex-wrap items-center gap-2" role="search">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
            <input
              ref={searchRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search messages"
              aria-label="Search log messages"
              aria-invalid={!!regexError}
              spellCheck={false}
              className={cn(
                'selectable h-8 w-full rounded-lg border bg-surface-2/70 pl-8 pr-[92px] font-[family-name:var(--font-mono)] text-[12px] text-ink placeholder:font-[family-name:var(--font-sans)] placeholder:text-ink-3 transition-colors hover:border-line-strong focus:border-accent focus:outline-none focus:ring-2 focus:ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]',
                regexError ? 'border-[color-mix(in_oklab,var(--crit)_60%,transparent)]' : 'border-line'
              )}
            />
            <div className="absolute right-1 top-1/2 flex -translate-y-1/2 items-center gap-0.5">
              {query && (
                <span className={cn('tnum mr-1 text-[10.5px]', regexError ? 'text-crit' : 'text-ink-3')} title={regexError ?? undefined}>
                  {regexError ? 'invalid' : `${scoped.length.toLocaleString()}`}
                </span>
              )}
              <button
                onClick={() => setRegex((r) => !r)}
                aria-pressed={regex}
                aria-label="Use regular expression"
                title="Regular expression"
                className={cn('app-no-drag grid size-6 place-items-center rounded-md transition-colors', regex ? 'bg-accent-soft text-accent' : 'text-ink-3 hover:bg-surface-3 hover:text-ink-2')}
              >
                <Regex className="size-3.5" />
              </button>
              {query ? (
                <button onClick={() => setQuery('')} aria-label="Clear search" title="Clear search (Esc)" className="app-no-drag grid size-6 place-items-center rounded-md text-ink-3 hover:bg-surface-3 hover:text-ink-2">
                  <X className="size-3.5" />
                </button>
              ) : (
                <Kbd>Ctrl F</Kbd>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1" role="group" aria-label="Sources">
            {SOURCES.map((s) => {
              const on = sources.has(s)
              return (
                <button
                  key={s}
                  onClick={() => toggleSource(s)}
                  aria-pressed={on}
                  className={cn(
                    'app-no-drag inline-flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-[12px] font-medium transition-colors',
                    on ? 'border-line-strong bg-surface-3 text-ink' : 'border-line bg-transparent text-ink-3 hover:text-ink-2'
                  )}
                >
                  <span className="size-2 rounded-full transition-opacity" style={{ background: sourceMeta[s].color, opacity: on ? 1 : 0.35 }} aria-hidden />
                  {sourceMeta[s].label}
                  <span className="tnum text-[11px] text-ink-3">{stream.counts[s].toLocaleString()}</span>
                </button>
              )
            })}
          </div>

          <div className="relative">
            <select aria-label="Minimum level" value={minLevel} onChange={(e) => setMinLevel(e.target.value as LogLevel)} className={cn(selectCls, 'appearance-none')}>
              {LEVELS.map((l) => (
                <option key={l} value={l}>
                  {l === 'debug' ? 'All levels' : `${levelMeta[l].long}+`}
                </option>
              ))}
            </select>
            <Chevron />
          </div>
          <div className="relative">
            <select aria-label="Loop" value={loop} onChange={(e) => setLoop(e.target.value)} className={cn(selectCls, 'max-w-[170px] appearance-none')}>
              <option value="">All loops</option>
              {loopOptions.map((l) => (
                <option key={l} value={l}>
                  loop: {l}
                </option>
              ))}
            </select>
            <Chevron />
          </div>
          {filtersActive && (
            <button onClick={resetFilters} className="app-no-drag h-8 rounded-lg px-2 text-[12px] text-ink-3 transition-colors hover:text-ink">
              Reset
            </button>
          )}
        </div>

        <ActivityStrip buckets={buckets} scoped={filtersActive} />

        {/* console */}
        <div className="glass flex min-h-0 flex-1 flex-col overflow-hidden rounded-xl">
          <LogList
            lines={visible}
            matcher={matcher}
            wrap={wrap}
            density={density}
            follow={follow && !paused}
            paused={!!paused}
            onFollowChange={(v) => setFollow(v)}
            expanded={expanded}
            onToggle={toggleExpanded}
            onLoopClick={setLoop}
            emptyTitle={emptyTitle}
            emptyBody={emptyBody}
            jumpSignal={jump}
          />
          <div className="tnum flex h-7 shrink-0 items-center justify-between gap-3 border-t border-line px-3 text-[11px] text-ink-3">
            <span>
              {visible.length.toLocaleString()} shown
              {visible.length !== src.length && ` of ${src.length.toLocaleString()}`}
              <span className="text-ink-3/70"> · buffer keeps the latest {MAX_LINES.toLocaleString()}</span>
              {clearedBefore > 0 && (
                <>
                  {' · '}
                  <button onClick={() => setClearedBefore(0)} className="text-accent hover:underline">
                    view cleared, restore
                  </button>
                </>
              )}
            </span>
            <span className="flex items-center gap-2">
              {paused ? (
                <span className="text-warn">Paused: {newCount.toLocaleString()} new line{newCount === 1 ? '' : 's'} waiting · press Space to resume</span>
              ) : live ? (
                <span>{follow ? 'Following tail' : 'Scrolled: not following'}</span>
              ) : null}
              {src.length > 0 && <span>latest {formatClock(src[src.length - 1].t)}</span>}
            </span>
          </div>
        </div>
      </div>
    </Page>
  )
}

function Chevron() {
  return (
    <svg className="pointer-events-none absolute right-2 top-1/2 size-3 -translate-y-1/2 text-ink-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="m3 4.5 3 3 3-3" />
    </svg>
  )
}
