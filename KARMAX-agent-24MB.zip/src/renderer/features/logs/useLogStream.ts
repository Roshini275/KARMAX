/**
 * The live log buffer. One process-wide store (ring buffer, 20k lines) fed by `bridge.logs`:
 * `history()` for the backlog, `onLine()` for the tail, de-duplicated on (source, seq, ts).
 *
 * - Lines are batched (one React update per ~100ms) so a burst of thousands of lines is one render.
 * - The `lines` array is IMMUTABLE per version, so a view can pause simply by holding a reference.
 * - The store is ref-counted: it subscribes to the bridge while any `useLogStream()` is mounted (plus a short
 *   grace period so route changes don't churn the subscription) and keeps the buffer across mounts.
 */
import { useEffect, useMemo, useSyncExternalStore } from 'react'
import type { LogLine, LogSource } from '@shared/ipc'
import { getBridge } from '@/lib/bridge'

export const MAX_LINES = 20_000
const HISTORY_LIMIT = 1000
const FLUSH_MS = 100

export interface LogEntry extends LogLine {
  /** Local arrival id, unique and increasing. Used as the row key so measurements survive front-trimming. */
  id: number
  /** `ts` parsed once (epoch ms). */
  t: number
}

export interface LogSnapshot {
  version: number
  lines: readonly LogEntry[]
  /** Cumulative count of unique lines accepted (does not shrink when the ring trims). */
  received: number
  counts: Record<LogSource, number>
  /** loop names seen in the buffer */
  loops: string[]
  status: 'idle' | 'loading' | 'live' | 'error'
  error?: string
}

const keyOf = (l: LogLine) => `${l.source}#${l.seq}#${l.ts}`

class LogStore {
  private lines: LogEntry[] = []
  private seen = new Set<string>()
  private loopCounts = new Map<string, number>()
  private counts: Record<LogSource, number> = { karmax: 0, wacli: 0, app: 0 }
  private received = 0
  private nextId = 1
  private version = 0
  private status: LogSnapshot['status'] = 'idle'
  private error: string | undefined
  private pending: LogLine[] = []
  private flushTimer: ReturnType<typeof setTimeout> | null = null
  private listeners = new Set<() => void>()
  private refs = 0
  private started = false
  private stopTimer: ReturnType<typeof setTimeout> | null = null
  private off: (() => void) | null = null
  private snap: LogSnapshot = this.build()

  subscribe = (cb: () => void) => {
    this.listeners.add(cb)
    return () => void this.listeners.delete(cb)
  }
  getSnapshot = () => this.snap

  /** Ref-counted start. Returns the release function. */
  acquire(): () => void {
    this.refs++
    if (this.stopTimer) {
      clearTimeout(this.stopTimer)
      this.stopTimer = null
    }
    if (!this.started) this.start()
    let released = false
    return () => {
      if (released) return
      released = true
      if (--this.refs === 0) this.stopTimer = setTimeout(() => this.stop(), 4000)
    }
  }

  private start() {
    this.started = true
    this.status = this.lines.length ? 'live' : 'loading'
    this.error = undefined
    this.commit()
    const bridge = getBridge()
    this.off = bridge.logs.onLine((l) => this.push(l))
    bridge.logs
      .history({ limit: HISTORY_LIMIT })
      .then((lines) => {
        if (!this.started) return
        this.ingest(lines)
        this.status = 'live'
        this.error = undefined
        this.commit()
      })
      .catch((e) => {
        if (!this.started) return
        this.status = 'error'
        this.error = e instanceof Error ? e.message : String(e)
        this.commit()
      })
  }

  private stop() {
    this.started = false
    this.off?.()
    this.off = null
    if (this.flushTimer) clearTimeout(this.flushTimer)
    this.flushTimer = null
    this.pending = []
  }

  /** Live line from the bridge: batched. */
  push(l: LogLine) {
    this.pending.push(l)
    if (!this.flushTimer) this.flushTimer = setTimeout(() => this.flush(), FLUSH_MS)
  }

  /** Bulk add (history, tests, the perf harness). Synchronous. */
  addMany(lines: LogLine[]) {
    this.ingest(lines)
    this.commit()
  }

  private flush() {
    this.flushTimer = null
    const batch = this.pending
    this.pending = []
    if (this.ingest(batch)) this.commit()
  }

  private ingest(batch: LogLine[]): boolean {
    let fresh: LogEntry[] | null = null
    for (const l of batch) {
      const k = keyOf(l)
      if (this.seen.has(k)) continue
      this.seen.add(k)
      const parsed = Date.parse(l.ts)
      const e: LogEntry = { ...l, id: this.nextId++, t: Number.isNaN(parsed) ? Date.now() : parsed }
      ;(fresh ??= []).push(e)
      this.counts[e.source] = (this.counts[e.source] ?? 0) + 1
      if (e.loop) this.loopCounts.set(e.loop, (this.loopCounts.get(e.loop) ?? 0) + 1)
    }
    if (!fresh) return false
    this.received += fresh.length

    const prev = this.lines
    const lastT = prev.length ? prev[prev.length - 1].t : -Infinity
    let inOrder = true
    for (let i = 0, t = lastT; i < fresh.length; i++) {
      if (fresh[i].t < t) {
        inOrder = false
        break
      }
      t = fresh[i].t
    }
    let next = prev.length ? prev.concat(fresh) : fresh
    // History arriving after a few live lines (or a merge on re-subscribe) can be older than the tail: keep time order.
    // Array.prototype.sort is stable, so equal timestamps keep arrival order.
    if (!inOrder) next = next.slice().sort((a, b) => a.t - b.t)
    if (next.length > MAX_LINES) {
      const drop = next.slice(0, next.length - MAX_LINES)
      next = next.slice(next.length - MAX_LINES)
      for (const d of drop) {
        this.seen.delete(keyOf(d))
        this.counts[d.source]--
        if (d.loop) {
          const n = (this.loopCounts.get(d.loop) ?? 1) - 1
          if (n <= 0) this.loopCounts.delete(d.loop)
          else this.loopCounts.set(d.loop, n)
        }
      }
    }
    this.lines = next
    return true
  }

  private build(): LogSnapshot {
    return {
      version: this.version,
      lines: this.lines,
      received: this.received,
      counts: { ...this.counts },
      loops: [...this.loopCounts.keys()].sort(),
      status: this.status,
      error: this.error
    }
  }

  private commit() {
    this.version++
    this.snap = this.build()
    for (const l of this.listeners) l()
  }
}

/** Exported for the perf harness / tests; features should use the hook. */
export const logStore = new LogStore()

export interface UseLogStreamOptions {
  /** Keep only lines this returns true for. MUST be referentially stable (useCallback / module scope). */
  match?: (l: LogEntry) => boolean
  /** With `match`: return at most the newest `tail` matching lines. */
  tail?: number
  /** Default true. Set false to not hold the bridge subscription open. */
  enabled?: boolean
}

export interface LogStreamResult extends Omit<LogSnapshot, 'lines'> {
  lines: readonly LogEntry[]
}

/**
 * Subscribe to the shared log buffer. Without `match` it returns the whole buffer (up to 20k lines, oldest first);
 * with `match` (+ optional `tail`) only the newest matching lines, recomputed per flush.
 */
export function useLogStream(opts: UseLogStreamOptions = {}): LogStreamResult {
  const { match, tail, enabled = true } = opts
  useEffect(() => (enabled ? logStore.acquire() : undefined), [enabled])
  const snap = useSyncExternalStore(logStore.subscribe, logStore.getSnapshot)
  const lines = useMemo(() => {
    if (!match) return snap.lines
    const out: LogEntry[] = []
    for (let i = snap.lines.length - 1; i >= 0; i--) {
      if (match(snap.lines[i])) {
        out.push(snap.lines[i])
        if (tail && out.length >= tail) break
      }
    }
    return out.reverse()
    // `snap.version` changes whenever the buffer does; `snap.lines` identity follows it.
  }, [snap.lines, match, tail])
  return { ...snap, lines }
}
