import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, MotionConfig } from 'framer-motion'
import { ShieldCheck } from 'lucide-react'
import { Badge, EmptyState, ErrorNote, Kbd, Page, Segmented, Skeleton } from '@/design/primitives'
import { useProposals } from '@/lib/api/hooks'
import type { Proposal } from '@/lib/api/schemas'
import { useNow } from '../tasks/taskModel'
import { useToasts } from '../tasks/ui/Toast'
import { AllClear } from './AllClear'
import { EditDialog, IrreversibleConfirm, RejectDialog } from './dialogs'
import { ProposalCard } from './ProposalCard'
import { createdMs, decidedMs, isPending, kindMeta, useDecide, type DecideVars } from './approvalModel'

type Tab = 'pending' | 'decided'

const isTyping = (t: EventTarget | null) => {
  const el = t as HTMLElement | null
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable)
}

export default function ApprovalsPage() {
  const pendingQ = useProposals('pending')
  const allQ = useProposals('') // empty status = every proposal, newest first
  const decide = useDecide()
  const { push, node: toasts } = useToasts()
  const now = useNow(15_000)

  const [tab, setTab] = useState<Tab>('pending')
  const [selected, setSelected] = useState<string | null>(null)
  const [confirming, setConfirming] = useState<Proposal | null>(null)
  const [rejecting, setRejecting] = useState<Proposal | null>(null)
  const [editing, setEditing] = useState<Proposal | null>(null)
  const listRef = useRef<HTMLDivElement>(null)

  const pending = useMemo(() => [...(pendingQ.data?.proposals ?? [])].sort((a, b) => createdMs(b) - createdMs(a)), [pendingQ.data])
  const decided = useMemo(() => (allQ.data?.proposals ?? []).filter((p) => !isPending(p)).sort((a, b) => decidedMs(b) - decidedMs(a)), [allQ.data])
  const list = tab === 'pending' ? pending : decided
  const q = tab === 'pending' ? pendingQ : allQ

  // Keep a valid selection: first item by default; when the selected one leaves (decided), stay at the same slot.
  const lastIdx = useRef(0)
  useEffect(() => {
    if (!list.length) {
      setSelected(null)
      return
    }
    const idx = selected ? list.findIndex((p) => p.id === selected) : -1
    if (idx >= 0) lastIdx.current = idx
    else setSelected(list[Math.min(lastIdx.current, list.length - 1)].id)
  }, [list, selected])

  useEffect(() => {
    if (!selected) return
    listRef.current?.querySelector<HTMLElement>(`[data-proposal-id="${CSS.escape(selected)}"]`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  }, [selected])

  /* ── decisions ─────────────────────────────────────────────────────── */
  const run = useCallback(
    (p: Proposal, vars: Omit<DecideVars, 'id'>) => {
      decide.mutate(
        { id: p.id, ...vars },
        {
          onSuccess: () =>
            push(
              vars.decision === 'approve'
                ? { tone: 'good', title: 'Approved', body: `${p.title}. KARMAX is carrying it out; the result will show under Decided.` }
                : { tone: 'muted', title: 'Rejected', body: vars.note ? `${p.title}. Your feedback was sent so KARMAX can rework it.` : p.title }
            ),
          onError: (e) => push({ tone: 'crit', title: `Couldn't ${vars.decision} that. Restored to Pending.`, body: e instanceof Error ? e.message : String(e) })
        }
      )
    },
    [decide, push]
  )
  const approve = useCallback(
    (p: Proposal) => {
      if (kindMeta(p.kind).destructive) setConfirming(p)
      else run(p, { decision: 'approve' })
    },
    [run]
  )
  const openEdit = useCallback((p: Proposal) => setEditing(p), [])
  const openReject = useCallback((p: Proposal) => setRejecting(p), [])

  /* ── keyboard: j/k move · a approve · r reject · e edit ────────────── */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (isTyping(e.target) || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('[role="dialog"]')) return
      const idx = list.findIndex((p) => p.id === selected)
      const cur = idx >= 0 ? list[idx] : undefined
      switch (e.key.toLowerCase()) {
        case 'j':
          e.preventDefault()
          if (list.length) setSelected(list[Math.min(list.length - 1, idx + 1)].id)
          break
        case 'k':
          e.preventDefault()
          if (list.length) setSelected(list[Math.max(0, idx - 1)].id)
          break
        case 'a':
          if (tab === 'pending' && cur && !decide.isPending) (e.preventDefault(), approve(cur))
          break
        case 'r':
          if (tab === 'pending' && cur) (e.preventDefault(), openReject(cur))
          break
        case 'e':
          if (tab === 'pending' && cur) (e.preventDefault(), openEdit(cur))
          break
      }
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [list, selected, tab, approve, openEdit, openReject, decide.isPending])

  const lastDecision = decided[0] ? { title: decided[0].title, status: decided[0].status, at: decided[0].decided_at } : undefined
  const loading = q.isPending

  return (
    <MotionConfig reducedMotion="user">
      <Page
        title="Approvals"
        subtitle={pendingQ.data ? (pending.length ? `${pending.length} proposal${pending.length === 1 ? '' : 's'} waiting for your decision` : 'Nothing is waiting for you') : 'What KARMAX wants your OK on before it acts'}
        actions={
          <>
            <div className="mr-1 hidden items-center gap-3 text-[11.5px] text-ink-3 xl:flex" aria-label="Keyboard shortcuts">
              <span className="flex items-center gap-1"><Kbd>J</Kbd><Kbd>K</Kbd> move</span>
              <span className="flex items-center gap-1"><Kbd>A</Kbd> approve</span>
              <span className="flex items-center gap-1"><Kbd>E</Kbd> edit</span>
              <span className="flex items-center gap-1"><Kbd>R</Kbd> reject</span>
            </div>
            <Segmented<Tab>
              value={tab}
              onChange={setTab}
              options={[
                {
                  value: 'pending',
                  label: (
                    <>
                      Pending
                      <Badge className={pending.length ? 'bg-accent text-white ring-0' : ''}>{pending.length}</Badge>
                    </>
                  )
                },
                {
                  value: 'decided',
                  label: (
                    <>
                      Decided
                      <Badge>{decided.length}</Badge>
                    </>
                  )
                }
              ]}
            />
          </>
        }
      >
        <div ref={listRef} className="mx-auto w-full max-w-[860px] pt-1">
          {q.isError && !q.data && (
            <div className="space-y-4">
              <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
              <EmptyState icon={<ShieldCheck className="size-5" />} title="Can't load proposals" body="The KARMAX daemon didn't answer. This list refreshes automatically once it's reachable." />
            </div>
          )}
          {q.isError && q.data && <div className="mb-4"><ErrorNote error={q.error} onRetry={() => void q.refetch()} /></div>}

          {loading ? (
            <div className="space-y-4">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-[210px] w-full rounded-2xl" />
              ))}
            </div>
          ) : list.length === 0 && !q.isError ? (
            tab === 'pending' ? (
              <AllClear lastDecision={lastDecision} onViewDecided={() => setTab('decided')} />
            ) : (
              <EmptyState icon={<ShieldCheck className="size-5" />} title="No decisions yet" body="Proposals you approve or reject are kept here with KARMAX's result." />
            )
          ) : (
            <div className="space-y-4">
              <AnimatePresence initial={false} mode="popLayout">
                {list.map((p) => (
                  <ProposalCard key={p.id} p={p} now={now} selected={selected === p.id} busy={decide.isPending && decide.variables?.id === p.id} onSelect={setSelected} onApprove={approve} onEdit={openEdit} onReject={openReject} />
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </Page>

      <IrreversibleConfirm
        p={confirming}
        onClose={() => setConfirming(null)}
        onConfirm={() => {
          const p = confirming
          setConfirming(null)
          if (p) run(p, { decision: 'approve' })
        }}
      />
      <RejectDialog
        p={rejecting}
        onClose={() => setRejecting(null)}
        onSubmit={(note) => {
          const p = rejecting
          setRejecting(null)
          if (p) run(p, { decision: 'reject', note: note || undefined })
        }}
      />
      <EditDialog
        p={editing}
        onClose={() => setEditing(null)}
        onSubmit={(edit, note) => {
          const p = editing
          setEditing(null)
          if (p) run(p, { decision: 'approve', edit: edit || undefined, note: note || undefined })
        }}
      />
      {toasts}
    </MotionConfig>
  )
}
