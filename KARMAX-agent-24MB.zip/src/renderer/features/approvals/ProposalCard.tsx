import { memo, useState } from 'react'
import { motion } from 'framer-motion'
import { Check, ChevronDown, CircleAlert, Clock, Copy, Pencil, Terminal, ThumbsDown, X } from 'lucide-react'
import { Button, Kbd } from '@/design/primitives'
import { StatusPill, toneVar, type Tone } from '@/design/status'
import { cn } from '@/design/cn'
import { spring } from '@/design/motion'
import { timeAgo } from '@/lib/format'
import type { Proposal } from '@/lib/api/schemas'
import { kindMeta } from './approvalModel'

/** Status = state, so always pill (icon + label). `approved` means "decided, the agent is executing it". */
function statusPill(status: string) {
  switch (status) {
    case 'pending':
      return <StatusPill tone="warn" label="Pending" icon={<Clock className="size-3" strokeWidth={2.5} />} />
    case 'approved':
      return <StatusPill tone="accent" label="Approved · executing" />
    case 'executed':
      return <StatusPill tone="good" label="Executed" />
    case 'failed':
      return <StatusPill tone="crit" label="Failed" />
    case 'rejected':
      return <StatusPill tone="muted" label="Rejected" icon={<X className="size-3" strokeWidth={2.75} />} />
    default:
      return <StatusPill tone="muted" label={status || 'Unknown'} />
  }
}

export const ProposalCard = memo(function ProposalCard({
  p,
  now,
  selected,
  busy,
  onSelect,
  onApprove,
  onEdit,
  onReject
}: {
  p: Proposal
  now: number
  selected: boolean
  busy: boolean
  onSelect: (id: string) => void
  onApprove: (p: Proposal) => void
  onEdit: (p: Proposal) => void
  onReject: (p: Proposal) => void
}) {
  const meta = kindMeta(p.kind)
  const Icon = meta.icon
  const pending = p.status === 'pending'
  const tone: Tone = meta.tone
  const c = toneVar[tone]
  const [copied, setCopied] = useState(false)
  const [open, setOpen] = useState(false)
  const longAction = p.action.length > 320 || p.action.split('\n').length > 8

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(p.action)
      setCopied(true)
      setTimeout(() => setCopied(false), 1400)
    } catch {
      /* clipboard unavailable */
    }
  }

  return (
    <motion.article
      layout="position"
      transition={spring}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: 36, scale: 0.98, transition: { duration: 0.18 } }}
      data-proposal-id={p.id}
      aria-label={`${p.title}. ${p.status}`}
      aria-current={selected || undefined}
      onClick={() => onSelect(p.id)}
      className={cn(
        'glass relative rounded-2xl p-5 transition-[border-color,box-shadow] duration-150',
        selected && pending ? 'border-[color-mix(in_oklab,var(--accent)_55%,transparent)]' : ''
      )}
      style={selected && pending ? { boxShadow: 'var(--glow-accent), inset 0 1px 0 color-mix(in oklab, var(--ink) 5%, transparent)' } : undefined}
    >
      <div className="flex items-start gap-3.5">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl ring-1" style={{ color: c, background: `color-mix(in oklab, ${c} 14%, transparent)`, ['--tw-ring-color' as string]: `color-mix(in oklab, ${c} 30%, transparent)` }} aria-hidden>
          <Icon className="size-[18px]" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <h3 className="text-[14.5px] font-semibold leading-snug tracking-tight">{p.title}</h3>
            <div className="shrink-0 pt-0.5">{statusPill(p.status)}</div>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11.5px] text-ink-3">
            <span className="font-medium text-ink-2">{meta.label}</span>
            <span aria-hidden>·</span>
            <span className="tnum" title={p.created_at ? new Date(p.created_at).toLocaleString() : undefined}>
              proposed {timeAgo(p.created_at, now)}
            </span>
            {!pending && p.decided_at && (
              <>
                <span aria-hidden>·</span>
                <span className="tnum" title={new Date(p.decided_at).toLocaleString()}>
                  decided {timeAgo(p.decided_at, now)}
                </span>
              </>
            )}
            <span aria-hidden>·</span>
            <span className="font-[family-name:var(--font-mono)]">{p.id}</span>
            {meta.destructive && pending && (
              <span className="ml-1 inline-flex items-center gap-1 rounded-full px-2 py-px text-[10.5px] font-semibold text-crit ring-1" style={{ background: 'color-mix(in oklab, var(--crit-mark) 12%, transparent)', ['--tw-ring-color' as string]: 'color-mix(in oklab, var(--crit-mark) 35%, transparent)' }}>
                <CircleAlert className="size-3" strokeWidth={2.5} /> Irreversible
              </span>
            )}
          </div>
        </div>
      </div>

      {p.summary && <p className="selectable mt-3.5 text-[13.5px] leading-relaxed text-ink">{p.summary}</p>}
      {p.context && (
        <div className="mt-3 rounded-xl bg-surface-2/60 px-3.5 py-2.5 ring-1 ring-line">
          <div className="label-micro mb-1">Context</div>
          <p className="selectable whitespace-pre-wrap text-[12.5px] leading-relaxed text-ink-2">{p.context}</p>
        </div>
      )}

      {p.action && (
        <div className="mt-3.5">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="label-micro flex items-center gap-1.5">
              <Terminal className="size-3" aria-hidden /> {pending ? 'Proposed action' : 'Action'}
            </span>
            <button onClick={(e) => (e.stopPropagation(), void copy())} aria-label="Copy action" className="app-no-drag flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] text-ink-3 transition-colors hover:bg-surface-3 hover:text-ink">
              {copied ? <Check className="size-3 text-good" /> : <Copy className="size-3" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <div className="relative overflow-hidden rounded-xl bg-[color-mix(in_oklab,var(--page)_55%,var(--surface))] ring-1 ring-line" style={{ boxShadow: `inset 3px 0 0 ${c}` }}>
            <pre className={cn('selectable scroll-thin overflow-auto whitespace-pre-wrap break-words py-3 pl-4 pr-3.5 font-[family-name:var(--font-mono)] text-[12px] leading-relaxed text-ink', longAction && !open ? 'max-h-32' : 'max-h-80')}>{p.action}</pre>
            {longAction && !open && <div className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-[color-mix(in_oklab,var(--page)_55%,var(--surface))] to-transparent" />}
          </div>
          {longAction && (
            <button onClick={(e) => (e.stopPropagation(), setOpen((o) => !o))} className="app-no-drag mt-1 flex items-center gap-1 text-[11.5px] text-ink-3 hover:text-ink">
              <ChevronDown className={cn('size-3 transition-transform', open && 'rotate-180')} /> {open ? 'Show less' : 'Show all'}
            </button>
          )}
        </div>
      )}

      {pending ? (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button variant="primary" icon={<Check className="size-3.5" strokeWidth={3} />} disabled={busy} onClick={(e) => (e.stopPropagation(), onApprove(p))}>
            Approve
            {selected && <Kbd>A</Kbd>}
          </Button>
          <Button variant="subtle" icon={<Pencil className="size-3.5" />} disabled={busy} onClick={(e) => (e.stopPropagation(), onEdit(p))}>
            Edit &amp; approve
            {selected && <Kbd>E</Kbd>}
          </Button>
          <Button variant="ghost" className="ml-auto" icon={<ThumbsDown className="size-3.5" />} disabled={busy} onClick={(e) => (e.stopPropagation(), onReject(p))}>
            Reject
            {selected && <Kbd>R</Kbd>}
          </Button>
        </div>
      ) : (
        (p.note || p.result) && (
          <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
            {p.note && (
              <div className="rounded-xl bg-surface-2/60 px-3.5 py-2.5 ring-1 ring-line">
                <div className="label-micro mb-1">Your note</div>
                <p className="selectable whitespace-pre-wrap text-[12.5px] leading-relaxed text-ink-2">{p.note}</p>
              </div>
            )}
            {p.result && (
              <div className={cn('rounded-xl px-3.5 py-2.5 ring-1', p.status === 'failed' ? 'ring-[color-mix(in_oklab,var(--crit-mark)_35%,transparent)]' : 'bg-surface-2/60 ring-line')} style={p.status === 'failed' ? { background: 'color-mix(in oklab, var(--crit-mark) 9%, transparent)' } : undefined}>
                <div className={cn('label-micro mb-1', p.status === 'failed' && 'text-crit')}>{p.status === 'failed' ? 'Failure' : 'Result'}</div>
                <p className="selectable line-clamp-6 whitespace-pre-wrap break-words text-[12.5px] leading-relaxed text-ink-2">{p.result}</p>
              </div>
            )}
          </div>
        )
      )}
    </motion.article>
  )
})
