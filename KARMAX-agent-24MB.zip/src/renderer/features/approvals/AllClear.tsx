import { motion } from 'framer-motion'
import { Check, ShieldCheck, Sparkle } from 'lucide-react'
import { Button } from '@/design/primitives'
import { ease } from '@/design/motion'
import { timeAgo } from '@/lib/format'

/** "Nothing needs you" illustration, built from CSS rings + icons (no assets). */
export function AllClear({ lastDecision, onViewDecided }: { lastDecision?: { title: string; status: string; at?: string }; onViewDecided: () => void }) {
  return (
    <div className="mx-auto flex max-w-[460px] flex-col items-center px-4 py-14 text-center">
      <div className="relative grid size-[176px] place-items-center" aria-hidden>
        {[176, 132, 92].map((s, i) => (
          <motion.span
            key={s}
            className="absolute rounded-full"
            style={{
              width: s,
              height: s,
              border: '1px solid color-mix(in oklab, var(--good) 26%, var(--line))',
              background: `radial-gradient(circle, color-mix(in oklab, var(--good) ${4 + i * 3}%, transparent), transparent 70%)`
            }}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: [1, 1.035, 1] }}
            transition={{ opacity: { duration: 0.5, delay: i * 0.1 }, scale: { duration: 4.5, repeat: Infinity, delay: i * 0.6, ease: 'easeInOut' } }}
          />
        ))}
        {/* orbiting sparkles */}
        <motion.div className="absolute inset-0" animate={{ rotate: 360 }} transition={{ duration: 38, repeat: Infinity, ease: 'linear' }}>
          <Sparkle className="absolute left-[10px] top-[46px] size-3 text-accent" fill="currentColor" strokeWidth={0} />
          <Sparkle className="absolute right-[6px] top-[92px] size-2.5 text-accent-2" fill="currentColor" strokeWidth={0} />
          <Sparkle className="absolute bottom-[14px] left-[62px] size-2 text-good" fill="currentColor" strokeWidth={0} />
        </motion.div>
        <motion.span
          className="relative grid size-[68px] place-items-center rounded-2xl ring-1"
          style={{
            background: 'linear-gradient(160deg, color-mix(in oklab, var(--good) 26%, var(--surface-2)), color-mix(in oklab, var(--good) 8%, var(--surface)))',
            ['--tw-ring-color' as string]: 'color-mix(in oklab, var(--good) 45%, transparent)',
            boxShadow: '0 12px 34px -10px color-mix(in oklab, var(--good) 60%, transparent), inset 0 1px 0 color-mix(in oklab, white 18%, transparent)'
          }}
          initial={{ scale: 0.7, opacity: 0, rotate: -8 }}
          animate={{ scale: 1, opacity: 1, rotate: 0, transition: { duration: 0.5, ease } }}
        >
          <ShieldCheck className="size-8 text-good" strokeWidth={1.8} />
          <span className="absolute -bottom-1.5 -right-1.5 grid size-6 place-items-center rounded-full bg-good text-white ring-[3px] ring-[var(--page)]">
            <Check className="size-3.5" strokeWidth={3.5} />
          </span>
        </motion.span>
      </div>

      <h2 className="mt-6 font-[family-name:var(--font-display)] text-[20px] font-semibold tracking-tight">All clear</h2>
      <p className="mt-2 max-w-[380px] text-[13px] leading-relaxed text-ink-3">
        Nothing is waiting for your decision. KARMAX will ask here before it spends money, posts publicly, deletes anything, or does something it can't undo.
      </p>
      {lastDecision && (
        <p className="mt-4 max-w-[380px] truncate text-[12px] text-ink-3">
          Last decision: <span className="text-ink-2">{lastDecision.title}</span> · <span className="capitalize">{lastDecision.status}</span> {lastDecision.at ? timeAgo(lastDecision.at) : ''}
        </p>
      )}
      <Button className="mt-5" onClick={onViewDecided}>
        View decided
      </Button>
    </div>
  )
}
