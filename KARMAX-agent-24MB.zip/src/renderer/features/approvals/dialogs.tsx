import { useEffect, useState } from 'react'
import { Check, Pencil, ShieldAlert, ThumbsDown } from 'lucide-react'
import { Button, Kbd, Textarea } from '@/design/primitives'
import { cn } from '@/design/cn'
import type { Proposal } from '@/lib/api/schemas'
import { ConfirmDialog, Dialog } from '../tasks/ui/Dialog'
import { kindMeta } from './approvalModel'

const ActionPreview = ({ action }: { action: string }) => (
  <pre className="selectable scroll-thin max-h-40 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-surface-2 px-3.5 py-3 font-[family-name:var(--font-mono)] text-[12px] leading-relaxed text-ink ring-1 ring-line">{action}</pre>
)

/** Extra confirmation for irreversible kinds (delete / spend / purchase). */
export function IrreversibleConfirm({ p, onClose, onConfirm, loading }: { p: Proposal | null; onClose: () => void; onConfirm: () => void; loading?: boolean }) {
  const meta = p ? kindMeta(p.kind) : null
  return (
    <ConfirmDialog
      open={!!p}
      onClose={onClose}
      onConfirm={onConfirm}
      loading={loading}
      danger
      icon={<ShieldAlert className="size-[18px]" />}
      title={p ? `Approve ${meta!.label.toLowerCase()}?` : ''}
      body="This can't be undone. Once approved, KARMAX carries it out immediately."
      confirmLabel="Yes, approve it"
      cancelLabel="Go back"
    >
      {p && (
        <div className="space-y-2">
          <div className="text-[13px] font-semibold">{p.title}</div>
          <ActionPreview action={p.action} />
        </div>
      )}
    </ConfirmDialog>
  )
}

export function RejectDialog({ p, onClose, onSubmit }: { p: Proposal | null; onClose: () => void; onSubmit: (note: string) => void }) {
  const [note, setNote] = useState('')
  useEffect(() => {
    if (p) setNote('')
  }, [p])
  return (
    <Dialog
      open={!!p}
      onClose={onClose}
      icon={<ThumbsDown className="size-[17px]" />}
      tone="muted"
      title="Reject this proposal"
      description={
        <>
          <span className="text-ink-2">{p?.title}</span>
          <br />
          Add a note and KARMAX reworks its approach using it, and may come back with a revised proposal. Leave it empty to simply drop the proposal.
        </>
      }
      onSubmit={() => onSubmit(note.trim())}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="danger" onClick={() => onSubmit(note.trim())}>
            {note.trim() ? 'Reject & send feedback' : 'Reject'}
          </Button>
        </>
      }
    >
      <Textarea rows={4} value={note} onChange={(e) => setNote(e.target.value)} aria-label="Feedback for KARMAX (optional)" placeholder="Optional feedback, e.g. “Make it shorter and don't tag Acme.”" />
      <div className="mt-2 flex items-center gap-1 text-[11.5px] text-ink-3">
        <Kbd>Ctrl</Kbd>
        <Kbd>Enter</Kbd> to submit
      </div>
    </Dialog>
  )
}

export function EditDialog({ p, onClose, onSubmit }: { p: Proposal | null; onClose: () => void; onSubmit: (edit: string, note: string) => void }) {
  const [text, setText] = useState('')
  const [note, setNote] = useState('')
  const [ack, setAck] = useState(false)
  useEffect(() => {
    if (p) {
      setText(p.action)
      setNote('')
      setAck(false)
    }
  }, [p])
  const destructive = p ? kindMeta(p.kind).destructive : false
  const changed = !!p && text.trim() !== p.action.trim()
  const ok = text.trim().length > 0 && (!destructive || ack)
  const submit = () => ok && onSubmit(changed ? text : '', note.trim())
  return (
    <Dialog
      open={!!p}
      onClose={onClose}
      icon={<Pencil className="size-[17px]" />}
      title="Edit & approve"
      description={
        <>
          <span className="text-ink-2">{p?.title}</span>
          <br />
          KARMAX executes exactly the text below instead of the original action.
        </>
      }
      width={600}
      onSubmit={submit}
      footer={
        <>
          <span className="mr-auto text-[11.5px] text-ink-3">{changed ? 'Edited: your version will run' : 'Unchanged: same as approving as-is'}</span>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" icon={<Check className="size-3.5" strokeWidth={3} />} onClick={submit} disabled={!ok}>
            Approve{changed ? ' edited action' : ''}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Textarea
          data-autofocus
          rows={8}
          value={text}
          onChange={(e) => setText(e.target.value)}
          aria-label="Action to execute"
          spellCheck={false}
          className="font-[family-name:var(--font-mono)] text-[12px] leading-relaxed"
        />
        <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} aria-label="Note for KARMAX (optional)" placeholder="Optional note passed along with the approval" />
        {destructive && (
          <button
            type="button"
            role="checkbox"
            aria-checked={ack}
            onClick={() => setAck((a) => !a)}
            className="app-no-drag flex w-full items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left text-[12.5px] transition-colors"
            style={{
              borderColor: 'color-mix(in oklab, var(--crit-mark) 40%, transparent)',
              background: ack ? 'color-mix(in oklab, var(--crit-mark) 14%, transparent)' : 'color-mix(in oklab, var(--crit-mark) 6%, transparent)'
            }}
          >
            <span className={cn('mt-px grid size-4 shrink-0 place-items-center rounded border', ack ? 'border-crit bg-crit text-white' : 'border-line-strong')}>{ack && <Check className="size-3" strokeWidth={3.5} />}</span>
            <span>
              <b className="text-crit">Irreversible.</b> <span className="text-ink-2">I understand this {kindMeta(p!.kind).label.toLowerCase()} can't be undone once approved.</span>
            </span>
          </button>
        )}
      </div>
    </Dialog>
  )
}
