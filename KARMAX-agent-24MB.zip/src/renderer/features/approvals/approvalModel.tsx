/**
 * Approvals model. Contract (verified in KARMAX/internal/api/server.go handleProposals / handleProposalDecision and
 * internal/store/proposal_store.go): GET /api/proposals?status= (empty status = all, newest first, default limit 50);
 * POST /api/proposals/{id}/decision {decision:'approve'|'reject', edit?, note?}.
 *  - approve: the agent EXECUTES the action (edited if `edit` is non-blank) in the background; status goes
 *    approved -> executed | failed, with `result` set.
 *  - reject WITH a note: the note is fed back to the agent, which may submit a revised proposal. Without a note it just drops it.
 *  - a proposal that is not `pending` answers 409 "already <status>".
 */
import { useMutation, useQueryClient, type QueryKey } from '@tanstack/react-query'
import { CalendarClock, CircleAlert, CreditCard, ListChecks, Megaphone, Send, Sparkles, Trash2, type LucideIcon } from 'lucide-react'
import { api } from '@/lib/api/client'
import type { Proposal } from '@/lib/api/schemas'
import type { Tone } from '@/design/status'

export type ProposalList = Awaited<ReturnType<typeof api.proposals.list>>

export interface KindMeta {
  label: string
  icon: LucideIcon
  /** Irreversible or money-moving: approving needs an extra confirmation. */
  destructive: boolean
  tone: Tone
}

const KINDS: Record<string, KindMeta> = {
  post: { label: 'Public post', icon: Megaphone, destructive: false, tone: 'accent' },
  message: { label: 'Message', icon: Send, destructive: false, tone: 'accent' },
  delete: { label: 'Deletion', icon: Trash2, destructive: true, tone: 'crit' },
  spend: { label: 'Spend', icon: CreditCard, destructive: true, tone: 'warn' },
  purchase: { label: 'Purchase', icon: CreditCard, destructive: true, tone: 'warn' },
  schedule: { label: 'Schedule', icon: CalendarClock, destructive: false, tone: 'accent' },
  task: { label: 'Task', icon: ListChecks, destructive: false, tone: 'accent' }
}
const OTHER: KindMeta = { label: 'Action', icon: Sparkles, destructive: false, tone: 'muted' }

export const kindMeta = (kind: string): KindMeta => KINDS[kind.toLowerCase()] ?? (kind ? { ...OTHER, label: kind[0].toUpperCase() + kind.slice(1) } : OTHER)

export const irreversibleIcon = CircleAlert

export const isPending = (p: Proposal) => p.status === 'pending'
export const createdMs = (p: Proposal) => (p.created_at ? Date.parse(p.created_at) || 0 : 0)
export const decidedMs = (p: Proposal) => (p.decided_at ? Date.parse(p.decided_at) || 0 : createdMs(p))

export type DecideVars = { id: string; decision: 'approve' | 'reject'; edit?: string; note?: string }

/**
 * Optimistic decision: the proposal leaves every `pending` list at once and shows up decided in the others.
 * Rolls back from a snapshot if the daemon refuses (e.g. 409 already decided), then re-syncs.
 */
export function useDecide() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (v: DecideVars) => api.proposals.decide(v.id, v.decision, { edit: v.edit, note: v.note }),
    onMutate: async (v) => {
      await qc.cancelQueries({ queryKey: ['proposals'] })
      const snapshot = qc.getQueriesData<ProposalList>({ queryKey: ['proposals'] })
      const now = new Date().toISOString()
      for (const [key, data] of snapshot as Array<[QueryKey, ProposalList | undefined]>) {
        if (!data) continue
        const hit = data.proposals.find((p) => p.id === v.id)
        if (!hit) continue
        const decided: Proposal = {
          ...hit,
          status: v.decision === 'approve' ? 'approved' : 'rejected',
          note: v.note ?? hit.note,
          action: v.edit?.trim() ? v.edit : hit.action,
          decided_at: now
        }
        const onlyPending = key[1] === 'pending'
        qc.setQueryData<ProposalList>(key, {
          ...data,
          proposals: onlyPending ? data.proposals.filter((p) => p.id !== v.id) : data.proposals.map((p) => (p.id === v.id ? decided : p))
        })
      }
      return { snapshot }
    },
    onError: (_e, _v, ctx) => {
      ctx?.snapshot.forEach(([key, data]) => qc.setQueryData(key, data))
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: ['proposals'] })
    }
  })
}
