import { describe, expect, it } from 'vitest'
import { countStates, deriveHealthState, normalizeHealth, parseTs, STATE_META, STATE_ORDER, type NormalizedHealth } from './health'
import { buildLoopVMs, hashName, kindOf, matchesFilter, sortLoops } from './model'
import { MIN } from './schedule'

const base: NormalizedHealth = { lastSuccess: 1_800_000_000_000, lastFailure: null, retryAt: null, consecutiveFailures: 0, running: false, dark: false, lastError: '' }
const h = (o: Partial<NormalizedHealth> = {}): NormalizedHealth => ({ ...base, ...o })

describe('deriveHealthState', () => {
  it('ok when it succeeded and nothing is wrong', () => {
    expect(deriveHealthState({ enabled: true, health: h() })).toBe('ok')
  })
  it('running beats everything, including failing and disabled', () => {
    expect(deriveHealthState({ enabled: true, health: h({ running: true }) })).toBe('running')
    expect(deriveHealthState({ enabled: true, health: h({ running: true, consecutiveFailures: 3, dark: true }) })).toBe('running')
    expect(deriveHealthState({ enabled: false, health: h({ running: true }) })).toBe('running')
  })
  it('disabled beats failing / dark (a disabled loop should not raise alarms)', () => {
    expect(deriveHealthState({ enabled: false, health: h({ consecutiveFailures: 2 }) })).toBe('disabled')
    expect(deriveHealthState({ enabled: false, health: null })).toBe('disabled')
  })
  it('failing when consecutive failures > 0', () => {
    expect(deriveHealthState({ enabled: true, health: h({ consecutiveFailures: 1 }) })).toBe('failing')
  })
  it('failing outranks dark', () => {
    expect(deriveHealthState({ enabled: true, health: h({ consecutiveFailures: 2, dark: true }) })).toBe('failing')
  })
  it('dark when the daemon says so and nothing is failing', () => {
    expect(deriveHealthState({ enabled: true, health: h({ dark: true }) })).toBe('dark')
  })
  it('dark outranks waiting: a loop that never ran and has been quiet 3 intervals IS dark', () => {
    expect(deriveHealthState({ enabled: true, health: h({ dark: true, lastSuccess: null }) })).toBe('dark')
  })
  it('waiting when it never succeeded, or the daemon has no record', () => {
    expect(deriveHealthState({ enabled: true, health: h({ lastSuccess: null }) })).toBe('waiting')
    expect(deriveHealthState({ enabled: true, health: null })).toBe('waiting')
    expect(deriveHealthState({ enabled: true })).toBe('waiting')
  })
})

describe('deriveHealthState: loops tracked only by their scheduler job (recipes, prompt loops)', () => {
  const now = 1_800_000_000_000
  const HOUR = 3600_000
  it('ok when it fired within three worst-case gaps', () => {
    expect(deriveHealthState({ enabled: true, job: { lastRun: now - HOUR, nextRun: now + HOUR, runCount: 3 }, maxGapMs: 2 * HOUR, now })).toBe('ok')
  })
  it('dark (judged here, not by the daemon) after three gaps of silence', () => {
    expect(deriveHealthState({ enabled: true, job: { lastRun: now - 7 * HOUR, nextRun: null, runCount: 3 }, maxGapMs: 2 * HOUR, now })).toBe('dark')
  })
  it('waiting when the job never fired or there is no job at all', () => {
    expect(deriveHealthState({ enabled: true, job: { lastRun: null, nextRun: now + HOUR, runCount: 0 }, maxGapMs: HOUR, now })).toBe('waiting')
    expect(deriveHealthState({ enabled: true, job: null })).toBe('waiting')
  })
  it('a health row always wins over a job', () => {
    expect(deriveHealthState({ enabled: true, health: h({ consecutiveFailures: 1 }), job: { lastRun: now, nextRun: null, runCount: 9 }, maxGapMs: HOUR, now })).toBe('failing')
  })
  it('disabled is still disabled', () => {
    expect(deriveHealthState({ enabled: false, job: { lastRun: now, nextRun: null, runCount: 1 } })).toBe('disabled')
  })
})

describe('parseTs / normalizeHealth', () => {
  it('treats Go zero time, epoch 0 and junk as never', () => {
    expect(parseTs('0001-01-01T00:00:00Z')).toBeNull()
    expect(parseTs(0)).toBeNull()
    expect(parseTs('')).toBeNull()
    expect(parseTs(null)).toBeNull()
    expect(parseTs('not a date')).toBeNull()
    expect(parseTs('2026-03-10T12:00:00Z')).toBe(Date.UTC(2026, 2, 10, 12))
  })
  it('normalises a raw row', () => {
    const n = normalizeHealth({ last_success: '2026-03-10T12:00:00Z', last_failure: '0001-01-01T00:00:00Z', consecutive_failures: 2, running: false, dark: true, last_error: '  boom \n' })
    expect(n).toMatchObject({ lastSuccess: Date.UTC(2026, 2, 10, 12), lastFailure: null, consecutiveFailures: 2, dark: true, lastError: 'boom' })
  })
})

describe('STATE_META', () => {
  it('has a distinct label and an icon for every state, and legend order covers all of them', () => {
    const states = Object.keys(STATE_META)
    expect(new Set(states.map((s) => STATE_META[s as keyof typeof STATE_META].label)).size).toBe(states.length)
    expect([...STATE_ORDER].sort()).toEqual([...states].sort())
    for (const s of states) expect(STATE_META[s as keyof typeof STATE_META].icon).toBeTruthy()
  })
  it('reserves status colours for state and gives the two muted states different icons', () => {
    expect(STATE_META.failing.tone).toBe('crit')
    expect(STATE_META.dark.tone).toBe('warn')
    expect(STATE_META.ok.tone).toBe('good')
    expect(STATE_META.running.tone).toBe('accent')
    expect(STATE_META.waiting.icon).not.toBe(STATE_META.disabled.icon)
  })
})

describe('countStates', () => {
  it('counts and computes the healthy share of loops whose state is known', () => {
    const c = countStates(['ok', 'ok', 'running', 'failing', 'dark', 'disabled', 'waiting'])
    expect(c).toMatchObject({ total: 7, enabled: 6, disabled: 1, ok: 2, running: 1, failing: 1, dark: 1, waiting: 1 })
    expect(c).toMatchObject({ known: 5, healthy: 3 })
    expect(c.healthyPct).toBe(60) // 3 of the 5 loops with a known state; the waiting one is left out, not counted as healthy
  })
  it('null share when nothing is known yet', () => {
    expect(countStates(['waiting', 'waiting']).healthyPct).toBeNull()
    expect(countStates([]).healthyPct).toBeNull()
    expect(countStates(['disabled']).healthyPct).toBeNull()
  })
})

describe('buildLoopVMs', () => {
  const now = new Date(2026, 2, 10, 12, 0, 0).getTime()
  const iso = (t: number) => new Date(t).toISOString()
  const list = [
    { name: 'hot-sync', kind: 'recipe', schedule: '@every 15m', enabled: true, description: 'sync' },
    { name: 'gchat-watch', kind: 'workflow', schedule: '@every 5m', enabled: true },
    { name: 'chat-sweep', kind: 'workflow', schedule: '@every 30m', enabled: false },
    { name: 'wa-monitor', kind: 'workflow', schedule: '', events: ['comms.message'], enabled: true },
    { name: 'daily-briefing', kind: 'recipe', schedule: '0 0 18 * * *', enabled: true }
  ]
  const health = [
    { name: 'hot-sync', last_success: iso(now - 5 * MIN), consecutive_failures: 0 },
    { name: 'gchat-watch', last_success: iso(now - 30 * MIN), last_failure: iso(now - MIN), consecutive_failures: 4, retry_at: iso(now + MIN), last_error: '429' },
    { name: 'daily-briefing', last_success: iso(now - 20 * 3600_000) },
    { name: 'orphan', last_success: iso(now - MIN), schedule: '@every 1h' }
  ]
  const vms = buildLoopVMs(list, health, now)
  const by = (n: string) => vms.find((v) => v.name === n)!

  it('joins list and health and keeps orphans', () => {
    expect(vms.map((v) => v.name)).toEqual(['hot-sync', 'gchat-watch', 'chat-sweep', 'wa-monitor', 'daily-briefing', 'orphan'])
    expect(by('orphan')).toMatchObject({ enabled: true, kind: 'other', state: 'ok' })
  })
  it('derives states', () => {
    expect(by('hot-sync').state).toBe('ok')
    expect(by('gchat-watch').state).toBe('failing')
    expect(by('chat-sweep').state).toBe('disabled')
    expect(by('wa-monitor').state).toBe('waiting') // event-driven, no health row
  })
  it('estimates next due: @every from last run, failing from the retry timer, cron from the wall clock', () => {
    expect(by('hot-sync').nextDue).toBe(now + 10 * MIN)
    expect(by('gchat-watch')).toMatchObject({ nextDue: now + MIN, nextIsRetry: true })
    expect(by('daily-briefing').nextDue).toBe(new Date(2026, 2, 10, 18, 0, 0).getTime())
    expect(by('chat-sweep').nextDue).toBeNull()
    expect(by('wa-monitor').nextDue).toBeNull()
  })
  it('places loops on cadence rings, clock-less ones on the event ring', () => {
    expect(by('gchat-watch').ring).toBe(0)
    expect(by('hot-sync').ring).toBe(1)
    expect(by('daily-briefing').ring).toBe(3)
    expect(by('wa-monitor').ring).toBe(5)
    expect(by('wa-monitor').sched.label).toBe('on comms.message')
  })
  it('uses scheduler jobs for loops with no health row: real next run, last fired, tracking kind', () => {
    const jobs = [
      { name: 'recipe:tech-news', last_run: iso(now - 2 * 3600_000), next_run: iso(now + 3 * 3600_000), run_count: 4 },
      { name: 'loop:weekly', last_run: null, next_run: iso(now + 86400_000), run_count: 0 }
    ]
    const v = buildLoopVMs([{ name: 'tech-news', kind: 'recipe', schedule: '0 0 0/6 * * *', enabled: true }, { name: 'weekly', kind: 'prompt', schedule: '0 0 9 * * 1', enabled: true }, { name: 'hot-sync', kind: 'recipe', schedule: '@every 15m', enabled: true }], health.slice(0, 1), now, jobs)
    const g = (n: string) => v.find((x) => x.name === n)!
    expect(g('tech-news')).toMatchObject({ tracking: 'schedule', state: 'ok', lastRun: now - 2 * 3600_000, lastSuccess: null, nextDue: now + 3 * 3600_000, nextSource: 'scheduler' })
    expect(g('weekly')).toMatchObject({ tracking: 'schedule', state: 'waiting' })
    expect(g('hot-sync')).toMatchObject({ tracking: 'health', state: 'ok', nextSource: 'estimate' })
  })
  it('sorts worst first', () => {
    expect(sortLoops(vms).map((v) => v.name)).toEqual(['gchat-watch', 'wa-monitor', 'daily-briefing', 'hot-sync', 'orphan', 'chat-sweep'])
  })
  it('filters', () => {
    expect(vms.filter((v) => matchesFilter(v, { q: '', mode: 'attention' })).map((v) => v.name)).toEqual(['gchat-watch'])
    expect(vms.filter((v) => matchesFilter(v, { q: 'SYNC', mode: 'all' })).map((v) => v.name)).toEqual(['hot-sync'])
    expect(vms.filter((v) => matchesFilter(v, { q: '', mode: 'disabled' })).map((v) => v.name)).toEqual(['chat-sweep'])
  })
})

describe('kindOf / hashName', () => {
  it('maps kinds, unknowns to other', () => {
    expect(kindOf('recipe')).toBe('recipe')
    expect(kindOf('weird')).toBe('other')
    expect(kindOf(undefined)).toBe('other')
  })
  it('hash is deterministic and spreads names', () => {
    expect(hashName('hot-sync')).toBe(hashName('hot-sync'))
    expect(hashName('hot-sync')).not.toBe(hashName('hot-sync2'))
    expect(hashName('a')).toBe(3826002220) // FNV-1a 32 of "a"
  })
})
