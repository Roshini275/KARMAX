/**
 * Small charts for the Loops screen. They follow the dataviz mark specs: 2px lines with round joins, >= 8px
 * end markers with a 2px surface ring, a recessive hairline grid, direct labels only where they earn their place,
 * a hover crosshair that snaps to the nearest sample and a table twin for the data.
 *
 * Every series here is OBSERVED data (see observed.ts): it starts when this app started watching.
 */
import { useId, useMemo, useState } from 'react'
import { useElementSize, clock, dateTime } from './ui'
import { FRESH_CAP, type FleetPt } from './observed'
import { cn } from '@/design/cn'

const ACCENT = 'var(--accent)'
const MUTED_LINE = 'var(--ink-3)'

/* ── tiny fleet sparkline for KPI tiles ───────────────────────────────── */

/** Step-resamples a time series into `n` evenly spaced points between t0 and t1, carrying the last value forward. */
export function resample(points: Array<[number, number]>, t0: number, t1: number, n = 12): number[] {
  if (points.length === 0 || t1 <= t0) return []
  const out: number[] = []
  let j = 0
  let last = points[0][1]
  for (let i = 0; i < n; i++) {
    const t = t0 + ((t1 - t0) * i) / (n - 1)
    while (j < points.length && points[j][0] <= t) {
      last = points[j][1]
      j++
    }
    out.push(last)
  }
  return out
}

export function fleetValues(fleet: FleetPt[], pick: (p: FleetPt) => number, now: number, minSpanMs = 45_000): { values: number[]; since: number } | null {
  if (fleet.length === 0) return null
  const t0 = fleet[0][0]
  if (now - t0 < minSpanMs) return null
  return { values: resample(fleet.map((p) => [p[0], pick(p)]), t0, now, 12), since: t0 }
}

/** 12-point sparkline: de-emphasis line, the current period (last segment) and end marker in the accent. */
export function MiniSpark({ values, width = 92, height = 30, label }: { values: number[]; width?: number; height?: number; label: string }) {
  const id = useId()
  if (values.length < 2) {
    return (
      <svg width={width} height={height} role="img" aria-label={`${label}: collecting`} className="shrink-0">
        <line x1={4} x2={width - 4} y1={height / 2} y2={height / 2} stroke="var(--axis)" strokeWidth={1.5} strokeDasharray="1 5" strokeLinecap="round" />
      </svg>
    )
  }
  const pad = 5
  const min = Math.min(...values)
  const max = Math.max(...values)
  const span = max - min || 1
  const flat = max === min
  const x = (i: number) => pad + (i * (width - pad * 2)) / (values.length - 1)
  const y = (v: number) => (flat ? height / 2 : height - pad - ((v - min) / span) * (height - pad * 2))
  const d = values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('')
  const tail = values.slice(-3).map((v, i) => `${i ? 'L' : 'M'}${x(values.length - 3 + i).toFixed(1)},${y(v).toFixed(1)}`).join('')
  const last = values.length - 1
  return (
    <svg width={width} height={height} role="img" aria-label={`${label}: ${values[0]} to ${values[last]} over the observed period`} className="shrink-0 overflow-visible">
      <defs>
        <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={MUTED_LINE} stopOpacity="0.14" />
          <stop offset="1" stopColor={MUTED_LINE} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${d}L${x(last)},${height - 2}L${x(0)},${height - 2}Z`} fill={`url(#${id})`} />
      <path d={d} fill="none" stroke={MUTED_LINE} strokeOpacity={0.75} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
      <path d={tail} fill="none" stroke={ACCENT} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={x(last)} cy={y(values[last])} r={4} fill={ACCENT} stroke="var(--surface)" strokeWidth={2} />
    </svg>
  )
}

/* ── per-loop freshness sparkline (grid cards) ────────────────────────── */

export type Series = Array<[number, number | null]>

/** Path segments for a series that may contain null breaks. */
function segments(series: Series, x: (t: number) => number, y: (v: number) => number): string[][] {
  const segs: string[][] = []
  let cur: string[] = []
  for (const [t, v] of series) {
    if (v == null) {
      if (cur.length) segs.push(cur)
      cur = []
    } else cur.push(`${x(t).toFixed(1)},${y(v).toFixed(1)}`)
  }
  if (cur.length) segs.push(cur)
  return segs
}

/**
 * Worst (highest) freshness per bucket. A saw-tooth of "time since last success" carries no information at this size,
 * but its envelope does: flat near 1x while the loop keeps succeeding, climbing when it stalls. A bucket is never
 * narrower than the loop's own interval, so every healthy bucket contains one full cycle.
 */
export function envelope(series: Series, now: number, maxBuckets: number, intervalMs: number | null): Series {
  const pts = series.filter((p): p is [number, number] => p[1] != null)
  if (pts.length < 2) return series
  const t0 = pts[0][0]
  const span = Math.max(1, now - t0)
  const bucket = Math.max(span / maxBuckets, intervalMs ?? 0)
  const n = Math.max(1, Math.ceil(span / bucket))
  const out: Series = []
  const best: (number | null)[] = Array.from({ length: n }, () => null)
  for (const [t, v] of pts) {
    const i = Math.min(n - 1, Math.floor((t - t0) / bucket))
    best[i] = best[i] == null ? v : Math.max(best[i] as number, v)
  }
  best.forEach((v, i) => out.push([t0 + (i + 0.5) * bucket, v]))
  return out
}

export function TimeSpark({ series, now, width = 140, height = 34, label, intervalMs = null }: { series: Series; now: number; width?: number; height?: number; label: string; intervalMs?: number | null }) {
  const nums = series.filter((p) => p[1] != null)
  if (nums.length < 2 || now - series[0][0] < 20_000) {
    return (
      <svg width={width} height={height} role="img" aria-label={`${label}: not enough observations yet`}>
        <line x1={4} x2={width - 4} y1={height / 2} y2={height / 2} stroke="var(--axis)" strokeWidth={1.5} strokeDasharray="1 5" strokeLinecap="round" />
      </svg>
    )
  }
  const pad = 5
  const env = envelope(series, now, Math.floor((width - pad * 2) / 4), intervalMs)
  const t0 = series[0][0]
  const yMax = Math.max(120, ...nums.map((p) => p[1] as number))
  const x = (t: number) => pad + ((t - t0) / Math.max(1, now - t0)) * (width - pad * 2 - 4)
  const y = (v: number) => height - pad - (v / yMax) * (height - pad * 2)
  // The last bucket ends at "now": anchor its point at the newest sample so the end marker is the current reading.
  const lastEnv = env.length - 1
  if (lastEnv >= 0 && env[lastEnv][1] != null) env[lastEnv] = [nums[nums.length - 1][0], env[lastEnv][1]]
  const segs = segments(env, x, y)
  const lastPt = (env[lastEnv]?.[1] != null ? env[lastEnv] : nums[nums.length - 1]) as [number, number]
  return (
    <svg width={width} height={height} role="img" aria-label={label} className="overflow-visible">
      <line x1={pad} x2={width - pad} y1={height - pad} y2={height - pad} stroke="var(--grid)" strokeWidth={1} />
      {segs.map((s, i) => (
        <path key={i} d={`M${s.join('L')}`} fill="none" stroke={MUTED_LINE} strokeOpacity={0.8} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
      ))}
      <circle cx={x(lastPt[0])} cy={y(lastPt[1])} r={4} fill={ACCENT} stroke="var(--surface)" strokeWidth={2} />
    </svg>
  )
}

/* ── the big one: freshness over the observed period (drawer, Activity tab) ─ */

export interface ChartEvent {
  t: number
  kind: 'ok' | 'fail'
}

export function FreshnessChart({ series, events, now, since, height = 176 }: { series: Series; events: ChartEvent[]; now: number; since: number; height?: number }) {
  const [ref, { w }] = useElementSize<HTMLDivElement>()
  const [hover, setHover] = useState<number | null>(null)
  const id = useId()

  const nums = useMemo(() => series.filter((p): p is [number, number] => p[1] != null), [series])
  const t0 = series.length ? Math.max(series[0][0], now - 6 * 3600_000) : now - 60_000
  const M = { l: 36, r: 14, t: 12, b: 24 }
  const iw = Math.max(10, w - M.l - M.r)
  const ih = height - M.t - M.b
  const yMax = Math.max(400, Math.ceil(Math.max(0, ...nums.map((p) => p[1])) / 100) * 100)
  const x = (t: number) => M.l + ((t - t0) / Math.max(1, now - t0)) * iw
  const y = (v: number) => M.t + ih - (Math.min(v, yMax) / yMax) * ih
  const segs = segments(series, x, y)
  const clockSec = (t: number) => `${clock(t)}:${String(new Date(t).getSeconds()).padStart(2, '0')}`
  const ticks = [0, 100, 200, 300, 400].filter((v) => v <= yMax)
  const xTicks = Array.from({ length: 4 }, (_, i) => t0 + ((now - t0) * i) / 3)

  const nearest = (px: number): number | null => {
    if (!nums.length) return null
    const t = t0 + ((px - M.l) / iw) * (now - t0)
    let best = 0
    for (let i = 1; i < nums.length; i++) if (Math.abs(nums[i][0] - t) < Math.abs(nums[best][0] - t)) best = i
    return best
  }
  const hp = hover != null ? nums[hover] : null

  const enough = nums.length >= 2 && now - t0 >= 20_000

  return (
    <div ref={ref} className="relative w-full" style={{ height }}>
      {w > 0 && (
        <svg
          width={w}
          height={height}
          role="img"
          aria-label="Freshness of the last success as a multiple of the loop's interval, observed by this app"
          tabIndex={enough ? 0 : -1}
          className="overflow-visible outline-none focus-visible:[&_.km-plot]:stroke-accent"
          onPointerMove={(e) => {
            const r = e.currentTarget.getBoundingClientRect()
            setHover(nearest(e.clientX - r.left))
          }}
          onPointerLeave={() => setHover(null)}
          onKeyDown={(e) => {
            if (!nums.length) return
            if (e.key === 'ArrowLeft') setHover((h) => Math.max(0, (h ?? nums.length) - 1))
            else if (e.key === 'ArrowRight') setHover((h) => Math.min(nums.length - 1, (h ?? -1) + 1))
            else if (e.key === 'Escape') setHover(null)
          }}
          onBlur={() => setHover(null)}
        >
          <defs>
            <linearGradient id={id} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor="var(--s1)" stopOpacity="0.16" />
              <stop offset="1" stopColor="var(--s1)" stopOpacity="0" />
            </linearGradient>
          </defs>
          <rect className="km-plot" x={M.l} y={M.t} width={iw} height={ih} fill="none" stroke="transparent" strokeWidth={2} rx={4} />
          {ticks.map((v) => (
            <g key={v}>
              <line x1={M.l} x2={M.l + iw} y1={y(v)} y2={y(v)} stroke="var(--grid)" strokeWidth={1} />
              <text x={M.l - 8} y={y(v) + 3.5} textAnchor="end" fontSize={10.5} fill="var(--ink-3)" className="tnum">
                {v / 100}×
              </text>
            </g>
          ))}
          {xTicks.map((t, i) => (
            <text key={i} x={x(t)} y={height - 6} textAnchor={i === 0 ? 'start' : i === xTicks.length - 1 ? 'end' : 'middle'} fontSize={10.5} fill="var(--ink-3)" className="tnum">
              {i === xTicks.length - 1 ? 'now' : now - t0 < 20 * 60_000 ? clockSec(t) : clock(t)}
            </text>
          ))}
          {/* the daemon's own "dark" threshold: three intervals without a success */}
          {yMax >= 300 && (
            <g>
              <line x1={M.l} x2={M.l + iw} y1={y(300)} y2={y(300)} stroke="var(--warn)" strokeOpacity={0.7} strokeWidth={1} strokeDasharray="4 4" />
              <text x={M.l + iw} y={y(300) - 5} textAnchor="end" fontSize={10.5} fill="var(--ink-2)">
                dark at 3×
              </text>
            </g>
          )}
          {enough && segs.map((s, i) => s.length > 1 && <path key={`a${i}`} d={`M${s.join('L')}L${s[s.length - 1].split(',')[0]},${M.t + ih}L${s[0].split(',')[0]},${M.t + ih}Z`} fill={`url(#${id})`} />)}
          {enough &&
            segs.map((s, i) => <path key={`l${i}`} d={`M${s.join('L')}`} fill="none" stroke="var(--s1)" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />)}
          {/* exact events the app saw happen: circle = success, diamond = failure, on the baseline */}
          {events
            .filter((ev) => ev.t >= t0 && ev.t <= now)
            .map((ev, i) =>
              ev.kind === 'ok' ? (
                <circle key={i} cx={x(ev.t)} cy={M.t + ih} r={4} fill="var(--good)" stroke="var(--surface)" strokeWidth={2} />
              ) : (
                <rect key={i} x={x(ev.t) - 4.5} y={M.t + ih - 4.5} width={9} height={9} rx={1.5} transform={`rotate(45 ${x(ev.t)} ${M.t + ih})`} fill="var(--crit-mark)" stroke="var(--surface)" strokeWidth={2} />
              )
            )}
          {enough && nums.length > 0 && !hp && <circle cx={x(nums[nums.length - 1][0])} cy={y(nums[nums.length - 1][1])} r={4} fill="var(--s1)" stroke="var(--surface)" strokeWidth={2} />}
          {hp && (
            <g>
              <line x1={x(hp[0])} x2={x(hp[0])} y1={M.t} y2={M.t + ih} stroke="var(--line-strong)" strokeWidth={1} />
              <circle cx={x(hp[0])} cy={y(hp[1])} r={4} fill="var(--s1)" stroke="var(--surface)" strokeWidth={2} />
            </g>
          )}
          {!enough && (
            <text x={M.l + iw / 2} y={M.t + ih / 2 + 4} textAnchor="middle" fontSize={12} fill="var(--ink-3)" style={{ paintOrder: 'stroke', stroke: 'var(--surface)', strokeWidth: 6, strokeLinejoin: 'round' }}>
              Collecting observations…
            </text>
          )}
        </svg>
      )}
      {hp && (
        <div
          className={cn('glass pointer-events-none absolute z-10 rounded-lg px-2.5 py-1.5 text-[11.5px] shadow-pop')}
          style={{ left: Math.min(Math.max(x(hp[0]) - 70, 0), Math.max(0, w - 150)), top: 0, background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
        >
          <div className="text-[13px] font-semibold tnum text-ink">{(hp[1] / 100).toFixed(2)}×{hp[1] >= FRESH_CAP ? '+' : ''} interval</div>
          <div className="text-ink-3">since last success · {dateTime(hp[0])}</div>
        </div>
      )}
      <span className="sr-only">{since ? `Observed since ${dateTime(since)}` : ''}</span>
    </div>
  )
}
