import { describe, expect, it } from 'vitest'
import { EVENT_RETENTION_MS, FRESH_CAP, GAP_MS, HEARTBEAT_MS, MAX_PTS, emptyObserved, freshnessPct, parseObserved, recordSnapshot, seriesOf, type Snapshot } from './observed'
import { MIN } from './schedule'

const T0 = Date.UTC(2026, 2, 10, 12, 0, 0)
const snap = (o: Partial<Snapshot> = {}): Snapshot => ({ name: 'hot-sync', state: 'ok', running: false, fails: 0, lastSuccess: T0 - 5 * MIN, lastFailure: null, intervalMs: 15 * MIN, ...o })

describe('freshnessPct', () => {
  it('is the age of the last success as a percentage of the interval', () => {
    expect(freshnessPct(15 * MIN, T0 - 5 * MIN, T0)).toBe(33)
    expect(freshnessPct(15 * MIN, T0 - 45 * MIN, T0)).toBe(300)
  })
  it('caps runaway silence and floors clock skew at 0', () => {
    expect(freshnessPct(MIN, T0 - 60 * MIN, T0)).toBe(FRESH_CAP)
    expect(freshnessPct(MIN, T0 + 5000, T0)).toBe(0)
  })
  it('is -1 when unknowable (no interval / never succeeded)', () => {
    expect(freshnessPct(null, T0, T0)).toBe(-1)
    expect(freshnessPct(15 * MIN, null, T0)).toBe(-1)
  })
})

describe('recordSnapshot', () => {
  it('records the first observation and stamps `since`', () => {
    const d = recordSnapshot(emptyObserved(T0), [snap()], T0)
    expect(d.since).toBe(T0)
    expect(d.loops['hot-sync'].pts).toEqual([[T0, 33]])
    expect(d.loops['hot-sync'].ok).toEqual([T0 - 5 * MIN])
    expect(d.fleet).toEqual([[T0, 1, 1, 0, 0, 0]])
  })

  it('returns the SAME object when nothing changed inside the heartbeat (so subscribers do not re-render)', () => {
    const a = recordSnapshot(emptyObserved(T0), [snap()], T0)
    const b = recordSnapshot(a, [snap()], T0 + 4000)
    expect(b).toBe(a)
  })

  it('adds a heartbeat point once the interval has passed', () => {
    const a = recordSnapshot(emptyObserved(T0), [snap()], T0)
    const b = recordSnapshot(a, [snap()], T0 + HEARTBEAT_MS)
    expect(b.loops['hot-sync'].pts).toHaveLength(2)
  })

  it('records immediately when the state changes and remembers each distinct success/failure as an exact marker', () => {
    let d = recordSnapshot(emptyObserved(T0), [snap()], T0)
    d = recordSnapshot(d, [snap({ state: 'failing', fails: 1, lastFailure: T0 + 3000 })], T0 + 4000)
    d = recordSnapshot(d, [snap({ state: 'ok', fails: 0, lastSuccess: T0 + 9000, lastFailure: T0 + 3000 })], T0 + 10_000)
    const l = d.loops['hot-sync']
    expect(l.pts.map((p) => p[0])).toEqual([T0, T0 + 4000, T0 + 10_000])
    expect(l.ok).toEqual([T0 - 5 * MIN, T0 + 9000])
    expect(l.fail).toEqual([T0 + 3000])
  })

  it('does not duplicate a success it has already seen', () => {
    let d = recordSnapshot(emptyObserved(T0), [snap()], T0)
    d = recordSnapshot(d, [snap()], T0 + HEARTBEAT_MS)
    d = recordSnapshot(d, [snap()], T0 + 2 * HEARTBEAT_MS)
    expect(d.loops['hot-sync'].ok).toHaveLength(1)
  })

  it('caps the ring buffer', () => {
    let d = emptyObserved(T0)
    for (let i = 0; i < MAX_PTS + 50; i++) d = recordSnapshot(d, [snap({ lastSuccess: T0 - MIN })], T0 + i * HEARTBEAT_MS)
    expect(d.loops['hot-sync'].pts.length).toBeLessThanOrEqual(MAX_PTS)
  })

  it('drops points beyond the retention window', () => {
    let d = recordSnapshot(emptyObserved(T0), [snap()], T0)
    d = recordSnapshot(d, [snap()], T0 + 7 * 3600_000)
    expect(d.loops['hot-sync'].pts.map((p) => p[0])).toEqual([T0 + 7 * 3600_000])
  })

  it('tracks the fleet counts', () => {
    const d = recordSnapshot(
      emptyObserved(T0),
      [snap({ name: 'a' }), snap({ name: 'b', state: 'failing', fails: 2 }), snap({ name: 'c', state: 'dark' }), snap({ name: 'd', state: 'running', running: true })],
      T0
    )
    expect(d.fleet[0]).toEqual([T0, 4, 1, 1, 1, 1])
  })

  it('forgets a loop that vanished once its data is stale', () => {
    let d = recordSnapshot(emptyObserved(T0), [snap({ name: 'gone' }), snap({ name: 'stay' })], T0)
    d = recordSnapshot(d, [snap({ name: 'stay' })], T0 + 60_000)
    expect(d.loops.gone).toBeDefined() // still inside the window
    d = recordSnapshot(d, [snap({ name: 'stay', lastSuccess: T0 + EVENT_RETENTION_MS + 1 })], T0 + EVENT_RETENTION_MS + 10_000)
    expect(d.loops.gone).toBeUndefined()
  })
})

describe('parseObserved', () => {
  it('round-trips what recordSnapshot produced', () => {
    const d = recordSnapshot(emptyObserved(T0), [snap()], T0)
    expect(parseObserved(JSON.stringify(d), T0 + 1000)).toEqual({ ...d, since: d.since })
  })
  it('discards garbage instead of trusting it', () => {
    expect(parseObserved(null, T0).loops).toEqual({})
    expect(parseObserved('not json', T0).loops).toEqual({})
    expect(parseObserved('{"v":2}', T0).loops).toEqual({})
    expect(parseObserved('{"v":1,"since":1,"loops":{"a":{"pts":"x","ok":[],"fail":[]}},"fleet":[]}', T0).loops).toEqual({})
  })
  it('filters malformed points but keeps the good ones', () => {
    const raw = JSON.stringify({ v: 1, since: T0, loops: { a: { pts: [[T0, 10], ['x', 1], [T0 + 1]], ok: [T0, 'y'], fail: [], sig: 's', lastOk: T0, lastFail: null } }, fleet: [[T0, 1, 1, 0, 0, 0], [1]] })
    const d = parseObserved(raw, T0)
    expect(d.loops.a.pts).toEqual([[T0, 10]])
    expect(d.loops.a.ok).toEqual([T0])
    expect(d.fleet).toHaveLength(1)
  })
})

describe('seriesOf', () => {
  it('breaks the line across an observation gap and on unknown values', () => {
    const l = { pts: [[T0, 10], [T0 + 30_000, 20], [T0 + 30_000 + GAP_MS + 1, 30], [T0 + 30_000 + GAP_MS + 31_000, -1]] as [number, number][], ok: [], fail: [], fired: [], sig: '', lastOk: null, lastFail: null }
    const s = seriesOf(l, T0 + 30_000 + GAP_MS + 31_000, 6 * 3600_000)
    expect(s.map((p) => p[1])).toEqual([10, 20, null, 30, null])
  })
  it('windowing and empty', () => {
    expect(seriesOf(undefined, T0, 1000)).toEqual([])
    const l = { pts: [[T0 - 10_000, 1], [T0, 2]] as [number, number][], ok: [], fail: [], fired: [], sig: '', lastOk: null, lastFail: null }
    expect(seriesOf(l, T0, 5000)).toEqual([[T0, 2]])
  })
})
