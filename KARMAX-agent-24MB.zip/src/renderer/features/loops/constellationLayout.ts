/**
 * Pure geometry for the constellation: where the cadence rings are and which angle each loop sits at.
 * Kept free of React/DOM so the layout rules can be unit tested.
 */
import { hashName } from './model'

export const TAU = Math.PI * 2
export const CORE_R = 44
export const NODE_R = 17

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))

export interface Ring {
  rx: number
  ry: number
}

export interface Geometry {
  cx: number
  cy: number
  /** ry / rx of every ring: the orbital plane is tilted, so orbits are ellipses of one shared aspect. */
  k: number
  rings: Ring[]
  /** Radius (in circle space) that covers the outermost ring: used by the radar sweep. */
  sweepR: number
}

/** Concentric similar ellipses that fit the container; the innermost keeps clear of the core, the outermost of the edges. */
export function ringGeometry(width: number, height: number, ringCount: number): Geometry {
  const cx = width / 2
  const cy = height / 2
  const rxMax = Math.max(120, width / 2 - 56)
  const ryMax = Math.max(90, height / 2 - 56)
  const k = clamp(ryMax / rxMax, 0.42, 0.86)
  const rxUse = Math.min(rxMax, ryMax / k)
  const ryOuter = k * rxUse
  const ry0 = Math.min(CORE_R + NODE_R + 18, ryOuter * 0.5)
  const rings: Ring[] = []
  for (let i = 0; i < ringCount; i++) {
    const t = ringCount === 1 ? 1 : i / (ringCount - 1)
    const ry = ry0 + (ryOuter - ry0) * t
    rings.push({ rx: ry / k, ry })
  }
  return { cx, cy, k, rings, sweepR: rxUse + 14 }
}

export interface AngleInput {
  name: string
  ring: number
}

/**
 * Angle (radians, ellipse parameter) for each loop.
 * Start from a hash of the name so the layout is stable across renders and sessions, then relax deterministically
 * so no two loops sit on nearly the same ray from the core (which would stack their labels on top of each other).
 */
export function computeAngles(nodes: AngleInput[]): Map<string, number> {
  const n = nodes.length
  const sorted = [...nodes].sort((a, b) => a.name.localeCompare(b.name))
  const theta = sorted.map((nd) => (hashName(nd.name) / 0x100000000) * TAU)
  const out = new Map<string, number>()
  if (n === 0) return out
  if (n === 1) {
    out.set(sorted[0].name, theta[0])
    return out
  }

  // Cut the circle at its widest gap so the seam is the least likely place to be constrained, then solve
  //   minimise sum (p_i - t_i)^2  subject to  p_{i+1} - p_i >= minSep
  // exactly, by pool-adjacent-violators on y_i = t_i - i*minSep.
  const minSep = Math.min((28 * Math.PI) / 180, (TAU / n) * 0.92)
  const order = theta.map((_, i) => i).sort((a, b) => theta[a] - theta[b] || a - b)
  let cut = 0
  let widest = -1
  for (let i = 0; i < n; i++) {
    const gap = i === n - 1 ? theta[order[0]] + TAU - theta[order[i]] : theta[order[i + 1]] - theta[order[i]]
    if (gap > widest) {
      widest = gap
      cut = (i + 1) % n
    }
  }
  const seq = Array.from({ length: n }, (_, i) => order[(cut + i) % n])
  const t: number[] = []
  seq.forEach((idx, i) => {
    let v = theta[idx]
    if (i > 0) while (v < t[i - 1]) v += TAU
    t.push(v)
  })

  const y = t.map((v, i) => v - i * minSep)
  const blocks: { sum: number; count: number }[] = []
  for (const v of y) {
    blocks.push({ sum: v, count: 1 })
    while (blocks.length > 1) {
      const b = blocks[blocks.length - 1]
      const a = blocks[blocks.length - 2]
      if (a.sum / a.count <= b.sum / b.count) break
      blocks.splice(blocks.length - 2, 2, { sum: a.sum + b.sum, count: a.count + b.count })
    }
  }
  let p: number[] = []
  for (const b of blocks) for (let j = 0; j < b.count; j++) p.push(b.sum / b.count + p.length * minSep)
  // Packed so tight the seam itself is violated: fall back to even spacing from the first loop.
  if (p[n - 1] - p[0] > TAU - minSep + 1e-9) p = t.map((_, i) => t[0] + (i * TAU) / n)

  seq.forEach((idx, i) => out.set(sorted[idx].name, ((p[i] % TAU) + TAU) % TAU))
  return out
}

export interface Point {
  x: number
  y: number
  /** Faux depth: nodes on the near (lower) side of the tilted plane are drawn a little larger. */
  scale: number
}

export function pointOn(g: Geometry, ring: number, theta: number): Point {
  const r = g.rings[Math.min(ring, g.rings.length - 1)]
  const s = Math.sin(theta)
  return { x: g.cx + r.rx * Math.cos(theta), y: g.cy + r.ry * s, scale: 0.92 + 0.16 * ((s + 1) / 2) }
}

/* ── label placement ───────────────────────────────────────────────────── */

export type LabelSlot = 'below' | 'above' | 'right' | 'left' | 'hidden'

export interface LabelItem {
  name: string
  x: number
  y: number
  /** Visual radius of the node (for keeping other labels off it). */
  r: number
  /** Estimated label width in px. */
  w: number
  /** 1 = name only, 2 = name + state line. */
  lines: 1 | 2
  /** Lower is placed first (and so wins a contested spot). */
  priority: number
  /** Always shown (the hovered node), even if it has to overlap. */
  force?: boolean
}

export interface Box {
  x0: number
  y0: number
  x1: number
  y1: number
}

/** Height of a label block (px): one 11px line, plus a 9.5px state line when the loop is not simply healthy. */
export const labelHeight = (lines: 1 | 2) => (lines === 2 ? 27 : 15)
export const LABEL_GAP = 5

const boxesOverlap = (a: Box, b: Box) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1
const circleHitsBox = (cx: number, cy: number, r: number, b: Box) => {
  const dx = Math.max(b.x0 - cx, 0, cx - b.x1)
  const dy = Math.max(b.y0 - cy, 0, cy - b.y1)
  return dx * dx + dy * dy < r * r
}

/** Top edge of the label block relative to the node centre, and its horizontal anchor, for a slot. */
export function slotOrigin(slot: Exclude<LabelSlot, 'hidden'>, r: number, lines: 1 | 2): { top: number; x: number; anchor: 'middle' | 'start' | 'end' } {
  const H = labelHeight(lines)
  switch (slot) {
    case 'below':
      return { top: r + LABEL_GAP, x: 0, anchor: 'middle' }
    case 'above':
      return { top: -(r + LABEL_GAP) - H, x: 0, anchor: 'middle' }
    case 'right':
      return { top: -H / 2, x: r + LABEL_GAP + 2, anchor: 'start' }
    case 'left':
      return { top: -H / 2, x: -(r + LABEL_GAP + 2), anchor: 'end' }
  }
}

/**
 * Greedy label declutter. Each label is tried below its node, then above, then to the right and left; a label that
 * would overlap another node, an already placed label, a fixed obstacle (ring captions) or leave the map is hidden.
 * Loops with something to say (failing, dark, running, hovered) are placed first so they always win. `prev` breaks
 * ties towards the previous choice so labels do not flicker as the plane drifts.
 */
export function placeLabels(items: LabelItem[], bounds: { w: number; h: number }, obstacles: Box[] = [], prev?: Map<string, LabelSlot>): Map<string, LabelSlot> {
  const out = new Map<string, LabelSlot>()
  const placed: Box[] = []
  const order = [...items].sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name))
  const boxFor = (it: LabelItem, slot: Exclude<LabelSlot, 'hidden'>): Box => {
    const o = slotOrigin(slot, it.r, it.lines)
    const H = labelHeight(it.lines)
    const y0 = it.y + o.top - 1
    const y1 = y0 + H + 2
    if (o.anchor === 'middle') return { x0: it.x - it.w / 2, x1: it.x + it.w / 2, y0, y1 }
    return o.anchor === 'start' ? { x0: it.x + o.x, x1: it.x + o.x + it.w, y0, y1 } : { x0: it.x + o.x - it.w, x1: it.x + o.x, y0, y1 }
  }
  const free = (it: LabelItem, b: Box) =>
    b.x0 >= 4 && b.x1 <= bounds.w - 4 && b.y0 >= 4 && b.y1 <= bounds.h - 4 &&
    !obstacles.some((o) => boxesOverlap(b, o)) &&
    !placed.some((o) => boxesOverlap(b, o)) &&
    !items.some((o) => o !== it && circleHitsBox(o.x, o.y, o.r, b))
  for (const it of order) {
    const base: Exclude<LabelSlot, 'hidden'>[] = ['below', 'above', 'right', 'left']
    const p = prev?.get(it.name)
    const slots = p && p !== 'hidden' ? [p, ...base.filter((s) => s !== p)] : base
    let chosen: LabelSlot = 'hidden'
    for (const s of slots) {
      const b = boxFor(it, s)
      if (free(it, b)) {
        chosen = s
        placed.push(b)
        break
      }
    }
    if (chosen === 'hidden' && it.force) {
      chosen = 'below'
      placed.push(boxFor(it, 'below'))
    }
    out.set(it.name, chosen)
  }
  return out
}
