import { describe, expect, it } from 'vitest'
import { CORE_R, NODE_R, TAU, computeAngles, placeLabels, pointOn, ringGeometry, type LabelItem } from './constellationLayout'

const names = ['tech-news', 'hot-sync', 'profile-refresh', 'daily-briefing', 'hn-digest', 'wa-monitor', 'chat-sweep', 'gchat-watch', 'cold-scan', 'lyzn-tasks', 'memmerge', 'weekly-review']

const circDist = (a: number, b: number) => {
  const d = Math.abs(a - b) % TAU
  return Math.min(d, TAU - d)
}

describe('computeAngles', () => {
  it('is deterministic and independent of input order', () => {
    const a = computeAngles(names.map((name, i) => ({ name, ring: i % 5 })))
    const b = computeAngles([...names].reverse().map((name, i) => ({ name, ring: i % 5 })))
    for (const n of names) expect(a.get(n)).toBeCloseTo(b.get(n)!, 9)
  })
  it('keeps every angle in [0, 2π)', () => {
    for (const v of computeAngles(names.map((name) => ({ name, ring: 0 }))).values()) {
      expect(v).toBeGreaterThanOrEqual(0)
      expect(v).toBeLessThan(TAU)
    }
  })
  it('separates loops so no two share nearly the same ray (12 loops)', () => {
    const a = [...computeAngles(names.map((name) => ({ name, ring: 0 }))).values()]
    let min = Infinity
    for (let i = 0; i < a.length; i++) for (let j = i + 1; j < a.length; j++) min = Math.min(min, circDist(a[i], a[j]))
    expect(min).toBeGreaterThan((20 * Math.PI) / 180)
  })
  it('still terminates and separates as far as it can with many loops', () => {
    const many = Array.from({ length: 60 }, (_, i) => ({ name: `loop-${i}`, ring: 0 }))
    const a = [...computeAngles(many).values()]
    expect(a).toHaveLength(60)
    let min = Infinity
    for (let i = 0; i < a.length; i++) for (let j = i + 1; j < a.length; j++) min = Math.min(min, circDist(a[i], a[j]))
    expect(min).toBeGreaterThan(0.02)
  })
  it('handles 0, 1 and 2 loops', () => {
    expect(computeAngles([]).size).toBe(0)
    expect(computeAngles([{ name: 'a', ring: 0 }]).size).toBe(1)
    const two = computeAngles([{ name: 'a', ring: 0 }, { name: 'b', ring: 1 }])
    expect(circDist(two.get('a')!, two.get('b')!)).toBeGreaterThan(0.3)
  })
})

describe('ringGeometry', () => {
  it('fits the container with the innermost ring clear of the core', () => {
    for (const [w, h] of [[900, 560], [1200, 620], [700, 520], [500, 500]] as const) {
      const g = ringGeometry(w, h, 6)
      expect(g.rings).toHaveLength(6)
      expect(g.rings[0].ry).toBeGreaterThanOrEqual(CORE_R + NODE_R)
      const outer = g.rings[5]
      expect(g.cx + outer.rx).toBeLessThanOrEqual(w)
      expect(g.cx - outer.rx).toBeGreaterThanOrEqual(0)
      expect(g.cy + outer.ry).toBeLessThanOrEqual(h)
      expect(g.cy - outer.ry).toBeGreaterThanOrEqual(0)
    }
  })
  it('rings are strictly nested and share one aspect', () => {
    const g = ringGeometry(1000, 600, 5)
    for (let i = 1; i < g.rings.length; i++) {
      expect(g.rings[i].rx).toBeGreaterThan(g.rings[i - 1].rx)
      expect(g.rings[i].ry / g.rings[i].rx).toBeCloseTo(g.k, 9)
    }
  })
})

describe('pointOn', () => {
  it('sits on its ellipse and is larger on the near side', () => {
    const g = ringGeometry(1000, 600, 5)
    const far = pointOn(g, 2, -Math.PI / 2)
    const near = pointOn(g, 2, Math.PI / 2)
    expect(far.y).toBeLessThan(g.cy)
    expect(near.y).toBeGreaterThan(g.cy)
    expect(near.scale).toBeGreaterThan(far.scale)
    const p = pointOn(g, 3, 1.1)
    const r = g.rings[3]
    expect(((p.x - g.cx) / r.rx) ** 2 + ((p.y - g.cy) / r.ry) ** 2).toBeCloseTo(1, 9)
  })
})

describe('placeLabels', () => {
  const item = (name: string, x: number, y: number, priority = 3, extra: Partial<LabelItem> = {}): LabelItem => ({ name, x, y, r: 16, w: 80, lines: 1, priority, ...extra })
  const bounds = { w: 600, h: 400 }

  it('puts a lone label below its node', () => {
    expect(placeLabels([item('a', 300, 200)], bounds).get('a')).toBe('below')
  })

  it('moves a label above when the space below is taken by another node', () => {
    const slots = placeLabels([item('a', 300, 200), item('b', 300, 232)], bounds)
    expect(slots.get('a')).toBe('above')
  })

  it('falls back to the side of a node when above and below are both taken', () => {
    const slots = placeLabels([item('a', 300, 200), item('up', 300, 160), item('down', 300, 240)], bounds)
    expect(['right', 'left']).toContain(slots.get('a'))
  })

  it('hides the lower-priority label when both spots are contested (here the top edge leaves only one)', () => {
    const slots = placeLabels([item('a', 100, 30, 1), item('b', 110, 32, 3)], { w: 200, h: 400 })
    expect(slots.get('a')).not.toBe('hidden')
    expect(slots.get('b')).toBe('hidden')
  })

  it('always keeps a forced (hovered) label and labels that leave the map are hidden', () => {
    const slots = placeLabels([item('a', 300, 200, 3), item('b', 300, 205, 0, { force: true }), item('edge', 10, 10)], bounds)
    expect(slots.get('b')).toBe('below')
    expect(slots.get('edge')).toBe('hidden')
  })

  it('avoids fixed obstacles and keeps the previous choice when both fit', () => {
    const slots = placeLabels([item('a', 300, 200)], bounds, [{ x0: 250, x1: 350, y0: 210, y1: 240 }])
    expect(slots.get('a')).toBe('above')
    expect(placeLabels([item('a', 300, 200)], bounds, [], new Map([['a', 'above']])).get('a')).toBe('above')
  })
})
