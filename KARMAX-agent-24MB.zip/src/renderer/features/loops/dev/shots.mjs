// Dev-only: screenshots of every Loops view/state against a PRIVATE mock daemon.
//   MOCK_KARMAX_PORT=9112 MOCK_WACLI_PORT=8812 node fixtures/mock-daemon/server.mjs &
//   node src/renderer/features/loops/dev/shots.mjs [scenario ...]      (default: all)
// Env: BASE (vite), QUERY (daemon/wacli override), OUT (default shots/loops).
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const Q = process.env.QUERY || 'daemon=http://127.0.0.1:9112&wacli=http://127.0.0.1:8812'
const OUT = process.env.OUT || 'shots/loops'
const only = process.argv.slice(2)

const chromePath = () => {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}
mkdirSync(OUT, { recursive: true })
const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] })
const errors = new Set()

async function scenario(name, opts, fn) {
  if (only.length && !only.includes(name)) return
  const { theme = 'dark', w = 1440, h = 900, query = Q, route, reduced, view = 'constellation', seed = false, wait = 'networkidle' } = opts
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: theme, reducedMotion: reduced ? 'reduce' : 'no-preference' })
  await ctx.addInitScript(([t, v]) => {
    try {
      localStorage.setItem('km.theme', t)
      localStorage.setItem('km.loops.view', v)
    } catch {}
  }, [theme, view])
  if (seed) await ctx.addInitScript(seedObserved)
  const page = await ctx.newPage()
  page.on('pageerror', (e) => errors.add(`[${name}] pageerror: ${e.message}`))
  page.on('console', (m) => m.type() === 'error' && errors.add(`[${name}] console.error: ${m.text()}`))
  page.on('response', (r) => r.status() === 404 && errors.add(`[${name}] 404 ${r.url()}`))
  if (route) await route(page)
  await page.goto(`${BASE}/?${query}#/loops`, { waitUntil: wait }).catch(() => {})
  await page.waitForTimeout(opts.settle ?? 2500)
  if (fn) await fn(page)
  await page.screenshot({ path: `${OUT}/${name}.png` })
  console.log('saved', name)
  if (opts.cleanup) await opts.cleanup(page).catch(() => {})
  await ctx.close()
}

// Three hours of synthetic "observed" history in localStorage so charts, sparklines and deltas can be reviewed.
function seedObserved() {
  try {
    const now = Date.now()
    const M = 60_000
    const since = now - 3 * 3600_000
    const spec = { 'hot-sync': 15, 'gh-notifications': 10, 'gchat-watch': 5, 'ledger-export': 60, 'calendar-sync': 5, 'inbox-triage': 20, 'hn-digest': 180, 'lyzn-tasks': 1, 'cdn-purge': 30, 'tech-news': 360 }
    const loops = {}
    for (const [name, iv] of Object.entries(spec)) {
      const ivMs = iv * M
      const ok = []
      const fail = []
      const pts = []
      const failing = name === 'gchat-watch' || name === 'ledger-export'
      const dark = name === 'cdn-purge'
      const phase = (name.length * 37_000) % ivMs
      let last = null
      for (let t = since; t <= now - 20_000; t += 60_000) {
        if (dark && t > now - 100 * M) {
          /* silent */
        } else if (!failing || t < now - 45 * M) {
          if ((t - since + phase) % ivMs < 60_000 && t - since > 0) {
            ok.push(t)
            last = t
          }
        } else if ((t - since) % (5 * M) < 60_000) fail.push(t)
        if (last) pts.push([t, Math.min(400, Math.round(((t - last) / ivMs) * 100))])
        // a gap where the app was closed
        if (name !== 'lyzn-tasks' && t > now - 95 * M && t < now - 80 * M) pts.pop()
      }
      loops[name] = { pts, ok, fail, fired: [], sig: '', lastOk: ok[ok.length - 1] ?? null, lastFail: fail[fail.length - 1] ?? null }
    }
    const fleet = []
    for (let t = since; t <= now - 20_000; t += 60_000) {
      const k = Math.floor((t - since) / (30 * M))
      fleet.push([t, 21, 16 - (k % 3 === 2 ? 1 : 0) - (t > now - 45 * M ? 1 : 0), t > now - 45 * M ? 2 : 1, t > now - 100 * M ? 3 : 2, 1])
    }
    localStorage.setItem('km.loops.observed.v1', JSON.stringify({ v: 1, since, loops, fleet }))
  } catch {}
}

const emptyDaemon = async (p) => {
  await p.route(/\/api\/loops(\/health)?(\?.*)?$/, (r) => r.fulfill({ status: 200, contentType: 'application/json', body: '{"loops":[]}' }))
}

const node = (page, n) => {
  const grp = page.locator(`[data-loop-node="${n}"]`)
  const loc = grp.locator('circle[fill="transparent"]').first()
  // The plane drifts, so the element is never "stable": aim at it, let hover freeze the motion, re-aim, then act.
  const aim = async () => {
    const b = await loc.boundingBox()
    await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2)
    await page.waitForTimeout(250)
    const c = await loc.boundingBox()
    await page.mouse.move(c.x + c.width / 2, c.y + c.height / 2)
    return c
  }
  return {
    hover: aim,
    click: async () => {
      const c = await aim()
      await page.mouse.click(c.x + c.width / 2, c.y + c.height / 2)
    },
    focus: () => grp.focus()
  }
}

await scenario('dark', {})
await scenario('dark-tall', { h: 1080 })
await scenario('dark-full', { h: 1250 })
await scenario('light', { theme: 'light' })
await scenario('narrow', { w: 1100, h: 700 })
await scenario('narrow-light', { w: 1100, h: 700, theme: 'light' })
await scenario('reduced-motion', { reduced: true })
await scenario('tooltip', {}, async (p) => {
  await node(p, 'gchat-watch').hover()
  await p.waitForTimeout(500)
})
await scenario('tooltip-light', { theme: 'light' }, async (p) => {
  await node(p, 'lyzn-tasks').hover()
  await p.waitForTimeout(500)
})
await scenario('keyboard-focus', {}, async (p) => {
  await node(p, 'hot-sync').focus()
  await p.keyboard.press('ArrowRight')
  await p.waitForTimeout(400)
})
await scenario('drawer-overview', {}, async (p) => {
  await node(p, 'gchat-watch').click()
  await p.waitForTimeout(900)
})
await scenario('drawer-definition', {}, async (p) => {
  await node(p, 'calendar-sync').click()
  await p.getByRole('tab', { name: /Definition/ }).click()
  await p.waitForTimeout(900)
})
await scenario('drawer-activity', {}, async (p) => {
  await node(p, 'hot-sync').click()
  await p.getByRole('tab', { name: /Activity/ }).click()
  await p.waitForTimeout(900)
})
await scenario('drawer-run-confirm', { theme: 'light' }, async (p) => {
  await node(p, 'inbox-triage').click()
  await p.waitForTimeout(700)
  await p.getByRole('button', { name: /Run now/ }).first().click()
  await p.waitForTimeout(500)
})
await scenario('drawer-light', { theme: 'light' }, async (p) => {
  await node(p, 'cdn-purge').click()
  await p.waitForTimeout(900)
})
await scenario('toggle-toast', { theme: 'light', cleanup: (p) => p.getByRole('button', { name: /^Enable/ }).click().then(() => p.waitForTimeout(600)) }, async (p) => {
  await node(p, 'hot-sync').click()
  await p.waitForTimeout(700)
  await p.getByRole('button', { name: /^Disable/ }).click()
  await p.waitForTimeout(900)
})
await scenario('seeded-dark', { seed: true })
await scenario('seeded-activity', { seed: true }, async (p) => {
  await node(p, 'hot-sync').click()
  await p.getByRole('tab', { name: /Activity/ }).click()
  await p.waitForTimeout(1000)
})
await scenario('seeded-activity-failing', { seed: true, theme: 'light' }, async (p) => {
  await node(p, 'gchat-watch').click()
  await p.getByRole('tab', { name: /Activity/ }).click()
  await p.waitForTimeout(1000)
})
await scenario('seeded-grid', { seed: true, view: 'grid' })
await scenario('seeded-timeline', { seed: true, view: 'timeline' })
await scenario('grid', { view: 'grid' })
await scenario('grid-light', { view: 'grid', theme: 'light' })
await scenario('timeline', { view: 'timeline' }, async (p) => {
  await p.waitForTimeout(500)
  const b = await p.locator('svg[role="img"] circle[r="5"]').first().boundingBox()
  if (b) await p.mouse.move(b.x + b.width / 2, b.y + b.height / 2, { steps: 4 })
  await p.waitForTimeout(400)
})
await scenario('timeline-light', { view: 'timeline', theme: 'light' })
await scenario('registry', { view: 'registry' })
await scenario('registry-light', { view: 'registry', theme: 'light' })
await scenario('consent', { view: 'registry' }, async (p) => {
  await p.getByRole('button', { name: 'Install stripe-watch' }).click()
  await p.waitForTimeout(1200)
})
await scenario('consent-typed', { view: 'registry', h: 1000 }, async (p) => {
  await p.getByRole('button', { name: 'Install news-radar' }).click()
  await p.waitForTimeout(900)
  await p.getByRole('button', { name: /Show the definition/ }).click()
  await p.getByLabel(/Type the loop name/).fill('news-radar')
  await p.waitForTimeout(400)
})
await scenario('consent-409', {
  view: 'registry',
  route: (p) => p.route(/\/api\/loops\/registry\/[^/]+\/install$/, (r) => r.fulfill({ status: 409, contentType: 'application/json', body: JSON.stringify({ error: 'untrusted: workflow signature not countersigned by a trusted registry' }) }))
}, async (p) => {
  await p.getByRole('button', { name: 'Install pr-reviewer' }).click()
  await p.waitForTimeout(900)
  await p.getByLabel(/Type the loop name/).fill('pr-reviewer')
  await p.getByRole('button', { name: /^Install$/ }).click()
  await p.waitForTimeout(900)
})
await scenario('empty', { route: emptyDaemon })
await scenario('empty-light', { theme: 'light', route: emptyDaemon })
await scenario('error', { query: 'daemon=http://127.0.0.1:59999&wacli=http://127.0.0.1:59998', settle: 5000 })
await scenario('error-light', { theme: 'light', query: 'daemon=http://127.0.0.1:59999&wacli=http://127.0.0.1:59998', settle: 5000 })
// Realistic daemon shape: recipes and prompt loops have NO health rows, only scheduler jobs (loopkit:/recipe:/loop:).
await scenario('loading', {
  wait: 'commit',
  settle: 700,
  route: async (p) => {
    await p.route(/\/api\/loops(\/health)?(\?.*)?$/, async (r) => {
      await new Promise((res) => setTimeout(res, 8000))
      await r.continue().catch(() => {})
    })
  }
})
await scenario('unreachable-with-data', { route: (p) => p.route(/\/api\/ping(\?.*)?$/, (r) => r.abort()) })
await scenario('health-error', {
  route: (p) => p.route(/\/api\/loops\/health(\?.*)?$/, (r) => r.fulfill({ status: 500, contentType: 'application/json', body: '{"error":"health store unavailable"}' }))
})
await scenario('tracking-tiers', {
  route: async (p) => {
    await p.route(/\/api\/loops\/health(\?.*)?$/, async (r) => {
      const res = await r.fetch()
      const j = await res.json()
      const keep = new Set(['gchat-watch', 'ledger-export', 'calendar-sync', 'webhook-intake', 'backup-verify', 'lyzn-tasks', 'wa-monitor', 'cold-scan', 'hn-digest', 'weekly-review', 'chat-sweep'])
      await r.fulfill({ response: res, json: { loops: j.loops.filter((l) => keep.has(l.name)) } })
    })
    await p.route(/\/api\/activity(\?.*)?$/, async (r) => {
      const res = await r.fetch()
      const j = await res.json()
      const iso = (ms) => new Date(Date.now() + ms).toISOString()
      const job = (name, last, next) => ({ id: name, name, cron: '', agent: 'karmax-agent', enabled: true, run_count: 12, last_run: iso(last), next_run: iso(next) })
      j.jobs = [...(j.jobs || []), job('recipe:tech-news', -50 * 60000, 5 * 3600000), job('recipe:hot-sync', -6 * 60000, 9 * 60000), job('recipe:inbox-triage', -12 * 60000, 8 * 60000), job('loop:reminder-sync', -20 * 60000, 25 * 60000), job('recipe:cdn-purge', -5 * 3600000, -3 * 3600000)]
      await r.fulfill({ response: res, json: j })
    })
  }
})
await browser.close()
console.log(errors.size ? `\nBROWSER ERRORS:\n - ${[...errors].join('\n - ')}` : '\nno browser errors')
