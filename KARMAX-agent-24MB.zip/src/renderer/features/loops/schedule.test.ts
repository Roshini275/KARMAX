import { describe, expect, it } from 'vitest'
import { DAY, HOUR, MIN, RING_BUCKETS, estimateNextFire, formatEvery, nextCronFire, parseCron, parseGoDuration, ringIndex, scheduleToInterval } from './schedule'

describe('parseGoDuration', () => {
  it('reads single and compound Go durations', () => {
    expect(parseGoDuration('15m')).toBe(15 * MIN)
    expect(parseGoDuration(' 6h ')).toBe(6 * HOUR)
    expect(parseGoDuration('1h30m')).toBe(90 * MIN)
    expect(parseGoDuration('90s')).toBe(90_000)
    expect(parseGoDuration('1.5h')).toBe(90 * MIN)
    expect(parseGoDuration('500ms')).toBe(500)
  })
  it('rejects junk and non-positive values', () => {
    expect(parseGoDuration('')).toBeNull()
    expect(parseGoDuration('soon')).toBeNull()
    expect(parseGoDuration('15')).toBeNull()
    expect(parseGoDuration('0s')).toBeNull()
    expect(parseGoDuration('5m junk')).toBeNull()
  })
})

describe('formatEvery', () => {
  it('picks a natural unit', () => {
    expect(formatEvery(MIN)).toBe('every minute')
    expect(formatEvery(15 * MIN)).toBe('every 15 min')
    expect(formatEvery(90 * MIN)).toBe('every 90 min')
    expect(formatEvery(HOUR)).toBe('every hour')
    expect(formatEvery(6 * HOUR)).toBe('every 6 h')
    expect(formatEvery(DAY)).toBe('daily')
    expect(formatEvery(2 * DAY)).toBe('every 2 d')
    expect(formatEvery(30_000)).toBe('every 30 sec')
  })
})

describe('scheduleToInterval: @every', () => {
  it('is exact', () => {
    expect(scheduleToInterval('@every 15m')).toMatchObject({ kind: 'every', intervalMs: 15 * MIN, label: 'every 15 min', exact: true })
    expect(scheduleToInterval('@every 2m')).toMatchObject({ intervalMs: 2 * MIN, label: 'every 2 min' })
    expect(scheduleToInterval('@every 12h')).toMatchObject({ intervalMs: 12 * HOUR, label: 'every 12 h' })
    expect(scheduleToInterval('@every 1m')).toMatchObject({ label: 'every minute' })
  })
  it('keeps unreadable durations as unknown rather than guessing', () => {
    expect(scheduleToInterval('@every banana')).toMatchObject({ kind: 'unknown', intervalMs: null, label: '@every banana' })
  })
})

describe('scheduleToInterval: cron with seconds', () => {
  it('every N hours', () => {
    expect(scheduleToInterval('0 0 */4 * * *')).toMatchObject({ kind: 'cron', intervalMs: 4 * HOUR, label: 'every 4 h', exact: false })
    expect(scheduleToInterval('0 0 */2 * * *')).toMatchObject({ intervalMs: 2 * HOUR, label: 'every 2 h' })
  })
  it('every N minutes', () => {
    expect(scheduleToInterval('0 */2 * * * *')).toMatchObject({ intervalMs: 2 * MIN, label: 'every 2 min' })
    expect(scheduleToInterval('0 */5 * * * *')).toMatchObject({ intervalMs: 5 * MIN, label: 'every 5 min' })
    // 45 does not divide 60 so the gaps alternate 45/15: the median is one of them, the label stays honest about the spec
    expect(scheduleToInterval('0 */45 * * * *').label).toBe('every 45 min')
  })
  it('daily at a time', () => {
    expect(scheduleToInterval('0 0 8 * * *')).toMatchObject({ intervalMs: DAY, label: 'daily 08:00' })
    expect(scheduleToInterval('0 30 8 * * *')).toMatchObject({ intervalMs: DAY, label: 'daily 08:30' })
    expect(scheduleToInterval('0 0 0 * * *').label).toBe('daily 00:00')
  })
  it('a single weekday', () => {
    expect(scheduleToInterval('0 0 18 * * 5')).toMatchObject({ intervalMs: 7 * DAY, label: 'Fridays 18:00' })
    expect(scheduleToInterval('0 0 9 * * MON').label).toBe('Mondays 09:00')
    expect(scheduleToInterval('0 0 9 * * 7').label).toBe('Sundays 09:00')
  })
  it('weekday ranges and lists', () => {
    const wk = scheduleToInterval('0 0 9 * * 1-5')
    expect(wk.label).toBe('weekdays 09:00')
    expect(wk.intervalMs).toBe(DAY) // median gap: four 24h gaps for every 72h one
    expect(scheduleToInterval('0 0 9 * * 0,6').label).toBe('weekends 09:00')
    expect(scheduleToInterval('0 0 9 * * 1,3,5').label).toBe('Mon, Wed, Fri 09:00')
  })
  it('several times a day', () => {
    expect(scheduleToInterval('0 0 8,20 * * *').label).toBe('daily 08:00 & 20:00')
  })
  it('monthly and yearly', () => {
    expect(scheduleToInterval('0 0 9 1 * *')).toMatchObject({ label: 'monthly on the 1st, 09:00' })
    expect(scheduleToInterval('0 0 9 1 * *').intervalMs).toBeGreaterThanOrEqual(28 * DAY)
    expect(scheduleToInterval('0 0 9 22 * *').label).toBe('monthly on the 22nd, 09:00')
    expect(scheduleToInterval('0 0 0 1 1 *').label).toBe('yearly Jan 1, 00:00')
  })
  it('sub-minute', () => {
    expect(scheduleToInterval('*/30 * * * * *')).toMatchObject({ intervalMs: 30_000, label: 'every 30 sec' })
  })
})

describe('scheduleToInterval: 5-field cron and descriptors', () => {
  it('accepts five fields (recipes allow them)', () => {
    expect(scheduleToInterval('0 9 * * *')).toMatchObject({ intervalMs: DAY, label: 'daily 09:00' })
    expect(scheduleToInterval('*/10 * * * *')).toMatchObject({ intervalMs: 10 * MIN, label: 'every 10 min' })
  })
  it('an hour range (real: daily-post is "0 18-22 * * *")', () => {
    const s = scheduleToInterval('0 18-22 * * *')
    expect(s.label).toBe('hourly 18:00–22:00')
    expect(s.intervalMs).toBe(HOUR)
  })
  it('descriptors', () => {
    expect(scheduleToInterval('@daily')).toMatchObject({ kind: 'descriptor', intervalMs: DAY, label: 'daily 00:00' })
    expect(scheduleToInterval('@hourly')).toMatchObject({ intervalMs: HOUR, label: 'every hour' })
    expect(scheduleToInterval('@weekly')).toMatchObject({ intervalMs: 7 * DAY })
    expect(scheduleToInterval('@yearly').intervalMs).toBeGreaterThanOrEqual(365 * DAY)
  })
})

describe('scheduleToInterval: no clock', () => {
  it('describes event-driven loops from the hints', () => {
    expect(scheduleToInterval('', { events: ['comms.message'] })).toMatchObject({ kind: 'event', intervalMs: null, label: 'on comms.message' })
    expect(scheduleToInterval('', { events: ['a', 'b', 'c'] }).label).toBe('on a +2')
    expect(scheduleToInterval('', { webhook: '/hooks/x' })).toMatchObject({ kind: 'event', label: 'webhook /hooks/x' })
  })
  it('manual when there is nothing at all', () => {
    expect(scheduleToInterval('')).toMatchObject({ kind: 'manual', intervalMs: null, label: 'on demand' })
    expect(scheduleToInterval(undefined).kind).toBe('manual')
  })
  it('never throws on garbage', () => {
    expect(scheduleToInterval('0 0 99 * * *')).toMatchObject({ kind: 'unknown', intervalMs: null })
    expect(scheduleToInterval('lol')).toMatchObject({ kind: 'unknown', label: 'lol' })
    expect(scheduleToInterval('* * *').kind).toBe('unknown')
  })
})

describe('nextCronFire', () => {
  const at = (y: number, mo: number, d: number, h = 0, mi = 0, s = 0) => new Date(y, mo - 1, d, h, mi, s).getTime()
  it('finds the next daily fire, today or tomorrow', () => {
    expect(nextCronFire('0 0 8 * * *', at(2026, 3, 10, 7, 0))).toBe(at(2026, 3, 10, 8, 0))
    expect(nextCronFire('0 0 8 * * *', at(2026, 3, 10, 8, 0))).toBe(at(2026, 3, 11, 8, 0))
    expect(nextCronFire('0 0 8 * * *', at(2026, 3, 10, 9, 0))).toBe(at(2026, 3, 11, 8, 0))
  })
  it('steps', () => {
    expect(nextCronFire('0 0 */4 * * *', at(2026, 3, 10, 5, 30))).toBe(at(2026, 3, 10, 8, 0))
    expect(nextCronFire('0 */15 * * * *', at(2026, 3, 10, 5, 31))).toBe(at(2026, 3, 10, 5, 45))
  })
  it('weekday (2026-03-10 is a Tuesday)', () => {
    expect(nextCronFire('0 0 18 * * 5', at(2026, 3, 10, 12))).toBe(at(2026, 3, 13, 18, 0))
    expect(nextCronFire('0 0 9 * * 1-5', at(2026, 3, 13, 10))).toBe(at(2026, 3, 16, 9, 0)) // Fri -> Mon
  })
  it('day of month and rolling over the month / year', () => {
    expect(nextCronFire('0 0 9 1 * *', at(2026, 3, 10))).toBe(at(2026, 4, 1, 9))
    expect(nextCronFire('0 0 0 1 1 *', at(2026, 3, 10))).toBe(at(2027, 1, 1))
  })
  it('ORs day-of-month with day-of-week when both are restricted (robfig semantics)', () => {
    // the 15th OR any Monday
    expect(nextCronFire('0 0 9 15 * 1', at(2026, 3, 10))).toBe(at(2026, 3, 15, 9)) // Sunday 15th comes before Monday 16th
    expect(nextCronFire('0 0 9 15 * 1', at(2026, 3, 9, 10))).toBe(at(2026, 3, 15, 9))
  })
  it('null for an impossible date', () => {
    expect(nextCronFire('0 0 0 31 2 *', at(2026, 1, 1))).toBeNull()
    expect(nextCronFire('nope', at(2026, 1, 1))).toBeNull()
  })
})

describe('parseCron', () => {
  it('validates bounds', () => {
    expect(parseCron('0 0 24 * * *')).toBeNull()
    expect(parseCron('0 60 * * * *')).toBeNull()
    expect(parseCron('0 0 0 0 * *')).toBeNull()
    expect(parseCron('0 0 0 * 13 *')).toBeNull()
    expect(parseCron('0 0 0 * * *')).not.toBeNull()
  })
})

describe('estimateNextFire', () => {
  const now = new Date(2026, 2, 10, 12, 0, 0).getTime()
  it('@every is last attempt + interval, and null with no history', () => {
    expect(estimateNextFire('@every 15m', { lastRun: now - 5 * MIN, now })).toBe(now + 10 * MIN)
    expect(estimateNextFire('@every 15m', { lastRun: null, now })).toBeNull()
  })
  it('an overdue @every loop reports a time in the past, so the UI can say overdue', () => {
    expect(estimateNextFire('@every 15m', { lastRun: now - 40 * MIN, now })).toBeLessThan(now)
  })
  it('cron is the next wall-clock match', () => {
    expect(estimateNextFire('0 0 18 * * *', { now })).toBe(new Date(2026, 2, 10, 18, 0, 0).getTime())
    expect(estimateNextFire('@daily', { now })).toBe(new Date(2026, 2, 11, 0, 0, 0).getTime())
  })
  it('null for event-driven', () => {
    expect(estimateNextFire('', { now, lastRun: now })).toBeNull()
  })
})

describe('ringIndex', () => {
  it('buckets by cadence', () => {
    expect(ringIndex(MIN)).toBe(0)
    expect(ringIndex(5 * MIN)).toBe(0)
    expect(ringIndex(5 * MIN + 1)).toBe(1)
    expect(ringIndex(HOUR)).toBe(1)
    expect(ringIndex(4 * HOUR)).toBe(2)
    expect(ringIndex(6 * HOUR)).toBe(2)
    expect(ringIndex(12 * HOUR)).toBe(3)
    expect(ringIndex(DAY)).toBe(3)
    expect(ringIndex(7 * DAY)).toBe(4)
  })
  it('puts clock-less loops on the event ring', () => {
    expect(ringIndex(null)).toBe(RING_BUCKETS.length)
  })
})
