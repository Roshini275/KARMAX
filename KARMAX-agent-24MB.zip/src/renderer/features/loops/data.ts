/**
 * Data layer of the Loops screen: joined view-models, observed-history recording, and the mutations
 * (run / enable / disable / install / uninstall). Only endpoints in lib/api/client.ts are used.
 */
import { useEffect, useMemo } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '@/lib/api/client'
import { qk, useActivity, useLoopHealth, useLoops } from '@/lib/api/hooks'
import { buildLoopVMs, sortLoops, type LoopVM } from './model'
import { useObserved, type Snapshot } from './observed'
import { useToasts } from './ui'

type LoopsData = Awaited<ReturnType<typeof api.loops.list>>

export interface LoopData {
  vms: LoopVM[]
  /** true until the FIRST answer to GET /api/loops. */
  loading: boolean
  /** Error from GET /api/loops (the screen cannot render without it). */
  error: unknown
  /** Health poll failed while loops loaded: states are then only as good as the last poll. */
  healthError: unknown
  /** When the last successful health/loops poll landed (epoch ms). */
  updatedAt: number
  fetching: boolean
  refetch: () => void
}

export function useLoopData(): LoopData {
  const listQ = useLoops()
  const healthQ = useLoopHealth()
  // Optional enrichment: the scheduler's real last/next fire for every job (recipes and prompt loops have no health row).
  const activityQ = useActivity()
  const record = useObserved((s) => s.record)

  const vms = useMemo(
    () => sortLoops(buildLoopVMs(listQ.data?.loops ?? [], healthQ.data?.loops ?? [], Date.now(), activityQ.data?.jobs ?? [])),
    // dataUpdatedAt changes on every successful poll, including ones that return identical data
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [listQ.data, healthQ.data, activityQ.data, listQ.dataUpdatedAt, healthQ.dataUpdatedAt, activityQ.dataUpdatedAt]
  )

  // Feed every successful health poll into the observed-history ring buffer.
  const healthAt = healthQ.dataUpdatedAt
  useEffect(() => {
    // Record when EITHER source answers: recipes/prompt loops only have scheduler facts.
    if (!listQ.data) return
    const snaps: Snapshot[] = vms
      .filter((v) => v.enabled || v.health)
      .map((v) => ({
        name: v.name,
        state: v.state,
        running: !!v.health?.running,
        fails: v.health?.consecutiveFailures ?? 0,
        lastSuccess: v.lastSuccess,
        lastFailure: v.lastFailure,
        lastFired: v.tracking === 'schedule' ? v.lastRun : null,
        intervalMs: v.sched.intervalMs
      }))
    record(snaps, Date.now())
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [healthAt, activityQ.dataUpdatedAt])

  return {
    vms,
    loading: listQ.isPending,
    error: listQ.error,
    healthError: healthQ.error,
    updatedAt: Math.max(listQ.dataUpdatedAt, healthQ.dataUpdatedAt),
    fetching: listQ.isFetching || healthQ.isFetching,
    refetch: () => {
      void listQ.refetch()
      void healthQ.refetch()
    }
  }
}

const errText = (e: unknown) => (e instanceof Error ? e.message : String(e))

/* ── run / enable / disable ────────────────────────────────────────────── */

export function useRunLoop() {
  const qc = useQueryClient()
  const push = useToasts((s) => s.push)
  return useMutation({
    mutationFn: (name: string) => api.loops.run(name),
    onSuccess: (_d, name) => {
      push('ok', `Run requested for ${name}. It will show as running on the next health poll.`)
      // The daemon answers as soon as the run is accepted; pick up the lease quickly.
      setTimeout(() => void qc.invalidateQueries({ queryKey: qk.loopHealth }), 800)
    },
    onError: (e, name) => push('error', `Could not run ${name}: ${errText(e)}`)
  })
}

export function useToggleLoop() {
  const qc = useQueryClient()
  const push = useToasts((s) => s.push)
  return useMutation({
    mutationFn: ({ name, enable }: { name: string; enable: boolean }) => (enable ? api.loops.enable(name) : api.loops.disable(name)),
    // Optimistic: flip the switch immediately, roll back if the daemon refuses.
    onMutate: async ({ name, enable }) => {
      await qc.cancelQueries({ queryKey: qk.loops, exact: true })
      const prev = qc.getQueryData<LoopsData>(qk.loops)
      qc.setQueryData<LoopsData>(qk.loops, (old) => (old ? { ...old, loops: old.loops.map((l) => (l.name === name ? { ...l, enabled: enable } : l)) } : old))
      return { prev }
    },
    onError: (e, { name, enable }, ctx) => {
      if (ctx?.prev) qc.setQueryData(qk.loops, ctx.prev)
      push('error', `Could not ${enable ? 'enable' : 'disable'} ${name}: ${errText(e)}`)
    },
    onSuccess: (_d, { name, enable }) => push('ok', `${name} ${enable ? 'enabled' : 'disabled'}.`),
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: qk.loops, exact: true })
      void qc.invalidateQueries({ queryKey: qk.loopHealth })
      void qc.invalidateQueries({ queryKey: qk.registry, exact: true })
    }
  })
}

/* ── registry ──────────────────────────────────────────────────────────── */

export function useRegistry() {
  return useQuery({ queryKey: qk.registry, queryFn: () => api.loops.registry(), staleTime: 60_000, retry: false, refetchOnMount: 'always' })
}

export function useRegistryRefresh() {
  const qc = useQueryClient()
  return useMutation({
    // ?refresh=1 bypasses the daemon's 5-minute index cache
    mutationFn: () => api.loops.registry(true),
    onSuccess: (data) => qc.setQueryData(qk.registry, data)
  })
}

export function useRegistryDetail(name: string | null, enabled = true) {
  return useQuery({
    queryKey: [...qk.registry, name] as const,
    queryFn: () => api.loops.registryDetail(name as string),
    enabled: !!name && enabled,
    staleTime: 5 * 60_000,
    retry: false
  })
}

export interface InstallResult {
  installed?: boolean
  restartRequired?: boolean
  message?: string
}

const asResult = (b: unknown): InstallResult => (b && typeof b === 'object' ? (b as InstallResult) : {})

export function useInstallLoop() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async ({ name, allowUntrusted }: { name: string; allowUntrusted: boolean }) => asResult(await api.loops.install(name, allowUntrusted)),
    onSettled: () => void qc.invalidateQueries({ queryKey: qk.loops })
  })
}

export function useUninstallLoop() {
  const qc = useQueryClient()
  const push = useToasts((s) => s.push)
  return useMutation({
    mutationFn: async (name: string) => asResult(await api.loops.uninstall(name)),
    onSuccess: (r, name) => push('ok', `${name} uninstalled.${r.restartRequired ? ' Restart KARMAX to finish removing it.' : ''}`),
    onError: (e, name) => push('error', `Could not uninstall ${name}: ${errText(e)}`),
    onSettled: () => void qc.invalidateQueries({ queryKey: qk.loops })
  })
}
