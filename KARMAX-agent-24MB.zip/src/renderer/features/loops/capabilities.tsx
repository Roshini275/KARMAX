/**
 * "What will it be allowed to do": the tools + host functions a loop declares, and its raw definition.
 * Shared by the drawer's Definition tab and the install consent dialog.
 */
import { useMemo } from 'react'
import { Cpu, ShieldAlert, Wrench } from 'lucide-react'
import { cn } from '@/design/cn'
import { CopyButton } from './ui'

/**
 * Plain-English meaning of each host function a signed workflow can import.
 * Copied from KARMAX/internal/wasmloop/host.go `hostDescriptions` (the same text the CLI shows before install),
 * so the desktop app and the terminal describe the same thing the same way.
 */
export const HOST_DESCRIPTIONS: Record<string, string> = {
  log: "write to KARMAX's log",
  recall: 'read your long-term memory',
  remember: 'write to your long-term memory',
  notify: 'send you notifications',
  http: 'use the network, but only the hosts it lists',
  trigger: 'see what triggered it',
  ask: 'ask your agent questions (which can use its tools)',
  config: 'read the settings you gave it at install',
  hosttool: 'learn where wacli and gog live (a path, not permission to run them)',
  harness: 'run a coding harness: shell, files and web research',
  gateway: 'ask the main model directly',
  session: 'hold a long-lived conversation with a coding harness',
  summarize: 'summarise text with the cheap model',
  propose: 'ask for your approval before acting',
  remind: 'put reminders on your list',
  tool: 'call the tools listed above, and nothing else',
  short_set: 'keep short-term working notes',
  short_get: 'read its short-term working notes',
  short_all: 'read all its short-term working notes',
  chat_summary_get: 'read stored per-chat summaries',
  chat_summary_save: 'write stored per-chat summaries',
  run_loop: 'trigger your other loops',
  short_forget: 'clear its short-term working notes',
  operator_chats: 'know which chats are yours rather than someone else\'s'
}

/** Host functions that let a loop reach beyond reading: run code, use the network, write memory, or message you. */
export const ELEVATED_HOST = new Set(['harness', 'session', 'gateway', 'ask', 'http', 'remember', 'notify', 'run_loop', 'chat_summary_save'])

/** Heuristic, by name only: tools that sound like they send or publish something. Labelled as such in the UI. */
export const looksOutward = (tool: string) => /(^|[._:-])(send|post|publish|push|write|delete|reply|create)([._:-]|$)/i.test(tool) || /(_send_|_post|\.post$)/i.test(tool)

function Row({ name, desc, flag, mono = true }: { name: string; desc?: string; flag?: string; mono?: boolean }) {
  return (
    <li className="flex items-start gap-3 rounded-lg px-2.5 py-1.5 odd:bg-surface-2/50">
      <span className={cn('min-w-[112px] shrink-0 text-[12px] text-ink', mono && 'font-[family-name:var(--font-mono)] text-[11.5px]')}>{name}</span>
      <span className="min-w-0 flex-1 text-[12px] text-ink-2">{desc}</span>
      {flag && (
        <span className="inline-flex shrink-0 items-center gap-1 text-[10.5px] font-semibold text-ink-2" title={flag}>
          <ShieldAlert className="size-3" /> {flag.startsWith('Sounds') ? 'sends/publishes?' : 'acts outward'}
        </span>
      )}
    </li>
  )
}

export function CapabilityList({ tools, host, kind }: { tools: string[]; host: string[]; kind: string }) {
  const elevated = host.filter((h) => ELEVATED_HOST.has(h))
  const outward = tools.filter(looksOutward)
  return (
    <div className="space-y-4">
      {(elevated.length > 0 || outward.length > 0) && (
        <div className="flex items-start gap-2.5 rounded-xl bg-surface-2 px-3 py-2.5 text-[12px] leading-relaxed text-ink-2 ring-1 ring-line-strong">
          <ShieldAlert className="mt-0.5 size-4 shrink-0 text-ink" />
          <div>
            {elevated.length > 0 && (
              <p>
                <span className="font-semibold text-ink">{elevated.length} host function{elevated.length === 1 ? '' : 's'} can act beyond reading</span> ({elevated.join(', ')}).
              </p>
            )}
            {outward.length > 0 && (
              <p className={cn(elevated.length > 0 && 'mt-1')}>
                <span className="font-semibold text-ink">By name, {outward.length} tool{outward.length === 1 ? '' : 's'} sound{outward.length === 1 ? 's' : ''} like {outward.length === 1 ? 'it sends or publishes' : 'they send or publish'}</span> ({outward.join(', ')}). That is a guess from the name, not a verified effect.
              </p>
            )}
          </div>
        </div>
      )}

      <section>
        <h4 className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-semibold uppercase tracking-[0.08em] text-ink-3">
          <Wrench className="size-3.5" /> KARMAX tools it may call <span className="tnum font-medium">{tools.length}</span>
        </h4>
        {tools.length === 0 ? (
          <p className="rounded-lg bg-surface-2/50 px-2.5 py-2 text-[12px] text-ink-3">
            {kind === 'recipe' ? 'None named. A recipe runs in the KARMAX interpreter and can only use the verbs its steps write out.' : 'None declared: it cannot call any KARMAX tool.'}
          </p>
        ) : (
          <ul>{tools.map((t) => <Row key={t} name={t} flag={looksOutward(t) ? 'Sounds like it sends or publishes (guessed from the name)' : undefined} />)}</ul>
        )}
      </section>

      <section>
        <h4 className="mb-1.5 flex items-center gap-1.5 text-[11.5px] font-semibold uppercase tracking-[0.08em] text-ink-3">
          <Cpu className="size-3.5" /> Host functions <span className="tnum font-medium">{host.length}</span>
        </h4>
        {host.length === 0 ? (
          <p className="rounded-lg bg-surface-2/50 px-2.5 py-2 text-[12px] text-ink-3">{kind === 'workflow' ? 'None declared: only the sandbox itself.' : 'Not applicable: host functions belong to signed workflows, and this is not one.'}</p>
        ) : (
          <ul>{host.map((h) => <Row key={h} name={h} desc={HOST_DESCRIPTIONS[h] ?? 'a host function this app does not have a description for'} flag={ELEVATED_HOST.has(h) ? 'Can act beyond reading' : undefined} />)}</ul>
        )}
      </section>
    </div>
  )
}

/** Raw YAML in a mono block: comments dimmed, keys emphasised. Text is inserted as text nodes, never as HTML. */
export function YamlBlock({ text, maxHeight = 320 }: { text: string; maxHeight?: number }) {
  const lines = useMemo(() => text.replace(/\r\n/g, '\n').replace(/\n+$/, '').split('\n'), [text])
  return (
    <div className="relative overflow-hidden rounded-xl bg-[color-mix(in_oklab,var(--page)_70%,var(--surface))] ring-1 ring-line">
      <div className="absolute right-1.5 top-1.5 z-10">
        <CopyButton text={text} label="Copy definition" />
      </div>
      <pre className="selectable scroll-thin overflow-auto py-2.5 font-[family-name:var(--font-mono)] text-[11.5px] leading-[1.6]" style={{ maxHeight }} tabIndex={0} aria-label="Definition (YAML)">
        {lines.map((ln, i) => {
          const comment = /^\s*#/.test(ln)
          const m = /^(\s*(?:-\s+)?)([A-Za-z0-9_.-]+)(:)(.*)$/.exec(ln)
          return (
            <div key={i} className="flex px-3 hover:bg-surface-2/40">
              <span className="mr-3 inline-block w-6 shrink-0 select-none text-right text-ink-3/70 tnum">{i + 1}</span>
              <code className="min-w-0 whitespace-pre-wrap break-words">
                {comment ? (
                  <span className="text-ink-3">{ln}</span>
                ) : m ? (
                  <>
                    <span className="text-ink-2">{m[1]}</span>
                    <span className="font-semibold text-ink">{m[2]}</span>
                    <span className="text-ink-3">{m[3]}</span>
                    <span className="text-ink-2">{m[4]}</span>
                  </>
                ) : (
                  <span className="text-ink-2">{ln || ' '}</span>
                )}
              </code>
            </div>
          )
        })}
      </pre>
    </div>
  )
}
