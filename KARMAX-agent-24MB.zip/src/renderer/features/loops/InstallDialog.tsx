/**
 * Consent dialog, modelled on the CLI's install screen: shown what it will be allowed to do BEFORE anything is
 * written, and for anything that does not ship with the engine an explicit acknowledgement that mirrors
 * `--untrusted`: you must type the loop's name.
 */
import { useEffect, useRef, useState } from 'react'
import { AlertTriangle, CheckCircle2, Download, RotateCcw, ShieldAlert } from 'lucide-react'
import { Button, ErrorNote, Input, Skeleton } from '@/design/primitives'
import { ApiError } from '@/lib/api/client'
import type { RegistryEntry } from '@/lib/api/schemas'
import { CapabilityList, YamlBlock } from './capabilities'
import { useInstallLoop, useRegistryDetail, type InstallResult } from './data'
import { KIND_META, kindOf } from './model'
import { Chip, KindGlyph, Modal } from './ui'

export function InstallDialog({ entry, onClose }: { entry: RegistryEntry | null; onClose: () => void }) {
  // Keep the entry mounted through the exit animation, then drop it so the next open starts from a clean consent
  // (nothing typed, no old result or error).
  const [shown, setShown] = useState<RegistryEntry | null>(entry)
  useEffect(() => {
    if (entry) {
      setShown(entry)
      return
    }
    const t = setTimeout(() => setShown(null), 400)
    return () => clearTimeout(t)
  }, [entry])
  const e = entry ?? shown
  if (!e) return null
  return <Session key={e.name} entry={e} open={!!entry} onClose={onClose} />
}

function Session({ entry, open, onClose }: { entry: RegistryEntry; open: boolean; onClose: () => void }) {
  const detail = useRegistryDetail(entry.name)
  const install = useInstallLoop()
  const [typed, setTyped] = useState('')
  const [showDef, setShowDef] = useState(false)
  const [result, setResult] = useState<InstallResult | null>(null)
  const kind = kindOf(entry.kind)
  const needsAck = !entry.shipsWithEngine
  const ackOk = !needsAck || typed === entry.name
  const errStatus = install.error instanceof ApiError ? install.error.status : 0

  const errRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (install.error) errRef.current?.scrollIntoView({ block: 'nearest' })
  }, [install.error])

  const go = () => install.mutate({ name: entry.name, allowUntrusted: needsAck }, { onSuccess: (r) => setResult(r) })
  const verb = entry.installed ? 'Reinstall' : 'Install'

  const footer = result ? (
    <Button variant="primary" onClick={onClose} data-autofocus>Done</Button>
  ) : (
    <div className="flex w-full items-center gap-3">
      {needsAck ? (
        <Input
          value={typed}
          onChange={(ev) => setTyped(ev.target.value)}
          placeholder={`Type ${entry.name} to confirm`}
          spellCheck={false}
          autoComplete="off"
          aria-label={`Type the loop name, ${entry.name}, to confirm you accept it`}
          className="h-9 min-w-0 max-w-[300px] flex-1 font-[family-name:var(--font-mono)] text-[12.5px]"
        />
      ) : (
        <span className="text-[11.5px] text-ink-3">Nothing is written until you press Install.</span>
      )}
      <div className="ml-auto flex shrink-0 gap-2">
        <Button variant="ghost" onClick={onClose} disabled={install.isPending} data-autofocus>Cancel</Button>
        <Button variant="primary" icon={<Download className="size-3.5" />} loading={install.isPending} disabled={!ackOk || !!detail.error || detail.isPending} onClick={go}>
          {verb}
        </Button>
      </div>
    </div>
  )

  return (
    <Modal
      open={open}
      onClose={onClose}
      width={680}
      title={<span className="flex items-center gap-2.5"><KindGlyph kind={kind} size={18} />{verb} {entry.name}</span>}
      subtitle={`${KIND_META[kind].label} · v${entry.version || '?'}${entry.author ? ` · by ${entry.author}` : ''}`}
      footer={footer}
    >
      {result ? (
        <div className="space-y-4" role="status">
          <div className="flex items-start gap-3 rounded-xl bg-[color-mix(in_oklab,var(--good)_10%,transparent)] p-4 ring-1 ring-[color-mix(in_oklab,var(--good)_30%,transparent)]">
            <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-good" />
            <div>
              <div className="text-[13.5px] font-semibold text-ink">{entry.name} installed</div>
              <p className="selectable mt-1 text-[12.5px] leading-relaxed text-ink-2">{result.message || 'The daemon accepted the install.'}</p>
            </div>
          </div>
          {result.restartRequired && (
            <div className="flex items-start gap-3 rounded-xl bg-surface-2 p-4 ring-1 ring-line-strong">
              <RotateCcw className="mt-0.5 size-4 shrink-0 text-ink" />
              <p className="text-[12.5px] leading-relaxed text-ink-2"><span className="font-semibold text-ink">Restart KARMAX to run it.</span> Signed workflows are loaded when the daemon starts, so it will not appear as an active loop until then. Use the KARMAX service controls in Settings.</p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          <p className="selectable text-[12.5px] leading-relaxed text-ink-2">{entry.description || 'No description.'}</p>
          {entry.requires.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="label-micro mr-1">Requires</span>
              {entry.requires.map((r) => <Chip key={r} mono>{r}</Chip>)}
            </div>
          )}

          <div>
            <h3 className="mb-2 text-[13px] font-semibold text-ink">What it will be allowed to do</h3>
            {detail.isPending ? (
              <div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-24 w-full" /></div>
            ) : detail.error ? (
              <div className="space-y-2">
                <ErrorNote error={detail.error} onRetry={() => void detail.refetch()} />
                <p className="text-[11.5px] text-ink-3">The definition could not be fetched, so you cannot see what this loop asks for. Installing without seeing it is disabled.</p>
              </div>
            ) : (
              <>
                <CapabilityList tools={detail.data.tools} host={detail.data.host} kind={kind} />
                <div className="mt-4">
                  <button className="text-[12px] font-medium text-accent hover:underline" onClick={() => setShowDef((s) => !s)} aria-expanded={showDef}>
                    {showDef ? 'Hide definition' : 'Show the definition that will be installed'}
                  </button>
                  {showDef && <div className="mt-2">{detail.data.definition ? <YamlBlock text={detail.data.definition} /> : <p className="text-[12px] text-ink-3">The registry returned no definition text.</p>}</div>}
                </div>
              </>
            )}
          </div>

          {kind === 'workflow' && (
            <div className="flex items-start gap-3 rounded-xl bg-surface-2 p-3.5 ring-1 ring-line-strong">
              <RotateCcw className="mt-0.5 size-4 shrink-0 text-ink" />
              <p className="text-[12.5px] leading-relaxed text-ink-2"><span className="font-semibold text-ink">This is a signed workflow: KARMAX needs a restart before it runs.</span> The install verifies its digest and signature first, then waits for the next daemon start.</p>
            </div>
          )}

          {needsAck && (
            <div className="rounded-xl p-3.5 ring-1 ring-[color-mix(in_oklab,var(--warn)_45%,transparent)]" style={{ background: 'color-mix(in oklab, var(--warn) 9%, transparent)' }}>
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="mt-0.5 size-4 shrink-0 text-[color-mix(in_oklab,var(--warn)_52%,var(--ink))]" />
                <div className="min-w-0 flex-1">
                  <p className="text-[12.5px] font-semibold text-ink">Untrusted: this loop does not ship with KARMAX</p>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink-2">
                    {kind === 'workflow' ? 'No registry you trust may have countersigned it. Installing it anyway is the app-side equivalent of the CLI\'s --untrusted flag.' : 'It is a file fetched from the registry, checked only against the index digest. You are reading the definition, not a signature.'} Type <code className="selectable rounded bg-surface-3 px-1 font-[family-name:var(--font-mono)] text-[11.5px] text-ink">{entry.name}</code> in the field next to the Install button to confirm you have read what it can do and accept it. Nothing is written until you press Install.
                  </p>
                </div>
              </div>
            </div>
          )}

          {install.error && (
            <div ref={errRef} role="alert" className="flex items-start gap-2.5 rounded-xl bg-[color-mix(in_oklab,var(--crit)_10%,transparent)] p-3.5 text-[12.5px] ring-1 ring-[color-mix(in_oklab,var(--crit)_32%,transparent)]">
              <ShieldAlert className="mt-0.5 size-4 shrink-0 text-crit" />
              <div className="min-w-0">
                <div className="font-semibold text-ink">Install failed{errStatus ? ` (${errStatus})` : ''}</div>
                <p className="selectable mt-0.5 break-words text-ink-2">{install.error instanceof Error ? install.error.message : String(install.error)}</p>
                {errStatus === 409 && <p className="mt-1 text-ink-3">The daemon refused it as untrusted. Nothing was written.</p>}
              </div>
            </div>
          )}
        </div>
      )}
    </Modal>
  )
}
