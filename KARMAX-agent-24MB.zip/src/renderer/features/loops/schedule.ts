/**
 * Loop schedules, understood.
 *
 * The daemon reports a loop's schedule as a string and we get exactly two shapes of it
 * (KARMAX/internal/runtime/looprun.go renderSchedule, scheduler/scheduler.go uses cron.WithSeconds()):
 *   - "@every 15m"            Go duration after "@every"
 *   - a cron spec             6 fields WITH seconds ("0 0 0/4 * * *" or "0 0 8 * * *"), 5 fields also accepted by recipes
 *                             ("0 18-22 * * *"), and the descriptors @hourly @daily @weekly @monthly @yearly
 * A loop driven purely by events/webhooks/manual runs has an empty schedule.
 *
 * `scheduleToInterval` turns any of those into an approximate interval (for cadence rings, freshness and
 * "silent for N intervals") plus a human label. `nextCronFire` computes the real next fire time of a cron spec
 * in the machine's local time zone (the daemon runs on the same machine and robfig/cron defaults to time.Local).
 *
 * Pure and dependency-free so it can be unit tested.
 */

export const SEC = 1000
export const MIN = 60 * SEC
export const HOUR = 60 * MIN
export const DAY = 24 * HOUR

export type ScheduleKind = 'every' | 'cron' | 'descriptor' | 'event' | 'manual' | 'unknown'

export interface ScheduleInfo {
  kind: ScheduleKind
  /** Approximate typical gap between two runs; null when the loop is not clock-driven or the spec is unreadable. */
  intervalMs: number | null
  /** "every 15 min", "daily 08:00", "Fridays 18:00", "on comms.message". */
  label: string
  /** True only when the interval is exact (an `@every` duration). Cron intervals are the median gap between fires. */
  exact: boolean
  /** Longest gap between two fires (weekday-only cron skips weekends): the fair yardstick for "silent too long". */
  maxGapMs: number | null
  raw: string
}

/* ── Go durations ──────────────────────────────────────────────────────── */

const UNIT_MS: Record<string, number> = { ns: 1e-6, us: 1e-3, µs: 1e-3, ms: 1, s: SEC, m: MIN, h: HOUR }

/** Parses a Go time.Duration string ("15m", "1h30m", "90s", "1.5h"). Returns null when unreadable or not positive. */
export function parseGoDuration(input: string): number | null {
  const s = input.trim()
  if (!s) return null
  const re = /(\d+\.?\d*|\.\d+)(ns|us|µs|ms|s|m|h)/y
  let total = 0
  let pos = 0
  while (pos < s.length) {
    re.lastIndex = pos
    const m = re.exec(s)
    if (!m) return null
    total += parseFloat(m[1]) * UNIT_MS[m[2]]
    pos = re.lastIndex
  }
  return total > 0 ? total : null
}

/** "every 15 min", "every 6 h", "every minute", "daily", "weekly". */
export function formatEvery(ms: number): string {
  if (ms === MIN) return 'every minute'
  if (ms === HOUR) return 'every hour'
  if (ms === DAY) return 'daily'
  if (ms === 7 * DAY) return 'weekly'
  if (ms >= DAY && ms % DAY === 0) return `every ${ms / DAY} d`
  if (ms >= HOUR && ms % HOUR === 0) return `every ${ms / HOUR} h`
  if (ms >= MIN && ms % MIN === 0) return `every ${ms / MIN} min`
  if (ms >= SEC * 2 && ms % SEC === 0) return `every ${ms / SEC} sec`
  if (ms < SEC) return `every ${Math.round(ms)} ms`
  if (ms >= HOUR) return `every ${trim1(ms / HOUR)} h`
  if (ms >= MIN) return `every ${trim1(ms / MIN)} min`
  return `every ${trim1(ms / SEC)} sec`
}
const trim1 = (n: number) => String(Math.round(n * 10) / 10)

/* ── Cron ──────────────────────────────────────────────────────────────── */

const DESCRIPTORS: Record<string, string> = {
  '@yearly': '0 0 0 1 1 *',
  '@annually': '0 0 0 1 1 *',
  '@monthly': '0 0 0 1 * *',
  '@weekly': '0 0 0 * * 0',
  '@daily': '0 0 0 * * *',
  '@midnight': '0 0 0 * * *',
  '@hourly': '0 0 * * * *'
}

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
const DOWS = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']

interface Field {
  expr: string
  set: Set<number>
  /** robfig/cron's "star bit": the field starts with * or ?. Decides dom/dow AND-vs-OR semantics. */
  star: boolean
}

export interface CronSpec {
  sec: Field
  min: Field
  hour: Field
  dom: Field
  mon: Field
  dow: Field
}

function parseNumber(tok: string, names?: string[], nameBase = 0): number | null {
  if (/^\d+$/.test(tok)) return parseInt(tok, 10)
  if (names) {
    const i = names.indexOf(tok.toUpperCase())
    if (i >= 0) return i + nameBase
  }
  return null
}

function parseField(expr: string, lo: number, hi: number, names?: string[], nameBase = 0): Field | null {
  const set = new Set<number>()
  const star = expr.startsWith('*') || expr.startsWith('?')
  for (const part of expr.split(',')) {
    if (!part) return null
    const [rangeStr, stepStr, extra] = part.split('/')
    if (extra !== undefined) return null
    let step = 1
    if (stepStr !== undefined) {
      if (!/^\d+$/.test(stepStr)) return null
      step = parseInt(stepStr, 10)
      if (step < 1) return null
    }
    let a: number
    let b: number
    if (rangeStr === '*' || rangeStr === '?') {
      a = lo
      b = hi
    } else if (rangeStr.includes('-')) {
      const [x, y, more] = rangeStr.split('-')
      if (more !== undefined) return null
      const nx = parseNumber(x, names, nameBase)
      const ny = parseNumber(y, names, nameBase)
      if (nx == null || ny == null) return null
      a = nx
      b = ny
    } else {
      const n = parseNumber(rangeStr, names, nameBase)
      if (n == null) return null
      a = n
      b = stepStr !== undefined ? hi : n // "5/15" means 5-max/15, like robfig
    }
    if (a < lo || b > hi || a > b) return null
    for (let v = a; v <= b; v += step) set.add(v)
  }
  return set.size ? { expr, set, star } : null
}

export function parseCron(spec: string): CronSpec | null {
  let s = spec.trim()
  if (DESCRIPTORS[s.toLowerCase()]) s = DESCRIPTORS[s.toLowerCase()]
  const parts = s.split(/\s+/)
  if (parts.length === 5) parts.unshift('0')
  if (parts.length !== 6) return null
  const [sec, min, hour, dom, mon, dow] = parts
  const f = {
    sec: parseField(sec, 0, 59),
    min: parseField(min, 0, 59),
    hour: parseField(hour, 0, 23),
    dom: parseField(dom, 1, 31),
    mon: parseField(mon, 1, 12, MONTHS, 1),
    dow: parseField(dow, 0, 7, DOWS, 0)
  }
  if (!f.sec || !f.min || !f.hour || !f.dom || !f.mon || !f.dow) return null
  // 7 is an accepted alias of Sunday
  if (f.dow.set.has(7)) {
    f.dow.set.delete(7)
    f.dow.set.add(0)
  }
  return f as CronSpec
}

function dayMatches(c: CronSpec, d: Date): boolean {
  const domOk = c.dom.set.has(d.getDate())
  const dowOk = c.dow.set.has(d.getDay())
  // robfig/cron: if either field is a star the two are ANDed, otherwise ORed.
  return c.dom.star || c.dow.star ? domOk && dowOk : domOk || dowOk
}

/** Next fire time strictly after `after` (epoch ms), local time. Null when the spec never fires within ~8 years. */
export function nextCronFire(spec: string | CronSpec, after: number): number | null {
  const c = typeof spec === 'string' ? parseCron(spec) : spec
  if (!c) return null
  const t = new Date(after)
  t.setMilliseconds(0)
  t.setSeconds(t.getSeconds() + 1)
  const limit = t.getFullYear() + 8
  for (let guard = 0; guard < 20000 && t.getFullYear() <= limit; guard++) {
    if (!c.mon.set.has(t.getMonth() + 1)) {
      t.setMonth(t.getMonth() + 1, 1)
      t.setHours(0, 0, 0, 0)
      continue
    }
    if (!dayMatches(c, t)) {
      t.setDate(t.getDate() + 1)
      t.setHours(0, 0, 0, 0)
      continue
    }
    if (!c.hour.set.has(t.getHours())) {
      t.setHours(t.getHours() + 1, 0, 0, 0)
      continue
    }
    if (!c.min.set.has(t.getMinutes())) {
      t.setMinutes(t.getMinutes() + 1, 0, 0)
      continue
    }
    if (!c.sec.set.has(t.getSeconds())) {
      t.setSeconds(t.getSeconds() + 1, 0)
      continue
    }
    return t.getTime()
  }
  return null
}

/** Median and longest gap between consecutive fires: the "typical" interval of a cron spec and its worst case. */
function cronInterval(c: CronSpec): { median: number; max: number } | null {
  // A fixed mid-winter reference keeps the answer independent of when the app is opened.
  let cursor = new Date(2026, 0, 12, 0, 0, 0).getTime()
  const fires: number[] = []
  for (let i = 0; i < 14; i++) {
    const n = nextCronFire(c, cursor)
    if (n == null) break
    fires.push(n)
    cursor = n
  }
  if (fires.length < 2) return null
  const gaps: number[] = []
  for (let i = 1; i < fires.length; i++) gaps.push(fires[i] - fires[i - 1])
  gaps.sort((a, b) => a - b)
  return { median: gaps[Math.floor(gaps.length / 2)], max: gaps[gaps.length - 1] }
}

const pad2 = (n: number) => String(n).padStart(2, '0')
const hhmm = (h: number, m: number) => `${pad2(h)}:${pad2(m)}`
const DOW_PLURAL = ['Sundays', 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays']
const DOW_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MON_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const ordinal = (n: number) => {
  const v = n % 100
  if (v >= 11 && v <= 13) return `${n}th`
  return `${n}${['th', 'st', 'nd', 'rd'][n % 10 > 3 ? 0 : n % 10] ?? 'th'}`
}

const isStar = (f: Field) => f.expr === '*' || f.expr === '?'
const stepOnly = (f: Field): number | null => {
  const m = /^\*\/(\d+)$/.exec(f.expr)
  return m ? parseInt(m[1], 10) : null
}
const single = (f: Field): number | null => (f.set.size === 1 && !f.star ? [...f.set][0] : null)
const isRange = (f: Field): [number, number] | null => {
  const m = /^(\d+)-(\d+)$/.exec(f.expr)
  return m ? [parseInt(m[1], 10), parseInt(m[2], 10)] : null
}

function dowText(f: Field): string | null {
  const days = [...f.set].sort((a, b) => a - b)
  if (days.length === 5 && days.join() === '1,2,3,4,5') return 'weekdays'
  if (days.length === 2 && days.join() === '0,6') return 'weekends'
  if (days.length === 1) return DOW_PLURAL[days[0]]
  if (days.length <= 4) return days.map((d) => DOW_SHORT[d]).join(', ')
  return null
}

function cronLabel(c: CronSpec, raw: string): string {
  const fallback = () => `cron ${raw.trim()}`
  const everyDay = isStar(c.dom) && isStar(c.mon) && isStar(c.dow)
  const secOnce = single(c.sec) !== null
  const h = single(c.hour)
  const m = single(c.min)

  if (everyDay) {
    // sub-minute
    if (isStar(c.hour) && isStar(c.min)) {
      const n = stepOnly(c.sec)
      if (isStar(c.sec)) return 'every second'
      if (n) return `every ${n} sec`
      if (secOnce) return 'every minute'
      return fallback()
    }
    if (isStar(c.hour) && secOnce) {
      const n = stepOnly(c.min)
      if (isStar(c.min)) return 'every minute'
      if (n) return n === 1 ? 'every minute' : `every ${n} min`
      if (m !== null) return `hourly at :${pad2(m)}`
      return fallback()
    }
    if (secOnce && m !== null) {
      const n = stepOnly(c.hour)
      if (n) return n === 1 ? (m === 0 ? 'every hour' : `hourly at :${pad2(m)}`) : `every ${n} h${m === 0 ? '' : ` at :${pad2(m)}`}`
      const r = isRange(c.hour)
      if (r) return m === 0 ? `hourly ${hhmm(r[0], 0)}–${hhmm(r[1], 0)}` : `hourly at :${pad2(m)}, ${pad2(r[0])}–${pad2(r[1])}h`
      if (h !== null) return `daily ${hhmm(h, m)}`
      if (!c.hour.star && c.hour.set.size <= 3) return `daily ${[...c.hour.set].sort((a, b) => a - b).map((x) => hhmm(x, m)).join(' & ')}`
    }
    return fallback()
  }

  // Restricted to certain weekdays, every month/day-of-month.
  if (isStar(c.dom) && isStar(c.mon) && !c.dow.star) {
    const d = dowText(c.dow)
    if (d && h !== null && m !== null && secOnce) return `${d} ${hhmm(h, m)}`
    if (d && secOnce && m !== null) {
      const n = stepOnly(c.hour)
      if (n) return `${d}, every ${n} h`
    }
    return fallback()
  }

  // A fixed day of the month.
  if (!c.dom.star && isStar(c.mon) && isStar(c.dow) && h !== null && m !== null && secOnce) {
    const d = single(c.dom)
    if (d !== null) return `monthly on the ${ordinal(d)}, ${hhmm(h, m)}`
  }

  // A fixed date in a fixed month.
  if (!c.dom.star && !c.mon.star && isStar(c.dow) && h !== null && m !== null && secOnce) {
    const d = single(c.dom)
    const mo = single(c.mon)
    if (d !== null && mo !== null) return `yearly ${MON_SHORT[mo - 1]} ${d}, ${hhmm(h, m)}`
  }
  return fallback()
}

/* ── Public entry points ───────────────────────────────────────────────── */

/**
 * Derives an approximate interval and a human label from a daemon schedule string.
 * `hint` carries what GET /api/loops says about non-clock triggers so an empty schedule can still be described.
 */
export function scheduleToInterval(schedule: string | null | undefined, hint: { events?: string[]; webhook?: string } = {}): ScheduleInfo {
  const raw = (schedule ?? '').trim()

  if (!raw) {
    if (hint.events && hint.events.length) {
      const [first, ...rest] = hint.events
      return { kind: 'event', intervalMs: null, label: `on ${first}${rest.length ? ` +${rest.length}` : ''}`, exact: false, maxGapMs: null, raw }
    }
    if (hint.webhook) return { kind: 'event', intervalMs: null, label: `webhook ${hint.webhook}`, exact: false, maxGapMs: null, raw }
    return { kind: 'manual', intervalMs: null, label: 'on demand', exact: false, maxGapMs: null, raw }
  }

  const lower = raw.toLowerCase()
  if (lower.startsWith('@every')) {
    const ms = parseGoDuration(raw.slice(6))
    if (ms == null) return { kind: 'unknown', intervalMs: null, label: raw, exact: false, maxGapMs: null, raw }
    return { kind: 'every', intervalMs: ms, label: formatEvery(ms), exact: true, maxGapMs: ms, raw }
  }
  if (lower.startsWith('on ') || lower.startsWith('webhook ')) {
    return { kind: 'event', intervalMs: null, label: raw, exact: false, maxGapMs: null, raw }
  }

  const cron = parseCron(raw)
  if (!cron) return { kind: 'unknown', intervalMs: null, label: raw, exact: false, maxGapMs: null, raw }
  const kind: ScheduleKind = lower.startsWith('@') ? 'descriptor' : 'cron'
  const interval = cronInterval(cron)
  let label = cronLabel(cron, raw)
  if (kind === 'descriptor') {
    const named: Record<string, string> = { '@hourly': 'every hour', '@daily': 'daily 00:00', '@midnight': 'daily 00:00', '@weekly': 'Sundays 00:00', '@monthly': 'monthly on the 1st, 00:00', '@yearly': 'yearly Jan 1, 00:00', '@annually': 'yearly Jan 1, 00:00' }
    label = named[lower] ?? label
  }
  return { kind, intervalMs: interval?.median ?? null, label, exact: false, maxGapMs: interval?.max ?? null, raw }
}

/**
 * Best guess at when a loop fires next.
 *  - `@every`: last attempt + interval (the scheduler re-arms after each run, so this is what the daemon does)
 *  - cron / descriptors: the real next matching wall-clock time
 *  - event-driven / manual / unreadable: null
 * Always labelled "estimated" in the UI: the daemon does not report its next fire time.
 */
export function estimateNextFire(schedule: string | null | undefined, opts: { lastRun?: number | null; now: number }): number | null {
  const info = scheduleToInterval(schedule)
  if (info.kind === 'every') {
    if (opts.lastRun == null || info.intervalMs == null) return null
    return opts.lastRun + info.intervalMs
  }
  if (info.kind === 'cron' || info.kind === 'descriptor') return nextCronFire(info.raw, opts.now)
  return null
}

/* ── Cadence rings (constellation) ─────────────────────────────────────── */

export interface RingBucket {
  id: string
  /** Inclusive upper bound of the interval; Infinity for the outermost clock ring. */
  maxMs: number
  label: string
}

export const RING_BUCKETS: RingBucket[] = [
  { id: 'lte5m', maxMs: 5 * MIN, label: '≤ 5 min' },
  { id: 'lte1h', maxMs: HOUR, label: '≤ 1 h' },
  { id: 'lte6h', maxMs: 6 * HOUR, label: '≤ 6 h' },
  { id: 'lte24h', maxMs: DAY, label: '≤ 24 h' },
  { id: 'longer', maxMs: Infinity, label: '> 24 h' }
]
/** Loops with no clock (events, webhooks, manual) orbit on their own outermost ring. */
export const EVENT_RING: RingBucket = { id: 'event', maxMs: Infinity, label: 'events / manual' }

/** Index into RING_BUCKETS, or RING_BUCKETS.length for the event ring. */
export function ringIndex(intervalMs: number | null): number {
  if (intervalMs == null) return RING_BUCKETS.length
  const i = RING_BUCKETS.findIndex((b) => intervalMs <= b.maxMs)
  return i < 0 ? RING_BUCKETS.length - 1 : i
}
