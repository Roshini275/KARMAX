/**
 * Loops overview: the hero screen. Constellation (default) · Grid · Timeline · Registry.
 * Owner: workstream C. Data: GET /api/loops + /api/loops/health + /api/activity jobs (see data.ts).
 */
import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { GanttChart, LayoutGrid, Orbit, PackageSearch, RefreshCw, Search, TriangleAlert, WifiOff } from 'lucide-react'
import { Button, IconButton, Input, Page, Segmented } from '@/design/primitives'
import { StatusDot } from '@/design/status'
import { pageTransition } from '@/design/motion'
import { useConnection } from '@/lib/api/hooks'
import { timeAgo } from '@/lib/format'
import { ConstellationView } from './ConstellationView'
import { LoopsStyles } from './Constellation'
import { useLoopData } from './data'
import { GridView } from './GridView'
import { KpiStrip } from './KpiStrip'
import { LoopDrawer } from './LoopDrawer'
import { matchesFilter, type LoopFilter, type LoopFilterMode } from './model'
import { RegistryView } from './RegistryView'
import { TimelineView } from './TimelineView'
import { ToastHost, useNow } from './ui'
import { countStates } from './health'

type View = 'constellation' | 'grid' | 'timeline' | 'registry'
const VIEW_KEY = 'km.loops.view'

const readView = (): View => {
  try {
    const v = localStorage.getItem(VIEW_KEY)
    if (v === 'constellation' || v === 'grid' || v === 'timeline' || v === 'registry') return v
  } catch {
    /* storage blocked */
  }
  return 'constellation'
}

export default function LoopsPage() {
  const data = useLoopData()
  const conn = useConnection()
  const now = useNow()
  const [view, setViewState] = useState<View>(readView)
  const [filter, setFilter] = useState<LoopFilter>({ q: '', mode: 'all' })
  const [selected, setSelected] = useState<string | null>(null)

  const setView = (v: View) => {
    setViewState(v)
    try {
      localStorage.setItem(VIEW_KEY, v)
    } catch {
      /* ignore */
    }
  }

  const { vms } = data
  const counts = useMemo(() => countStates(vms.map((v) => v.state)), [vms])
  const visibleVms = useMemo(() => vms.filter((v) => matchesFilter(v, filter)), [vms, filter])
  const visible = useMemo(() => new Set(visibleVms.map((v) => v.name)), [visibleVms])
  const selectedVm = selected ? (vms.find((v) => v.name === selected) ?? null) : null

  // A loop that disappears (uninstalled) must not leave an empty drawer open.
  useEffect(() => {
    if (selected && !data.loading && !vms.some((v) => v.name === selected)) setSelected(null)
  }, [selected, vms, data.loading])

  const attention = counts.failing + counts.dark
  const fatal = !!data.error && vms.length === 0
  // Health endpoint down and nothing has a health row: failing/dark/running are unknowable, not zero.
  const healthDown = data.healthError != null && vms.length > 0 && !vms.some((v) => v.health)
  const subtitle = data.loading ? 'Loading loops…' : fatal ? 'Could not load loops' : vms.length === 0 ? 'No loops installed' : healthDown ? `${vms.length} loop${vms.length === 1 ? '' : 's'} · health unavailable` : `${vms.length} loop${vms.length === 1 ? '' : 's'} · ${attention ? `${attention} need${attention === 1 ? 's' : ''} attention` : 'all on track'}${counts.running ? ` · ${counts.running} running` : ''}${counts.waiting ? ` · ${counts.waiting} waiting` : ''}`
  const unreachable = conn && !conn.reachable

  const n = (x: number) => (data.loading ? '' : ` ${x}`)
  const filterOptions: { value: LoopFilterMode; label: string }[] = [
    { value: 'all', label: `All${n(vms.length)}` },
    { value: 'attention', label: healthDown ? 'Attention' : `Attention${n(attention)}` },
    { value: 'running', label: healthDown ? 'Running' : `Running${n(counts.running)}` },
    { value: 'disabled', label: `Disabled${n(counts.disabled)}` }
  ]

  return (
    <Page
      title="Loops"
      subtitle={subtitle}
      actions={
        <>
          <span className="hidden text-[11.5px] text-ink-3 md:inline" aria-live="off">
            {data.updatedAt ? `Updated ${timeAgo(data.updatedAt, now)}` : 'Not updated yet'}
          </span>
          <IconButton label="Refresh now" onClick={data.refetch} className="size-8">
            <RefreshCw className={data.fetching ? 'size-4 animate-[km-spin_0.8s_linear_infinite]' : 'size-4'} />
          </IconButton>
          <Segmented<View>
            value={view}
            onChange={setView}
            options={[
              { value: 'constellation', label: <><Orbit className="size-3.5" />Constellation</> },
              { value: 'grid', label: <><LayoutGrid className="size-3.5" />Grid</> },
              { value: 'timeline', label: <><GanttChart className="size-3.5" />Timeline</> },
              { value: 'registry', label: <><PackageSearch className="size-3.5" />Registry</> }
            ]}
          />
        </>
      }
    >
      <LoopsStyles />
      <div className="space-y-3 pb-2">
        {unreachable && (
          <div role="alert" className="flex items-center gap-2.5 rounded-xl border border-[color-mix(in_oklab,var(--crit)_35%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-4 py-2.5 text-[12.5px] text-ink">
            <WifiOff className="size-4 shrink-0 text-crit" />
            <StatusDot tone="crit" size={7} />
            <span className="font-semibold">Daemon unreachable.</span>
            <span className="min-w-0 truncate text-ink-2">KARMAX is not answering at {conn?.karmaxUrl}. {vms.length ? 'Showing the last data received; it is not live.' : ''}</span>
          </div>
        )}
        {!fatal && data.healthError != null && !unreachable && (
          <div className="flex items-center gap-2.5 rounded-xl border border-line-strong bg-surface-2/60 px-4 py-2 text-[12px] text-ink-2">
            <TriangleAlert className="size-4 shrink-0 text-ink" />
            Health data is unavailable ({data.healthError instanceof Error ? data.healthError.message : 'error'}). {healthDown ? 'Loop states cannot be determined, so enabled loops show as Waiting.' : 'States may be stale.'}
          </div>
        )}

        {view === 'registry' ? (
          <RegistryView />
        ) : fatal ? (
          <div className="glass rounded-2xl px-6 py-14 text-center">
            <div className="mx-auto mb-4 grid size-12 place-items-center rounded-2xl bg-[color-mix(in_oklab,var(--crit)_12%,transparent)] text-crit ring-1 ring-[color-mix(in_oklab,var(--crit)_30%,transparent)]">
              <WifiOff className="size-5" />
            </div>
            <div className="text-[14px] font-semibold text-ink">Could not load loops</div>
            <p className="selectable mx-auto mt-1.5 max-w-md text-[12.5px] leading-relaxed text-ink-3">{data.error instanceof Error ? data.error.message : String(data.error)}</p>
            <div className="mt-4 flex justify-center gap-2">
              <Button variant="primary" icon={<RefreshCw className="size-3.5" />} onClick={data.refetch}>Retry</Button>
              <Button variant="subtle" onClick={() => setView('registry')}>Browse the registry</Button>
            </div>
          </div>
        ) : (
          <>
            <KpiStrip vms={vms} loading={data.loading} unknown={healthDown} />
            {(vms.length > 0 || data.loading) && (
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative min-w-[200px] max-w-[300px] flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
                  <Input value={filter.q} onChange={(e) => setFilter((f) => ({ ...f, q: e.target.value }))} placeholder="Filter loops" aria-label="Filter loops by name" className="h-8 pl-9" />
                </div>
                <Segmented<LoopFilterMode> value={filter.mode} onChange={(mode) => setFilter((f) => ({ ...f, mode }))} options={filterOptions} />
                {view === 'constellation' && <span className="ml-auto hidden text-[11.5px] text-ink-3 lg:inline">Rings are cadence buckets. Hover a node for details, click to open.</span>}
              </div>
            )}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={view} {...pageTransition}>
                {data.loading ? (
                  <div className="glass h-[420px] animate-pulse rounded-2xl" aria-busy="true" aria-label="Loading loops" />
                ) : view === 'constellation' ? (
                  <ConstellationView vms={vms} visible={visible} onOpen={setSelected} frozen={!!selectedVm} onBrowse={() => setView('registry')} />
                ) : view === 'grid' ? (
                  vms.length === 0 ? <ConstellationView vms={vms} visible={visible} onOpen={setSelected} frozen={false} onBrowse={() => setView('registry')} /> : <GridView vms={visibleVms} onOpen={setSelected} />
                ) : vms.length === 0 ? (
                  <ConstellationView vms={vms} visible={visible} onOpen={setSelected} frozen={false} onBrowse={() => setView('registry')} />
                ) : (
                  <TimelineView vms={visibleVms} onOpen={setSelected} />
                )}
              </motion.div>
            </AnimatePresence>
          </>
        )}
      </div>

      <LoopDrawer vm={selectedVm} onClose={() => setSelected(null)} />
      <ToastHost inset={selectedVm ? 580 : 0} />
    </Page>
  )
}
