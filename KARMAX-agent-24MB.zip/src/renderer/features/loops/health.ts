/**
 * The ONE place a loop's health state is derived. Everything on screen (constellation nodes, grid pills,
 * timeline lanes, KPI tiles, drawer) reads `LoopVM.state`, which comes from `deriveHealthState` below.
 *
 * Source facts (KARMAX/internal/runtime/looprun.go LoopHealthReport, GET /api/loops/health):
 *   - only REGISTERED (enabled) loops have a health row, so a disabled loop has none
 *   - `dark` is the daemon's own verdict: no success in 3 intervals, measured from the later of the last success
 *     and the daemon's start. It is only ever true for `@every` loops: the daemon refuses to guess a period for a
 *     cron spec. We do not second-guess it.
 *   - `running` is a live lease, `consecutive_failures` resets on success, `retry_at` is the backoff timer.
 *
 * Precedence, worst-news-last so the loudest true thing wins:
 *   running  > disabled > failing > dark > waiting (never succeeded) > ok
 */
import type { Tone } from '@/design/status'

export type HealthState = 'running' | 'disabled' | 'failing' | 'dark' | 'waiting' | 'ok'

/** Just the fields of GET /api/loops/health we read, with timestamps already parsed to epoch ms. */
export interface NormalizedHealth {
  lastSuccess: number | null
  lastFailure: number | null
  retryAt: number | null
  consecutiveFailures: number
  running: boolean
  dark: boolean
  lastError: string
}

export interface RawHealth {
  last_success?: string | null
  last_failure?: string | null
  retry_at?: string | null
  consecutive_failures?: number | null
  running?: boolean | null
  dark?: boolean | null
  last_error?: string | null
}

/**
 * Go's zero time.Time serialises as "0001-01-01T00:00:00Z" and an unset *time.Time as absent/null: both mean
 * "never". Anything before 2000 is treated the same way (a clock epoch of 0 is never a real run).
 */
export function parseTs(v: string | number | null | undefined): number | null {
  if (v == null || v === '') return null
  const t = typeof v === 'number' ? v : new Date(v).getTime()
  if (!Number.isFinite(t) || t < Date.UTC(2000, 0, 1)) return null
  return t
}

export function normalizeHealth(h: RawHealth): NormalizedHealth {
  return {
    lastSuccess: parseTs(h.last_success),
    lastFailure: parseTs(h.last_failure),
    retryAt: parseTs(h.retry_at),
    consecutiveFailures: Math.max(0, h.consecutive_failures ?? 0),
    running: !!h.running,
    dark: !!h.dark,
    lastError: (h.last_error ?? '').trim()
  }
}

/** What the daemon's scheduler knows about a loop's job (GET /api/activity jobs[]): when it last fired, when it fires next. */
export interface JobFacts {
  lastRun: number | null
  nextRun: number | null
  runCount: number
}

/**
 * Where a loop's facts come from. The daemon only writes success/failure health for loopkit loops (compiled and
 * signed workflows: runtime/looprun.go LoopHealthReport iterates rt.loopkitLoops). Recipes and prompt loops have no
 * health row, only a scheduler job that says when it last FIRED, not whether that run succeeded.
 */
export type Tracking = 'health' | 'schedule' | 'none'

export const trackingOf = (health: NormalizedHealth | null | undefined, job: JobFacts | null | undefined): Tracking => (health ? 'health' : job ? 'schedule' : 'none')

export function deriveHealthState(input: {
  enabled: boolean
  health?: NormalizedHealth | null
  job?: JobFacts | null
  /** Longest expected gap between runs; with `now` lets a schedule-tracked loop be judged dark (3 gaps of silence). */
  maxGapMs?: number | null
  now?: number
}): HealthState {
  const h = input.health ?? null
  if (h?.running) return 'running'
  if (!input.enabled) return 'disabled'
  if (h) {
    if (h.consecutiveFailures > 0) return 'failing'
    if (h.dark) return 'dark'
    // Never succeeded (and is not failing): it has not had a turn yet.
    return h.lastSuccess == null ? 'waiting' : 'ok'
  }
  // No health row: judge by the scheduler job. We cannot see failures here, only silence.
  const job = input.job ?? null
  if (!job || job.lastRun == null) return 'waiting'
  if (input.now != null && input.maxGapMs && input.now - job.lastRun > 3 * input.maxGapMs) return 'dark'
  return 'ok'
}

export interface StateMeta {
  tone: Tone
  label: string
  /** lucide icon name; resolved to a component in stateIcons.tsx so this file stays pure. */
  icon: 'loader' | 'check' | 'octagon-x' | 'triangle-alert' | 'clock' | 'pause'
  /** One sentence for legends and tooltips. */
  hint: string
  /** Lower sorts first (worst news on top). */
  rank: number
}

export const STATE_META: Record<HealthState, StateMeta> = {
  failing: { tone: 'crit', label: 'Failing', icon: 'octagon-x', hint: 'Its last run(s) failed; the daemon is retrying with backoff.', rank: 0 },
  dark: { tone: 'warn', label: 'Dark', icon: 'triangle-alert', hint: 'No success in 3 intervals, though nothing is failing.', rank: 1 },
  running: { tone: 'accent', label: 'Running', icon: 'loader', hint: 'A run is in flight right now.', rank: 2 },
  waiting: { tone: 'muted', label: 'Waiting', icon: 'clock', hint: 'No completed run on record yet (or the daemon does not track it).', rank: 3 },
  ok: { tone: 'good', label: 'Healthy', icon: 'check', hint: 'Last run succeeded and it is on schedule.', rank: 4 },
  disabled: { tone: 'muted', label: 'Disabled', icon: 'pause', hint: 'Turned off by the operator; the daemon will not run it.', rank: 5 }
}

/** Legend order: how a person would scan it, healthy first. */
export const STATE_ORDER: HealthState[] = ['ok', 'running', 'waiting', 'dark', 'failing', 'disabled']

export interface FleetCounts {
  total: number
  enabled: number
  disabled: number
  ok: number
  running: number
  waiting: number
  dark: number
  failing: number
  /** Loops whose state is actually known (enabled and not waiting): ok + running + dark + failing. */
  known: number
  /** ok + running. */
  healthy: number
  /**
   * Share of KNOWN loops that are ok or running, 0..100. A loop still waiting for its first report is neither
   * healthy nor unhealthy, so it is left out of both sides rather than flattering (or punishing) the number.
   * null when nothing is known.
   */
  healthyPct: number | null
}

export function countStates(states: HealthState[]): FleetCounts {
  const c: FleetCounts = { total: states.length, enabled: 0, disabled: 0, ok: 0, running: 0, waiting: 0, dark: 0, failing: 0, known: 0, healthy: 0, healthyPct: null }
  for (const s of states) c[s]++
  c.enabled = c.total - c.disabled
  c.healthy = c.ok + c.running
  c.known = c.healthy + c.failing + c.dark
  if (c.known > 0) c.healthyPct = Math.round((c.healthy / c.known) * 100)
  return c
}
