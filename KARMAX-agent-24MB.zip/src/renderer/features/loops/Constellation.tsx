/**
 * The constellation: an orbital map of every loop.
 *
 *  - a glowing KARMAX core at the centre with the loop count and a health arc around it
 *  - concentric orbit rings by cadence (<= 5 min innermost ... > 24 h outermost, plus an outer ring for loops
 *    with no clock: events / webhooks / manual)
 *  - one node per loop at a stable angle (hash of the name, relaxed so labels do not collide)
 *  - node SHAPE = kind (circle recipe, hexagon workflow, diamond compiled, triangle prompt), node COLOUR + ICON = state
 *  - running loops pulse and send dashes down their edge to the core; disabled loops are dashed and dim
 *  - the plane tilts (ellipses), drifts very slowly and is swept by a faint radar beam; both pause while you
 *    hover or focus, while a drawer is open, and never run under prefers-reduced-motion
 *
 * Motion is imperative (one requestAnimationFrame loop writing SVG attributes) so a 60-node map does not re-render
 * React at 60 fps.
 */
import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type KeyboardEvent as ReactKeyboardEvent } from 'react'
import { useReducedMotion } from 'framer-motion'
import { Pause, Play } from 'lucide-react'
import { cn } from '@/design/cn'
import { IconButton } from '@/design/primitives'
import { STATE_META, STATE_ORDER, countStates, type HealthState } from './health'
import { KIND_META, KIND_ORDER, lastLabel, lastTime, nextLabel, nextShort, type LoopVM } from './model'
import { CORE_R, NODE_R, TAU, computeAngles, placeLabels, pointOn, ringGeometry, slotOrigin, type Box, type Geometry, type LabelSlot } from './constellationLayout'
import { EVENT_RING, RING_BUCKETS } from './schedule'
import { KindGlyph, StateIcon, StatePill, When, clock, shapePath, stateColor, stateIcon, stateInk, useElementSize } from './ui'
import { toneVar } from '@/design/status'

const DRIFT_RAD_PER_S = TAU / 540 // one slow lap every nine minutes
const SWEEP_RAD_PER_S = TAU / 15
const SWEEP_WIDTH = (52 * Math.PI) / 180
const CAPTION_ANGLE = -0.74 // ring captions sit on one radial line, upper right, so their spacing is the ring gap
const AFTERGLOW = 1.05 // radians behind the beam a node keeps glowing

/** Styles that need @keyframes / :focus-visible on SVG parts. Rendered once by the page. */
export function LoopsStyles() {
  return (
    <style>{`
      @keyframes km-flow { to { stroke-dashoffset: -20; } }
      @keyframes km-breathe { 0%, 100% { transform: scale(1); opacity: .9; } 50% { transform: scale(1.07); opacity: 1; } }
      .km-node { outline: none; cursor: pointer; }
      .km-node .km-focus { opacity: 0; transition: opacity .12s; }
      .km-node:focus-visible .km-focus { opacity: 1; }
      .km-node .km-lift { transition: transform .18s cubic-bezier(.22,1,.36,1); transform-box: fill-box; transform-origin: center; }
      .km-node[data-hover="true"] .km-lift { transform: scale(1.16); }
      .km-node { transition: opacity .2s; }
      .km-label { transition: opacity .25s; }
      .km-core-glow { transform-box: fill-box; transform-origin: center; animation: km-breathe 5s ease-in-out infinite; }
      .km-spin-g { transform-box: fill-box; transform-origin: center; animation: km-spin 1.1s linear infinite; }
      .km-pulse { transform-box: fill-box; transform-origin: center; animation: km-pulse-ring 1.9s ease-out infinite; }
    `}</style>
  )
}

interface NodeEls {
  g?: SVGGElement | null
  depth?: SVGGElement | null
  edge?: SVGLineElement | null
  halo?: SVGCircleElement | null
  packet?: SVGCircleElement | null
  label?: SVGGElement | null
  name?: SVGTextElement | null
  sub?: SVGTextElement | null
}

const arcPath = (r: number, a0: number, a1: number) => {
  const large = a1 - a0 > Math.PI ? 1 : 0
  const p = (a: number) => `${(r * Math.cos(a)).toFixed(2)},${(r * Math.sin(a)).toFixed(2)}`
  return `M${p(a0)}A${r},${r} 0 ${large} 1 ${p(a1)}`
}

/** Faint deterministic star field: depth without competing with the data. */
function stars(w: number, h: number, n = 46) {
  const out: { x: number; y: number; r: number; o: number }[] = []
  let s = 1337
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 0x100000000)
  for (let i = 0; i < n; i++) out.push({ x: rnd() * w, y: rnd() * h, r: 0.5 + rnd() * 0.9, o: 0.1 + rnd() * 0.22 })
  return out
}

interface MapProps {
  vms: LoopVM[]
  dim: Set<string> | null
  hover: string | null
  setHover: (name: string | null) => void
  onOpen: (name: string) => void
  frozen: boolean
}

export const ConstellationMap = memo(function ConstellationMap({ vms, dim, hover, setHover, onOpen, frozen }: MapProps) {
  const [wrapRef, { w, h }] = useElementSize<HTMLDivElement>()
  const svgRef = useRef<SVGSVGElement>(null)
  const reduced = useReducedMotion() ?? false
  const [userPaused, setUserPaused] = useState(false)

  const hasEventRing = vms.some((v) => v.ring >= RING_BUCKETS.length)
  const ringCount = RING_BUCKETS.length + (hasEventRing ? 1 : 0)
  const geom: Geometry = useMemo(() => ringGeometry(Math.max(w, 1), Math.max(h, 1), ringCount), [w, h, ringCount])
  const angleKey = vms.map((v) => v.name).join('\u0000')
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const angles = useMemo(() => computeAngles(vms.map((v) => ({ name: v.name, ring: v.ring }))), [angleKey])
  const bg = useMemo(() => stars(Math.max(w, 1), Math.max(h, 1)), [w, h])

  const counts = useMemo(() => countStates(vms.map((v) => v.state)), [vms])
  // Denser maps get slightly smaller nodes so labels stay readable.
  const ns = vms.length <= 12 ? 1 : vms.length <= 20 ? 0.9 : 0.8

  /* ── imperative motion ─────────────────────────────────────────────── */
  const els = useRef(new Map<string, NodeEls>())
  const pos = useRef(new Map<string, { x: number; y: number }>())
  const sweepEl = useRef<SVGGElement | null>(null)
  const anim = useRef({ drift: 0, sweep: 0, clock: 0, last: 0, on: false, dirty: true, placedAt: 0 })
  const slots = useRef(new Map<string, LabelSlot>())
  const live = useRef({ geom, angles, vms, reduced, ns, hover, w, h, hasEventRing })
  live.current = { geom, angles, vms, reduced, ns, hover, w, h, hasEventRing }

  const motionOn = !reduced && !userPaused && !frozen && hover === null
  useEffect(() => {
    anim.current.on = motionOn
  }, [motionOn])

  const apply = useCallback(() => {
    const { geom: g, angles: ang, vms: list, reduced: red, ns: nodeScale, hover: hov, w: mw, h: mh, hasEventRing: evRing } = live.current
    const a = anim.current
    for (const v of list) {
      const e = els.current.get(v.name)
      if (!e?.g) continue
      const base = ang.get(v.name) ?? 0
      const th = base + a.drift
      const p = pointOn(g, v.ring, th)
      e.g.setAttribute('transform', `translate(${p.x.toFixed(2)} ${p.y.toFixed(2)})`)
      e.depth?.setAttribute('transform', `scale(${(p.scale * nodeScale).toFixed(3)})`)
      e.edge?.setAttribute('x2', p.x.toFixed(2))
      e.edge?.setAttribute('y2', p.y.toFixed(2))
      pos.current.set(v.name, { x: p.x, y: p.y })
      if (e.packet) {
        const t = (a.clock * 0.42 + (base / TAU)) % 1
        e.packet.setAttribute('cx', (g.cx + (p.x - g.cx) * (1 - t)).toFixed(2))
        e.packet.setAttribute('cy', (g.cy + (p.y - g.cy) * (1 - t)).toFixed(2))
        e.packet.setAttribute('opacity', (Math.sin(Math.PI * t) * 0.95).toFixed(2))
      }
      if (e.halo) {
        let glow = 0
        if (!red) {
          const d = (((a.sweep - th) % TAU) + TAU) % TAU
          if (d < AFTERGLOW) glow = (1 - d / AFTERGLOW) ** 2
        }
        e.halo.setAttribute('opacity', (glow * 0.6).toFixed(3))
      }
    }
    // Labels: re-decided a few times a second (and immediately when something changed), so they do not flicker.
    const t = performance.now()
    if (a.dirty || t - a.placedAt > 350) {
      a.placedAt = t
      const items = list.flatMap((v) => {
        const p = pos.current.get(v.name)
        if (!p) return []
        const lines: 1 | 2 = v.state === 'ok' ? 1 : 2
        const name = v.name
        const secondLen = v.state === 'ok' ? 0 : v.state === 'failing' ? 10 : STATE_META[v.state].label.length
        return [{
          name,
          x: p.x,
          y: p.y,
          r: NODE_R * nodeScale * 1.08 + 3,
          w: Math.max(name.length * 6.2, secondLen * 5.9) + 8,
          lines,
          priority: name === hov ? 0 : v.state === 'failing' || v.state === 'dark' || v.state === 'running' ? 1 : v.state === 'ok' ? 3 : 2,
          force: name === hov
        } as const]
      })
      const captions: Box[] = g.rings.map((r, i) => {
        const cx = g.cx + r.rx * Math.cos(CAPTION_ANGLE)
        const cy = g.cy + r.ry * Math.sin(CAPTION_ANGLE)
        const label = evRing && i === g.rings.length - 1 ? EVENT_RING.label : RING_BUCKETS[i].label
        const hw = (label.length * 6.4 + 8) / 2
        return { x0: cx - hw, x1: cx + hw, y0: cy - 8, y1: cy + 8 }
      })
      const coreBox: Box = { x0: g.cx - CORE_R - 12, x1: g.cx + CORE_R + 12, y0: g.cy - CORE_R - 12, y1: g.cy + CORE_R + 12 }
      const next = placeLabels([...items], { w: mw, h: mh }, [...captions, coreBox], slots.current)
      slots.current = next
      for (const v of list) {
        const e = els.current.get(v.name)
        const slot = next.get(v.name) ?? 'hidden'
        if (!e?.label) continue
        e.label.style.opacity = slot === 'hidden' ? '0' : '1'
        if (slot === 'hidden') continue
        const lines: 1 | 2 = v.state === 'ok' ? 1 : 2
        const o = slotOrigin(slot, NODE_R * nodeScale, lines)
        e.name?.setAttribute('text-anchor', o.anchor)
        e.name?.setAttribute('x', String(o.x))
        e.name?.setAttribute('y', (o.top + 10).toFixed(1))
        e.sub?.setAttribute('text-anchor', o.anchor)
        e.sub?.setAttribute('x', String(o.x))
        e.sub?.setAttribute('y', (o.top + 22).toFixed(1))
      }
    }
    sweepEl.current?.setAttribute('transform', `translate(${g.cx} ${g.cy}) scale(1 ${g.k}) rotate(${((a.sweep * 180) / Math.PI).toFixed(2)})`)
  }, [])

  useLayoutEffect(() => {
    anim.current.dirty = true
    apply()
  }, [geom, angles, vms, hover, ns, apply])

  useEffect(() => {
    if (reduced) return
    let raf = 0
    const loop = (ts: number) => {
      const a = anim.current
      const dt = a.last ? Math.min(0.1, (ts - a.last) / 1000) : 0
      a.last = ts
      if (a.on) {
        a.drift += dt * DRIFT_RAD_PER_S
        a.sweep += dt * SWEEP_RAD_PER_S
        a.clock += dt
        apply()
      } else if (a.dirty) {
        apply()
      }
      a.dirty = false
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [reduced, apply])

  /* ── interaction ───────────────────────────────────────────────────── */
  const focusSibling = (from: string, dir: 1 | -1) => {
    const nodes = [...(svgRef.current?.querySelectorAll<SVGGElement>('[data-loop-node]:not([data-dim="true"])') ?? [])]
    const i = nodes.findIndex((n) => n.dataset.loopNode === from)
    const next = nodes[(i + dir + nodes.length) % nodes.length]
    next?.focus()
  }
  const onKey = (e: ReactKeyboardEvent, name: string) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      onOpen(name)
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault()
      focusSibling(name, 1)
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault()
      focusSibling(name, -1)
    }
  }

  const hovered = hover ? vms.find((v) => v.name === hover) : undefined
  const hp = hover ? pos.current.get(hover) : undefined

  const arcs = useMemo(() => {
    const segs = STATE_ORDER.map((s) => ({ s, n: counts[s] })).filter((x) => x.n > 0)
    const total = segs.reduce((n, x) => n + x.n, 0)
    if (!total) return []
    const r = CORE_R + 9
    const gap = segs.length > 1 ? 2.5 / r : 0
    let a = -Math.PI / 2
    return segs.map((x) => {
      const span = (x.n / total) * TAU
      const d = arcPath(r, a + gap / 2, a + span - gap / 2 + (segs.length === 1 ? -0.0001 : 0))
      a += span
      return { ...x, d }
    })
  }, [counts])

  const ready = w > 40 && h > 40

  return (
    <div ref={wrapRef} className="relative h-full min-h-[440px] w-full overflow-hidden rounded-[inherit]">
      {ready && (
        <svg
          ref={svgRef}
          width={w}
          height={h}
          role="group"
          aria-label={`Loop constellation. ${vms.length} loops orbiting by cadence. ${counts.failing} failing, ${counts.dark} dark, ${counts.running} running. Use Tab or arrow keys to move between loops, Enter to open one.`}
          className="block"
        >
          <defs>
            <radialGradient id="km-bg" cx="50%" cy="50%" r="50%">
              <stop offset="0" stopColor="var(--accent)" stopOpacity="0.11" />
              <stop offset="0.6" stopColor="var(--accent-2)" stopOpacity="0.035" />
              <stop offset="1" stopColor="var(--accent)" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="km-core-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0.25" stopColor="var(--accent)" stopOpacity="0.55" />
              <stop offset="0.6" stopColor="var(--accent-2)" stopOpacity="0.16" />
              <stop offset="1" stopColor="var(--accent)" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="km-core" cx="38%" cy="30%" r="80%">
              <stop offset="0" stopColor="color-mix(in oklab, var(--accent) 88%, white)" />
              <stop offset="0.55" stopColor="color-mix(in oklab, var(--accent) 60%, #0a1330)" />
              <stop offset="1" stopColor="color-mix(in oklab, var(--accent-2) 55%, #0a1330)" />
            </radialGradient>
            <radialGradient id="km-sweep" gradientUnits="userSpaceOnUse" cx="0" cy="0" r={geom.sweepR}>
              <stop offset="0.12" stopColor="var(--accent)" stopOpacity="0" />
              <stop offset="1" stopColor="var(--accent)" stopOpacity="1" />
            </radialGradient>
            {(['good', 'warn', 'crit', 'accent', 'muted'] as const).map((t) => (
              <radialGradient key={t} id={`km-glow-${t}`} cx="50%" cy="50%" r="50%">
                <stop offset="0.3" stopColor={toneVar[t]} stopOpacity={t === 'muted' ? 0.12 : 0.42} />
                <stop offset="1" stopColor={toneVar[t]} stopOpacity="0" />
              </radialGradient>
            ))}
          </defs>

          {/* backdrop + stars */}
          <g aria-hidden pointerEvents="none">
            <ellipse cx={geom.cx} cy={geom.cy} rx={geom.rings[geom.rings.length - 1].rx + 36} ry={geom.rings[geom.rings.length - 1].ry + 30} fill="url(#km-bg)" />
            {bg.map((s, i) => (
              <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="var(--ink)" opacity={s.o * 0.6} />
            ))}
          </g>

          {/* radar sweep (circle space, squashed into the tilted plane by the parent transform) */}
          {!reduced && (
            <g ref={sweepEl} aria-hidden pointerEvents="none" opacity={frozen ? 0.4 : 1}>
              {Array.from({ length: 12 }, (_, i) => {
                const a0 = -SWEEP_WIDTH + (SWEEP_WIDTH * i) / 12
                const a1 = -SWEEP_WIDTH + (SWEEP_WIDTH * (i + 1)) / 12
                const R = geom.sweepR
                return (
                  <path
                    key={i}
                    d={`M0,0L${(R * Math.cos(a0)).toFixed(1)},${(R * Math.sin(a0)).toFixed(1)}A${R},${R} 0 0 1 ${(R * Math.cos(a1)).toFixed(1)},${(R * Math.sin(a1)).toFixed(1)}Z`}
                    fill="url(#km-sweep)"
                    opacity={0.015 + (i / 12) ** 2 * 0.13}
                  />
                )
              })}
              <line x1={0} y1={0} x2={geom.sweepR} y2={0} stroke="var(--accent)" strokeOpacity={0.4} strokeWidth={1} />
            </g>
          )}

          {/* orbit rings + captions */}
          <g aria-hidden pointerEvents="none">
            {geom.rings.map((r, i) => {
              const isEvent = hasEventRing && i === geom.rings.length - 1
              const bucket = isEvent ? EVENT_RING : RING_BUCKETS[i]
              const occupied = vms.some((v) => v.ring === i)
              return (
                <g key={i}>
                  <ellipse cx={geom.cx} cy={geom.cy} rx={r.rx} ry={r.ry} fill="none" stroke="var(--ink)" strokeOpacity={0.2 - i * 0.014} strokeWidth={1} strokeDasharray={isEvent ? '2 7' : undefined} />
                  <text
                    x={geom.cx + r.rx * Math.cos(CAPTION_ANGLE)}
                    y={geom.cy + r.ry * Math.sin(CAPTION_ANGLE) + 3}
                    textAnchor="middle"
                    fontSize={9}
                    fontWeight={600}
                    letterSpacing="0.08em"
                    fill="var(--ink-3)"
                    opacity={occupied ? 0.95 : 0.55}
                    style={{ textTransform: 'uppercase', paintOrder: 'stroke', stroke: 'var(--page)', strokeWidth: 5, strokeLinejoin: 'round' }}
                  >
                    {bucket.label}
                  </text>
                </g>
              )
            })}
          </g>

          {/* edges core -> node */}
          <g aria-hidden pointerEvents="none">
            {vms.map((v) => {
              const running = v.state === 'running'
              const isHover = hover === v.name
              return (
                <line
                  key={v.name}
                  ref={(el) => {
                    const e = els.current.get(v.name) ?? {}
                    e.edge = el
                    els.current.set(v.name, e)
                  }}
                  x1={geom.cx}
                  y1={geom.cy}
                  x2={geom.cx}
                  y2={geom.cy}
                  stroke={running || isHover ? 'var(--accent)' : 'var(--ink)'}
                  strokeOpacity={running ? 0.7 : isHover ? 0.4 : v.state === 'disabled' ? 0 : 0.055}
                  strokeWidth={running ? 1.5 : 1}
                  strokeDasharray={running ? '3 7' : undefined}
                  strokeLinecap="round"
                  style={running && !reduced ? { animation: 'km-flow 0.9s linear infinite' } : undefined}
                />
              )
            })}
            {vms
              .filter((v) => v.state === 'running' && !reduced)
              .map((v) => (
                <circle
                  key={`pk-${v.name}`}
                  ref={(el) => {
                    const e = els.current.get(v.name) ?? {}
                    e.packet = el
                    els.current.set(v.name, e)
                  }}
                  r={2.6}
                  fill="var(--accent)"
                />
              ))}
          </g>

          {/* core */}
          <g transform={`translate(${geom.cx} ${geom.cy})`} role="img" aria-label={`KARMAX core: ${counts.total} loops, ${counts.enabled} enabled`}>
            <circle r={CORE_R * 2.5} fill="url(#km-core-glow)" className="km-core-glow" pointerEvents="none" />
            <circle r={CORE_R + 9} fill="none" stroke="var(--ink)" strokeOpacity={0.07} strokeWidth={4} pointerEvents="none" />
            {arcs.map((a) => (
              <path key={a.s} d={a.d} fill="none" stroke={stateColor(a.s)} strokeWidth={4} strokeLinecap="butt" opacity={a.s === 'disabled' || a.s === 'waiting' ? 0.55 : 1}>
                <title>{`${STATE_META[a.s].label}: ${a.n}`}</title>
              </path>
            ))}
            <circle r={CORE_R} fill="url(#km-core)" stroke="rgba(255,255,255,0.28)" strokeWidth={1} />
            <ellipse cx={0} cy={-CORE_R * 0.52} rx={CORE_R * 0.66} ry={CORE_R * 0.34} fill="white" opacity={0.1} />
            <text y={7} textAnchor="middle" fontSize={30} fontWeight={600} fill="#fff" letterSpacing="-0.03em">
              {counts.total}
            </text>
            <text y={23} textAnchor="middle" fontSize={9} fontWeight={600} letterSpacing="0.14em" fill="#fff" opacity={0.86}>
              {counts.total === 1 ? 'LOOP' : 'LOOPS'}
            </text>
          </g>

          {/* nodes */}
          {vms.map((v) => {
            const tone = STATE_META[v.state].tone
            const color = toneVar[tone]
            const glowTone = tone === 'muted' ? 'muted' : tone
            const dimmed = dim?.has(v.name) ?? false
            const isHover = hover === v.name
            const fade = dimmed ? 0.16 : hover && !isHover ? 0.42 : 1
            const second = v.state === 'ok' ? '' : v.state === 'failing' ? `Failing ×${v.health?.consecutiveFailures ?? 0}` : STATE_META[v.state].label
            return (
              <g
                key={v.name}
                ref={(el) => {
                  const e = els.current.get(v.name) ?? {}
                  e.g = el
                  els.current.set(v.name, e)
                }}
                className="km-node"
                data-loop-node={v.name}
                data-hover={isHover}
                data-dim={dimmed}
                role="button"
                tabIndex={dimmed ? -1 : 0}
                aria-label={`${v.name}. ${KIND_META[v.kind].label} loop, ${STATE_META[v.state].label.toLowerCase()}, ${v.sched.label}. Press Enter for details.`}
                opacity={fade}
                pointerEvents={dimmed ? 'none' : undefined}
                onPointerEnter={() => setHover(v.name)}
                onPointerLeave={() => setHover(null)}
                onFocus={() => setHover(v.name)}
                onBlur={() => setHover(null)}
                onClick={() => onOpen(v.name)}
                onKeyDown={(e) => onKey(e, v.name)}
              >
                <g
                  ref={(el) => {
                    const e = els.current.get(v.name) ?? {}
                    e.depth = el
                    els.current.set(v.name, e)
                  }}
                >
                  <circle r={NODE_R * 2.3} fill={`url(#km-glow-${glowTone})`} pointerEvents="none" />
                  <circle
                    ref={(el) => {
                      const e = els.current.get(v.name) ?? {}
                      e.halo = el
                      els.current.set(v.name, e)
                    }}
                    r={NODE_R + 8}
                    fill="none"
                    stroke="var(--accent)"
                    strokeWidth={2}
                    opacity={0}
                    pointerEvents="none"
                  />
                  {v.state === 'running' && !reduced && <circle className="km-pulse" r={NODE_R - 2} fill="none" stroke="var(--accent)" strokeWidth={1.6} pointerEvents="none" />}
                  <g className="km-lift">
                    <path
                      d={shapePath(v.kind)}
                      fill={`color-mix(in oklab, ${color} ${v.state === 'disabled' || v.state === 'waiting' ? 8 : 16}%, var(--panel))`}
                      stroke={color}
                      strokeWidth={2}
                      strokeLinejoin="round"
                      strokeDasharray={v.state === 'disabled' ? '3.5 3.5' : v.state === 'waiting' ? '1 3.5' : undefined}
                      strokeLinecap="round"
                    />
                    <g transform={`translate(0 ${v.kind === 'prompt' ? 2.5 : 0})`} color={color}>
                      {v.state === 'running' ? (
                        <g className="km-spin-g">
                          <StateGlyph state={v.state} />
                        </g>
                      ) : (
                        <StateGlyph state={v.state} />
                      )}
                    </g>
                  </g>
                  <circle className="km-focus" r={NODE_R + 7} fill="none" stroke="var(--accent)" strokeWidth={2} pointerEvents="none" />
                  {/* hit target >= 24px */}
                  <circle r={NODE_R + 9} fill="transparent" />
                </g>
                <g
                    className="km-label"
                    pointerEvents="none"
                    ref={(el) => {
                      const e = els.current.get(v.name) ?? {}
                      e.label = el
                      els.current.set(v.name, e)
                    }}
                  >
                    <text
                      ref={(el) => {
                        const e = els.current.get(v.name) ?? {}
                        e.name = el
                        els.current.set(v.name, e)
                      }}
                      y={NODE_R * ns + 15}
                      textAnchor="middle"
                      fontSize={11}
                      fontWeight={isHover ? 600 : 500}
                      fill={isHover ? 'var(--ink)' : 'var(--ink-2)'}
                      style={{ paintOrder: 'stroke', stroke: 'var(--page)', strokeWidth: 4, strokeLinejoin: 'round' }}
                    >
                      {v.name}
                    </text>
                    {second && (
                      <text
                        ref={(el) => {
                          const e = els.current.get(v.name) ?? {}
                          e.sub = el
                          els.current.set(v.name, e)
                        }}
                        y={NODE_R * ns + 27}
                        textAnchor="middle"
                        fontSize={9.5}
                        fontWeight={600}
                        letterSpacing="0.04em"
                        fill="var(--ink-2)"
                        style={{ paintOrder: 'stroke', stroke: 'var(--page)', strokeWidth: 4, strokeLinejoin: 'round' }}
                      >
                        {second}
                      </text>
                    )}
                </g>
              </g>
            )
          })}
        </svg>
      )}

      {/* motion control */}
      <div className="absolute right-3 top-3 z-10">
        <IconButton
          label={reduced ? 'Motion is off (system reduced-motion setting)' : userPaused ? 'Resume drift and radar sweep' : 'Pause drift and radar sweep'}
          disabled={reduced}
          onClick={() => setUserPaused((p) => !p)}
          className="size-7 bg-surface-2/60 ring-1 ring-line backdrop-blur"
          aria-pressed={userPaused}
        >
          {userPaused || reduced ? <Play className="size-3.5" /> : <Pause className="size-3.5" />}
        </IconButton>
      </div>

      {/* hover / focus card */}
      {hovered && hp && ready && <NodeTooltip vm={hovered} x={hp.x} y={hp.y} w={w} h={h} />}
    </div>
  )
})

function StateGlyph({ state }: { state: HealthState }) {
  // lucide icons render their own <svg>; nested in the node's <svg> they are positioned with x/y and take the
  // colour from the parent <g color=...>.
  const Icon = stateIcon(state)
  return <Icon x={-7} y={-7} width={14} height={14} strokeWidth={2.8} aria-hidden />
}

/* ── tooltip ───────────────────────────────────────────────────────────── */

const TIP_W = 272

export function NodeTooltip({ vm, x, y, w, h }: { vm: LoopVM; x: number; y: number; w: number; h: number }) {
  const gap = 62 // clears the node's own name label
  const left = x + gap + TIP_W > w - 8 ? x - gap - TIP_W : x + gap
  const top = Math.max(8, Math.min(y - 70, h - 250))
  const hh = vm.health
  return (
    <div
      role="tooltip"
      className="glass pointer-events-none absolute z-20 rounded-xl p-3.5 shadow-pop"
      style={{ left: Math.max(8, left), top, width: TIP_W, background: 'color-mix(in oklab, var(--panel) 93%, transparent)' }}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <KindGlyph kind={vm.kind} size={15} />
          <span className="truncate text-[13.5px] font-semibold tracking-tight">{vm.name}</span>
        </div>
        <StatePill state={vm.state} />
      </div>
      <div className="mt-1 text-[11.5px] text-ink-3">
        {KIND_META[vm.kind].label} · {vm.sched.label}
      </div>
      <dl className="mt-2.5 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-[12px]">
        <dt className="text-ink-3">{lastLabel(vm)}</dt>
        <dd className="text-ink">
          {lastTime(vm) ? (
            <>
              <When t={lastTime(vm)} /> <span className="text-ink-3">· {clock(lastTime(vm))}</span>
            </>
          ) : (
            'never'
          )}
        </dd>
        <dt className="text-ink-3">{nextLabel(vm).replace(' (estimated)', '')}</dt>
        <dd className="text-ink">{vm.nextDue ? <><When t={vm.nextDue} future /> <span className="text-ink-3">· {nextShort(vm)}</span></> : vm.enabled ? <span className="text-ink-3">not estimable</span> : <span className="text-ink-3">disabled</span>}</dd>
        <dt className="text-ink-3">Failures</dt>
        <dd className={cn('tnum', hh && hh.consecutiveFailures > 0 ? 'font-semibold text-ink' : 'text-ink')}>{hh ? `${hh.consecutiveFailures} in a row` : <span className="text-ink-3">not tracked</span>}</dd>
      </dl>
      {hh?.lastError && (
        <div className="selectable mt-2.5 line-clamp-3 rounded-md bg-surface-2 px-2 py-1.5 font-[family-name:var(--font-mono)] text-[10.5px] leading-snug text-ink-2 ring-1 ring-line">{hh.lastError}</div>
      )}
      <div className="mt-2.5 text-[10.5px] text-ink-3">Click or press Enter for details</div>
    </div>
  )
}

/* ── legend (mandatory): kinds by shape, states by colour + icon + label ─ */

export function Legend({ vms, className }: { vms: LoopVM[]; className?: string }) {
  const counts = countStates(vms.map((v) => v.state))
  return (
    <div className={cn('flex flex-wrap items-center gap-x-6 gap-y-2 text-[11.5px] text-ink-2', className)} aria-label="Legend">
      <div className="flex items-center gap-3">
        <span className="label-micro">Kind</span>
        {KIND_ORDER.map((k) => (
          <span key={k} className="inline-flex items-center gap-1.5" title={KIND_META[k].blurb}>
            <KindGlyph kind={k} size={15} />
            {KIND_META[k].label}
          </span>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-x-3.5 gap-y-1.5">
        <span className="label-micro">State</span>
        {STATE_ORDER.map((s) => (
          <span key={s} className="inline-flex items-center gap-1.5" title={STATE_META[s].hint}>
            <span className="grid size-[18px] place-items-center rounded-full" style={{ color: stateInk(s), background: `color-mix(in oklab, ${stateColor(s)} 15%, transparent)`, boxShadow: `inset 0 0 0 1px color-mix(in oklab, ${stateColor(s)} 35%, transparent)` }}>
              <StateIcon state={s} className="size-[11px]" />
            </span>
            {STATE_META[s].label}
            <span className="tnum text-ink-3">{counts[s]}</span>
          </span>
        ))}
      </div>
    </div>
  )
}
