/**
 * Observed history.
 *
 * The daemon exposes NO run history: /api/loops/health is a snapshot (last success, last failure, a failure
 * counter). To give the screen a time dimension anyway, every health poll is recorded here into a small capped
 * ring buffer, persisted to localStorage. Everything derived from it is labelled "observed" in the UI:
 * it only covers the time this app was open and polling, never the loop's real run history.
 *
 * Per loop we keep
 *   - pts:  sampled freshness  (age of the last success / expected interval, x100), on change or every ~30 s
 *   - ok:   every distinct `last_success` timestamp we have seen (so a run that happened while we were watching
 *           is a real, exact marker, not an estimate)
 *   - fail: the same for `last_failure`
 * plus a fleet-wide series of state counts for the KPI tiles.
 *
 * `recordSnapshot` is a pure reducer so it can be unit tested.
 */
import { create } from 'zustand'
import type { HealthState } from './health'

export const HEARTBEAT_MS = 30_000
export const PT_RETENTION_MS = 6 * 3600_000
export const EVENT_RETENTION_MS = 26 * 3600_000
export const MAX_PTS = 360
export const MAX_EVENTS = 300
/** Cap on the freshness ratio (x100): beyond ~4 intervals of silence the line would just flatten the rest of the series. */
export const FRESH_CAP = 400
/** A gap this long between two samples means the app was closed or the daemon unreachable: do not join them with a line. */
export const GAP_MS = 5 * 60_000

export type Pt = [t: number, fresh: number]
/** [t, total, healthy(ok), failing, dark, running] */
export type FleetPt = [t: number, total: number, ok: number, failing: number, dark: number, running: number]

export interface ObservedLoop {
  pts: Pt[]
  ok: number[]
  fail: number[]
  /** Scheduler "last fired" timestamps, for loops the daemon tracks only by job (recipes, prompt loops): fired, outcome unknown. */
  fired: number[]
  /** For change detection between polls. */
  sig: string
  lastOk: number | null
  lastFail: number | null
}

export interface ObservedData {
  v: 1
  /** First moment anything was observed (clamped to the retention window). */
  since: number
  loops: Record<string, ObservedLoop>
  fleet: FleetPt[]
}

export interface Snapshot {
  name: string
  state: HealthState
  running: boolean
  fails: number
  lastSuccess: number | null
  lastFailure: number | null
  /** Scheduler last-fire time; only set for loops without a health row. */
  lastFired?: number | null
  intervalMs: number | null
}

export const emptyObserved = (now: number): ObservedData => ({ v: 1, since: now, loops: {}, fleet: [] })

/** Age of the last success as a percentage of the expected interval; -1 when it cannot be computed. */
export function freshnessPct(intervalMs: number | null, lastSuccess: number | null, now: number): number {
  if (!intervalMs || lastSuccess == null) return -1
  return Math.max(0, Math.min(FRESH_CAP, Math.round(((now - lastSuccess) / intervalMs) * 100)))
}

const pushUnique = (arr: number[], t: number | null, now: number): number[] => {
  if (t == null || arr.includes(t)) return arr
  const next = [...arr, t].sort((a, b) => a - b)
  return next.filter((x) => now - x <= EVENT_RETENTION_MS).slice(-MAX_EVENTS)
}

export function recordSnapshot(prev: ObservedData, snaps: Snapshot[], now: number): ObservedData {
  const loops: Record<string, ObservedLoop> = { ...prev.loops }
  let changed = false

  for (const s of snaps) {
    const old = loops[s.name]
    const sig = `${s.state}|${s.fails}|${s.running ? 1 : 0}`
    const lastPt = old?.pts[old.pts.length - 1]
    const oldOk = old?.ok ?? []
    const oldFail = old?.fail ?? []
    const oldFired = old?.fired ?? []
    const ok = pushUnique(oldOk, s.lastSuccess, now)
    const fail = pushUnique(oldFail, s.lastFailure, now)
    const fired = pushUnique(oldFired, s.lastFired ?? null, now)
    const eventsChanged = ok !== oldOk || fail !== oldFail || fired !== oldFired
    // A newly observed success/failure also samples a point, so the freshness sawtooth resets where it really did.
    const due = !lastPt || old.sig !== sig || eventsChanged || now - lastPt[0] >= HEARTBEAT_MS
    if (!due) continue

    let pts = old?.pts ?? []
    if (due) {
      pts = [...pts, [now, freshnessPct(s.intervalMs, s.lastSuccess ?? s.lastFired ?? null, now)] as Pt].filter((p) => now - p[0] <= PT_RETENTION_MS).slice(-MAX_PTS)
    }
    loops[s.name] = { pts, ok, fail, fired, sig, lastOk: s.lastSuccess ?? old?.lastOk ?? null, lastFail: s.lastFailure ?? old?.lastFail ?? null }
    changed = true
  }

  // Forget loops that are gone and have nothing left inside the retention window.
  const live = new Set(snaps.map((s) => s.name))
  for (const name of Object.keys(loops)) {
    if (live.has(name)) continue
    const l = loops[name]
    const stale = (l.pts.length === 0 || now - l.pts[l.pts.length - 1][0] > PT_RETENTION_MS) && l.ok.every((t) => now - t > EVENT_RETENTION_MS) && l.fail.every((t) => now - t > EVENT_RETENTION_MS) && l.fired.every((t) => now - t > EVENT_RETENTION_MS)
    if (stale) {
      delete loops[name]
      changed = true
    }
  }

  // Fleet series
  let fleet = prev.fleet
  if (snaps.length) {
    const count = (st: HealthState) => snaps.filter((s) => s.state === st).length
    const pt: FleetPt = [now, snaps.length, count('ok'), count('failing'), count('dark'), count('running')]
    const last = fleet[fleet.length - 1]
    const same = last && last[1] === pt[1] && last[2] === pt[2] && last[3] === pt[3] && last[4] === pt[4] && last[5] === pt[5]
    if (!last || !same || now - last[0] >= HEARTBEAT_MS) {
      fleet = [...fleet, pt].filter((p) => now - p[0] <= PT_RETENTION_MS).slice(-MAX_PTS)
      changed = true
    }
  }

  if (!changed) return prev
  return { v: 1, since: Math.max(prev.since, now - EVENT_RETENTION_MS), loops, fleet }
}

/* ── Persistence (localStorage, always try/catch: it can be blocked or full) ─ */

export const STORAGE_KEY = 'km.loops.observed.v1'

const isNum = (x: unknown): x is number => typeof x === 'number' && Number.isFinite(x)

/** Defensive: anything that does not look exactly like what we wrote is discarded rather than trusted. */
export function parseObserved(raw: string | null, now: number): ObservedData {
  if (!raw) return emptyObserved(now)
  try {
    const d = JSON.parse(raw) as Partial<ObservedData>
    if (d?.v !== 1 || !isNum(d.since) || typeof d.loops !== 'object' || d.loops === null || !Array.isArray(d.fleet)) return emptyObserved(now)
    const loops: Record<string, ObservedLoop> = {}
    for (const [name, l] of Object.entries(d.loops)) {
      if (!l || !Array.isArray(l.pts) || !Array.isArray(l.ok) || !Array.isArray(l.fail)) continue
      loops[name] = {
        pts: l.pts.filter((p): p is Pt => Array.isArray(p) && isNum(p[0]) && isNum(p[1])).slice(-MAX_PTS),
        ok: l.ok.filter(isNum).slice(-MAX_EVENTS),
        fail: l.fail.filter(isNum).slice(-MAX_EVENTS),
        fired: Array.isArray(l.fired) ? l.fired.filter(isNum).slice(-MAX_EVENTS) : [],
        sig: typeof l.sig === 'string' ? l.sig : '',
        lastOk: isNum(l.lastOk) ? l.lastOk : null,
        lastFail: isNum(l.lastFail) ? l.lastFail : null
      }
    }
    const fleet = d.fleet.filter((p): p is FleetPt => Array.isArray(p) && p.length === 6 && p.every(isNum)).slice(-MAX_PTS)
    return { v: 1, since: Math.max(d.since, now - EVENT_RETENTION_MS), loops, fleet }
  } catch {
    return emptyObserved(now)
  }
}

function load(): ObservedData {
  try {
    return parseObserved(localStorage.getItem(STORAGE_KEY), Date.now())
  } catch {
    return emptyObserved(Date.now())
  }
}

let saveTimer: ReturnType<typeof setTimeout> | undefined
function scheduleSave(get: () => ObservedData) {
  if (saveTimer) return
  saveTimer = setTimeout(() => {
    saveTimer = undefined
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(get()))
    } catch {
      /* storage unavailable or full: history just will not survive a restart */
    }
  }, 4000)
}

interface ObservedStore {
  data: ObservedData
  record: (snaps: Snapshot[], now?: number) => void
  reset: () => void
}

export const useObserved = create<ObservedStore>((set, get) => ({
  data: load(),
  record: (snaps, now = Date.now()) => {
    const next = recordSnapshot(get().data, snaps, now)
    if (next === get().data) return
    set({ data: next })
    scheduleSave(() => get().data)
  },
  reset: () => {
    set({ data: emptyObserved(Date.now()) })
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* ignore */
    }
  }
}))

/* ── Selectors used by the views ──────────────────────────────────────── */

/**
 * Points inside [now - windowMs, now] with a `null` break inserted wherever the observation had a gap,
 * as [t, value|null]. Unknown freshness (-1) also breaks the line.
 */
export function seriesOf(loop: ObservedLoop | undefined, now: number, windowMs: number): Array<[number, number | null]> {
  if (!loop) return []
  const out: Array<[number, number | null]> = []
  let prevT: number | null = null
  for (const [t, v] of loop.pts) {
    if (now - t > windowMs) continue
    if (prevT != null && t - prevT > GAP_MS) out.push([prevT + 1, null])
    out.push([t, v < 0 ? null : v])
    prevT = t
  }
  return out
}
