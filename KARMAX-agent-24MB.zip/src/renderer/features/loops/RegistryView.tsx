/** Registry tab: browse and install loops from karmax-loops, with a consent dialog before anything is written. */
import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowUpCircle, Check, Download, PackageSearch, RefreshCw, Search, ShieldCheck, Trash2 } from 'lucide-react'
import { Button, EmptyState, ErrorNote, Input, Segmented, Skeleton } from '@/design/primitives'
import { fadeUp, stagger } from '@/design/motion'
import { cn } from '@/design/cn'
import { StatusPill } from '@/design/status'
import type { RegistryEntry } from '@/lib/api/schemas'
import { ApiError } from '@/lib/api/client'
import { useRegistry, useRegistryRefresh, useUninstallLoop } from './data'
import { InstallDialog } from './InstallDialog'
import { KIND_META, kindOf, type LoopKind } from './model'
import { Chip, KindGlyph, useNow, whenText } from './ui'

type KindFilter = 'all' | 'recipe' | 'workflow'
type StateFilter = 'all' | 'installed' | 'available' | 'engine'

function Card({ e, onInstall }: { e: RegistryEntry; onInstall: (e: RegistryEntry) => void }) {
  const uninstall = useUninstallLoop()
  const [confirm, setConfirm] = useState(false)
  const kind = kindOf(e.kind)
  const outdated = e.installed && !!e.installedVersion && !!e.version && e.installedVersion !== e.version
  return (
    <motion.article variants={fadeUp} className="glass relative flex flex-col rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <KindGlyph kind={kind} size={16} title />
            <h3 className="truncate text-[14px] font-semibold tracking-tight text-ink">{e.name}</h3>
          </div>
          <div className="mt-0.5 text-[11.5px] text-ink-3">
            <span className="tnum">v{e.version || '?'}</span>
            {e.author && <> · by {e.author}</>}
            {' · '}
            {KIND_META[kind].label}
          </div>
        </div>
        {e.installed ? (
          e.active ? (
            <StatusPill tone="good" label="Active" />
          ) : (
            <StatusPill tone="muted" label="Inactive" />
          )
        ) : (
          <span className="rounded-full px-2 py-[3px] text-[11px] font-medium text-ink-3 ring-1 ring-line">Not installed</span>
        )}
      </div>

      <p className="mt-2.5 line-clamp-3 min-h-[54px] text-[12.5px] leading-[18px] text-ink-2">{e.description || 'No description.'}</p>

      <div className="mt-2.5 flex min-h-[24px] flex-wrap items-center gap-1.5">
        {e.shipsWithEngine && (
          <Chip className="gap-1" title="Embedded in the KARMAX binary; nothing to fetch and it cannot be removed">
            <ShieldCheck className="size-3" /> Ships with engine
          </Chip>
        )}
        {outdated && (
          <Chip className="gap-1" title={`Installed ${e.installedVersion}`}>
            <ArrowUpCircle className="size-3" /> Update to v{e.version}
          </Chip>
        )}
        {e.requires.slice(0, 3).map((r) => (
          <Chip key={r} mono title="Requires">{r}</Chip>
        ))}
        {e.requires.length > 3 && <Chip title={e.requires.slice(3).join(', ')}>+{e.requires.length - 3}</Chip>}
      </div>

      <div className="mt-3 flex items-center justify-between gap-2 border-t border-line pt-3">
        {e.sourceUrl ? (
          <span className="min-w-0 truncate text-[11px] text-ink-3" title={e.sourceUrl}>
            {e.sourceUrl.replace(/^https?:\/\/(www\.)?/, '')}
          </span>
        ) : (
          <span />
        )}
        <div className="flex shrink-0 items-center gap-1.5">
          {e.installed && !e.shipsWithEngine && (
            confirm ? (
              <>
                <Button size="sm" variant="ghost" onClick={() => setConfirm(false)}>Cancel</Button>
                <Button size="sm" variant="danger" loading={uninstall.isPending} icon={<Trash2 className="size-3.5" />} onClick={() => uninstall.mutate(e.name, { onSettled: () => setConfirm(false) })}>
                  Remove {e.name}
                </Button>
              </>
            ) : (
              <Button size="sm" variant="ghost" icon={<Trash2 className="size-3.5" />} onClick={() => setConfirm(true)} aria-label={`Uninstall ${e.name}`}>Uninstall</Button>
            )
          )}
          {e.installed && e.shipsWithEngine && <span className="inline-flex items-center gap-1 text-[11.5px] text-ink-3"><Check className="size-3.5" /> Built in</span>}
          {!confirm && (!e.installed || outdated) && (
            <Button size="sm" variant="primary" icon={<Download className="size-3.5" />} onClick={() => onInstall(e)} aria-label={`${outdated ? 'Update' : 'Install'} ${e.name}`}>
              {outdated ? 'Update' : 'Install'}
            </Button>
          )}
        </div>
      </div>
    </motion.article>
  )
}

export function RegistryView() {
  const q = useRegistry()
  const refresh = useRegistryRefresh()
  const now = useNow()
  const [search, setSearch] = useState('')
  const [kind, setKind] = useState<KindFilter>('all')
  const [state, setState] = useState<StateFilter>('all')
  const [target, setTarget] = useState<RegistryEntry | null>(null)

  const entries = q.data?.entries ?? []
  const shown = useMemo(() => {
    const s = search.trim().toLowerCase()
    return entries
      .filter((e) => (kind === 'all' || e.kind === kind) && (state === 'all' || (state === 'installed' ? e.installed : state === 'available' ? !e.installed : e.shipsWithEngine)) && (!s || `${e.name} ${e.description} ${e.author} ${e.requires.join(' ')}`.toLowerCase().includes(s)))
      .sort((a, b) => Number(b.installed) - Number(a.installed) || a.name.localeCompare(b.name))
  }, [entries, search, kind, state])

  const fetchedAt = q.data?.fetchedAt ? new Date(q.data.fetchedAt).getTime() : null
  const status = q.error instanceof ApiError ? q.error.status : 0

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2.5">
        <div className="relative min-w-[200px] max-w-[320px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search registry" aria-label="Search registry" className="h-8 pl-9" />
        </div>
        <Segmented<KindFilter> value={kind} onChange={setKind} options={[{ value: 'all', label: 'All kinds' }, { value: 'recipe', label: 'Recipes' }, { value: 'workflow', label: 'Workflows' }]} />
        <Segmented<StateFilter> value={state} onChange={setState} options={[{ value: 'all', label: 'All' }, { value: 'installed', label: 'Installed' }, { value: 'available', label: 'Available' }, { value: 'engine', label: 'Ships with engine' }]} />
        <div className="ml-auto flex items-center gap-3 text-[11.5px] text-ink-3">
          {fetchedAt && <span>Index fetched {whenText(fetchedAt, now)}</span>}
          <Button size="sm" variant="subtle" icon={<RefreshCw className={cn('size-3.5', refresh.isPending && 'animate-[km-spin_0.8s_linear_infinite]')} />} disabled={refresh.isPending} onClick={() => refresh.mutate()}>
            Refresh index
          </Button>
        </div>
      </div>

      {refresh.error && <ErrorNote error={refresh.error} />}

      {q.isPending ? (
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
          {Array.from({ length: 6 }, (_, i) => <Skeleton key={i} className="h-[230px] rounded-2xl" />)}
        </div>
      ) : q.error ? (
        <div className="glass rounded-2xl p-6">
          <div className="mx-auto max-w-lg text-center">
            <div className="text-[14px] font-semibold text-ink">{status === 502 ? 'The registry could not be reached' : 'Could not load the registry'}</div>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-3">The daemon fetches the karmax-loops index from the network (and caches it for five minutes). Installing needs it; the loops you already run are unaffected.</p>
            <div className="mt-4"><ErrorNote error={q.error} onRetry={() => void q.refetch()} /></div>
          </div>
        </div>
      ) : shown.length === 0 ? (
        <div className="glass rounded-2xl"><EmptyState icon={<PackageSearch className="size-5" />} title={entries.length ? 'Nothing matches' : 'The registry is empty'} body={entries.length ? 'Try a different search or clear the filters.' : 'The index returned no entries.'} /></div>
      ) : (
        <motion.div variants={stagger(0.03)} initial="hidden" animate="show" key={`${kind}${state}${search}`} className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
          {shown.map((e) => <Card key={e.name} e={e} onInstall={setTarget} />)}
        </motion.div>
      )}

      <InstallDialog entry={target} onClose={() => setTarget(null)} />
    </div>
  )
}

export type { LoopKind }
