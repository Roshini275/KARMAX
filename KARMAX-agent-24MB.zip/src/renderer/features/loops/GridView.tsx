import { memo, useMemo } from 'react'
import { motion } from 'framer-motion'
import { CalendarClock, ChevronRight } from 'lucide-react'
import { fadeUp, stagger } from '@/design/motion'
import { EmptyState } from '@/design/primitives'
import { cn } from '@/design/cn'
import { TimeSpark } from './charts'
import { lastLabel, lastTime, nextLabel, nextShort, type LoopVM } from './model'
import { seriesOf, useObserved } from './observed'
import { Chip, KindGlyph, StatePill, When, dateTime, stateColor, useNow } from './ui'
import { STATE_META } from './health'
import { KIND_META } from './model'
import { Search } from 'lucide-react'

const LoopCard = memo(function LoopCard({ vm, onOpen }: { vm: LoopVM; onOpen: (n: string) => void }) {
  const now = useNow()
  const track = useObserved((s) => s.data.loops[vm.name])
  const series = useMemo(() => seriesOf(track, now, 6 * 3600_000), [track, now])
  const first = track?.pts[0]?.[0]
  const attention = vm.state === 'failing' || vm.state === 'dark' || vm.state === 'running'
  const c = stateColor(vm.state)
  const hasFreshness = vm.sched.intervalMs != null

  return (
    <motion.article variants={fadeUp} className="glass group relative flex flex-col overflow-hidden rounded-2xl p-4 transition-[box-shadow,transform] duration-200 hover:-translate-y-px hover:shadow-pop">
      {attention && <div aria-hidden className="absolute inset-x-0 top-0 h-px" style={{ background: `linear-gradient(90deg, transparent, ${c}, transparent)`, opacity: 0.8 }} />}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <KindGlyph kind={vm.kind} size={16} title />
            {/* stretched button: the whole card opens the drawer, footer content stays selectable */}
            <button onClick={() => onOpen(vm.name)} className="truncate text-left text-[14px] font-semibold tracking-tight text-ink outline-none after:absolute after:inset-0 after:rounded-2xl focus-visible:after:ring-2 focus-visible:after:ring-accent" aria-label={`${vm.name}, ${STATE_META[vm.state].label}. Open details`}>
              {vm.name}
            </button>
          </div>
          <p className="mt-1 line-clamp-2 min-h-[36px] text-[12px] leading-[18px] text-ink-3">{vm.description || KIND_META[vm.kind].blurb}</p>
        </div>
        <StatePill state={vm.state} className="shrink-0" />
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <Chip className="gap-1.5">
          <CalendarClock className="size-3" />
          {vm.sched.label}
        </Chip>
        <Chip>{KIND_META[vm.kind].label}</Chip>
        {vm.tracking === 'schedule' && <Chip title="The daemon records when this fires, not whether it succeeded">outcome not tracked</Chip>}
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-3 text-[12px]">
        <div>
          <dt className="text-ink-3">{lastLabel(vm)}</dt>
          <dd className="mt-0.5 font-medium text-ink" title={lastTime(vm) ? dateTime(lastTime(vm)) : undefined}>
            {lastTime(vm) ? <When t={lastTime(vm)} /> : <span className="font-normal text-ink-3">never</span>}
          </dd>
        </div>
        <div>
          <dt className="text-ink-3">{nextLabel(vm).replace(' (estimated)', '')}</dt>
          <dd className="mt-0.5 font-medium text-ink">
            {vm.nextDue ? (
              <>
                <When t={vm.nextDue} future /> <span className="font-normal text-ink-3">({nextShort(vm)})</span>
              </>
            ) : (
              <span className="font-normal text-ink-3">{vm.enabled ? 'not estimable' : 'disabled'}</span>
            )}
          </dd>
        </div>
      </dl>

      <div className={cn('mt-3 flex items-end justify-between gap-3 border-t border-line pt-3', !hasFreshness && 'opacity-70')}>
        <div className="min-w-0">
          <div className="text-[11px] font-medium text-ink-2">Freshness, worst per cycle</div>
          <div className="mt-0.5 text-[10.5px] leading-snug text-ink-3">{hasFreshness ? (first ? `since ${dateTime(first).replace(/:\d\d$/, '')}, this app only` : 'collecting…') : 'no fixed interval'}</div>
        </div>
        <TimeSpark series={hasFreshness ? series : []} now={now} width={128} height={32} intervalMs={vm.sched.intervalMs} label={`${vm.name} worst freshness per interval, observed by this app`} />
      </div>
      <ChevronRight aria-hidden className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-ink-3 opacity-0 transition-opacity group-hover:opacity-60" />
    </motion.article>
  )
})

export function GridView({ vms, onOpen }: { vms: LoopVM[]; onOpen: (n: string) => void }) {
  if (vms.length === 0) return <EmptyState icon={<Search className="size-5" />} title="No loops match" body="Try a different search or clear the filter." />
  return (
    <motion.div variants={stagger(0.035)} initial="hidden" animate="show" className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
      {vms.map((v) => (
        <LoopCard key={v.name} vm={v} onOpen={onOpen} />
      ))}
    </motion.div>
  )
}
