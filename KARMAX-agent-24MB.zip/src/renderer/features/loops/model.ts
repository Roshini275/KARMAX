/**
 * The view-model every Loops view renders: GET /api/loops (what exists, how it is scheduled, enabled or not)
 * joined with GET /api/loops/health (how it is doing) plus the schedule maths.
 */
import { deriveHealthState, normalizeHealth, parseTs, STATE_META, trackingOf, type HealthState, type JobFacts, type NormalizedHealth, type RawHealth, type Tracking } from './health'
import { estimateNextFire, ringIndex, scheduleToInterval, type ScheduleInfo } from './schedule'

export type LoopKind = 'recipe' | 'workflow' | 'compiled' | 'prompt' | 'other'

export interface KindMeta {
  label: string
  /** How it runs, in one line (KARMAX/internal/api/server.go LoopInfo.Kind). */
  blurb: string
}

export const KIND_META: Record<LoopKind, KindMeta> = {
  recipe: { label: 'Recipe', blurb: 'Interpreted YAML; hot-reloaded, no restart.' },
  workflow: { label: 'Workflow', blurb: 'Signed WASM module; needs a daemon restart to load.' },
  compiled: { label: 'Compiled', blurb: 'Built into the KARMAX binary.' },
  prompt: { label: 'Prompt', blurb: 'A scheduled prompt fired straight at the agent (karmax.yaml).' },
  other: { label: 'Other', blurb: 'A loop kind this app does not recognise.' }
}
export const KIND_ORDER: LoopKind[] = ['recipe', 'workflow', 'compiled', 'prompt']

export function kindOf(k: string | null | undefined): LoopKind {
  return k === 'recipe' || k === 'workflow' || k === 'compiled' || k === 'prompt' ? k : 'other'
}

export interface LoopListItem {
  name: string
  description?: string
  schedule?: string
  webhook?: string
  events?: string[]
  kind?: string
  enabled?: boolean
}

export interface LoopHealthItem extends RawHealth {
  name: string
  schedule?: string
}

/** A scheduler job from GET /api/activity. Names are "loopkit:<n>" (compiled, workflow), "recipe:<n>", "loop:<n>" (prompt). */
export interface JobItem {
  name: string
  last_run?: string | null
  next_run?: string | null
  run_count?: number
}

export function jobFor(name: string, jobs: JobItem[]): JobFacts | null {
  for (const prefix of ['loopkit:', 'recipe:', 'loop:']) {
    const j = jobs.find((x) => x.name === prefix + name)
    if (j) return { lastRun: parseTs(j.last_run), nextRun: parseTs(j.next_run), runCount: j.run_count ?? 0 }
  }
  return null
}

export interface LoopVM {
  name: string
  kind: LoopKind
  description: string
  /** Raw schedule string exactly as the daemon reports it (list wins over health). */
  schedule: string
  sched: ScheduleInfo
  enabled: boolean
  webhook?: string
  events: string[]
  health: NormalizedHealth | null
  /** Scheduler facts (real last/next fire) when the daemon has a job for it. */
  job: JobFacts | null
  tracking: Tracking
  state: HealthState
  lastSuccess: number | null
  lastFailure: number | null
  /** The later of success/failure, or the scheduler's last fire for loops without health: when we last know it ran. */
  lastRun: number | null
  /** Estimated next fire (epoch ms). Past values mean overdue. Null when it cannot be estimated. */
  nextDue: number | null
  /** True when nextDue is the daemon's own retry timer rather than the schedule. */
  nextIsRetry: boolean
  /** 'scheduler' = the daemon's own next_run; 'estimate' = computed here from the schedule string. */
  nextSource: 'scheduler' | 'estimate' | 'retry' | null
  /** Index into RING_BUCKETS, or RING_BUCKETS.length for the event ring. */
  ring: number
}

export function buildLoopVMs(list: LoopListItem[], health: LoopHealthItem[], now: number, jobs: JobItem[] = []): LoopVM[] {
  const hByName = new Map(health.map((h) => [h.name, h]))
  const seen = new Set<string>()
  const out: LoopVM[] = []

  const make = (l: LoopListItem, h: LoopHealthItem | undefined): LoopVM => {
    const nh = h ? normalizeHealth(h) : null
    const enabled = l.enabled !== false
    const schedule = (l.schedule || h?.schedule || '').trim()
    const events = l.events ?? []
    const sched = scheduleToInterval(schedule, { events, webhook: l.webhook })
    const job = jobFor(l.name, jobs)
    const state = deriveHealthState({ enabled, health: nh, job, maxGapMs: sched.maxGapMs, now })
    const lastSuccess = nh?.lastSuccess ?? null
    const lastFailure = nh?.lastFailure ?? null
    const lastRun = nh ? (lastSuccess != null || lastFailure != null ? Math.max(lastSuccess ?? 0, lastFailure ?? 0) : null) : (job?.lastRun ?? null)

    let nextDue: number | null = null
    let nextIsRetry = false
    let nextSource: LoopVM['nextSource'] = null
    if (enabled) {
      if (nh && nh.consecutiveFailures > 0 && nh.retryAt != null && nh.retryAt > now) {
        nextDue = nh.retryAt
        nextIsRetry = true
        nextSource = 'retry'
      } else if (job?.nextRun != null && job.nextRun > now - 60_000) {
        nextDue = job.nextRun
        nextSource = 'scheduler'
      } else {
        nextDue = estimateNextFire(schedule, { lastRun, now })
        nextSource = nextDue != null ? 'estimate' : null
      }
    }
    return {
      name: l.name,
      kind: kindOf(l.kind),
      description: l.description ?? '',
      schedule,
      sched,
      enabled,
      webhook: l.webhook,
      events,
      health: nh,
      job,
      tracking: trackingOf(nh, job),
      state,
      lastSuccess,
      lastFailure,
      lastRun,
      nextDue,
      nextIsRetry,
      nextSource,
      ring: ringIndex(sched.intervalMs)
    }
  }

  for (const l of list) {
    if (seen.has(l.name)) continue
    seen.add(l.name)
    out.push(make(l, hByName.get(l.name)))
  }
  // A health row with no list entry (the daemon registers it, /api/loops did not mention it yet): still show it.
  for (const h of health) {
    if (seen.has(h.name)) continue
    seen.add(h.name)
    out.push(make({ name: h.name, schedule: h.schedule, enabled: true }, h))
  }
  return out
}

/** Worst news first, then by name: what an operator wants at the top of any list. */
export function sortLoops(vms: LoopVM[]): LoopVM[] {
  return [...vms].sort((a, b) => STATE_META[a.state].rank - STATE_META[b.state].rank || a.name.localeCompare(b.name))
}

/* ── Filtering shared by the constellation, grid and timeline ──────────── */

export type LoopFilterMode = 'all' | 'attention' | 'running' | 'disabled'

export interface LoopFilter {
  q: string
  mode: LoopFilterMode
}

export function matchesFilter(vm: LoopVM, f: LoopFilter): boolean {
  const q = f.q.trim().toLowerCase()
  if (q && !vm.name.toLowerCase().includes(q) && !vm.description.toLowerCase().includes(q) && !vm.sched.label.toLowerCase().includes(q)) return false
  switch (f.mode) {
    case 'attention':
      return vm.state === 'failing' || vm.state === 'dark'
    case 'running':
      return vm.state === 'running'
    case 'disabled':
      return vm.state === 'disabled'
    default:
      return true
  }
}

/** Deterministic 32-bit FNV-1a hash: the layout of the constellation must not move between renders or sessions. */
export function hashName(name: string): number {
  let h = 0x811c9dc5
  for (let i = 0; i < name.length; i++) {
    h ^= name.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return h >>> 0
}

/** Wording that stays honest about what the daemon reports for this loop. */
export const lastLabel = (vm: LoopVM) => (vm.tracking === 'schedule' ? 'Last fired' : 'Last success')
export const lastTime = (vm: LoopVM) => (vm.tracking === 'schedule' ? vm.lastRun : vm.lastSuccess)
export const nextLabel = (vm: LoopVM) => (vm.nextSource === 'retry' ? 'Retry at' : vm.nextSource === 'scheduler' ? 'Next run' : 'Next due (estimated)')
export const nextShort = (vm: LoopVM) => (vm.nextSource === 'retry' ? 'retry' : vm.nextSource === 'scheduler' ? 'scheduled' : 'estimated')
