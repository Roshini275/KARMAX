/**
 * Small shared pieces of the Loops screen: shared clock, element size, kind glyphs, state icons/pills,
 * relative-time text, copy button, modal and toasts. Nothing here knows about the daemon.
 */
import { createPortal } from 'react-dom'
import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, CheckCircle2, Clock, Copy, LoaderCircle, OctagonX, Pause, TriangleAlert, X, CircleAlert, Info } from 'lucide-react'
import { create } from 'zustand'
import { cn } from '@/design/cn'
import { IconButton } from '@/design/primitives'
import { StatusPill, toneVar, type Tone } from '@/design/status'
import { timeAgo } from '@/lib/format'
import { STATE_META, type HealthState } from './health'
import { KIND_META, type LoopKind } from './model'

/* ── one shared 1 Hz clock ─────────────────────────────────────────────── */

const listeners = new Set<() => void>()
let tick = Math.floor(Date.now() / 1000) * 1000
let timer: ReturnType<typeof setInterval> | undefined

function subscribe(cb: () => void) {
  listeners.add(cb)
  if (!timer) {
    timer = setInterval(() => {
      tick = Math.floor(Date.now() / 1000) * 1000
      listeners.forEach((l) => l())
    }, 1000)
  }
  return () => {
    listeners.delete(cb)
    if (listeners.size === 0 && timer) {
      clearInterval(timer)
      timer = undefined
    }
  }
}

/** Current time, ticking once a second. Every consumer shares one interval. */
export function useNow(): number {
  return useSyncExternalStore(subscribe, () => tick, () => tick)
}

export function useElementSize<T extends HTMLElement>() {
  const ref = useRef<T | null>(null)
  const [size, setSize] = useState({ w: 0, h: 0 })
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const ro = new ResizeObserver(([e]) => {
      const r = e.contentRect
      setSize((s) => (Math.abs(s.w - r.width) < 0.5 && Math.abs(s.h - r.height) < 0.5 ? s : { w: r.width, h: r.height }))
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  return [ref, size] as const
}

/* ── time text ─────────────────────────────────────────────────────────── */

export const clock = (t: number | null | undefined): string => {
  if (t == null) return '—'
  const d = new Date(t)
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

export const dateTime = (t: number | null | undefined): string => {
  if (t == null) return '—'
  const d = new Date(t)
  const same = new Date().toDateString() === d.toDateString()
  return `${same ? '' : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' '}${clock(t)}:${String(d.getSeconds()).padStart(2, '0')}`
}

/** "3m ago", "in 12m", "overdue 4m". */
export function whenText(t: number | null | undefined, now: number, opts: { future?: boolean } = {}): string {
  if (t == null) return '—'
  if (opts.future && t < now - 5000) return `overdue ${timeAgo(t, now).replace(' ago', '')}`
  return timeAgo(t, now)
}

export function When({ t, future, className }: { t: number | null | undefined; future?: boolean; className?: string }) {
  const now = useNow()
  return <span className={cn('tnum', className)}>{whenText(t, now, { future })}</span>
}

/* ── kind glyphs: kind is encoded by SHAPE, never by the reserved status colours ─ */

const SHAPES: Record<LoopKind, string> = {
  recipe: 'M-14,0a14,14 0 1,0 28,0a14,14 0 1,0 -28,0Z',
  workflow: 'M0,-16L13.9,-8L13.9,8L0,16L-13.9,8L-13.9,-8Z',
  compiled: 'M0,-17L17,0L0,17L-17,0Z',
  prompt: 'M0,-16.5L16,11.5L-16,11.5Z',
  other: 'M-11.5,-11.5H11.5V11.5H-11.5Z'
}
export const shapePath = (k: LoopKind) => SHAPES[k]

export function KindGlyph({ kind, size = 16, className, title }: { kind: LoopKind; size?: number; className?: string; title?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="-20 -20 40 40" className={cn('shrink-0 text-ink-2', className)} role="img" aria-label={KIND_META[kind].label}>
      {title && <title>{KIND_META[kind].label}</title>}
      <path d={SHAPES[kind]} fill="none" stroke="currentColor" strokeWidth={3.4} strokeLinejoin="round" />
    </svg>
  )
}

/* ── state icons / pills ───────────────────────────────────────────────── */

const ICONS = { loader: LoaderCircle, check: Check, 'octagon-x': OctagonX, 'triangle-alert': TriangleAlert, clock: Clock, pause: Pause } as const

export const stateIcon = (s: HealthState) => ICONS[STATE_META[s].icon]

export function StateIcon({ state, className, strokeWidth = 2.6 }: { state: HealthState; className?: string; strokeWidth?: number }) {
  const Icon = ICONS[STATE_META[state].icon]
  return <Icon className={cn('size-3', state === 'running' && 'animate-[km-spin_1s_linear_infinite]', className)} strokeWidth={strokeWidth} aria-hidden />
}

/**
 * Text/icon colour for a state. The raw status colours are for marks and fills; as TEXT on the light surface amber
 * is far below 3:1, so warn (and slightly good) are pulled towards the ink colour. Icon + label still carry the meaning.
 */
export const stateInk = (s: HealthState): string => {
  const t = STATE_META[s].tone
  if (t === 'warn') return 'color-mix(in oklab, var(--warn) 52%, var(--ink))'
  if (t === 'good') return 'color-mix(in oklab, var(--good) 80%, var(--ink))'
  if (t === 'crit') return 'var(--crit)'
  return toneVar[t]
}

export function StatePill({ state, className }: { state: HealthState; className?: string }) {
  const m = STATE_META[state]
  const c = toneVar[m.tone]
  return (
    <span
      className={cn('inline-flex items-center gap-1.5 rounded-full px-2 py-[3px] text-[11px] font-semibold ring-1', className)}
      style={{
        color: stateInk(state),
        background: `color-mix(in oklab, ${c} 13%, transparent)`,
        ['--tw-ring-color' as string]: `color-mix(in oklab, ${c} 32%, transparent)`
      }}
    >
      <StateIcon state={state} />
      {m.label}
    </span>
  )
}

export const stateTone = (s: HealthState): Tone => STATE_META[s].tone
export const stateColor = (s: HealthState): string => toneVar[STATE_META[s].tone]

/* ── misc ──────────────────────────────────────────────────────────────── */

export function useCopy() {
  const [copied, setCopied] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  useEffect(() => () => clearTimeout(timer.current), [])
  const copy = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      // clipboard API blocked (insecure context / permissions): fall back to a temporary textarea
      try {
        const ta = document.createElement('textarea')
        ta.value = text
        ta.style.position = 'fixed'
        ta.style.opacity = '0'
        document.body.appendChild(ta)
        ta.select()
        document.execCommand('copy')
        ta.remove()
      } catch {
        return
      }
    }
    setCopied(true)
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setCopied(false), 1600)
  }, [])
  return { copied, copy }
}

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const { copied, copy } = useCopy()
  return (
    <IconButton label={copied ? 'Copied' : label} onClick={() => void copy(text)} className="size-7" aria-live="polite">
      {copied ? <Check className="size-3.5 text-good" strokeWidth={3} /> : <Copy className="size-3.5" />}
    </IconButton>
  )
}

export function Chip({ children, className, title, mono }: { children: ReactNode; className?: string; title?: string; mono?: boolean }) {
  return (
    <span title={title} className={cn('inline-flex items-center gap-1 rounded-md bg-surface-2 px-1.5 py-0.5 text-[11px] font-medium text-ink-2 ring-1 ring-line', mono && 'font-[family-name:var(--font-mono)] text-[10.5px]', className)}>
      {children}
    </span>
  )
}

/* ── modal ─────────────────────────────────────────────────────────────── */

const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  width = 640,
  dismissible = true
}: {
  open: boolean
  onClose: () => void
  title: ReactNode
  subtitle?: ReactNode
  children: ReactNode
  footer?: ReactNode
  width?: number
  dismissible?: boolean
}) {
  const panel = useRef<HTMLDivElement>(null)
  const prevFocus = useRef<HTMLElement | null>(null)

  useEffect(() => {
    if (!open) return
    prevFocus.current = document.activeElement as HTMLElement | null
    const t = setTimeout(() => {
      const first = panel.current?.querySelector<HTMLElement>('[data-autofocus]') ?? panel.current?.querySelector<HTMLElement>(FOCUSABLE)
      first?.focus()
    }, 30)
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissible) {
        e.stopPropagation()
        onClose()
      } else if (e.key === 'Tab' && panel.current) {
        const els = [...panel.current.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((el) => el.offsetParent !== null)
        if (!els.length) return
        const first = els[0]
        const last = els[els.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    // capture: the Drawer underneath also listens for Escape on window, and must not close with us
    window.addEventListener('keydown', onKey, true)
    return () => {
      clearTimeout(t)
      window.removeEventListener('keydown', onKey, true)
      prevFocus.current?.focus?.()
    }
  }, [open, onClose, dismissible])

  if (typeof document === 'undefined') return null
  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] grid place-items-center p-4">
          <motion.div className="absolute inset-0 bg-black/55 backdrop-blur-[3px]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={dismissible ? onClose : undefined} />
          <motion.div
            ref={panel}
            role="dialog"
            aria-modal="true"
            aria-label={typeof title === 'string' ? title : undefined}
            className="glass relative flex max-h-[min(86vh,760px)] w-full flex-col overflow-hidden rounded-2xl shadow-pop"
            style={{ maxWidth: width, background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
            initial={{ opacity: 0, y: 14, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: { duration: 0.22, ease: [0.22, 1, 0.36, 1] } }}
            exit={{ opacity: 0, y: 8, transition: { duration: 0.12 } }}
          >
            <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
              <div className="min-w-0">
                <div className="truncate text-[15px] font-semibold tracking-tight">{title}</div>
                {subtitle && <div className="mt-0.5 text-[12px] text-ink-3">{subtitle}</div>}
              </div>
              {dismissible && (
                <IconButton label="Close dialog" onClick={onClose}>
                  <X className="size-4" />
                </IconButton>
              )}
            </div>
            <div className="scroll-thin min-h-0 flex-1 overflow-auto px-5 py-4">{children}</div>
            {footer && <div className="flex items-center justify-end gap-2 border-t border-line px-5 py-3">{footer}</div>}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  )
}

/* ── toasts ────────────────────────────────────────────────────────────── */

export interface Toast {
  id: number
  kind: 'ok' | 'error' | 'info'
  text: string
}
let toastSeq = 0
export const useToasts = create<{ items: Toast[]; push: (kind: Toast['kind'], text: string, ttl?: number) => void; dismiss: (id: number) => void }>((set, get) => ({
  items: [],
  push: (kind, text, ttl = 4500) => {
    const id = ++toastSeq
    set({ items: [...get().items.slice(-3), { id, kind, text }] })
    setTimeout(() => get().dismiss(id), ttl)
  },
  dismiss: (id) => set({ items: get().items.filter((t) => t.id !== id) })
}))

/** `inset` keeps toasts clear of a drawer that is open on the right. */
export function ToastHost({ inset = 0 }: { inset?: number }) {
  const items = useToasts((s) => s.items)
  const dismiss = useToasts((s) => s.dismiss)
  if (typeof document === 'undefined') return null
  return createPortal(
    <div className="pointer-events-none fixed bottom-4 z-[70] flex w-[340px] max-w-[calc(100vw-32px)] flex-col gap-2 transition-[right] duration-200" style={{ right: `min(${16 + inset}px, calc(100vw - 356px))` }} role="status" aria-live="polite">
      <AnimatePresence initial={false}>
        {items.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: 12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: { duration: 0.2, ease: [0.22, 1, 0.36, 1] } }}
            exit={{ opacity: 0, x: 24, transition: { duration: 0.14 } }}
            className="glass pointer-events-auto flex items-start gap-2.5 rounded-xl px-3.5 py-3 text-[12.5px] shadow-pop"
            style={{ background: 'color-mix(in oklab, var(--panel) 92%, transparent)' }}
          >
            {t.kind === 'ok' ? <CheckCircle2 className="mt-px size-4 shrink-0 text-good" /> : t.kind === 'error' ? <CircleAlert className="mt-px size-4 shrink-0 text-crit" /> : <Info className="mt-px size-4 shrink-0 text-accent" />}
            <span className="selectable min-w-0 flex-1 break-words text-ink">{t.text}</span>
            <button className="text-ink-3 hover:text-ink" aria-label="Dismiss" onClick={() => dismiss(t.id)}>
              <X className="size-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>,
    document.body
  )
}
