/**
 * KPI strip: stat tiles per the dataviz contract (label · value · delta vs a named period · 12-point trend).
 * One hero figure (Healthy), the rest are regular tiles. Trends and deltas come from the OBSERVED fleet series,
 * so they only exist once the app has watched for a minute, and the period is always named.
 */
import { motion } from 'framer-motion'
import { ArrowDownRight, ArrowUpRight, Minus, Orbit, Timer } from 'lucide-react'
import type { ReactNode } from 'react'
import { cn } from '@/design/cn'
import { Skeleton } from '@/design/primitives'
import { fadeUp, stagger } from '@/design/motion'
import { countStates } from './health'
import { nextShort, type LoopVM } from './model'
import { fleetValues, MiniSpark } from './charts'
import { useObserved, type FleetPt } from './observed'
import { StateIcon, useNow, stateColor, stateInk } from './ui'
import type { HealthState } from './health'

export function fmtCountdown(ms: number): string {
  if (ms <= 0) return 'due now'
  const s = Math.round(ms / 1000)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ${String(s % 60).padStart(2, '0')}s`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ${String(m % 60).padStart(2, '0')}m`
  return `${Math.floor(h / 24)}d ${h % 24}h`
}

const since = (ms: number) => {
  const m = Math.round(ms / 60_000)
  if (m < 1) return 'under a minute ago'
  if (m < 60) return `${m} min ago`
  return `${Math.round(m / 6) / 10} h ago`
}

interface TileProps {
  label: string
  value: ReactNode
  hero?: boolean
  state?: HealthState
  quiet?: boolean
  context?: ReactNode
  trend?: number[] | null
  trendLabel: string
  delta?: { d: number; period: string; goodWhen: 'up' | 'down' | 'neutral'; unit?: string } | null
  icon?: ReactNode
}

function Delta({ d, period, goodWhen, unit = '' }: NonNullable<TileProps['delta']>) {
  if (d === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-[11.5px] text-ink-3">
        <Minus className="size-3" /> no change vs {period}
      </span>
    )
  }
  const up = d > 0
  const good = goodWhen === 'neutral' ? null : goodWhen === (up ? 'up' : 'down')
  const Icon = up ? ArrowUpRight : ArrowDownRight
  return (
    <span className="inline-flex items-center gap-1 text-[11.5px] text-ink-2">
      <Icon className={cn('size-3.5', good === true && 'text-good', good === false && 'text-crit', good === null && 'text-ink-3')} strokeWidth={2.6} />
      <span className="tnum font-semibold text-ink">
        {up ? '+' : '−'}
        {Math.abs(d)}
        {unit}
      </span>
      <span className="text-ink-3">vs {period}</span>
    </span>
  )
}

/** Six across when there is room, otherwise 3x2 or 2x3: never an orphaned row of one or two tiles. */
const GRID = 'grid grid-cols-2 gap-3 min-[820px]:grid-cols-3 min-[1280px]:grid-cols-6'

function Tile({ label, value, hero, state, quiet, context, trend, trendLabel, delta, icon }: TileProps) {
  return (
    <motion.div
      variants={fadeUp}
      className={cn('glass relative flex min-w-0 flex-col justify-between overflow-hidden rounded-2xl p-4', 'min-h-[128px]')}
      style={hero ? { background: 'linear-gradient(140deg, color-mix(in oklab, var(--accent) 11%, var(--surface)) 0%, color-mix(in oklab, var(--surface) 78%, transparent) 62%)' } : undefined}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="label-micro">{label}</span>
        {(state || icon) && (
          <span
            className="grid size-[22px] place-items-center rounded-md"
            style={{
              color: state && !quiet ? stateInk(state) : 'var(--ink-3)',
              background: state && !quiet ? `color-mix(in oklab, ${stateColor(state)} 14%, transparent)` : 'var(--surface-2)'
            }}
          >
            {state ? <StateIcon state={state} className="size-[13px]" /> : icon}
          </span>
        )}
      </div>
      <div className="mt-2 flex items-end justify-between gap-3">
        <div className={cn('font-semibold leading-none tracking-[-0.035em] text-ink', hero ? 'text-[48px]' : 'text-[30px]')}>{value}</div>
        {trend != null && <MiniSpark values={trend ?? []} label={trendLabel} width={hero ? 50 : 60} height={hero ? 36 : 30} />}
      </div>
      <div className="mt-2 min-h-[16px] text-[11.5px] leading-tight text-ink-3" title={typeof context === 'string' ? context : undefined}>
        <span className="line-clamp-2">{context}</span>
      </div>
      <div className="mt-1 min-h-[17px]">{delta && <Delta {...delta} />}</div>
    </motion.div>
  )
}

/** `unknown`: the health endpoint is failing and no loop has a health row, so failing/dark/running cannot be stated at all. */
export function KpiStrip({ vms, loading, unknown = false }: { vms: LoopVM[]; loading: boolean; unknown?: boolean }) {
  const now = useNow()
  const fleet = useObserved((s) => s.data.fleet)

  if (loading) {
    return (
      <div className={GRID}>
        {Array.from({ length: 6 }, (_, i) => (
          <Skeleton key={i} className="h-[132px] rounded-2xl" />
        ))}
      </div>
    )
  }

  const c = countStates(vms.map((v) => v.state))
  const failing = vms.filter((v) => v.state === 'failing')
  const dark = vms.filter((v) => v.state === 'dark')
  const running = vms.filter((v) => v.state === 'running')
  const worst = [...failing].sort((a, b) => (b.health?.consecutiveFailures ?? 0) - (a.health?.consecutiveFailures ?? 0))[0]

  const due = vms.filter((v) => v.enabled && v.state !== 'running' && v.nextDue != null && (v.nextDue as number) > now - 5000).sort((a, b) => (a.nextDue as number) - (b.nextDue as number))[0]

  const series = (pick: (p: FleetPt) => number) => fleetValues(fleet, pick, now)
  const healthySeries = series((p) => {
    const known = p[2] + p[3] + p[4] + p[5]
    return known ? Math.round(((p[2] + p[5]) / known) * 100) : 0
  })
  const failingSeries = series((p) => p[3])
  const darkSeries = series((p) => p[4])
  const runningSeries = series((p) => p[5])
  const mk = (s: ReturnType<typeof series>, cur: number, goodWhen: 'up' | 'down' | 'neutral') =>
    s ? { d: cur - s.values[0], period: since(now - s.since), goodWhen } : null

  return (
    <motion.section aria-label="Fleet summary" variants={stagger(0.05)} initial="hidden" animate="show" className={GRID}>
      <Tile
        label="Healthy"
        hero
        state="ok"
        quiet={c.healthyPct == null}
        value={c.healthyPct == null ? '—' : <>{c.healthyPct}<span className="ml-0.5 text-[24px] font-medium text-ink-3">%</span></>}
        context={unknown ? 'Health data unavailable' : c.known ? `${c.healthy} of ${c.known} reporting${c.waiting ? ` · ${c.waiting} waiting` : ''}` : c.enabled ? `${c.waiting} waiting for a first report` : 'No enabled loops'}
        trend={healthySeries?.values ?? null}
        trendLabel="Healthy share, observed"
        delta={!unknown && healthySeries && c.healthyPct != null ? { d: c.healthyPct - healthySeries.values[0], period: since(now - healthySeries.since), goodWhen: 'up', unit: ' pts' } : null}
      />
      <Tile
        label="Total loops"
        icon={<Orbit className="size-[13px]" />}
        value={c.total}
        context={`${c.enabled} enabled · ${c.disabled} disabled`}
        trend={undefined}
        trendLabel=""
      />
      <Tile
        label="Failing"
        state="failing"
        quiet={unknown || c.failing === 0}
        value={unknown ? '—' : c.failing}
        context={unknown ? 'Health data unavailable' : worst ? `${worst.name} · ${worst.health?.consecutiveFailures} in a row` : 'All clear'}
        trend={failingSeries?.values ?? null}
        trendLabel="Failing loops, observed"
        delta={unknown ? null : mk(failingSeries, c.failing, 'down')}
      />
      <Tile
        label="Dark"
        state="dark"
        quiet={unknown || c.dark === 0}
        value={unknown ? '—' : c.dark}
        context={unknown ? 'Health data unavailable' : dark.length ? dark.slice(0, 2).map((v) => v.name).join(', ') + (dark.length > 2 ? ` +${dark.length - 2}` : '') : 'None gone quiet'}
        trend={darkSeries?.values ?? null}
        trendLabel="Dark loops, observed"
        delta={unknown ? null : mk(darkSeries, c.dark, 'down')}
      />
      <Tile
        label="Running now"
        state="running"
        quiet={unknown || c.running === 0}
        value={unknown ? '—' : c.running}
        context={unknown ? 'Health data unavailable' : running.length ? running.slice(0, 2).map((v) => v.name).join(', ') + (running.length > 2 ? ` +${running.length - 2}` : '') : 'Nothing in flight'}
        trend={runningSeries?.values ?? null}
        trendLabel="Running loops, observed"
        delta={unknown ? null : mk(runningSeries, c.running, 'neutral')}
      />
      <Tile
        label="Next due"
        icon={<Timer className="size-[13px]" />}
        value={due ? <span className="tnum">{fmtCountdown((due.nextDue as number) - now)}</span> : '—'}
        context={due ? `${due.name} · ${nextShort(due)}` : 'Nothing scheduled to estimate'}
        trendLabel=""
      />
    </motion.section>
  )
}
