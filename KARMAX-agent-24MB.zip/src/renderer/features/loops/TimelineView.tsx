/**
 * Timeline: one swimlane per loop over the last 24 hours (plus a short look ahead) on a single time axis.
 * Markers are exact daemon timestamps seen by this app (last success / last failure / scheduler last-fired),
 * plus the expected next fire. The stretch before this app started watching is shaded and labelled: successes
 * and failures that happened while it was closed are simply not known.
 */
import { useMemo, useState } from 'react'
import { ArrowRight, Search } from 'lucide-react'
import { EmptyState } from '@/design/primitives'
import { cn } from '@/design/cn'
import { STATE_META } from './health'
import { lastLabel, lastTime, nextLabel, nextShort, type LoopVM } from './model'
import { useObserved, type ObservedLoop } from './observed'
import { HOUR, MIN } from './schedule'
import { KindGlyph, StateIcon, clock, dateTime, stateColor, stateInk, useElementSize, useNow, whenText } from './ui'

const WINDOW_BACK = 24 * HOUR
const WINDOW_AHEAD = 3 * HOUR
const LANE_H = 42
const GAP = 2
const AXIS_H = 30
const LABEL_W = 236
const CLUSTER_PX = 11

interface Tip {
  x: number
  y: number
  title: string
  lines: string[]
  loop: string
}

interface Cluster {
  x0: number
  x1: number
  ts: number[]
}

function cluster(times: number[], x: (t: number) => number): Cluster[] {
  const out: Cluster[] = []
  for (const t of [...times].sort((a, b) => a - b)) {
    const px = x(t)
    const last = out[out.length - 1]
    if (last && px - last.x1 < CLUSTER_PX) {
      last.x1 = px
      last.ts.push(t)
    } else out.push({ x0: px, x1: px, ts: [t] })
  }
  return out
}

function laneEvents(vm: LoopVM, track: ObservedLoop | undefined) {
  const ok = new Set(track?.ok ?? [])
  const fail = new Set(track?.fail ?? [])
  const fired = new Set(track?.fired ?? [])
  if (vm.lastSuccess) ok.add(vm.lastSuccess)
  if (vm.lastFailure) fail.add(vm.lastFailure)
  if (vm.tracking === 'schedule' && vm.lastRun) fired.add(vm.lastRun)
  return { ok: [...ok], fail: [...fail], fired: [...fired] }
}

export function TimelineView({ vms, onOpen }: { vms: LoopVM[]; onOpen: (n: string) => void }) {
  const now = useNow()
  const observed = useObserved((s) => s.data)
  const [wrapRef, { w }] = useElementSize<HTMLDivElement>()
  const [tip, setTip] = useState<Tip | null>(null)
  const [hoverLane, setHoverLane] = useState<string | null>(null)

  const plotW = Math.max(160, w - LABEL_W)
  const start = now - WINDOW_BACK
  const end = now + WINDOW_AHEAD
  const x = (t: number) => ((t - start) / (end - start)) * plotW
  const H = AXIS_H + vms.length * (LANE_H + GAP)

  const ticks = useMemo(() => {
    const out: number[] = []
    const d = new Date(start)
    d.setMinutes(0, 0, 0)
    let t = d.getTime()
    while (t <= end) {
      if (t >= start && new Date(t).getHours() % 4 === 0) out.push(t)
      t += HOUR
    }
    return out
  }, [Math.floor(start / HOUR), end]) // eslint-disable-line react-hooks/exhaustive-deps

  if (vms.length === 0) return <EmptyState icon={<Search className="size-5" />} title="No loops match" body="Try a different search or clear the filter." />

  const sinceX = Math.max(0, x(observed.since))
  const nowX = x(now)

  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
        <div>
          <h2 className="text-[13px] font-semibold text-ink">Last 24 hours, and what is expected next</h2>
          <p className="text-[11.5px] text-ink-3">
            Observed since {dateTime(observed.since).replace(/:\d\d$/, '')}. Before that, only each loop's last-reported success / failure is known; the daemon keeps no run history.
          </p>
        </div>
      </div>

      <div ref={wrapRef} className="relative overflow-x-auto" onPointerLeave={() => setTip(null)}>
        <div className="relative" style={{ height: H, minWidth: LABEL_W + 160 }}>
          {/* lane labels (HTML: focusable, the keyboard path to the same details as the markers' tooltips) */}
          <div className="absolute left-0 top-0" style={{ width: LABEL_W, paddingTop: AXIS_H }}>
            {vms.map((v) => {
              const c = stateColor(v.state)
              const lt = lastTime(v)
              return (
                <button
                  key={v.name}
                  onClick={() => onOpen(v.name)}
                  onPointerEnter={() => setHoverLane(v.name)}
                  onPointerLeave={() => setHoverLane(null)}
                  onFocus={() => setHoverLane(v.name)}
                  onBlur={() => setHoverLane(null)}
                  aria-label={`${v.name}, ${STATE_META[v.state].label}. ${lastLabel(v)} ${lt ? whenText(lt, now) : 'never'}. ${nextLabel(v)} ${v.nextDue ? whenText(v.nextDue, now, { future: true }) : 'none'}. Open details.`}
                  className={cn('mb-[2px] flex w-full items-center gap-2 rounded-l-lg px-3 text-left transition-colors', hoverLane === v.name ? 'bg-surface-2' : 'bg-surface-2/40')}
                  style={{ height: LANE_H }}
                >
                  <KindGlyph kind={v.kind} size={15} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-medium text-ink">{v.name}</span>
                    <span className="block truncate text-[10.5px] text-ink-3 tnum">
                      {lt ? `${v.tracking === 'schedule' ? 'fired' : 'ok'} ${whenText(lt, now)}` : 'never ran'}
                      {v.nextDue ? ` · ${v.nextDue < now - 5000 ? '' : 'next '}${whenText(v.nextDue, now, { future: true })}` : ''}
                    </span>
                  </span>
                  <span className="grid size-[18px] shrink-0 place-items-center rounded-full" style={{ color: stateInk(v.state), background: `color-mix(in oklab, ${c} 15%, transparent)` }} title={STATE_META[v.state].label}>
                    <StateIcon state={v.state} className="size-[11px]" />
                  </span>
                </button>
              )
            })}
          </div>

          <svg className="absolute top-0" style={{ left: LABEL_W }} width={plotW} height={H} role="img" aria-label="Timeline of observed loop runs over the last 24 hours. The same information is in each row's label.">
            {/* not-observed region */}
            {sinceX > 0 && (
              <g>
                <rect x={0} y={AXIS_H} width={sinceX} height={H - AXIS_H} fill="var(--ink)" opacity={0.045} />
                {sinceX > 120 && (
                  <text x={8} y={AXIS_H - 9} fontSize={10} fill="var(--ink-3)" fontWeight={600} letterSpacing="0.06em">
                    NOT OBSERVED
                  </text>
                )}
              </g>
            )}
            {/* look-ahead region */}
            <rect x={nowX} y={AXIS_H} width={Math.max(0, plotW - nowX)} height={H - AXIS_H} fill="var(--accent)" opacity={0.045} />
            {/* grid + axis */}
            {ticks.map((t) => {
              const tx = x(t)
              const hideForNote = sinceX > 120 && tx < 128 // "NOT OBSERVED" sits at the left of the axis
              const nearNow = Math.abs(tx - nowX) < 26 // "now" has the spot
              return (
                <g key={t}>
                  <line x1={tx} x2={tx} y1={AXIS_H - 4} y2={H} stroke="var(--grid)" strokeWidth={1} />
                  {!hideForNote && !nearNow && (
                    <text x={tx} y={AXIS_H - 12} fontSize={10.5} textAnchor={tx > plotW - 22 ? 'end' : 'middle'} fill="var(--ink-3)" className="tnum">
                      {clock(t)}
                    </text>
                  )}
                </g>
              )
            })}
            {/* lanes */}
            {vms.map((v, i) => {
              const y0 = AXIS_H + i * (LANE_H + GAP)
              const cy = y0 + LANE_H / 2
              const ev = laneEvents(v, observed.loops[v.name])
              const inWin = (t: number) => t >= start && t <= now + 1000
              const okC = cluster(ev.ok.filter(inWin), x)
              const firedC = cluster(ev.fired.filter(inWin), x)
              const fails = cluster(ev.fail.filter(inWin), x)
              const showTip = (e: { clientX: number; clientY: number }, title: string, lines: string[]) => {
                const r = wrapRef.current?.getBoundingClientRect()
                if (!r) return
                setTip({ x: e.clientX - r.left, y: e.clientY - r.top, title, lines, loop: v.name })
              }
              const range = (c: Cluster) => (c.ts.length > 1 ? `${clock(Math.min(...c.ts))}–${clock(Math.max(...c.ts))}` : dateTime(c.ts[0]))
              const nextX = v.nextDue != null ? Math.max(x(v.nextDue), nowX) : null
              const nextBeyond = v.nextDue != null && v.nextDue > end
              const silent = v.state === 'dark' && lastTime(v) != null && inWinLoose(lastTime(v) as number, start)
              return (
                <g key={v.name} onPointerEnter={() => setHoverLane(v.name)} onPointerLeave={() => setHoverLane(null)}>
                  <rect x={0} y={y0} width={plotW} height={LANE_H} rx={6} fill="var(--surface-2)" opacity={hoverLane === v.name ? 0.95 : 0.45} />
                  <line x1={0} x2={plotW} y1={cy} y2={cy} stroke="var(--grid)" strokeWidth={1} />
                  {silent && (
                    <rect x={Math.max(0, x(lastTime(v) as number))} y={cy - 3.5} width={Math.max(2, nowX - Math.max(0, x(lastTime(v) as number)))} height={7} rx={3.5} fill="var(--warn)" opacity={0.32}>
                      <title>{`${v.name}: silent since its last ${v.tracking === 'schedule' ? 'fire' : 'success'}`}</title>
                    </rect>
                  )}
                  {okC.map((c, k) => (
                    <g key={`o${k}`} onPointerMove={(e) => showTip(e, c.ts.length > 1 ? `${c.ts.length} successes observed` : 'Success', [range(c), v.name])}>
                      <rect x={c.x0 - 4} y={cy - 4} width={c.x1 - c.x0 + 8} height={8} rx={4} fill="var(--good)" stroke="var(--surface)" strokeWidth={2} />
                      <rect x={c.x0 - 12} y={cy - 12} width={c.x1 - c.x0 + 24} height={24} fill="transparent" />
                    </g>
                  ))}
                  {firedC.map((c, k) => (
                    <g key={`f${k}`} onPointerMove={(e) => showTip(e, c.ts.length > 1 ? `${c.ts.length} fires observed` : 'Fired (outcome not tracked)', [range(c), v.name])}>
                      <rect x={c.x0 - 4} y={cy - 4} width={c.x1 - c.x0 + 8} height={8} rx={4} fill="var(--ink-2)" stroke="var(--surface)" strokeWidth={2} />
                      <rect x={c.x0 - 12} y={cy - 12} width={c.x1 - c.x0 + 24} height={24} fill="transparent" />
                    </g>
                  ))}
                  {fails.map((c, k) => (
                    <g key={`x${k}`} onPointerMove={(e) => showTip(e, c.ts.length > 1 ? `${c.ts.length} failures observed` : 'Failure', [range(c), v.health?.lastError ? v.health.lastError : v.name])}>
                      <rect x={(c.x0 + c.x1) / 2 - 5} y={cy - 5} width={10} height={10} rx={1.5} transform={`rotate(45 ${(c.x0 + c.x1) / 2} ${cy})`} fill="var(--crit-mark)" stroke="var(--surface)" strokeWidth={2} />
                      <rect x={c.x0 - 12} y={cy - 12} width={c.x1 - c.x0 + 24} height={24} fill="transparent" />
                    </g>
                  ))}
                  {nextX != null && !nextBeyond && (
                    <g onPointerMove={(e) => showTip(e, v.nextIsRetry ? 'Retry timer' : 'Expected next fire', [dateTime(v.nextDue), `${nextShort(v)} · ${whenText(v.nextDue, now, { future: true })}`, v.name])}>
                      <circle cx={nextX} cy={cy} r={5} fill="var(--surface)" stroke={v.nextIsRetry ? 'var(--crit-mark)' : 'var(--accent)'} strokeWidth={2} />
                      <circle cx={nextX} cy={cy} r={13} fill="transparent" />
                    </g>
                  )}
                  {nextBeyond && (
                    <g onPointerMove={(e) => showTip(e, 'Expected next fire', [dateTime(v.nextDue), `${nextShort(v)} · ${whenText(v.nextDue, now, { future: true })}`, v.name])}>
                      <text x={plotW - 8} y={cy + 3.5} textAnchor="end" fontSize={10.5} fill="var(--ink-2)" className="tnum">
                        next {whenText(v.nextDue, now, { future: true }).replace('in ', '')} →
                      </text>
                      <rect x={plotW - 90} y={cy - 12} width={90} height={24} fill="transparent" />
                    </g>
                  )}
                </g>
              )
            })}
            {/* now line */}
            <line x1={nowX} x2={nowX} y1={AXIS_H - 6} y2={H} stroke="var(--accent)" strokeWidth={1.5} pointerEvents="none" />
            <text x={nowX} y={AXIS_H - 12} textAnchor="middle" pointerEvents="none" fontSize={10.5} fontWeight={700} fill="var(--ink)" style={{ paintOrder: 'stroke', stroke: 'var(--surface)', strokeWidth: 4 }}>
              now
            </text>
          </svg>

          {tip && (
            <div
              role="tooltip"
              className="glass pointer-events-none absolute z-20 max-w-[280px] rounded-lg px-2.5 py-2 text-[11.5px] shadow-pop"
              style={{ left: Math.min(tip.x + 14, Math.max(8, w - 290)), top: tip.y + 12, background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
            >
              <div className="text-[12.5px] font-semibold text-ink">{tip.title}</div>
              {tip.lines.map((l, i) => (
                <div key={i} className={cn('tnum', i === 0 ? 'text-ink-2' : 'text-ink-3', 'line-clamp-2')}>
                  {l}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line px-4 py-2.5 text-[11.5px] text-ink-2" aria-label="Legend">
        <span className="label-micro">Legend</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block h-2 w-3.5 rounded-full bg-good" /> success seen</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block size-2 rotate-45 rounded-[2px] bg-[var(--crit-mark)]" /> failure seen</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block h-2 w-3.5 rounded-full bg-ink-2" /> fired, outcome not tracked</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block size-2.5 rounded-full border-2 border-accent" /> expected next fire</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block size-2.5 rounded-full border-2 border-[var(--crit-mark)]" /> retry timer</span>
        <span className="inline-flex items-center gap-1.5"><span className="inline-block h-1.5 w-4 rounded-full bg-warn/40" /> silent (dark)</span>
        <span className="inline-flex items-center gap-1.5"><ArrowRight className="size-3" /> next fire beyond the window</span>
      </div>
    </div>
  )
}

const inWinLoose = (t: number, start: number) => t >= start - 30 * MIN
