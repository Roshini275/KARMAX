/**
 * Detail drawer for one loop: Overview · Definition · Activity, plus Run now and Enable/Disable.
 */
import { useEffect, useMemo, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { CalendarClock, CircleAlert, FileCode2, Play, Power, PowerOff, RotateCw, Webhook, Zap } from 'lucide-react'
import { Button, ErrorNote, Segmented, Skeleton } from '@/design/primitives'
import { Drawer } from '@/design/Drawer'
import { ApiError } from '@/lib/api/client'
import { cn } from '@/design/cn'
import { CapabilityList, YamlBlock } from './capabilities'
import { FreshnessChart, type ChartEvent } from './charts'
import { useRegistryDetail, useRunLoop, useToggleLoop } from './data'
import { STATE_META } from './health'
import { KIND_META, lastLabel, lastTime, nextLabel, type LoopVM } from './model'
import { useObserved, seriesOf } from './observed'
import { Chip, CopyButton, KindGlyph, StateIcon, StatePill, When, clock, dateTime, stateColor, useNow } from './ui'

type Tab = 'overview' | 'definition' | 'activity'

export function LoopDrawer({ vm, onClose }: { vm: LoopVM | null; onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('overview')
  // Keep the last vm while the drawer animates out so the content does not blank.
  const [shown, setShown] = useState<LoopVM | null>(vm)
  useEffect(() => {
    if (vm) setShown(vm)
  }, [vm])
  useEffect(() => {
    setTab('overview')
  }, [vm?.name])

  const v = vm ?? shown

  // Portalled to <body>: the shell's top bar (z-20) would otherwise paint over the drawer's header and close button.
  return createPortal(
    <Drawer
      open={!!vm}
      onClose={onClose}
      width={580}
      title={
        v && (
          <span className="flex items-center gap-2.5">
            <KindGlyph kind={v.kind} size={18} />
            <span className="truncate">{v.name}</span>
          </span>
        )
      }
      subtitle={v && <span>{KIND_META[v.kind].label} · {v.sched.label}</span>}
      footer={v && <Actions vm={v} />}
    >
      {v && (
        <div>
          <Segmented<Tab>
            className="mb-4"
            value={tab}
            onChange={setTab}
            options={[
              { value: 'overview', label: 'Overview' },
              { value: 'definition', label: 'Definition' },
              { value: 'activity', label: 'Activity' }
            ]}
          />
          <AnimatePresence mode="wait" initial={false}>
            <motion.div key={tab} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0, transition: { duration: 0.16 } }} exit={{ opacity: 0, transition: { duration: 0.08 } }}>
              {tab === 'overview' && <Overview vm={v} />}
              {tab === 'definition' && <Definition vm={v} />}
              {tab === 'activity' && <Activity vm={v} />}
            </motion.div>
          </AnimatePresence>
        </div>
      )}
    </Drawer>,
    document.body
  )
}

/* ── Overview ──────────────────────────────────────────────────────────── */

function Fact({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <div className="min-w-0 rounded-xl bg-surface-2/55 px-3 py-2.5 ring-1 ring-line">
      <div className="label-micro">{label}</div>
      <div className="mt-1 text-[13px] text-ink">{children}</div>
      {hint && <div className="mt-0.5 text-[11px] text-ink-3">{hint}</div>}
    </div>
  )
}

function stateSentence(vm: LoopVM): string {
  const h = vm.health
  switch (vm.state) {
    case 'failing':
      return `${h?.consecutiveFailures ?? 0} failure${h?.consecutiveFailures === 1 ? '' : 's'} in a row. The daemon retries with backoff${vm.nextIsRetry && vm.nextDue ? `; next attempt about ${clock(vm.nextDue)}` : ''}.`
    case 'dark':
      return vm.tracking === 'schedule'
        ? 'It has not fired in three of its intervals (judged here from the scheduler, since the daemon does not flag this tier). Check the schedule and the daemon logs.'
        : 'It has not succeeded in three of its intervals, though nothing is failing outright. Something upstream may have stalled.'
    case 'running':
      return 'A run is in flight right now.'
    case 'waiting':
      return h ? 'It has not completed a run yet.' : vm.tracking === 'schedule' ? 'Its scheduler job has not fired yet.' : 'The daemon has no run record for it (event- or webhook-driven recipes are not tracked).'
    case 'disabled':
      return 'Turned off. The daemon will not run it until you enable it.'
    default:
      return vm.tracking === 'schedule'
        ? 'It fired on schedule. The daemon records when recipe and prompt loops fire but not whether the run succeeded, so a failing one would not show here.'
        : 'Its last run succeeded and it is on schedule.'
  }
}

function Overview({ vm }: { vm: LoopVM }) {
  const now = useNow()
  const h = vm.health
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 rounded-2xl p-3.5 ring-1" style={{ background: `color-mix(in oklab, ${stateColor(vm.state)} 8%, var(--surface-2))`, ['--tw-ring-color' as string]: `color-mix(in oklab, ${stateColor(vm.state)} 30%, transparent)` }}>
        <StatePill state={vm.state} />
        <p className="text-[12.5px] leading-relaxed text-ink-2">{stateSentence(vm)}</p>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <Fact label={lastLabel(vm)} hint={lastTime(vm) ? dateTime(lastTime(vm)) : undefined}>
          {lastTime(vm) ? <When t={lastTime(vm)} /> : <span className="text-ink-3">{!vm.enabled && !h ? 'not reported while disabled' : 'never'}</span>}
        </Fact>
        <Fact label="Last failure" hint={vm.tracking === 'schedule' ? 'the daemon does not record outcomes for this tier' : vm.lastFailure ? dateTime(vm.lastFailure) : undefined}>
          {vm.tracking === 'schedule' ? <span className="text-ink-3">not tracked</span> : vm.lastFailure ? <When t={vm.lastFailure} /> : <span className="text-ink-3">{!vm.enabled && !h ? 'not reported while disabled' : 'none recorded'}</span>}
        </Fact>
        <Fact label="Consecutive failures">
          <span className={cn('tnum', (h?.consecutiveFailures ?? 0) > 0 && 'font-semibold', !h && 'text-ink-3')}>{h ? h.consecutiveFailures : 'not tracked'}</span>
        </Fact>
        <Fact label={nextLabel(vm)} hint={vm.nextDue ? clock(vm.nextDue) : undefined}>
          {vm.nextDue ? <When t={vm.nextDue} future /> : <span className="text-ink-3">{vm.enabled ? 'not estimable' : 'disabled'}</span>}
        </Fact>
      </div>

      {vm.state === 'failing' && h?.lastError && (
        <section>
          <div className="mb-1.5 flex items-center justify-between">
            <h4 className="label-micro flex items-center gap-1.5"><CircleAlert className="size-3.5" /> Last error</h4>
            <CopyButton text={h.lastError} label="Copy error" />
          </div>
          <pre className="selectable scroll-thin max-h-40 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-[color-mix(in_oklab,var(--crit)_9%,var(--surface-2))] p-3 font-[family-name:var(--font-mono)] text-[11.5px] leading-relaxed text-ink ring-1 ring-[color-mix(in_oklab,var(--crit)_28%,transparent)]">{h.lastError}</pre>
        </section>
      )}
      {vm.state !== 'failing' && h?.lastError && (
        <section>
          <div className="mb-1.5 flex items-center justify-between">
            <h4 className="label-micro">Last recorded error</h4>
            <CopyButton text={h.lastError} label="Copy error" />
          </div>
          <pre className="selectable scroll-thin max-h-32 overflow-auto whitespace-pre-wrap break-words rounded-xl bg-surface-2 p-3 font-[family-name:var(--font-mono)] text-[11.5px] leading-relaxed text-ink-2 ring-1 ring-line">{h.lastError}</pre>
        </section>
      )}

      <section className="space-y-2.5">
        <h4 className="label-micro">Trigger</h4>
        <div className="flex flex-wrap items-center gap-2">
          {vm.schedule ? (
            <Chip className="gap-1.5 py-1 text-[12px]">
              <CalendarClock className="size-3.5" />
              {vm.sched.label}
            </Chip>
          ) : null}
          {vm.schedule ? <Chip mono title="Exactly as the daemon reports it">{vm.schedule}</Chip> : null}
          {vm.events.map((e) => (
            <Chip key={e} mono className="gap-1"><Zap className="size-3" />{e}</Chip>
          ))}
          {vm.webhook && (
            <Chip mono className="gap-1"><Webhook className="size-3" />{vm.webhook}</Chip>
          )}
          {!vm.schedule && vm.events.length === 0 && !vm.webhook && <span className="text-[12.5px] text-ink-3">Runs only when triggered manually.</span>}
        </div>
        {vm.sched.kind === 'cron' && vm.sched.intervalMs != null && (
          <p className="text-[11px] text-ink-3">Cron schedule: the daemon does not flag cron loops as dark, so silence there is only visible from the last-success time.</p>
        )}
      </section>

      {vm.description && (
        <section>
          <h4 className="label-micro mb-1.5">Description</h4>
          <p className="selectable text-[13px] leading-relaxed text-ink-2">{vm.description}</p>
        </section>
      )}

      <section>
        <h4 className="label-micro mb-1.5">Kind</h4>
        <div className="flex items-center gap-2.5 text-[12.5px] text-ink-2">
          <KindGlyph kind={vm.kind} size={18} />
          <span><span className="font-medium text-ink">{KIND_META[vm.kind].label}.</span> {KIND_META[vm.kind].blurb}</span>
        </div>
      </section>

      <p className="text-[11px] text-ink-3">Updated {clock(now)} · state comes from GET /api/loops/health and the scheduler jobs in GET /api/activity; the daemon reports no run history.</p>
    </div>
  )
}

/* ── Definition ────────────────────────────────────────────────────────── */

function Definition({ vm }: { vm: LoopVM }) {
  const q = useRegistryDetail(vm.name, vm.kind === 'recipe' || vm.kind === 'workflow' || vm.kind === 'other')
  const noDefinition = vm.kind === 'compiled' || vm.kind === 'prompt'

  if (noDefinition) {
    return (
      <div className="rounded-2xl bg-surface-2/55 p-4 text-[12.5px] leading-relaxed text-ink-2 ring-1 ring-line">
        <div className="mb-1.5 flex items-center gap-2 font-semibold text-ink">
          <FileCode2 className="size-4" /> Definition not available
        </div>
        {vm.kind === 'compiled'
          ? 'Compiled loops are built into the KARMAX binary, so there is no YAML or manifest to show. What one can do is defined in Go source, not in a file you can read here.'
          : 'A prompt loop is a scheduled prompt defined under loops: in karmax.yaml. It has no separate definition file; open that config to read or edit it.'}
      </div>
    )
  }
  if (q.isPending) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    )
  }
  if (q.error) {
    const status = q.error instanceof ApiError ? q.error.status : 0
    if (status === 404) {
      return (
        <div className="rounded-2xl bg-surface-2/55 p-4 text-[12.5px] leading-relaxed text-ink-2 ring-1 ring-line">
          <div className="mb-1.5 flex items-center gap-2 font-semibold text-ink">
            <FileCode2 className="size-4" /> Not in the registry
          </div>
          {vm.name} is not listed in the karmax-loops registry, so its definition cannot be fetched here. It may be a local or custom loop. What it is allowed to do is defined where it is installed on this machine.
        </div>
      )
    }
    return (
      <div className="space-y-2">
        <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
        <p className="text-[11.5px] text-ink-3">The definition is fetched through the daemon from the karmax-loops registry, so it needs the registry to be reachable.</p>
      </div>
    )
  }
  const d = q.data
  return (
    <div className="space-y-5">
      <p className="text-[11.5px] leading-relaxed text-ink-3">This is the registry's copy of <span className="font-medium text-ink-2">{vm.name}</span> v{d.entry.version || '?'}, described before anything is written. It can differ from what is installed on this machine.</p>
      <CapabilityList tools={d.tools} host={d.host} kind={d.entry.kind} />
      <section>
        <h4 className="label-micro mb-1.5">Definition</h4>
        {d.definition ? <YamlBlock text={d.definition} /> : <p className="text-[12px] text-ink-3">The registry returned no definition text.</p>}
      </section>
    </div>
  )
}

/* ── Activity ──────────────────────────────────────────────────────────── */

function Activity({ vm }: { vm: LoopVM }) {
  const now = useNow()
  const track = useObserved((s) => s.data.loops[vm.name])
  const since = useObserved((s) => s.data.since)
  const series = useMemo(() => seriesOf(track, now, 6 * 3600_000), [track, now])
  const events: ChartEvent[] = useMemo(() => {
    const ok = new Set([...(track?.ok ?? []), ...(vm.lastSuccess ? [vm.lastSuccess] : [])])
    const fail = new Set([...(track?.fail ?? []), ...(vm.lastFailure ? [vm.lastFailure] : [])])
    return [...[...ok].map((t) => ({ t, kind: 'ok' as const })), ...[...fail].map((t) => ({ t, kind: 'fail' as const }))].sort((a, b) => b.t - a.t)
  }, [track, vm.lastSuccess, vm.lastFailure])
  const first = track?.pts[0]?.[0]

  return (
    <div className="space-y-5">
      <div className="rounded-xl bg-surface-2/55 px-3 py-2.5 text-[11.5px] leading-relaxed text-ink-3 ring-1 ring-line">
        <span className="font-semibold text-ink-2">Observed since you opened KARMAX Desktop{first ? ` (${dateTime(first)})` : ''}.</span> The daemon keeps no run history, so this is only what this app saw while it was polling, not every run the loop made.
      </div>

      <section>
        <div className="mb-2 flex items-end justify-between">
          <div>
            <h4 className="text-[13px] font-semibold text-ink">Freshness</h4>
            <p className="text-[11.5px] text-ink-3">Time since the last success, as a multiple of the loop's interval. It resets to 0 on each success.</p>
          </div>
        </div>
        {vm.sched.intervalMs == null ? (
          <div className="rounded-xl bg-surface-2/55 p-4 text-[12.5px] text-ink-3 ring-1 ring-line">This loop has no fixed interval ({vm.sched.label}), so freshness cannot be computed. Its observed successes and failures are listed below.</div>
        ) : (
          <FreshnessChart series={series} events={events} now={now} since={since} />
        )}
        <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-ink-3">
          <span className="inline-flex items-center gap-1.5"><span className="inline-block h-[2px] w-4 rounded bg-s1" /> freshness</span>
          <span className="inline-flex items-center gap-1.5"><span className="inline-block size-2 rounded-full bg-good" /> success seen</span>
          <span className="inline-flex items-center gap-1.5"><span className="inline-block size-2 rotate-45 rounded-[2px] bg-[var(--crit-mark)]" /> failure seen</span>
          <span className="inline-flex items-center gap-1.5"><span className="inline-block h-0 w-4 border-t border-dashed border-warn" /> dark threshold (3×)</span>
        </div>
      </section>

      <section>
        <h4 className="label-micro mb-1.5">Observed events</h4>
        {events.length === 0 ? (
          <p className="text-[12px] text-ink-3">Nothing observed yet. The daemon reports a loop's last success and last failure; each new one seen while this app is open is listed here.</p>
        ) : (
          <table className="w-full text-left text-[12px]">
            <thead>
              <tr className="text-[10.5px] uppercase tracking-[0.08em] text-ink-3">
                <th className="py-1 pr-3 font-semibold">When</th>
                <th className="py-1 pr-3 font-semibold">Result</th>
                <th className="py-1 text-right font-semibold">Ago</th>
              </tr>
            </thead>
            <tbody>
              {events.slice(0, 14).map((e) => (
                <tr key={`${e.kind}${e.t}`} className="border-t border-line">
                  <td className="tnum py-1.5 pr-3 text-ink-2">{dateTime(e.t)}</td>
                  <td className="py-1.5 pr-3">
                    <span className="inline-flex items-center gap-1.5 text-ink">
                      <span style={{ color: e.kind === 'ok' ? 'var(--good)' : 'var(--crit)' }}>
                        <StateIcon state={e.kind === 'ok' ? 'ok' : 'failing'} />
                      </span>
                      {e.kind === 'ok' ? 'Succeeded' : 'Failed'}
                    </span>
                  </td>
                  <td className="py-1.5 text-right text-ink-3"><When t={e.t} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  )
}

/* ── Footer actions ────────────────────────────────────────────────────── */

function Actions({ vm }: { vm: LoopVM }) {
  const run = useRunLoop()
  const toggle = useToggleLoop()
  const [confirm, setConfirm] = useState(false)
  const [note, setNote] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null)
  const running = vm.state === 'running'

  useEffect(() => {
    setConfirm(false)
    setNote(null)
  }, [vm.name])

  const doRun = () => {
    setConfirm(false)
    run.mutate(vm.name, {
      onSuccess: () => setNote({ kind: 'ok', text: `Run requested at ${clock(Date.now())}:${String(new Date().getSeconds()).padStart(2, '0')}. The daemon accepted it; the state updates on the next health poll.` }),
      onError: (e) => setNote({ kind: 'error', text: e instanceof Error ? e.message : String(e) })
    })
  }

  return (
    <div className="space-y-2.5">
      <AnimatePresence initial={false}>
        {note && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <div
              role={note.kind === 'error' ? 'alert' : 'status'}
              className={cn('selectable rounded-lg px-3 py-2 text-[12px] leading-snug ring-1', note.kind === 'ok' ? 'bg-[color-mix(in_oklab,var(--good)_10%,transparent)] text-ink ring-[color-mix(in_oklab,var(--good)_30%,transparent)]' : 'bg-[color-mix(in_oklab,var(--crit)_10%,transparent)] text-crit ring-[color-mix(in_oklab,var(--crit)_32%,transparent)]')}
            >
              {note.text}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {confirm ? (
        <div className="flex items-center justify-between gap-3">
          <span className="text-[12.5px] text-ink-2">Run <span className="font-semibold text-ink">{vm.name}</span> now, outside its schedule?</span>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setConfirm(false)}>Cancel</Button>
            <Button size="sm" variant="primary" icon={<Play className="size-3.5" />} onClick={doRun} data-autofocus>Run now</Button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between gap-3">
          <Button
            variant={vm.enabled ? 'subtle' : 'primary'}
            icon={vm.enabled ? <PowerOff className="size-3.5" /> : <Power className="size-3.5" />}
            loading={toggle.isPending}
            onClick={() => toggle.mutate({ name: vm.name, enable: !vm.enabled })}
          >
            {vm.enabled ? 'Disable' : 'Enable'}
          </Button>
          <Button
            variant="primary"
            icon={running || run.isPending ? <RotateCw className="size-3.5 animate-[km-spin_1s_linear_infinite]" /> : <Play className="size-3.5" />}
            disabled={running || run.isPending || !vm.enabled || vm.kind === 'prompt'}
            title={!vm.enabled ? 'Enable the loop first' : vm.kind === 'prompt' ? 'Prompt loops fire on their schedule; the daemon can only run compiled, workflow and recipe loops on demand' : running ? 'Already running' : undefined}
            onClick={() => setConfirm(true)}
          >
            {running ? 'Running…' : 'Run now'}
          </Button>
        </div>
      )}
      {!vm.enabled && <p className="text-[11px] text-ink-3">Disabled loops are not registered with the scheduler, so Run is unavailable until you enable it.</p>}
      {vm.kind === 'prompt' && vm.enabled && <p className="text-[11px] text-ink-3">Prompt loops fire on their schedule. The daemon can run compiled, workflow and recipe loops on demand, not this kind.</p>}
      {running && (
        <p className="flex items-center gap-1.5 text-[11px] text-ink-3">
          <span style={{ color: 'var(--accent)' }}><StateIcon state="running" /></span> {STATE_META.running.hint}
        </p>
      )}
    </div>
  )
}
