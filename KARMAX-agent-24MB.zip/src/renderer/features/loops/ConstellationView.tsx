import { useState } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/design/cn'
import { EmptyState } from '@/design/primitives'
import { STATE_META } from './health'
import { KIND_META, type LoopVM } from './model'
import { ConstellationMap, Legend } from './Constellation'
import { KindGlyph, StatePill, When, useElementSize } from './ui'
import { Orbit } from 'lucide-react'

/** Compact list of every loop: the accessible twin of the map, and a hover-linked index of it. */
export function LoopRail({ vms, hover, setHover, onOpen, className }: { vms: LoopVM[]; hover: string | null; setHover: (n: string | null) => void; onOpen: (n: string) => void; className?: string }) {
  return (
    <section aria-label="All loops" className={cn('glass flex min-h-0 flex-col overflow-hidden rounded-2xl', className)}>
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <span className="label-micro">All loops</span>
        <span className="tnum text-[11px] text-ink-3">{vms.length}</span>
      </div>
      {vms.length === 0 ? (
        <div className="px-4 py-8 text-center text-[12.5px] text-ink-3">No loops match this filter.</div>
      ) : (
        <ul className="scroll-thin min-h-0 flex-1 overflow-auto p-1.5">
          {vms.map((v) => (
            <li key={v.name}>
              <button
                onClick={() => onOpen(v.name)}
                onPointerEnter={() => setHover(v.name)}
                onPointerLeave={() => setHover(null)}
                onFocus={() => setHover(v.name)}
                onBlur={() => setHover(null)}
                aria-label={`${v.name}, ${STATE_META[v.state].label}, ${v.sched.label}`}
                className={cn('group flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors', hover === v.name ? 'bg-surface-2' : 'hover:bg-surface-2/70')}
              >
                <KindGlyph kind={v.kind} size={16} className={cn(hover === v.name && 'text-ink')} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-medium text-ink">{v.name}</span>
                  <span className="block truncate text-[11px] text-ink-3">
                    {v.sched.label}
                    {v.lastSuccess ? (
                      <>
                        {' · '}
                        <When t={v.lastSuccess} />
                      </>
                    ) : null}
                  </span>
                </span>
                <StatePill state={v.state} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

export function ConstellationView({
  vms,
  visible,
  onOpen,
  frozen,
  onBrowse
}: {
  vms: LoopVM[]
  /** Names that pass the current filter. */
  visible: Set<string>
  onOpen: (name: string) => void
  frozen: boolean
  onBrowse: () => void
}) {
  const [hover, setHover] = useState<string | null>(null)
  const [ref, { w }] = useElementSize<HTMLDivElement>()
  const stacked = w > 0 && w < 980
  const dim = visible.size === vms.length ? null : new Set(vms.filter((v) => !visible.has(v.name)).map((v) => v.name))

  if (vms.length === 0) {
    return (
      <div className="glass rounded-2xl">
        <EmptyState
          icon={<Orbit className="size-5" />}
          title="No loops yet: browse the registry"
          body="Loops are recurring automations KARMAX runs on a schedule. Install one from the registry and it will appear here as a node orbiting the core."
          action={
            <button onClick={onBrowse} className="app-no-drag inline-flex h-8 items-center rounded-lg bg-accent px-3.5 text-[13px] font-medium text-white shadow-[0_6px_18px_-8px_var(--accent)] hover:brightness-110">
              Browse the registry
            </button>
          }
        />
      </div>
    )
  }

  return (
    <div ref={ref} className={cn('grid gap-3', stacked ? 'grid-cols-1' : 'grid-cols-[minmax(0,1fr)_296px]')}>
      <motion.section
        aria-label="Loop constellation"
        initial={{ opacity: 0, scale: 0.985 }}
        animate={{ opacity: 1, scale: 1, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } }}
        className="glass relative flex flex-col overflow-hidden rounded-2xl"
        style={{ height: stacked ? 'clamp(460px, 62vh, 620px)' : 'clamp(580px, calc(100vh - 300px), 860px)' }}
      >
        <div className="min-h-0 flex-1">
          <ConstellationMap vms={vms} dim={dim} hover={hover} setHover={setHover} onOpen={onOpen} frozen={frozen} />
        </div>
        <div className="border-t border-line px-4 py-2.5">
          <Legend vms={vms} />
        </div>
      </motion.section>
      <LoopRail vms={vms.filter((v) => visible.has(v.name))} hover={hover} setHover={setHover} onOpen={onOpen} className={stacked ? 'max-h-[360px]' : ''} />
    </div>
  )
}
