import type { z } from 'zod'
import type { DaemonRequest, DaemonTarget } from '@shared/ipc'
import { getBridge } from '@/lib/bridge'
import { ApiError } from '@/lib/api/client'

/** Local copy of the lib/api call helper (it is not exported): parse with zod, surface daemon errors as ApiError. */

function messageOf(body: unknown, status: number): string {
  if (body && typeof body === 'object' && 'error' in body && typeof (body as { error: unknown }).error === 'string') return (body as { error: string }).error
  if (typeof body === 'string' && body.trim()) return body.slice(0, 300)
  if (status === 0) return 'Cannot reach the daemon.'
  return `Request failed (${status})`
}

async function raw(req: DaemonRequest): Promise<unknown> {
  let res
  try {
    res = await getBridge().daemon.request(req)
  } catch (e) {
    throw new ApiError(e instanceof Error ? e.message : 'Cannot reach the daemon.', 0)
  }
  if (!res.ok) throw new ApiError(messageOf(res.body, res.status), res.status)
  return res.body
}

export async function daemonCall<S extends z.ZodType>(schema: S, req: DaemonRequest): Promise<z.output<S>> {
  const body = await raw(req)
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    console.warn(`[api] unexpected response shape from ${req.method} ${req.path}`, parsed.error.issues)
    throw new ApiError(`Unexpected response from ${req.path}`, 200)
  }
  return parsed.data
}

export const daemonSend = raw

export const req = (target: DaemonTarget, method: string, path: string, extra: Partial<DaemonRequest> = {}): DaemonRequest => ({ target, method, path, ...extra })

/** The service did not answer at all (as opposed to answering with an error). */
export function isUnreachable(e: unknown): boolean {
  return e instanceof ApiError && (e.status === 0 || e.status === 502 || e.status === 503 || e.status === 504)
}
