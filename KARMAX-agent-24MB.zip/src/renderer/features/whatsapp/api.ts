/**
 * Local wrappers for the wacli API + the KARMAX comms.send tool. See schemas.ts for the verified wire shapes.
 * wacli has no auth (127.0.0.1 only), so these carry no token; the bridge adds none for target 'wacli'.
 */
import { callTool } from '@/lib/api/client'
import { daemonCall, req } from './http'
import {
  ChatUpdateSchema,
  ChatsResponseSchema,
  CommsSendOutputSchema,
  LogsResponseSchema,
  MessagesResponseSchema,
  StatusSchema,
  WebhooksResponseSchema,
  type WaChat
} from './schemas'
import { z } from 'zod'

const W = (method: string, path: string, extra = {}) => req('wacli', method, path, extra)

export const wa = {
  status: () => daemonCall(StatusSchema, W('GET', '/status')),

  /** Only sends and webhooks work while DND is ON; OFF blocks all automation. */
  setDnd: (enabled: boolean) => daemonCall(z.looseObject({ enabled: z.boolean().optional() }), W('PUT', '/dnd', { body: { enabled } })),

  chats: (limit = 500) => daemonCall(ChatsResponseSchema, W('GET', '/chats', { query: { limit } })).then((r) => r.chats),

  /** PUT /chats/{jid} {locked}. 404 when the chat is unknown. Returns the stored chat when the daemon echoes it. */
  setChatLocked: (jid: string, locked: boolean): Promise<WaChat | undefined> =>
    daemonCall(ChatUpdateSchema, W('PUT', `/chats/${encodeURIComponent(jid)}`, { body: { locked } })).then((r) => r.chat),

  /** Oldest first (the store reverses its DESC query). */
  messages: (chatJid: string, limit = 30) => daemonCall(MessagesResponseSchema, W('GET', '/messages', { query: { chat_jid: chatJid, limit } })).then((r) => r.messages),

  /** Newest first on the wire. */
  logs: (limit = 50) => daemonCall(LogsResponseSchema, W('GET', '/logs', { query: { limit } })).then((r) => r.logs),

  webhooks: () => daemonCall(WebhooksResponseSchema, W('GET', '/webhooks')).then((r) => r.webhooks)
}

/**
 * KARMAX's own send path: POST /api/tools/comms.send {target, content} (channel_id omitted = default channel).
 * It goes through Manager.send, which refuses a repeat of a message sent to the same target within 6h, so callers
 * must make the content unique. Failures arrive as {ok:false, error} which callTool turns into an ApiError.
 */
export const sendViaKarmax = (target: string, content: string) => callTool('comms.send', { target, content }, CommsSendOutputSchema)
