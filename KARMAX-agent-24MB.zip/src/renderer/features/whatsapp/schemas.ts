/**
 * wacli local API schemas, verified against wacli/wa/api.go + wa/store.go (NOT the guesses in lib/api/schemas.ts).
 *
 *   GET  /status          StatusSnapshot   {connected, user_jid?, user_lid?, dnd_mode, initial_access_configured, chat_count, message_count, last_history_sync?}
 *   PUT  /dnd             {enabled} -> {enabled}
 *   GET  /chats           {chats: ChatRecord[] | null}   (Go nil slice => null). ChatRecord times are RFC3339; a chat that never had a
 *                         message serialises last_message_at as the Unix epoch, so anything before 2001 means "none".
 *   PUT  /chats/{jid}     {locked} -> {chat}     <- the per-chat toggle. NOTE /chats/access is different: it takes {unlocked_jids}
 *                         and LOCKS EVERY OTHER CHAT (first-run bulk configuration). Never used from this screen.
 *   GET  /messages        ?chat_ref|chat_jid=&limit=  -> {messages: MessageRecord[] (oldest first), resolved_chat, resolved_sender}
 *   GET  /logs            ?limit= -> {logs: AppLogRecord[] | null}  (newest first)
 *   GET  /webhooks        {webhooks: WebhookRecord[] | null}. The list INCLUDES each webhook's `secret`: it is stripped here so it
 *                         never enters renderer memory.
 */
import { z } from 'zod'

const arr = <T extends z.ZodType>(t: T) =>
  z
    .array(t)
    .nullish()
    .transform((v) => v ?? [])

export const StatusSchema = z.looseObject({
  connected: z.boolean().default(false),
  user_jid: z.string().optional(),
  user_lid: z.string().optional(),
  dnd_mode: z.boolean().default(false),
  initial_access_configured: z.boolean().default(false),
  chat_count: z.number().default(0),
  message_count: z.number().default(0),
  last_history_sync: z.string().nullish()
})
export type WaStatus = z.infer<typeof StatusSchema>

export const ChatSchema = z.object({
  jid: z.string(),
  name: z.string().default(''),
  is_group: z.boolean().default(false),
  locked: z.boolean().default(false),
  first_seen_at: z.string().optional(),
  last_message_at: z.string().optional(),
  last_message_preview: z.string().default('')
})
export type WaChat = z.infer<typeof ChatSchema>
export const ChatsResponseSchema = z.looseObject({ chats: arr(ChatSchema) })
export const ChatUpdateSchema = z.looseObject({ chat: ChatSchema.optional() })

export const MessageSchema = z.object({
  id: z.string(),
  chat_jid: z.string().default(''),
  sender_jid: z.string().default(''),
  content: z.string().default(''),
  timestamp: z.string(),
  is_from_me: z.boolean().default(false),
  message_type: z.string().default('text'),
  media_type: z.string().optional(),
  file_name: z.string().optional()
})
export type WaMessage = z.infer<typeof MessageSchema>
export const MessagesResponseSchema = z.looseObject({ messages: arr(MessageSchema) })

export const LogSchema = z.object({
  id: z.number(),
  level: z.string().default('info'),
  category: z.string().default(''),
  message: z.string().default(''),
  created_at: z.string()
})
export type WaLog = z.infer<typeof LogSchema>
export const LogsResponseSchema = z.looseObject({ logs: arr(LogSchema) })

/** `secret` is deliberately absent: z.object strips unknown keys. */
export const WebhookSchema = z.object({
  id: z.number(),
  url: z.string(),
  events: arr(z.string()),
  scope: z.string().default('all_unlocked'),
  chat_jids: arr(z.string()),
  enabled: z.boolean().default(true),
  include_mentions: z.boolean().default(false)
})
export type WaWebhook = z.infer<typeof WebhookSchema>
export const WebhooksResponseSchema = z.looseObject({ webhooks: arr(WebhookSchema) })

/** Output of KARMAX's comms.send tool (internal/tools/builtin/comms.go). */
export const CommsSendOutputSchema = z.looseObject({ status: z.string().optional(), channel_id: z.string().optional(), target: z.string().optional() })
