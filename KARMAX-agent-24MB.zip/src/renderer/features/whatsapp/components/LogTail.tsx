import { useLayoutEffect, useMemo, useRef } from 'react'
import { Bug, Info, OctagonX, ScrollText, TriangleAlert } from 'lucide-react'
import { EmptyState, ErrorNote, Skeleton } from '@/design/primitives'
import { cn } from '@/design/cn'
import { formatClock } from '@/lib/format'
import { Panel } from '../ui/Bits'
import type { WaLog } from '../schemas'
import { warnText } from '../ui/tone'

type Lvl = 'debug' | 'info' | 'warn' | 'error'
const LEVELS: Record<Lvl, { label: string; icon: React.ReactNode; text: string; row: string }> = {
  debug: { label: 'DEBUG', icon: <Bug className="size-3" />, text: 'text-ink-3', row: '' },
  info: { label: 'INFO', icon: <Info className="size-3" />, text: 'text-ink-2', row: '' },
  warn: { label: 'WARN', icon: <TriangleAlert className="size-3" strokeWidth={2.5} />, text: warnText, row: 'bg-[color-mix(in_oklab,var(--warn)_7%,transparent)]' },
  error: { label: 'ERROR', icon: <OctagonX className="size-3" strokeWidth={2.5} />, text: 'text-crit', row: 'bg-[color-mix(in_oklab,var(--crit)_9%,transparent)]' }
}
const lvl = (s: string): Lvl => (s === 'warning' ? 'warn' : s in LEVELS ? (s as Lvl) : 'info')

export function LogTail({ logs, loading, error, onRetry }: { logs?: WaLog[]; loading: boolean; error?: unknown; onRetry: () => void }) {
  // wacli returns newest first; a tail reads oldest to newest with the latest at the bottom.
  const lines = useMemo(() => [...(logs ?? [])].sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at) || a.id - b.id), [logs])
  const box = useRef<HTMLDivElement>(null)
  const stick = useRef(true)
  const last = lines.at(-1)?.id

  useLayoutEffect(() => {
    const el = box.current
    if (el && stick.current) el.scrollTop = el.scrollHeight
  }, [last])

  return (
    <Panel icon={<ScrollText className="size-3.5" />} title="wacli log" hint="Last 50 lines from wacli /logs" bodyClassName="px-5 pb-4">
      {error ? (
        <ErrorNote error={error} onRetry={onRetry} />
      ) : loading ? (
        <div className="space-y-1.5">
          {[0, 1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-5 w-full" />
          ))}
        </div>
      ) : lines.length === 0 ? (
        <EmptyState icon={<ScrollText className="size-5" />} title="No log lines" body="wacli has not written anything yet." />
      ) : (
        <div
          ref={box}
          onScroll={(e) => {
            const el = e.currentTarget
            stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40
          }}
          className="selectable scroll-thin max-h-[300px] overflow-auto rounded-xl bg-[color-mix(in_oklab,var(--page)_55%,transparent)] py-1.5 font-[family-name:var(--font-mono)] text-[11.5px] leading-[1.55] ring-1 ring-line"
          role="log"
          aria-label="wacli log"
        >
          {lines.map((l) => {
            const v = LEVELS[lvl(l.level)]
            return (
              <div key={l.id} className={cn('flex items-baseline gap-3 px-3 py-[2px]', v.row)}>
                <span className="tnum shrink-0 text-ink-3">{formatClock(l.created_at)}</span>
                <span className={cn('inline-flex w-[58px] shrink-0 items-center gap-1 font-semibold', v.text)}>
                  {v.icon}
                  {v.label}
                </span>
                <span className="hidden w-[68px] shrink-0 truncate text-ink-3 @xl:inline">{l.category}</span>
                <span className={cn('min-w-0 flex-1 break-words', l.level === 'error' ? 'text-crit' : 'text-ink-2')}>{l.message}</span>
              </div>
            )
          })}
        </div>
      )}
    </Panel>
  )
}
