import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Lock, LockOpen, MessageSquareOff, Search, SearchX, ShieldAlert, Users, X } from 'lucide-react'
import { Badge, EmptyState, ErrorNote, Skeleton, Switch } from '@/design/primitives'
import { cn } from '@/design/cn'
import { timeAgo } from '@/lib/format'
import { Panel } from '../ui/Bits'
import { ConfirmDialog } from '../ui/ConfirmDialog'
import { validTime } from '../logic'
import type { WaChat } from '../schemas'
import { goodText, warnText } from '../ui/tone'

type Filter = 'all' | 'unlocked' | 'locked' | 'groups'

const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'unlocked', label: 'Unlocked' },
  { id: 'locked', label: 'Locked' },
  { id: 'groups', label: 'Groups' }
]

function Avatar({ chat, operator }: { chat: WaChat; operator: boolean }) {
  const initial = (chat.name || '?').trim().charAt(0).toUpperCase()
  return (
    <span
      className={cn('grid size-8 shrink-0 place-items-center rounded-full text-[12px] font-semibold ring-1', operator ? 'bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_45%,transparent)]' : 'bg-surface-3 text-ink-2 ring-line')}
      aria-hidden
    >
      {chat.is_group ? <Users className="size-4" /> : initial}
    </span>
  )
}

function AccessLabel({ chat, operator }: { chat: WaChat; operator: boolean }) {
  if (chat.locked)
    return (
      <span className="inline-flex w-[92px] items-center gap-1.5 text-[11.5px] font-medium text-ink-3">
        <Lock className="size-3.5" />
        Locked
      </span>
    )
  return (
    <span className={cn('inline-flex w-[92px] items-center gap-1.5 text-[11.5px] font-semibold', operator ? goodText : warnText)}>
      <LockOpen className="size-3.5" />
      Unlocked
    </span>
  )
}

export function ChatTable({
  chats,
  loading,
  error,
  onRetry,
  operatorJid,
  pendingJids,
  totalCount,
  onSetLocked
}: {
  chats: WaChat[]
  loading: boolean
  error?: unknown
  onRetry: () => void
  operatorJid?: string
  pendingJids: Set<string>
  totalCount?: number
  onSetLocked: (chat: WaChat, locked: boolean) => void
}) {
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [unlocking, setUnlocking] = useState<WaChat | null>(null)

  const counts = useMemo(
    () => ({ all: chats.length, unlocked: chats.filter((c) => !c.locked).length, locked: chats.filter((c) => c.locked).length, groups: chats.filter((c) => c.is_group).length }),
    [chats]
  )

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase()
    const list = chats.filter((c) => {
      if (filter === 'unlocked' && c.locked) return false
      if (filter === 'locked' && !c.locked) return false
      if (filter === 'groups' && !c.is_group) return false
      if (!needle) return true
      return c.name.toLowerCase().includes(needle) || c.jid.toLowerCase().includes(needle) || c.last_message_preview.toLowerCase().includes(needle)
    })
    // The operator chat always floats to the top; everything else keeps wacli's recency order.
    return [...list].sort((a, b) => Number(b.jid === operatorJid) - Number(a.jid === operatorJid))
  }, [chats, q, filter, operatorJid])

  const request = (chat: WaChat, wantUnlocked: boolean) => {
    if (!wantUnlocked) return onSetLocked(chat, true)
    // Unlocking the operator chat is the point of the exercise; anything else widens what automation may touch.
    if (chat.jid === operatorJid) return onSetLocked(chat, false)
    setUnlocking(chat)
  }

  return (
    <Panel
      icon={<ShieldAlert className="size-3.5" />}
      title="Chat access"
      hint="Locked chats can never be touched by automation. New chats start unlocked."
      right={
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-ink-3" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search chats"
            aria-label="Search chats"
            className="selectable app-no-drag h-8 w-[220px] rounded-lg border border-line bg-surface-2/70 pl-8 pr-7 text-[12.5px] text-ink placeholder:text-ink-3 transition-colors hover:border-line-strong focus:border-accent focus:outline-none focus:ring-2 focus:ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]"
          />
          {q && (
            <button aria-label="Clear search" onClick={() => setQ('')} className="app-no-drag absolute right-1.5 top-1/2 grid size-5 -translate-y-1/2 place-items-center rounded text-ink-3 hover:text-ink">
              <X className="size-3.5" />
            </button>
          )}
        </div>
      }
      bodyClassName="px-5 pb-0"
    >
      <div role="group" aria-label="Filter chats" className="mb-3 flex flex-wrap gap-1.5">
        {FILTERS.map((f) => {
          const on = filter === f.id
          return (
            <button
              key={f.id}
              aria-pressed={on}
              onClick={() => setFilter(f.id)}
              className={cn(
                'app-no-drag inline-flex h-7 items-center gap-1.5 rounded-full px-3 text-[12px] font-medium ring-1 transition-colors',
                on ? 'bg-accent-soft text-ink ring-[color-mix(in_oklab,var(--accent)_45%,transparent)]' : 'text-ink-2 ring-line hover:bg-surface-2 hover:text-ink'
              )}
            >
              {f.label}
              <span className={cn('tnum text-[11px]', on ? 'text-accent' : 'text-ink-3')}>{counts[f.id]}</span>
            </button>
          )
        })}
        {totalCount != null && totalCount > chats.length && <span className="ml-auto self-center text-[11.5px] text-ink-3">Showing {chats.length} of {totalCount}</span>}
      </div>

      {error ? (
        <div className="pb-5">
          <ErrorNote error={error} onRetry={onRetry} />
        </div>
      ) : loading ? (
        <div className="space-y-2 pb-5">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : chats.length === 0 ? (
        <EmptyState icon={<MessageSquareOff className="size-5" />} title="No chats yet" body="wacli has not stored any chats. They appear after the first history sync or the first message." />
      ) : rows.length === 0 ? (
        <EmptyState
          icon={<SearchX className="size-5" />}
          title="No chats match"
          body={q ? `Nothing matches “${q}” in this filter.` : 'Nothing in this filter.'}
          action={
            <button
              onClick={() => {
                setQ('')
                setFilter('all')
              }}
              className="app-no-drag rounded-lg px-3 py-1.5 text-[12.5px] font-medium text-accent hover:bg-accent-soft"
            >
              Clear filters
            </button>
          }
        />
      ) : (
        <div className="-mx-5 max-h-[440px] overflow-auto border-t border-line scroll-thin" role="table" aria-label="Chat access" aria-rowcount={rows.length}>
          <div role="row" className="sticky top-0 z-10 hidden grid-cols-[minmax(0,1.1fr)_minmax(0,1.4fr)_88px_150px] gap-4 border-b border-line bg-surface px-5 py-2 @2xl:grid">
            <span role="columnheader" className="label-micro">Chat</span>
            <span role="columnheader" className="label-micro">Last message</span>
            <span role="columnheader" className="label-micro text-right">When</span>
            <span role="columnheader" className="label-micro">Access</span>
          </div>
          <AnimatePresence initial={false}>
            {rows.map((c) => {
              const op = c.jid === operatorJid
              const t = validTime(c.last_message_at)
              const busy = pendingJids.has(c.jid)
              return (
                <motion.div
                  key={c.jid}
                  layout="position"
                  role="row"
                  transition={{ duration: 0.2 }}
                  className={cn(
                    'relative grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-1 border-b border-line/70 px-5 py-2.5 transition-colors last:border-b-0 @2xl:grid-cols-[minmax(0,1.1fr)_minmax(0,1.4fr)_88px_150px]',
                    op ? 'bg-accent-soft' : 'hover:bg-surface-2/50'
                  )}
                >
                  {op && <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-full bg-accent shadow-[0_0_12px_var(--accent)]" />}
                  <div role="cell" className="flex min-w-0 items-center gap-3">
                    <Avatar chat={c} operator={op} />
                    <div className="min-w-0">
                      <div className="flex min-w-0 items-center gap-1.5">
                        <span className="selectable truncate text-[13px] font-medium text-ink">{c.name || 'Unnamed chat'}</span>
                        {op && <Badge className="bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_40%,transparent)]">Operator</Badge>}
                        {c.is_group && (
                          <Badge>
                            <Users className="size-3" />
                            Group
                          </Badge>
                        )}
                      </div>
                      <div className="truncate font-[family-name:var(--font-mono)] text-[10.5px] text-ink-3">{c.jid.split('@')[0]}</div>
                    </div>
                  </div>
                  <div role="cell" className="selectable order-3 col-span-2 min-w-0 truncate text-[12.5px] text-ink-2 @2xl:order-none @2xl:col-span-1">
                    {c.last_message_preview || <span className="text-ink-3">No messages</span>}
                    <span className="tnum ml-2 text-[11px] text-ink-3 @2xl:hidden">{t ? timeAgo(t) : ''}</span>
                  </div>
                  <div role="cell" className="tnum hidden text-right text-[11.5px] text-ink-3 @2xl:block">{t ? timeAgo(t) : '—'}</div>
                  <div role="cell" className="flex items-center justify-end gap-3 @2xl:justify-between">
                    <AccessLabel chat={c} operator={op} />
                    <Switch
                      checked={!c.locked}
                      disabled={busy}
                      label={c.locked ? `Unlock ${c.name || c.jid}` : `Lock ${c.name || c.jid}`}
                      onChange={(v) => request(c, v)}
                    />
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}

      <ConfirmDialog
        open={!!unlocking}
        tone="warn"
        icon={<LockOpen className="size-4" />}
        title={unlocking ? `Unlock “${unlocking.name || 'this chat'}”?` : ''}
        confirmLabel="Unlock chat"
        onCancel={() => setUnlocking(null)}
        onConfirm={() => {
          const c = unlocking
          setUnlocking(null)
          if (c) onSetLocked(c, false)
        }}
      >
        {unlocking?.is_group ? (
          <p>
            KARMAX will be able to read and post in this <b className="font-semibold text-ink">group</b>. Everyone in it will see what KARMAX writes, and their messages can reach KARMAX if a webhook covers the group.
          </p>
        ) : (
          <p>
            KARMAX will be able to message <b className="font-semibold text-ink">{unlocking?.name || 'this contact'}</b>, and their messages can reach KARMAX if a webhook covers this chat.
          </p>
        )}
        <p className="text-ink-3">Only your operator chat needs to be unlocked to give KARMAX tasks. Unlock others only when you want KARMAX to talk to them. You can lock it again at any time.</p>
      </ConfirmDialog>
    </Panel>
  )
}
