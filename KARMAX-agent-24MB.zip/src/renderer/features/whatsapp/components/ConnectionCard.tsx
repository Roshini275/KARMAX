import { Link } from 'react-router-dom'
import { CloudOff, MessageSquareText, Radio, ShieldCheck, ShieldQuestion } from 'lucide-react'
import { Skeleton } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { timeAgo } from '@/lib/format'
import { KV, Panel, Reveal } from '../ui/Bits'
import { maskJid, validTime } from '../logic'
import type { WaStatus } from '../schemas'
import { cn } from '@/design/cn'
import { warnText } from '../ui/tone'

const nf = new Intl.NumberFormat('en-US')

function Stat({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="flex-1 rounded-xl bg-surface-2/60 px-3.5 py-3 ring-1 ring-line">
      <div className="flex items-center gap-1.5 text-ink-3">
        {icon}
        <span className="label-micro">{label}</span>
      </div>
      <div className="tnum mt-1 font-[family-name:var(--font-display)] text-[24px] font-semibold leading-none tracking-tight text-ink">{nf.format(value)}</div>
    </div>
  )
}

export function ConnectionCard({ status, loading, wacliUrl }: { status?: WaStatus; loading: boolean; wacliUrl?: string }) {
  const connected = !!status?.connected
  const sync = validTime(status?.last_history_sync ?? undefined)
  return (
    <Panel
      icon={<Radio className="size-3.5" />}
      title="Connection"
      hint="Session held by wacli"
      right={loading || !status ? <Skeleton className="h-5 w-24" /> : connected ? <StatusPill tone="good" label="Connected" /> : <StatusPill tone="crit" label="Disconnected" />}
      className="h-full"
    >
      {loading || !status ? (
        <div className="space-y-3">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      ) : (
        <>
          <div className="flex gap-3">
            <Stat label="Chats" value={status.chat_count} icon={<MessageSquareText className="size-3" />} />
            <Stat label="Messages" value={status.message_count} icon={<MessageSquareText className="size-3" />} />
          </div>
          <dl className="mt-3 divide-y divide-line">
            <KV k="Linked account">{status.user_jid ? <Reveal masked={maskJid(status.user_jid)} revealed={status.user_jid.split('@')[0].split(':')[0]} /> : 'Not linked'}</KV>
            <KV k="wacli endpoint">{wacliUrl ? <span className="font-[family-name:var(--font-mono)] text-[12px]">{wacliUrl.replace(/^https?:\/\//, '')}</span> : '—'}</KV>
            <KV k="Last history sync">{sync ? timeAgo(sync) : 'Never'}</KV>
            <KV k="First-run access">
              {status.initial_access_configured ? (
                <span className="inline-flex items-center gap-1.5 text-ink-2">
                  <ShieldCheck className="size-3.5 text-good" />
                  Configured
                </span>
              ) : (
                <span className={cn('inline-flex items-center gap-1.5', warnText)}>
                  <ShieldQuestion className="size-3.5" />
                  Not configured
                </span>
              )}
            </KV>
          </dl>
          {!connected && (
            <div className="mt-3 flex items-start gap-2.5 rounded-xl border border-[color-mix(in_oklab,var(--crit)_35%,transparent)] bg-[color-mix(in_oklab,var(--crit)_9%,transparent)] px-3.5 py-3 text-[12px] leading-relaxed text-ink-2">
              <CloudOff className="mt-0.5 size-4 shrink-0 text-crit" />
              <div>
                <span className="font-semibold text-crit">wacli is running, but WhatsApp is not connected.</span> Messages neither arrive nor leave. If your phone unlinked the device, pair again from{' '}
                <Link to="/settings?section=setup" className="text-accent underline-offset-2 hover:underline">
                  Settings, Setup
                </Link>
                ; otherwise check{' '}
                <Link to="/settings?section=processes" className="text-accent underline-offset-2 hover:underline">
                  Processes
                </Link>
                .
              </div>
            </div>
          )}
        </>
      )}
    </Panel>
  )
}
