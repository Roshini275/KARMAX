import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Check, CircleAlert, Clock, LockOpen, Send, TriangleAlert, UserRound } from 'lucide-react'
import { Button, Skeleton } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { cn } from '@/design/cn'
import { KV, Panel, Reveal } from '../ui/Bits'
import { ConfirmDialog } from '../ui/ConfirmDialog'
import { maskPhone, revealPhone, testMessage, type Check as CheckT, type CheckState, type OperatorVerdict } from '../logic'
import type { WaChat } from '../schemas'
import { goodText, seriousText, warnText } from '../ui/tone'

const stateIcon: Record<CheckState, React.ReactNode> = {
  pass: <Check className="size-3" strokeWidth={3} />,
  fail: <CircleAlert className="size-3" strokeWidth={2.5} />,
  warn: <TriangleAlert className="size-3" strokeWidth={2.5} />,
  todo: <Clock className="size-3" strokeWidth={2.5} />
}
const stateText: Record<CheckState, string> = { pass: goodText, fail: seriousText, warn: warnText, todo: 'text-ink-3' }
const stateWord: Record<CheckState, string> = { pass: 'OK', fail: 'Problem', warn: 'Warning', todo: 'Pending' }

function CheckRow({ c, action }: { c: CheckT; action?: React.ReactNode }) {
  return (
    <li className="flex items-start gap-2.5 py-[5px]">
      <span className={cn('mt-[2px] grid size-[18px] shrink-0 place-items-center rounded-full ring-1', stateText[c.state])} style={{ background: 'color-mix(in oklab, currentColor 12%, transparent)', ['--tw-ring-color' as string]: 'color-mix(in oklab, currentColor 30%, transparent)' }}>
        {stateIcon[c.state]}
        <span className="sr-only">{stateWord[c.state]}:</span>
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[12.5px] font-medium text-ink">{c.label}</span>
          {action}
        </div>
        {c.detail && (c.state !== 'pass' || c.id === 'only') && <p className="mt-0.5 text-[11.5px] leading-snug text-ink-3">{c.detail}</p>}
      </div>
    </li>
  )
}

export interface SendGate {
  ok: boolean
  reason?: string
}

export function OperatorCard({
  loading,
  operatorNumber,
  operatorChat,
  verdict,
  sendGate,
  sending,
  onSend,
  onUnlockOperator
}: {
  loading: boolean
  operatorNumber?: string
  operatorChat?: WaChat
  verdict: OperatorVerdict
  sendGate: SendGate
  sending: boolean
  onSend: (text: string) => void
  onUnlockOperator: () => void
}) {
  const [confirm, setConfirm] = useState(false)
  const [text, setText] = useState('')
  const verdictIcon = verdict.tone === 'muted' ? <Clock className="size-3" strokeWidth={2.5} /> : verdict.tone === 'serious' ? <CircleAlert className="size-3" strokeWidth={2.5} /> : undefined

  return (
    <Panel
      icon={<UserRound className="size-3.5" />}
      title="Operator"
      hint="Who gives KARMAX tasks"
      right={loading ? <Skeleton className="h-5 w-28" /> : <StatusPill tone={verdict.tone} label={verdict.label} icon={verdictIcon} className="whitespace-nowrap" />}
      className="h-full"
    >
      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-5 w-2/3" />
          <Skeleton className="h-24 w-full" />
        </div>
      ) : (
        <div className="flex h-full flex-col">
          <dl className="divide-y divide-line">
            <KV k="Operator number">
              {operatorNumber ? (
                <Reveal masked={maskPhone(operatorNumber)} revealed={revealPhone(operatorNumber)} />
              ) : (
                <span className="text-ink-3">
                  Not set.{' '}
                  <Link to="/settings?section=setup" className="text-accent hover:underline">
                    Open setup
                  </Link>
                </span>
              )}
            </KV>
            <KV k="Chat in wacli">{operatorChat ? operatorChat.name || 'Unnamed chat' : <span className="text-ink-3">Not seen yet</span>}</KV>
          </dl>

          {!verdict.checks.some((c) => c.state !== 'pass' && c.detail === verdict.summary) && <p className="mt-3 text-[12.5px] leading-relaxed text-ink-2">{verdict.summary}</p>}

          {(() => {
            const loud = verdict.checks.filter((c) => c.state !== 'pass' || (c.id === 'only' && c.detail))
            const quiet = verdict.checks.filter((c) => !loud.includes(c))
            return (
              <>
                {loud.length > 0 && (
                  <ul className="mt-2 divide-y divide-line/60" aria-label="Checks that need attention">
                    {loud.map((c) => (
                      <CheckRow
                        key={c.id}
                        c={c}
                        action={
                          c.id === 'unlocked' && c.state === 'fail' ? (
                            <Button size="sm" variant="subtle" icon={<LockOpen className="size-3" />} onClick={onUnlockOperator}>
                              Unlock
                            </Button>
                          ) : undefined
                        }
                      />
                    ))}
                  </ul>
                )}
                {quiet.length > 0 && (
                  <ul className={cn('grid grid-cols-1 gap-x-4 @md:grid-cols-2', loud.length ? 'mt-1 border-t border-line/60 pt-1' : 'mt-2')} aria-label="Passing checks">
                    {quiet.map((c) => (
                      <CheckRow key={c.id} c={c} />
                    ))}
                  </ul>
                )}
              </>
            )
          })()}

          <div className="mt-auto flex flex-wrap items-center gap-x-3 gap-y-2 pt-4">
            <Button variant="primary" icon={<Send className="size-3.5" />} disabled={!sendGate.ok} loading={sending} onClick={() => {
                setText(testMessage())
                setConfirm(true)
              }}
            >
              Send test update
            </Button>
            <span className="min-w-0 flex-1 text-[11.5px] leading-snug text-ink-3">{sendGate.ok ? 'Sends a real WhatsApp message to the operator.' : sendGate.reason}</span>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={confirm}
        tone="primary"
        icon={<Send className="size-4" />}
        title="Send a real WhatsApp message?"
        confirmLabel="Send message"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          setConfirm(false)
          onSend(text)
        }}
      >
        <p>
          KARMAX will send this from the linked WhatsApp account to your operator number{operatorNumber ? <> (<span className="font-[family-name:var(--font-mono)] text-[11.5px] text-ink">{maskPhone(operatorNumber)}</span>)</> : ''}. It goes out immediately and cannot be recalled.
        </p>
        <blockquote className="selectable rounded-lg border-l-2 border-accent bg-surface-2 px-3 py-2 text-[12px] italic text-ink">{text}</blockquote>
      </ConfirmDialog>
    </Panel>
  )
}
