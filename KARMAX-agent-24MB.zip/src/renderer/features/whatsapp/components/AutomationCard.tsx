import { useState } from 'react'
import { motion } from 'framer-motion'
import { Ban, Check, LockOpen, Power, ShieldAlert, TriangleAlert, Webhook, Zap } from 'lucide-react'
import { Skeleton } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { cn } from '@/design/cn'
import { spring } from '@/design/motion'
import { Panel } from '../ui/Bits'
import { ConfirmDialog } from '../ui/ConfirmDialog'
import type { WaChat } from '../schemas'
import { warnText } from '../ui/tone'

/** The one control that matters most on this screen, so it is big, labelled and unambiguous. */
function BigSwitch({ armed, onChange, disabled, pending }: { armed: boolean; onChange: (v: boolean) => void; disabled?: boolean; pending?: boolean }) {
  return (
    <button
      role="switch"
      aria-checked={armed}
      aria-label="Automation (Do Not Disturb)"
      aria-busy={pending}
      disabled={disabled}
      onClick={() => onChange(!armed)}
      className={cn(
        'app-no-drag relative h-[38px] w-[72px] shrink-0 rounded-full p-[3px] ring-1 transition-[background,box-shadow] duration-300 disabled:opacity-50',
        armed ? 'bg-accent ring-[color-mix(in_oklab,var(--accent)_60%,white_10%)] shadow-[0_0_0_4px_var(--accent-soft),0_0_32px_-4px_var(--accent)]' : 'bg-surface-3 ring-line-strong'
      )}
    >
      <motion.span
        initial={false}
        animate={{ x: armed ? 34 : 0 }}
        transition={spring}
        className="grid size-8 place-items-center rounded-full bg-white shadow-md"
      >
        {armed ? <Zap className="size-4 text-accent" fill="currentColor" /> : <Power className="size-4 text-neutral-500" />}
      </motion.span>
    </button>
  )
}

const Bullet = ({ icon, children, tone }: { icon: React.ReactNode; children: React.ReactNode; tone: 'on' | 'off' }) => (
  <li className="flex items-start gap-2.5 text-[12.5px] leading-snug text-ink-2">
    <span className={cn('mt-[1px] grid size-[18px] shrink-0 place-items-center rounded-md ring-1', tone === 'on' ? 'bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_30%,transparent)]' : 'bg-surface-2 text-ink-3 ring-line')}>{icon}</span>
    <span>{children}</span>
  </li>
)

function Fact({ label, value, warn }: { label: string; value: string; warn?: boolean }) {
  return (
    <div className="px-4 py-2.5">
      <dt className="label-micro">{label}</dt>
      <dd className={cn('tnum mt-0.5 flex items-center gap-1.5 whitespace-nowrap text-[14px] font-semibold', warn ? warnText : 'text-ink')}>
        {warn && <TriangleAlert className="size-3.5" strokeWidth={2.5} />}
        {value}
      </dd>
    </div>
  )
}

export function AutomationCard({
  armed,
  loading,
  pending,
  chats,
  operatorChat,
  onSet
}: {
  armed: boolean
  loading: boolean
  pending: boolean
  chats: WaChat[]
  operatorChat?: WaChat
  onSet: (enabled: boolean) => void
}) {
  const [confirm, setConfirm] = useState(false)
  const unlockedOthers = chats.filter((c) => !c.locked && c.jid !== operatorChat?.jid)

  return (
    <Panel
      icon={<Zap className="size-3.5" />}
      title="Automation"
      hint="wacli Do Not Disturb, inverted: ON means armed"
      right={loading ? <Skeleton className="h-5 w-20" /> : armed ? <StatusPill tone="accent" label="Armed" icon={<Zap className="size-3" fill="currentColor" strokeWidth={2} />} /> : <StatusPill tone="muted" label="Disarmed" icon={<Ban className="size-3" strokeWidth={2.5} />} />}
      className="h-full"
    >
      {loading ? (
        <Skeleton className="h-28 w-full" />
      ) : (
        <div className="flex h-full flex-col gap-5">
        <div className="flex flex-1 flex-col justify-center gap-5 @xl:flex-row @xl:items-center">
          <div className="flex items-center gap-4 @xl:flex-col @xl:items-start">
            <BigSwitch armed={armed} pending={pending} onChange={(v) => (v ? setConfirm(true) : onSet(false))} />
            <div>
              <div className="font-[family-name:var(--font-display)] text-[18px] font-semibold leading-tight tracking-tight">{armed ? 'KARMAX is armed' : 'KARMAX is disarmed'}</div>
              <div className="mt-0.5 text-[12px] text-ink-3">{armed ? 'Turn off to block everything at once.' : 'Nothing goes in or out until you arm it.'}</div>
            </div>
          </div>
          <ul className="grid flex-1 gap-2.5 @xl:border-l @xl:border-line @xl:pl-6">
            {armed ? (
              <>
                <Bullet tone="on" icon={<Check className="size-3" strokeWidth={3} />}>KARMAX may send messages to <b className="font-semibold text-ink">unlocked</b> chats.</Bullet>
                <Bullet tone="on" icon={<Webhook className="size-3" />}>Messages from unlocked chats are forwarded to KARMAX as webhooks.</Bullet>
                <Bullet tone="on" icon={<ShieldAlert className="size-3" />}>Locked chats stay untouchable, always.</Bullet>
              </>
            ) : (
              <>
                <Bullet tone="off" icon={<Ban className="size-3" />}>All sends, stories and auto-replies are <b className="font-semibold text-ink">blocked</b>.</Bullet>
                <Bullet tone="off" icon={<Webhook className="size-3" />}>Webhooks stop: KARMAX will not see your operator messages.</Bullet>
                <Bullet tone="off" icon={<ShieldAlert className="size-3" />}>Messages are still stored by wacli, just not acted on.</Bullet>
              </>
            )}
          </ul>
        </div>
        {chats.length > 0 && (
          <dl className="grid grid-cols-3 divide-x divide-line rounded-xl bg-surface-2/50 ring-1 ring-line">
            <Fact label="Unlocked" value={String(chats.filter((c) => !c.locked).length)} />
            <Fact label="Locked" value={String(chats.filter((c) => c.locked).length)} />
            <Fact
              label="Can reach"
              value={!operatorChat || operatorChat.locked ? (unlockedOthers.length ? `${unlockedOthers.length} other${unlockedOthers.length > 1 ? 's' : ''}` : 'Nobody') : unlockedOthers.length === 0 ? 'Operator only' : `Operator + ${unlockedOthers.length}`}
              warn={unlockedOthers.length > 0}
            />
          </dl>
        )}
        </div>
      )}

      <ConfirmDialog
        open={confirm}
        tone="primary"
        icon={<Zap className="size-4" fill="currentColor" />}
        title="Arm automation?"
        confirmLabel="Arm automation"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          setConfirm(false)
          onSet(true)
        }}
      >
        <p>KARMAX will be able to send WhatsApp messages, and wacli will forward incoming messages from unlocked chats to it.</p>
        <p className="flex items-start gap-2 rounded-lg bg-surface-2 px-3 py-2 ring-1 ring-line">
          <LockOpen className="mt-0.5 size-3.5 shrink-0 text-ink-3" />
          <span>
            {operatorChat ? (operatorChat.locked ? 'Your operator chat is locked, so nothing will reach KARMAX yet. ' : 'Your operator chat is unlocked. ') : ''}
            {unlockedOthers.length === 0 ? 'No other chat is unlocked.' : <><b className="font-semibold text-ink">{unlockedOthers.length} other chat{unlockedOthers.length > 1 ? 's are' : ' is'} unlocked</b> ({unlockedOthers.slice(0, 3).map((c) => c.name || 'unnamed').join(', ')}{unlockedOthers.length > 3 ? ', …' : ''}).</>}
          </span>
        </p>
      </ConfirmDialog>
    </Panel>
  )
}
