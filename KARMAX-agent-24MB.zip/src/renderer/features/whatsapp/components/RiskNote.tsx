import { ShieldAlert } from 'lucide-react'

/** Permanent and deliberately calm: neutral surface, no status colour (it is context, not state). */
export function RiskNote() {
  return (
    <aside className="flex items-start gap-3 rounded-xl bg-surface-2/50 px-4 py-3 ring-1 ring-line" aria-label="Risk note">
      <ShieldAlert className="mt-0.5 size-4 shrink-0 text-ink-3" />
      <p className="text-[12px] leading-relaxed text-ink-3">
        <span className="font-semibold text-ink-2">A note on risk.</span> Automating a personal WhatsApp account goes against WhatsApp&apos;s Terms of Service and can get the number banned. A dedicated number for KARMAX is strongly recommended: message it from your own, and keep your personal chats locked.
      </p>
    </aside>
  )
}
