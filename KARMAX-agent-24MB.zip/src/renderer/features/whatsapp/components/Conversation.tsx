import { useLayoutEffect, useMemo, useRef } from 'react'
import { AudioLines, FileText, ImageIcon, MessageCircleOff, MessagesSquare, Sticker, Video } from 'lucide-react'
import { EmptyState, ErrorNote, Skeleton } from '@/design/primitives'
import { cn } from '@/design/cn'
import { Panel } from '../ui/Bits'
import type { WaMessage } from '../schemas'

const mediaLabel: Record<string, { label: string; icon: React.ReactNode }> = {
  audio: { label: 'Voice note', icon: <AudioLines className="size-3.5" /> },
  image: { label: 'Photo', icon: <ImageIcon className="size-3.5" /> },
  video: { label: 'Video', icon: <Video className="size-3.5" /> },
  document: { label: 'Document', icon: <FileText className="size-3.5" /> },
  sticker: { label: 'Sticker', icon: <Sticker className="size-3.5" /> }
}

function dayLabel(d: Date, now = new Date()): string {
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime()
  const diff = Math.round((start(now) - start(d)) / 86_400_000)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Yesterday'
  return d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })
}
const clock = (d: Date) => d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

type Item = { kind: 'day'; key: string; label: string } | { kind: 'msg'; key: string; m: WaMessage; d: Date; tight: boolean }

function toItems(messages: WaMessage[]): Item[] {
  const out: Item[] = []
  let lastDay = ''
  let prev: { m: WaMessage; t: number } | undefined
  for (const m of messages) {
    const d = new Date(m.timestamp)
    if (Number.isNaN(d.getTime())) continue
    const dk = d.toDateString()
    if (dk !== lastDay) {
      lastDay = dk
      out.push({ kind: 'day', key: `day-${dk}`, label: dayLabel(d) })
      prev = undefined
    }
    const tight = !!prev && prev.m.is_from_me === m.is_from_me && d.getTime() - prev.t < 2 * 60_000
    out.push({ kind: 'msg', key: m.id, m, d, tight })
    prev = { m, t: d.getTime() }
  }
  return out
}

function Bubble({ m, d, tight }: { m: WaMessage; d: Date; tight: boolean }) {
  const mine = m.is_from_me // from the KARMAX account => KARMAX speaking
  const media = m.media_type || (m.message_type !== 'text' && m.message_type !== 'message' ? m.message_type : '')
  const meta = media ? mediaLabel[media] ?? { label: media, icon: <FileText className="size-3.5" /> } : undefined
  return (
    <div className={cn('flex flex-col', mine ? 'items-end' : 'items-start', tight ? 'mt-0.5' : 'mt-2.5')}>
      {!tight && <span className={cn('mb-1 text-[10.5px] font-semibold tracking-wide', mine ? 'text-accent' : 'text-ink-3')}>{mine ? 'KARMAX' : 'You'}</span>}
      <div
        className={cn(
          'max-w-[86%] rounded-2xl px-3 py-1.5 text-[12.5px] leading-snug ring-1',
          mine ? 'rounded-tr-md bg-accent-soft text-ink ring-[color-mix(in_oklab,var(--accent)_28%,transparent)]' : 'rounded-tl-md bg-surface-2 text-ink ring-line'
        )}
      >
        {meta && (
          <span className="mb-0.5 inline-flex items-center gap-1.5 text-[11.5px] italic text-ink-3">
            {meta.icon}
            {meta.label}
          </span>
        )}
        {m.content && <div className="selectable whitespace-pre-wrap break-words">{m.content}</div>}
        <div className={cn('tnum mt-0.5 text-[10px] text-ink-3', mine ? 'text-right' : 'text-left')}>{clock(d)}</div>
      </div>
    </div>
  )
}

export function Conversation({
  messages,
  loading,
  error,
  onRetry,
  notSeen,
  noOperator
}: {
  messages?: WaMessage[]
  loading: boolean
  error?: unknown
  onRetry: () => void
  notSeen: boolean
  noOperator: boolean
}) {
  const scroller = useRef<HTMLDivElement>(null)
  const items = useMemo(() => toItems(messages ?? []), [messages])
  const stick = useRef(true)
  const lastId = messages?.at(-1)?.id

  useLayoutEffect(() => {
    const el = scroller.current
    if (el && stick.current) el.scrollTop = el.scrollHeight
  }, [lastId, items.length])

  return (
    <Panel
      icon={<MessagesSquare className="size-3.5" />}
      title="Recent operator conversation"
      hint="Last 30 messages, refreshed every 5 seconds"
      right={
        <div className="hidden items-center gap-3 text-[11px] text-ink-3 @xl:flex">
          <span className="inline-flex items-center gap-1.5">
            <span className="size-2 rounded-sm bg-surface-3 ring-1 ring-line-strong" />
            You
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="size-2 rounded-sm bg-accent" />
            KARMAX
          </span>
        </div>
      }
      className="h-full"
      bodyClassName="flex flex-col px-5 pb-5"
    >
      {noOperator ? (
        <EmptyState icon={<MessageCircleOff className="size-5" />} title="No operator number" body="Set one in Setup to see your conversation with KARMAX here." />
      ) : notSeen ? (
        <EmptyState icon={<MessageCircleOff className="size-5" />} title="No conversation yet" body="Send “hi” from your operator number to the KARMAX WhatsApp number. It appears here as soon as wacli sees it." />
      ) : error ? (
        <ErrorNote error={error} onRetry={onRetry} />
      ) : loading ? (
        <div className="space-y-3">
          <Skeleton className="h-9 w-2/3" />
          <Skeleton className="ml-auto h-12 w-3/4" />
          <Skeleton className="h-9 w-1/2" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={<MessageCircleOff className="size-5" />} title="Nothing said yet" body="The operator chat exists but has no stored messages." />
      ) : (
        <div
          ref={scroller}
          onScroll={(e) => {
            const el = e.currentTarget
            stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80
          }}
          className="scroll-thin -mr-2 min-h-[340px] flex-1 basis-0 overflow-y-auto pr-2"
          role="log"
          aria-label="Operator conversation"
        >
          {items.map((it) =>
            it.kind === 'day' ? (
              <div key={it.key} className="my-3 flex items-center gap-3 first:mt-0">
                <span className="h-px flex-1 bg-line" />
                <span className="label-micro">{it.label}</span>
                <span className="h-px flex-1 bg-line" />
              </div>
            ) : (
              <Bubble key={it.key} m={it.m} d={it.d} tight={it.tight} />
            )
          )}
        </div>
      )}
    </Panel>
  )
}
