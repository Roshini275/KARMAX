import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { qk } from '@/lib/api/hooks'
import { sendViaKarmax, wa } from './api'
import type { WaChat, WaStatus } from './schemas'

export const waKeys = {
  status: ['wa', 'status'] as const,
  chats: ['wa', 'chats'] as const,
  webhooks: ['wa', 'webhooks'] as const,
  messages: (jid: string) => ['wa', 'messages', jid] as const,
  logs: ['wa', 'logs'] as const
}

export const useWaStatus = () => useQuery({ queryKey: waKeys.status, queryFn: wa.status, refetchInterval: 4000, retry: false })
export const useWaChats = () => useQuery({ queryKey: waKeys.chats, queryFn: () => wa.chats(500), refetchInterval: 10_000, retry: false })
export const useWaWebhooks = () => useQuery({ queryKey: waKeys.webhooks, queryFn: wa.webhooks, refetchInterval: 15_000, retry: false })
export const useWaMessages = (jid: string | undefined) =>
  useQuery({ queryKey: waKeys.messages(jid ?? ''), queryFn: () => wa.messages(jid as string, 30), enabled: !!jid, refetchInterval: 5000, retry: false })
export const useWaLogs = () => useQuery({ queryKey: waKeys.logs, queryFn: () => wa.logs(50), refetchInterval: 6000, retry: false })

/** DND with optimistic update + rollback. */
export function useSetDnd() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enabled: boolean) => wa.setDnd(enabled),
    onMutate: async (enabled) => {
      await qc.cancelQueries({ queryKey: waKeys.status })
      const prev = qc.getQueryData<WaStatus>(waKeys.status)
      if (prev) qc.setQueryData<WaStatus>(waKeys.status, { ...prev, dnd_mode: enabled })
      return { prev }
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(waKeys.status, ctx.prev)
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: waKeys.status })
      void qc.invalidateQueries({ queryKey: qk.wacliStatus })
    }
  })
}

/** Lock / unlock one chat (PUT /chats/{jid}) with optimistic update + rollback. */
export function useSetChatLocked() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ jid, locked }: { jid: string; locked: boolean }) => wa.setChatLocked(jid, locked),
    onMutate: async ({ jid, locked }) => {
      await qc.cancelQueries({ queryKey: waKeys.chats })
      const prev = qc.getQueryData<WaChat[]>(waKeys.chats)
      if (prev) qc.setQueryData<WaChat[]>(waKeys.chats, prev.map((c) => (c.jid === jid ? { ...c, locked } : c)))
      return { prev }
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(waKeys.chats, ctx.prev)
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: waKeys.chats })
      void qc.invalidateQueries({ queryKey: qk.wacliChats })
    }
  })
}

export function useSendTest(operatorJid: string | undefined) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ target, content }: { target: string; content: string }) => sendViaKarmax(target, content),
    onSuccess: () => {
      if (operatorJid) void qc.invalidateQueries({ queryKey: waKeys.messages(operatorJid) })
      void qc.invalidateQueries({ queryKey: waKeys.chats })
      void qc.invalidateQueries({ queryKey: waKeys.logs })
    }
  })
}
