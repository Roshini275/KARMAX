import { useState, type ReactNode } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { Card } from '@/design/primitives'
import { cn } from '@/design/cn'

/** Titled glass card used by every panel on the WhatsApp / Settings / Memory screens. */
export function Panel({
  icon,
  title,
  hint,
  right,
  children,
  className,
  bodyClassName,
  id
}: {
  icon?: ReactNode
  title?: string
  hint?: string
  right?: ReactNode
  children: ReactNode
  className?: string
  bodyClassName?: string
  id?: string
}) {
  return (
    <Card className={cn('@container flex min-h-0 flex-col overflow-hidden', className)} {...(id ? { id } : {})}>
      {(title || right) && (
        <div className="flex items-center justify-between gap-3 px-5 pb-3 pt-4">
          <div className="flex min-w-0 items-center gap-2.5">
            {icon && <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-surface-2 text-ink-2 ring-1 ring-line">{icon}</span>}
            <div className="min-w-0">
              {title && <h2 className="truncate text-[13.5px] font-semibold tracking-tight text-ink">{title}</h2>}
              {hint && <p className="truncate text-[11.5px] text-ink-3">{hint}</p>}
            </div>
          </div>
          {right}
        </div>
      )}
      <div className={cn('min-h-0 flex-1', bodyClassName ?? 'px-5 pb-5')}>{children}</div>
    </Card>
  )
}

/** Label / value row. */
export function KV({ k, children, className }: { k: string; children: ReactNode; className?: string }) {
  return (
    <div className={cn('flex min-h-[34px] items-center justify-between gap-4 py-1.5 text-[12.5px]', className)}>
      <dt className="shrink-0 text-ink-3">{k}</dt>
      <dd className="selectable min-w-0 truncate text-right text-ink-2">{children}</dd>
    </div>
  )
}

/** Value that is masked until the user asks to see it. */
export function Reveal({ masked, revealed, mono = true }: { masked: string; revealed: string; mono?: boolean }) {
  const [show, setShow] = useState(false)
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cn('selectable tnum', mono && 'font-[family-name:var(--font-mono)] text-[12px]')}>{show ? revealed : masked}</span>
      <button
        type="button"
        onClick={() => setShow((v) => !v)}
        aria-label={show ? 'Hide value' : 'Reveal value'}
        aria-pressed={show}
        title={show ? 'Hide' : 'Reveal'}
        className="app-no-drag grid size-5 place-items-center rounded text-ink-3 transition-colors hover:bg-surface-3 hover:text-ink"
      >
        {show ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
      </button>
    </span>
  )
}
