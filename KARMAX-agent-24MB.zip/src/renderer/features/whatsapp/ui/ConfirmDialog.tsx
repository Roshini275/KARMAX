import { useEffect, useId, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Button } from '@/design/primitives'
import { ease } from '@/design/motion'
import { cn } from '@/design/cn'

export interface ConfirmProps {
  open: boolean
  title: string
  icon?: ReactNode
  /** Plain-language consequence. Say what happens, not "are you sure". */
  children: ReactNode
  confirmLabel: string
  cancelLabel?: string
  /** danger = destructive/irreversible, warn = widens what automation may touch, primary = ordinary. */
  tone?: 'danger' | 'warn' | 'primary'
  /** Overrides the confirm button style (default: danger tone => danger button, otherwise primary). */
  confirmVariant?: 'danger' | 'primary'
  loading?: boolean
  onConfirm: () => void
  onCancel: () => void
}

const ring: Record<NonNullable<ConfirmProps['tone']>, string> = {
  danger: 'bg-[color-mix(in_oklab,var(--crit)_16%,transparent)] text-crit ring-[color-mix(in_oklab,var(--crit)_35%,transparent)]',
  warn: 'bg-[color-mix(in_oklab,var(--warn)_16%,transparent)] text-warn ring-[color-mix(in_oklab,var(--warn)_35%,transparent)]',
  primary: 'bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_35%,transparent)]'
}

/**
 * Modal confirmation. Focus starts on Cancel (so a stray Enter never confirms), Tab is trapped, Esc cancels,
 * focus returns to whatever opened it. Rendered in a portal so page transforms cannot offset it.
 */
export function ConfirmDialog({ open, title, icon, children, confirmLabel, cancelLabel = 'Cancel', tone = 'primary', confirmVariant, loading, onConfirm, onCancel }: ConfirmProps) {
  const titleId = useId()
  const bodyId = useId()
  const box = useRef<HTMLDivElement>(null)
  const cancelRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    const t = window.setTimeout(() => cancelRef.current?.focus(), 30)
    return () => {
      window.clearTimeout(t)
      prev?.focus?.()
    }
  }, [open])

  useEffect(() => {
    if (!open) return
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        if (!loading) onCancel()
        return
      }
      if (e.key !== 'Tab' || !box.current) return
      const f = [...box.current.querySelectorAll<HTMLElement>('button:not([disabled]), [href], input, [tabindex]:not([tabindex="-1"])')]
      if (!f.length) return
      const first = f[0]
      const last = f[f.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }
    window.addEventListener('keydown', h, true)
    return () => window.removeEventListener('keydown', h, true)
  }, [open, onCancel, loading])

  if (typeof document === 'undefined') return null
  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center p-6">
          <motion.div className="absolute inset-0 bg-black/55 backdrop-blur-[3px]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => !loading && onCancel()} />
          <motion.div
            ref={box}
            role="alertdialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={bodyId}
            className="glass relative w-full max-w-[440px] rounded-2xl p-5 shadow-pop"
            style={{ background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1, transition: { duration: 0.22, ease } }}
            exit={{ opacity: 0, y: 4, transition: { duration: 0.12 } }}
          >
            <div className="flex items-start gap-3.5">
              {icon && <div className={cn('grid size-9 shrink-0 place-items-center rounded-xl ring-1', ring[tone])}>{icon}</div>}
              <div className="min-w-0">
                <h2 id={titleId} className="text-[15px] font-semibold tracking-tight text-ink">
                  {title}
                </h2>
                <div id={bodyId} className="mt-1.5 space-y-2 text-[12.5px] leading-relaxed text-ink-2">
                  {children}
                </div>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <Button ref={cancelRef} variant="ghost" onClick={onCancel} disabled={loading}>
                {cancelLabel}
              </Button>
              <Button variant={confirmVariant ?? (tone === 'danger' ? 'danger' : 'primary')} loading={loading} onClick={onConfirm}>
                {confirmLabel}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  )
}
