import { useCallback, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, OctagonX, X } from 'lucide-react'
import { fast } from '@/design/motion'
import { cn } from '@/design/cn'

export interface ToastItem {
  id: number
  kind: 'ok' | 'error'
  text: string
}

/** Tiny local toast stack (design/ has none). `const { push, node } = useToasts()`; render `{node}` once in the page. */
export function useToasts(): { push: (kind: ToastItem['kind'], text: string) => void; node: ReactNode } {
  const [items, setItems] = useState<ToastItem[]>([])
  const seq = useRef(0)
  const dismiss = useCallback((id: number) => setItems((l) => l.filter((t) => t.id !== id)), [])
  const push = useCallback(
    (kind: ToastItem['kind'], text: string) => {
      const id = ++seq.current
      setItems((l) => [...l.slice(-3), { id, kind, text }])
      window.setTimeout(() => dismiss(id), kind === 'error' ? 8000 : 4200)
    },
    [dismiss]
  )
  const node =
    typeof document === 'undefined'
      ? null
      : createPortal(
          <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex w-[360px] max-w-[calc(100vw-2rem)] flex-col gap-2" aria-live="polite" role="status">
            <AnimatePresence initial={false}>
              {items.map((t) => (
                <motion.div
                  key={t.id}
                  layout
                  initial={{ opacity: 0, y: 12, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1, transition: fast }}
                  exit={{ opacity: 0, x: 24, transition: { duration: 0.14 } }}
                  className={cn('glass pointer-events-auto flex items-start gap-2.5 rounded-xl px-3.5 py-2.5 text-[12.5px] shadow-pop', t.kind === 'error' ? 'text-crit' : 'text-ink')}
                  style={{ background: 'color-mix(in oklab, var(--panel) 94%, transparent)' }}
                >
                  {t.kind === 'error' ? <OctagonX className="mt-px size-4 shrink-0 text-crit" /> : <Check className="mt-px size-4 shrink-0 text-good" strokeWidth={3} />}
                  <span className="selectable min-w-0 flex-1 leading-snug">{t.text}</span>
                  <button aria-label="Dismiss" onClick={() => dismiss(t.id)} className="app-no-drag -mr-1 rounded p-0.5 text-ink-3 hover:text-ink">
                    <X className="size-3.5" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>,
          document.body
        )
  return { push, node }
}
