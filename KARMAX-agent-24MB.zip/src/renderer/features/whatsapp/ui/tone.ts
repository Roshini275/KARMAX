/**
 * State text colours that stay legible on the light theme. The shared tokens make `--warn` (#fab219) and `--serious`
 * fine on dark surfaces but under 3:1 on light ones, so on light we mix them toward the ink colour. State is still
 * always carried by an icon + label; this only keeps the words readable.
 */
export const warnText = 'text-warn [:root[data-theme=light]_&]:text-[color-mix(in_oklab,var(--warn)_48%,var(--ink))]'
export const seriousText = 'text-serious [:root[data-theme=light]_&]:text-[color-mix(in_oklab,var(--serious)_70%,var(--ink))]'
export const goodText = 'text-good [:root[data-theme=light]_&]:text-[color-mix(in_oklab,var(--good)_80%,var(--ink))]'
