// Interaction screenshots for the WhatsApp / Settings / Memory screens (workstream E). Dev tool, not shipped.
//   MOCK_KARMAX_PORT=9104 MOCK_WACLI_PORT=8804 node fixtures/mock-daemon/server.mjs &
//   node src/renderer/features/whatsapp/dev/shots.mjs [scenario ...]          (default: all)
//   THEME=light W=1100 H=700 OUT=shots/e node src/renderer/features/whatsapp/dev/shots.mjs wa-main
// The web bridge's setup stub has no operatorNumber, so this script patches it in at the network layer.
import { chromium } from 'playwright'
import { mkdirSync, existsSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const OUT = process.env.OUT || 'shots/e'
const THEME = process.env.THEME || 'dark'
const W = Number(process.env.W || 1440)
const H = Number(process.env.H || 900)
const KP = process.env.MOCK_KARMAX_PORT || 9104
const WP = process.env.MOCK_WACLI_PORT || 8804
const OPERATOR = process.env.OPERATOR ?? '919876543210'
const suffix = `${THEME}${W < 1300 ? '-narrow' : ''}`

const chromePath = () => {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}
const wa = (body) => fetch(`http://127.0.0.1:${WP}/__mock/wa/scenario`, { method: 'POST', body: JSON.stringify(body) }).then((r) => r.json())
const mem = (body) => fetch(`http://127.0.0.1:${KP}/__mock/memory`, { method: 'POST', body: JSON.stringify(body) }).then((r) => r.json())

mkdirSync(OUT, { recursive: true })
const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] })

async function open(route, { daemon = `http://127.0.0.1:${KP}`, wacli = `http://127.0.0.1:${WP}`, operator = OPERATOR, settle = 1800, w = W, h = H } = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1, colorScheme: THEME === 'light' ? 'light' : 'dark' })
  await ctx.addInitScript((t) => { try { localStorage.setItem('km.theme', t); localStorage.removeItem('km.daemon'); localStorage.removeItem('km.wacli') } catch {} }, THEME)
  await ctx.route('**/webSetup.ts*', async (r) => {
    const res = await r.fetch()
    let body = await res.text()
    if (operator) body = body.replace('hasApiKey: !startIncomplete,', `hasApiKey: !startIncomplete, operatorNumber: '${operator}', waMode: 'dedicated',`)
    await r.fulfill({ response: res, body })
  })
  const page = await ctx.newPage()
  const errors = []
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
  page.on('console', (m) => m.type() === 'error' && !/Failed to load resource|ERR_CONNECTION_REFUSED|net::/.test(m.text()) && errors.push(`console.error: ${m.text()}`))
  await page.goto(`${BASE}/?daemon=${encodeURIComponent(daemon)}&wacli=${encodeURIComponent(wacli)}#${route}`, { waitUntil: 'networkidle' }).catch(() => {})
  await page.waitForTimeout(settle)
  return { ctx, page, errors }
}
const shot = async (page, name, opts = {}) => { await page.screenshot({ path: `${OUT}/${name}-${suffix}.png`, ...opts }); console.log('saved', `${OUT}/${name}-${suffix}.png`) }

const S = {
  // ── WhatsApp ────────────────────────────────────────────────────────
  async 'wa-main'() {
    await wa({ reset: true })
    const { ctx, page, errors } = await open('/whatsapp')
    await shot(page, 'wa-main')
    await shot(page, 'wa-full', { fullPage: false })
    await page.evaluate(() => document.querySelector('main .scroll-thin')?.scrollTo(0, 99999))
    await page.waitForTimeout(500)
    await shot(page, 'wa-main-scrolled')
    await ctx.close(); return errors
  },
  async 'wa-confirms'() {
    await wa({ reset: true, dnd: false })
    const { ctx, page, errors } = await open('/whatsapp')
    await shot(page, 'wa-disarmed')
    await page.getByRole('switch', { name: /Automation/ }).click()
    await page.waitForTimeout(500)
    await shot(page, 'wa-confirm-arm')
    await page.keyboard.press('Escape')
    await page.waitForTimeout(300)
    // unlock a group -> confirm
    await page.getByRole('switch', { name: /Unlock LYZN AI/ }).scrollIntoViewIfNeeded()
    await page.getByRole('switch', { name: /Unlock LYZN AI/ }).click()
    await page.waitForTimeout(500)
    await shot(page, 'wa-confirm-unlock-group')
    await page.keyboard.press('Escape')
    await page.waitForTimeout(300)
    await wa({ dnd: true }); await page.waitForTimeout(4500)
    await page.evaluate(() => document.querySelector('main .scroll-thin')?.scrollTo(0, 0))
    await page.getByRole('button', { name: 'Send test update' }).click()
    await page.waitForTimeout(500)
    await shot(page, 'wa-confirm-send')
    await page.getByRole('button', { name: 'Send message' }).click()
    await page.waitForTimeout(1500)
    await shot(page, 'wa-sent')
    await ctx.close(); await wa({ reset: true }); return errors
  },
  async 'wa-arm-flow'() {
    await wa({ reset: true, dnd: false })
    const { ctx, page, errors } = await open('/whatsapp')
    await page.getByRole('switch', { name: /Automation/ }).click()
    await page.getByRole('button', { name: 'Arm automation' }).click()
    await page.waitForTimeout(700)
    await shot(page, 'wa-armed-toast')
    await ctx.close(); await wa({ reset: true }); return errors
  },
  async 'wa-filters'() {
    await wa({ reset: true })
    const { ctx, page, errors } = await open('/whatsapp')
    await page.getByRole('button', { name: /^Groups/ }).click()
    await page.waitForTimeout(400)
    await page.getByRole('switch', { name: /Unlock LYZN AI/ }).scrollIntoViewIfNeeded()
    await shot(page, 'wa-filter-groups')
    await page.getByPlaceholder('Search chats').fill('zzzz')
    await page.waitForTimeout(400)
    await shot(page, 'wa-filter-empty')
    await ctx.close(); return errors
  },
  async 'wa-rollback'() {
    await wa({ reset: true, failLock: true })
    const { ctx, page, errors } = await open('/whatsapp')
    await page.getByRole('switch', { name: /Unlock Mom/ }).scrollIntoViewIfNeeded()
    await page.getByRole('switch', { name: /Unlock Mom/ }).click()
    await page.getByRole('button', { name: 'Unlock chat' }).click()
    await page.waitForTimeout(150)
    await shot(page, 'wa-optimistic')
    await page.waitForTimeout(1200)
    await shot(page, 'wa-rollback')
    await ctx.close(); await wa({ reset: true }); return errors
  },
  async 'wa-verdicts'() {
    const errors = []
    for (const [name, sc] of [
      ['wide', { webhook: 'wide' }],
      ['missing', { webhook: 'missing' }],
      ['all-unlocked', { webhook: 'all_unlocked' }],
      ['operator-absent', { operator: 'absent' }],
      ['operator-locked', { operator: 'locked' }]
    ]) {
      await wa({ reset: true, ...sc })
      const { ctx, page, errors: e } = await open('/whatsapp')
      await shot(page, `wa-verdict-${name}`, { clip: { x: 0, y: 0, width: W, height: Math.min(H, 900) } })
      errors.push(...e)
      await ctx.close()
    }
    await wa({ reset: true }); return errors
  },
  async 'wa-no-operator'() {
    await wa({ reset: true })
    const { ctx, page, errors } = await open('/whatsapp', { operator: '' })
    await shot(page, 'wa-no-operator')
    await ctx.close(); return errors
  },
  async 'wa-disconnected'() {
    await wa({ reset: true, connected: false, dnd: false })
    const { ctx, page, errors } = await open('/whatsapp')
    await shot(page, 'wa-disconnected')
    await ctx.close(); await wa({ reset: true }); return errors
  },
  async 'wa-wacli-down'() {
    const { ctx, page, errors } = await open('/whatsapp', { wacli: 'http://127.0.0.1:1' })
    await shot(page, 'wa-wacli-down')
    await ctx.close(); return errors
  },
  async 'wa-daemon-down'() {
    await wa({ reset: true })
    const { ctx, page, errors } = await open('/whatsapp', { daemon: 'http://127.0.0.1:1' })
    await shot(page, 'wa-daemon-down')
    await ctx.close(); return errors
  },
  async 'wa-both-down'() {
    const { ctx, page, errors } = await open('/whatsapp', { daemon: 'http://127.0.0.1:1', wacli: 'http://127.0.0.1:1' })
    await shot(page, 'wa-both-down')
    await ctx.close(); return errors
  }
}


const SECTIONS = ['connection', 'processes', 'appearance', 'startup', 'setup', 'models', 'notifications', 'about']
Object.assign(S, {
  async 'st-sections'() {
    const errors = []
    for (const sec of SECTIONS) {
      const { ctx, page, errors: e } = await open(`/settings?section=${sec}`, { settle: 1400 })
      await shot(page, `st-${sec}`)
      errors.push(...e); await ctx.close()
    }
    return errors
  },
  async 'st-confirms'() {
    const { ctx, page, errors } = await open('/settings?section=processes')
    await page.getByRole('button', { name: 'Stop' }).nth(1).click()
    await page.waitForTimeout(500)
    await shot(page, 'st-confirm-stop-wacli')
    await page.keyboard.press('Escape')
    await page.waitForTimeout(300)
    await page.getByRole('button', { name: 'Restart' }).first().click()
    await page.waitForTimeout(500)
    await shot(page, 'st-confirm-restart-karmax')
    await page.getByRole('button', { name: 'Restart', exact: true }).last().click()
    await page.waitForTimeout(900)
    await shot(page, 'st-restarting')
    await page.goto(`${BASE}/?daemon=${encodeURIComponent(`http://127.0.0.1:${KP}`)}&wacli=${encodeURIComponent(`http://127.0.0.1:${WP}`)}#/settings?section=setup`)
    await page.waitForTimeout(1200)
    await page.getByRole('button', { name: 'Run setup again' }).click()
    await page.waitForTimeout(500)
    await shot(page, 'st-confirm-setup')
    await ctx.close(); return errors
  },
  async 'st-conn-test'() {
    const { ctx, page, errors } = await open('/settings?section=connection')
    await page.getByRole('button', { name: 'Test connection' }).click()
    await page.waitForTimeout(1500)
    await shot(page, 'st-conn-tested')
    await ctx.close(); return errors
  },
  async 'st-down'() {
    const errors = []
    for (const sec of ['connection', 'processes', 'notifications', 'models', 'startup']) {
      const { ctx, page, errors: e } = await open(`/settings?section=${sec}`, { daemon: 'http://127.0.0.1:1', wacli: 'http://127.0.0.1:1', settle: 1800 })
      if (sec === 'connection') { await page.getByRole('button', { name: 'Test connection' }).click(); await page.waitForTimeout(1500) }
      await shot(page, `st-down-${sec}`)
      errors.push(...e); await ctx.close()
    }
    return errors
  },
  async 'st-notif-flow'() {
    const { ctx, page, errors } = await open('/settings?section=notifications')
    await page.getByRole('button', { name: 'Mark read' }).first().click()
    await page.waitForTimeout(500)
    await shot(page, 'st-notif-read')
    await ctx.close(); return errors
  },
  // ── Memory ──────────────────────────────────────────────────────────
  async 'mem-main'() {
    await mem({ reset: true })
    const { ctx, page, errors } = await open('/memory')
    await shot(page, 'mem-entries')
    await page.getByPlaceholder(/Search memory/i).fill('billing')
    await page.waitForTimeout(900)
    await shot(page, 'mem-search')
    await page.getByPlaceholder(/Search memory/i).fill('')
    await page.getByRole('tab', { name: /Tree/ }).click()
    await page.waitForTimeout(800)
    await shot(page, 'mem-tree')
    await page.getByRole('tab', { name: /Cleanup/ }).click()
    await page.waitForTimeout(500)
    await shot(page, 'mem-cleanup-idle')
    await page.getByRole('button', { name: /Start cleanup/i }).click()
    await page.waitForTimeout(2000)
    await shot(page, 'mem-cleanup-question')
    await ctx.close(); return errors
  },
  async 'mem-delete'() {
    await mem({ reset: true })
    const { ctx, page, errors } = await open('/memory')
    await page.getByRole('button', { name: /Forget/ }).first().click()
    await page.waitForTimeout(500)
    await shot(page, 'mem-confirm-delete')
    await ctx.close(); return errors
  },
  async 'mem-states'() {
    const errors = []
    await mem({ empty: true })
    let r = await open('/memory'); await shot(r.page, 'mem-empty'); errors.push(...r.errors); await r.ctx.close()
    await mem({ reset: true, slow: 2500 })
    r = await open('/memory', { settle: 500 }); await shot(r.page, 'mem-loading'); errors.push(...r.errors); await r.ctx.close()
    await mem({ reset: true })
    r = await open('/memory', { daemon: 'http://127.0.0.1:1' }); await shot(r.page, 'mem-daemon-down'); errors.push(...r.errors); await r.ctx.close()
    return errors
  }
})

const want = process.argv.slice(2)
const names = want.length ? want : Object.keys(S)
const all = []
for (const n of names) {
  if (!S[n]) { console.log('unknown scenario', n); continue }
  console.log('==', n)
  try { all.push(...(await S[n]())) } catch (e) { console.log('SCENARIO FAILED', n, e.message.split('\n')[0]) }
}
await browser.close()
if (all.length) { console.log('\nBROWSER ERRORS:'); for (const e of [...new Set(all)]) console.log(' -', e) }
