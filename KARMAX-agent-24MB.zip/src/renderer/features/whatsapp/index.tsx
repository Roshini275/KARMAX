import { useCallback, useState, type ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { MotionConfig, motion } from 'framer-motion'
import { CloudOff, PlugZap, RefreshCw, ServerOff } from 'lucide-react'
import { Button, Card, ErrorNote, IconButton, Page } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { cn } from '@/design/cn'
import { fadeUp, stagger } from '@/design/motion'
import { useConnection, useSetupState } from '@/lib/api/hooks'
import { isUnreachable } from './http'
import { digitsOnly, evaluateOperator, findOperatorChat, type OperatorVerdict } from './logic'
import { useSendTest, useSetChatLocked, useSetDnd, useWaChats, useWaLogs, useWaMessages, useWaStatus, useWaWebhooks } from './hooks'
import { AutomationCard } from './components/AutomationCard'
import { ChatTable } from './components/ChatTable'
import { ConnectionCard } from './components/ConnectionCard'
import { Conversation } from './components/Conversation'
import { LogTail } from './components/LogTail'
import { OperatorCard, type SendGate } from './components/OperatorCard'
import { RiskNote } from './components/RiskNote'
import { useToasts } from './ui/Toast'
import type { WaChat } from './schemas'
import { warnText } from './ui/tone'

const Item = ({ children, className }: { children: ReactNode; className?: string }) => (
  <motion.div variants={fadeUp} className={cn('min-w-0', className)}>
    {children}
  </motion.div>
)

const errText = (e: unknown) => (e instanceof Error ? e.message : String(e))

function Banner({ tone, icon, title, children, action }: { tone: 'crit' | 'warn'; icon: ReactNode; title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <div
      role="status"
      className="flex items-start gap-3 rounded-xl px-4 py-3 ring-1"
      style={{ background: `color-mix(in oklab, var(--${tone === 'crit' ? 'crit-mark' : 'warn'}) 9%, transparent)`, ['--tw-ring-color' as string]: `color-mix(in oklab, var(--${tone === 'crit' ? 'crit-mark' : 'warn'}) 35%, transparent)` }}
    >
      <span className={cn('mt-0.5 shrink-0', tone === 'crit' ? 'text-crit' : warnText)}>{icon}</span>
      <div className="min-w-0 flex-1 text-[12.5px] leading-relaxed text-ink-2">
        <span className={cn('font-semibold', tone === 'crit' ? 'text-crit' : warnText)}>{title}</span> {children}
      </div>
      {action}
    </div>
  )
}

export default function WhatsAppPage() {
  const nav = useNavigate()
  const qc = useQueryClient()
  const conn = useConnection()
  const setup = useSetupState()
  const status = useWaStatus()
  const chatsQ = useWaChats()
  const hooksQ = useWaWebhooks()
  const logsQ = useWaLogs()
  const { push, node: toasts } = useToasts()

  const opDigits = setup?.operatorNumber ? digitsOnly(setup.operatorNumber) : undefined
  const chats = chatsQ.data ?? []
  const operatorChat = findOperatorChat(chats, opDigits)
  const messagesQ = useWaMessages(operatorChat?.jid)

  const dnd = useSetDnd()
  const lock = useSetChatLocked()
  const send = useSendTest(operatorChat?.jid)
  const [pendingJids, setPendingJids] = useState<Set<string>>(new Set())

  const refresh = useCallback(() => {
    void qc.invalidateQueries({ queryKey: ['wa'] })
  }, [qc])

  const armed = !!status.data?.dnd_mode
  const wacliDown = status.isError && isUnreachable(status.error)

  const setLocked = (chat: WaChat, locked: boolean) => {
    setPendingJids((s) => new Set(s).add(chat.jid))
    lock.mutate(
      { jid: chat.jid, locked },
      {
        onSuccess: () => push('ok', locked ? `Locked ${chat.name || 'chat'}. Automation can no longer touch it.` : `Unlocked ${chat.name || 'chat'}.`),
        onError: (e) => push('error', `Could not ${locked ? 'lock' : 'unlock'} ${chat.name || 'the chat'}: ${errText(e)}. Reverted.`),
        onSettled: () =>
          setPendingJids((s) => {
            const n = new Set(s)
            n.delete(chat.jid)
            return n
          })
      }
    )
  }

  const setArmed = (enabled: boolean) =>
    dnd.mutate(enabled, {
      onSuccess: () => push('ok', enabled ? 'Automation armed. KARMAX may now message unlocked chats.' : 'Automation disarmed. Everything is blocked.'),
      onError: (e) => push('error', `Could not ${enabled ? 'arm' : 'disarm'} automation: ${errText(e)}. Reverted.`)
    })

  const webhooksUnknown = hooksQ.isError
  const verdict: OperatorVerdict = webhooksUnknown
    ? { tone: 'muted', label: 'Unknown', summary: `Could not read wacli's webhooks (${errText(hooksQ.error)}), so the channel cannot be verified.`, checks: [], extraChats: [], inertChats: [], mentionLeak: false }
    : evaluateOperator({ operatorDigits: opDigits, chats, webhooks: hooksQ.data ?? [], dnd: armed })

  const sendGate: SendGate = !opDigits
    ? { ok: false, reason: 'Set an operator number in Setup first.' }
    : conn && !conn.reachable
      ? { ok: false, reason: 'KARMAX is offline: it sends the message.' }
      : !status.data?.connected
        ? { ok: false, reason: 'WhatsApp is disconnected.' }
        : !armed
          ? { ok: false, reason: 'Arm automation first: sends are blocked while it is off.' }
          : operatorChat?.locked
            ? { ok: false, reason: 'The operator chat is locked. Unlock it first.' }
            : { ok: true }

  const onSend = (text: string) =>
    send.mutate(
      { target: operatorChat?.jid ?? (opDigits as string), content: text },
      {
        onSuccess: () => push('ok', 'Test update sent. It should appear in the conversation below.'),
        onError: (e) => push('error', `Test update not sent: ${errText(e)}`)
      }
    )

  const header = (
    <IconButton label="Refresh now" onClick={refresh}>
      <RefreshCw className={cn('size-4', (status.isFetching || chatsQ.isFetching) && 'animate-[km-spin_0.8s_linear_infinite]')} />
    </IconButton>
  )

  /* wacli not answering: a first-class state, not an error toast. */
  if (wacliDown) {
    return (
      <MotionConfig reducedMotion="user">
        <Page title="WhatsApp" subtitle="Operator channel: send KARMAX tasks from your phone, get updates back" actions={header}>
          <div className="mx-auto flex max-w-[860px] flex-col gap-4">
            <Card className="px-8 py-12 text-center">
              <div className="mx-auto mb-5 grid size-14 place-items-center rounded-2xl bg-[color-mix(in_oklab,var(--crit-mark)_14%,transparent)] text-crit ring-1 ring-[color-mix(in_oklab,var(--crit-mark)_35%,transparent)]">
                <PlugZap className="size-6" />
              </div>
              <StatusPill tone="crit" label="wacli not reachable" />
              <h2 className="mt-3 font-[family-name:var(--font-display)] text-[20px] font-semibold tracking-tight">The WhatsApp service is not answering</h2>
              <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-ink-2">
                KARMAX Desktop could not reach wacli{conn ? <> at <span className="selectable font-[family-name:var(--font-mono)] text-[12px] text-ink">{conn.wacliUrl}</span></> : ''}. Until it is running, tasks sent from your operator number cannot arrive and KARMAX cannot send you updates.
              </p>
              <div className="mt-6 flex justify-center gap-2">
                <Button variant="primary" onClick={() => nav('/settings?section=processes')}>
                  Open Settings, Processes
                </Button>
                <Button onClick={() => void status.refetch()} loading={status.isFetching} icon={<RefreshCw className="size-3.5" />}>
                  Retry
                </Button>
              </div>
            </Card>
            <RiskNote />
          </div>
        </Page>
        {toasts}
      </MotionConfig>
    )
  }

  const loadingTop = status.isLoading

  return (
    <MotionConfig reducedMotion="user">
      <Page title="WhatsApp" subtitle="Operator channel: send KARMAX tasks from your phone, get updates back" actions={header}>
        <motion.div className="@container/page mx-auto flex max-w-[1280px] flex-col gap-4" variants={stagger(0.05)} initial="hidden" animate="show">
          {status.isError && !wacliDown && <ErrorNote error={status.error} onRetry={() => void status.refetch()} />}
          {conn && !conn.reachable && (
            <Item>
              <Banner
                tone="warn"
                icon={<ServerOff className="size-4" />}
                title="KARMAX is offline."
                action={
                  <Button size="sm" variant="subtle" onClick={() => nav('/settings?section=processes')}>
                    Processes
                  </Button>
                }
              >
                WhatsApp messages are still stored by wacli, but nothing is processing them and test updates cannot be sent.
              </Banner>
            </Item>
          )}
          {status.data && !status.data.connected && (
            <Item>
              <Banner tone="crit" icon={<CloudOff className="size-4" />} title="WhatsApp is disconnected.">
                The channel is down until the session reconnects. Details are in the Connection card.
              </Banner>
            </Item>
          )}

          <Item>
            <RiskNote />
          </Item>

          <div className="grid gap-4 @3xl/page:grid-cols-12">
            <Item className="@3xl/page:col-span-7">
              <AutomationCard armed={armed} loading={loadingTop} pending={dnd.isPending} chats={chats} operatorChat={operatorChat} onSet={setArmed} />
            </Item>
            <Item className="@3xl/page:col-span-5">
              <ConnectionCard status={status.data} loading={loadingTop} wacliUrl={conn?.wacliUrl} />
            </Item>
            <Item className="@3xl/page:col-span-5">
              <OperatorCard
                loading={!setup || chatsQ.isLoading || hooksQ.isLoading}
                operatorNumber={setup?.operatorNumber}
                operatorChat={operatorChat}
                verdict={verdict}
                sendGate={sendGate}
                sending={send.isPending}
                onSend={onSend}
                onUnlockOperator={() => operatorChat && setLocked(operatorChat, false)}
              />
            </Item>
            <Item className="@3xl/page:col-span-7">
              <Conversation
                messages={messagesQ.data}
                loading={messagesQ.isLoading}
                error={messagesQ.error}
                onRetry={() => void messagesQ.refetch()}
                notSeen={!!opDigits && !operatorChat && !chatsQ.isLoading}
                noOperator={!!setup && !opDigits}
              />
            </Item>
          </div>

          <Item>
            <ChatTable
              chats={chats}
              loading={chatsQ.isLoading}
              error={chatsQ.error}
              onRetry={() => void chatsQ.refetch()}
              operatorJid={operatorChat?.jid}
              pendingJids={pendingJids}
              totalCount={status.data?.chat_count}
              onSetLocked={setLocked}
            />
          </Item>

          <Item>
            <LogTail logs={logsQ.data} loading={logsQ.isLoading} error={logsQ.error} onRetry={() => void logsQ.refetch()} />
          </Item>
        </motion.div>
      </Page>
      {toasts}
    </MotionConfig>
  )
}
