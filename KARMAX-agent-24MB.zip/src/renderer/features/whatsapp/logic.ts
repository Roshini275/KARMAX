/**
 * Pure logic for the operator channel: number masking, chat matching and the webhook health verdict.
 *
 * Facts this rests on (verified in wacli/wa/*.go):
 *  - webhooks fire only while DND is ON (service.dispatchWebhook),
 *  - a LOCKED chat never fires a message webhook (webhookMatchesPayload), whatever the scope,
 *  - scope `selected_chats` fires for chat_jids only, `all_unlocked` for every unlocked chat, present and future,
 *  - `include_mentions` additionally delivers @-mentions of this account from any UNLOCKED chat outside the scope,
 *  - chats discovered after first-run access configuration are created UNLOCKED (docs/cli-reference.md).
 * KARMAX matches its webhook by `URL contains "/comms/whatsapp"` (internal/tools/builtin/whatsapp_integration.go); so do we.
 */
import type { Tone } from '@/design/status'
import type { WaChat, WaWebhook } from './schemas'

/** Same normalisation as KARMAX's NormalizeChatID: lower-case, cut at the first '@' or ':'. */
export function normalizeChatId(s: string): string {
  const t = s.toLowerCase().trim()
  const i = t.search(/[@:]/)
  return i >= 0 ? t.slice(0, i) : t
}

export const digitsOnly = (s: string) => s.replace(/\D/g, '')

/** "+91 ••••• ••210". Keeps the country-code guess (first 2 digits) and the last 3; short numbers are masked harder. */
export function maskPhone(digits: string): string {
  const d = digitsOnly(digits)
  if (!d) return '—'
  if (d.length <= 6) return `+${'•'.repeat(Math.max(d.length - 2, 2))}${d.slice(-2)}`
  return `+${d.slice(0, 2)} ${'•'.repeat(5)} ${'•'.repeat(Math.max(d.length - 10, 2))}${d.slice(-3)}`
}

export function maskJid(jid: string | undefined): string {
  if (!jid) return '—'
  const [user, server] = jid.split('@')
  const id = user.split(':')[0]
  if (server?.startsWith('g.us')) return `group ${'•'.repeat(4)}${id.slice(-4)}`
  return `${maskPhone(id)}${server && server !== 's.whatsapp.net' ? `@${server}` : ''}`
}

export const revealPhone = (digits: string) => `+${digitsOnly(digits)}`

export function findOperatorChat(chats: WaChat[], operatorDigits: string | undefined): WaChat | undefined {
  if (!operatorDigits) return undefined
  const want = digitsOnly(operatorDigits)
  return chats.find((c) => !c.is_group && normalizeChatId(c.jid) === want)
}

/** wacli serialises "no messages yet" as the Unix epoch. */
export function validTime(iso: string | undefined | null): string | undefined {
  if (!iso) return undefined
  const t = Date.parse(iso)
  return Number.isFinite(t) && t > Date.UTC(2001, 0, 1) ? iso : undefined
}

/* ── operator health verdict ──────────────────────────────────────────── */

export const KARMAX_HOOK_PATH = '/comms/whatsapp'

export type CheckState = 'pass' | 'fail' | 'warn' | 'todo'
export interface Check {
  id: string
  state: CheckState
  label: string
  detail?: string
}

export interface OperatorVerdict {
  tone: Tone
  label: string
  summary: string
  checks: Check[]
  /** Other chats KARMAX would receive messages from (unlocked and covered by an enabled KARMAX webhook). */
  extraChats: string[]
  /** Chats named in the webhook that are locked (so currently inert, but one click from live). */
  inertChats: string[]
  mentionLeak: boolean
}

interface VerdictInput {
  operatorDigits?: string
  chats: WaChat[]
  webhooks: WaWebhook[]
  dnd: boolean
}

export function evaluateOperator({ operatorDigits, chats, webhooks, dnd }: VerdictInput): OperatorVerdict {
  const checks: Check[] = []
  const nameOf = (jid: string) => chats.find((c) => c.jid === jid)?.name || maskJid(jid)
  const hooks = webhooks.filter((w) => w.url.includes(KARMAX_HOOK_PATH))
  const live = hooks.filter((w) => w.enabled)

  if (!operatorDigits) {
    return {
      tone: 'muted',
      label: 'No operator number',
      summary: 'Setup has no operator number yet, so there is nothing to verify.',
      checks: [{ id: 'number', state: 'todo', label: 'Operator number not set', detail: 'Add it in Setup.' }],
      extraChats: [],
      inertChats: [],
      mentionLeak: false
    }
  }
  checks.push({ id: 'number', state: 'pass', label: 'Operator number configured' })

  const op = findOperatorChat(chats, operatorDigits)
  const opNorm = digitsOnly(operatorDigits)
  const isOp = (jid: string) => normalizeChatId(jid) === opNorm

  checks.push(
    op
      ? { id: 'seen', state: 'pass', label: 'Operator chat seen', detail: op.name || undefined }
      : { id: 'seen', state: 'todo', label: 'Operator chat not seen yet', detail: 'Send "hi" from the operator number to the KARMAX WhatsApp number.' }
  )
  if (op) {
    checks.push(
      op.locked
        ? { id: 'unlocked', state: 'fail', label: 'Operator chat is locked', detail: 'wacli ignores locked chats, so your messages never reach KARMAX. Unlock it below.' }
        : { id: 'unlocked', state: 'pass', label: 'Operator chat unlocked' }
    )
  }

  // Which chats can the KARMAX webhook(s) actually fire for right now?
  const covered = new Map<string, { locked: boolean; known: boolean }>()
  let mentionLeak = false
  for (const w of live) {
    if (w.scope === 'all_unlocked') {
      for (const c of chats) covered.set(c.jid, { locked: c.locked, known: true })
    } else {
      for (const jid of w.chat_jids) {
        const c = chats.find((x) => x.jid === jid)
        covered.set(jid, { locked: c?.locked ?? false, known: !!c })
      }
    }
    if (w.include_mentions) mentionLeak = true
  }
  const coversOperator = [...covered.keys()].some(isOp)
  const others = [...covered.entries()].filter(([jid]) => !isOp(jid))
  const extraChats = others.filter(([, v]) => !v.locked).map(([jid]) => nameOf(jid))
  const inertChats = others.filter(([, v]) => v.locked).map(([jid]) => nameOf(jid))

  if (hooks.length === 0) {
    checks.push({ id: 'hook', state: 'fail', label: 'No KARMAX webhook', detail: `wacli has no webhook to ${KARMAX_HOOK_PATH}, so incoming messages never reach KARMAX. Re-run setup to register it.` })
  } else if (live.length === 0) {
    checks.push({ id: 'hook', state: 'fail', label: 'KARMAX webhook is disabled', detail: 'The webhook exists but is switched off in wacli.' })
  } else {
    checks.push({ id: 'hook', state: 'pass', label: 'KARMAX webhook enabled', detail: live.map((w) => w.scope.replace('_', ' ')).join(', ') })
    checks.push(
      coversOperator
        ? { id: 'covers', state: 'pass', label: 'Covers the operator chat' }
        : { id: 'covers', state: 'fail', label: 'Does not cover the operator chat', detail: 'The webhook is scoped to other chats only.' }
    )
    checks.push(
      extraChats.length === 0 && !mentionLeak
        ? { id: 'only', state: 'pass', label: 'Only the operator chat', detail: inertChats.length ? `${inertChats.length} other chat${inertChats.length > 1 ? 's' : ''} listed but locked (inactive).` : undefined }
        : {
            id: 'only',
            state: 'warn',
            label: extraChats.length ? `Also covers ${extraChats.length} other chat${extraChats.length > 1 ? 's' : ''}` : 'Delivers @-mentions from other chats',
            detail: extraChats.length
              ? `${extraChats.slice(0, 3).join(', ')}${extraChats.length > 3 ? ` and ${extraChats.length - 3} more` : ''} can send tasks to KARMAX.`
              : 'The webhook has include_mentions on: anyone in an unlocked chat who @-mentions this account reaches KARMAX.'
          }
    )
  }
  checks.push(dnd ? { id: 'armed', state: 'pass', label: 'Automation armed' } : { id: 'armed', state: 'warn', label: 'Automation disarmed', detail: 'DND is off: webhooks and sends are blocked.' })

  const failing = checks.find((c) => c.state === 'fail')
  const warning = checks.find((c) => c.state === 'warn' && c.id === 'only')
  if (failing) {
    return { tone: 'serious', label: 'Not receiving tasks', summary: failing.detail ?? failing.label, checks, extraChats, inertChats, mentionLeak }
  }
  if (!op) return { tone: 'muted', label: 'Waiting for first message', summary: 'Send "hi" from the operator number to the KARMAX WhatsApp number.', checks, extraChats, inertChats, mentionLeak }
  if (warning) return { tone: 'warn', label: 'Wider than operator', summary: warning.detail ?? warning.label, checks, extraChats, inertChats, mentionLeak }
  if (!dnd) return { tone: 'muted', label: 'Disarmed', summary: 'Configuration looks right, but automation is switched off.', checks, extraChats, inertChats, mentionLeak }
  return { tone: 'good', label: 'Healthy', summary: 'Your messages reach KARMAX, and nobody else\'s do.', checks, extraChats, inertChats, mentionLeak }
}

/** Unique per send: KARMAX refuses an identical message to the same target within 6 hours. */
export function testMessage(now = new Date()): string {
  const t = now.toTimeString().slice(0, 8)
  return `KARMAX Desktop test update (${t}). If you can read this, the WhatsApp channel works. No reply needed.`
}
