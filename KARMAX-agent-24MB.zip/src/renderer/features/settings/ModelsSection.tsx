import { Brain, Gauge, Sparkles } from 'lucide-react'
import { Badge, ErrorNote, Skeleton } from '@/design/primitives'
import { useChatOptions } from '@/lib/api/hooks'
import { KV, Panel } from '@/features/whatsapp/ui/Bits'
import { SectionHead } from './parts'

export function ModelsSection() {
  const q = useChatOptions()
  const o = q.data
  const def = o?.models.find((m) => m.id === o.defaultModel)
  return (
    <div>
      <SectionHead title="Models" description="What the daemon offers for conversation. This is read-only: the daemon's own configuration decides the brain and the available models." />
      {q.isError ? (
        <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
      ) : !o ? (
        <Skeleton className="h-56 w-full" />
      ) : (
        <div className="space-y-4">
          <Panel icon={<Brain className="size-3.5" />} title="Brain">
            <dl className="divide-y divide-line">
              <KV k="Brain">
                <Badge className="capitalize">{o.brain}</Badge>
              </KV>
              <KV k="Default model">{def ? `${def.label} (${def.id})` : o.defaultModel || 'Provider default'}</KV>
              <KV k="Default effort">{o.defaultEffort || 'Provider default'}</KV>
            </dl>
          </Panel>
          <Panel icon={<Sparkles className="size-3.5" />} title="Available models" hint={`${o.models.length} offered`}>
            {o.models.length === 0 ? (
              <p className="text-[12.5px] text-ink-3">The daemon did not list any models, so the brain's own default applies.</p>
            ) : (
              <ul className="divide-y divide-line" aria-label="Available models">
                {o.models.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-4 py-2.5">
                    <span className="text-[13px] font-medium text-ink">{m.label}</span>
                    <span className="flex items-center gap-2.5">
                      {m.id === o.defaultModel && <Badge className="bg-accent-soft text-accent">Default</Badge>}
                      <code className="selectable font-[family-name:var(--font-mono)] text-[11.5px] text-ink-3">{m.id}</code>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
          {o.efforts.length > 0 && (
            <Panel icon={<Gauge className="size-3.5" />} title="Effort levels">
              <ul className="flex flex-wrap gap-2" aria-label="Effort levels">
                {o.efforts.map((e) => (
                  <li key={e}>
                    <Badge className={e === o.defaultEffort ? 'bg-accent-soft text-accent' : ''}>{e}</Badge>
                  </li>
                ))}
              </ul>
            </Panel>
          )}
        </div>
      )}
    </div>
  )
}
