import { useEffect, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Check, CircleAlert, Eye, EyeOff, KeyRound, Lock, PlugZap, Save, Server, Smartphone } from 'lucide-react'
import { Button, Input, Skeleton } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { api } from '@/lib/api/client'
import { useConnection } from '@/lib/api/hooks'
import { getBridge } from '@/lib/bridge'
import { KV, Panel } from '@/features/whatsapp/ui/Bits'
import { wa } from '@/features/whatsapp/api'
import { SectionHead } from './parts'

interface Probe {
  id: string
  label: string
  ok: boolean
  detail: string
  ms?: number
}

async function timed<T>(fn: () => Promise<T>): Promise<{ ok: true; v: T; ms: number } | { ok: false; error: string; ms: number }> {
  const t = performance.now()
  try {
    const v = await fn()
    return { ok: true, v, ms: Math.round(performance.now() - t) }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e), ms: Math.round(performance.now() - t) }
  }
}

export function ConnectionSection({ toast }: { toast: (kind: 'ok' | 'error', text: string) => void }) {
  const qc = useQueryClient()
  const conn = useConnection()
  const bridge = getBridge()
  const editable = conn?.mode === 'web' && !!bridge.connection.configure

  const [karmaxUrl, setKarmaxUrl] = useState('')
  const [wacliUrl, setWacliUrl] = useState('')
  const [token, setToken] = useState('')
  const [showToken, setShowToken] = useState(false)
  const [seeded, setSeeded] = useState(false)
  const [saving, setSaving] = useState(false)
  const [probes, setProbes] = useState<Probe[] | null>(null)
  const [testing, setTesting] = useState(false)

  // Seed the form once from the live connection; after that the user's edits win.
  useEffect(() => {
    if (conn && !seeded) {
      setKarmaxUrl(conn.karmaxUrl)
      setWacliUrl(conn.wacliUrl)
      setSeeded(true)
    }
  }, [conn, seeded])

  const test = async () => {
    setTesting(true)
    const out: Probe[] = []
    const k = await timed(() => api.ping())
    out.push(
      k.ok
        ? { id: 'karmax', label: 'KARMAX daemon', ok: k.v.service === 'karmax', detail: k.v.service === 'karmax' ? `v${(k.v.version ?? '?').replace(/^v/, '')}${k.v.agent ? ` · agent ${k.v.agent}` : ''}` : `Answered, but as “${k.v.service}”, not karmax`, ms: k.ms }
        : { id: 'karmax', label: 'KARMAX daemon', ok: false, detail: k.error, ms: k.ms }
    )
    // /api/ping is public, so also hit something that needs the bearer token. ping.auth says whether the daemon requires one.
    if (!k.ok) {
      out.push({ id: 'auth', label: 'API token', ok: false, detail: 'Skipped: the daemon did not answer' })
    } else {
      const a = await timed(() => api.chat.options())
      const required = k.v.auth !== false
      out.push(a.ok ? { id: 'auth', label: 'API token', ok: true, detail: required ? 'Accepted by the daemon' : 'Not required: the daemon runs without auth', ms: a.ms } : { id: 'auth', label: 'API token', ok: false, detail: a.error, ms: a.ms })
    }
    const w = await timed(() => wa.status())
    out.push(
      w.ok
        ? { id: 'wacli', label: 'wacli', ok: true, detail: w.v.connected ? 'Reachable, WhatsApp connected' : 'Reachable, but WhatsApp is not connected', ms: w.ms }
        : { id: 'wacli', label: 'wacli', ok: false, detail: w.error, ms: w.ms }
    )
    setProbes(out)
    setTesting(false)
  }

  const save = async () => {
    setSaving(true)
    try {
      await bridge.connection.configure?.({ karmaxUrl: karmaxUrl.trim() || undefined, wacliUrl: wacliUrl.trim() || undefined, ...(token ? { token } : {}) })
      setToken('')
      await qc.invalidateQueries()
      toast('ok', 'Connection saved. Testing it now.')
      await test()
    } catch (e) {
      toast('error', `Could not save: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <SectionHead title="Connection" description="Where KARMAX Desktop finds the KARMAX daemon and the wacli WhatsApp service, and whether they answer." />

      <Panel
        icon={<PlugZap className="size-3.5" />}
        title="Daemon"
        hint={conn?.mode === 'electron' ? 'Managed by the app' : 'Browser preview: editable'}
        right={!conn ? <Skeleton className="h-5 w-24" /> : conn.reachable ? <StatusPill tone="good" label="Reachable" /> : <StatusPill tone="crit" label="Unreachable" />}
      >
        {!conn ? (
          <Skeleton className="h-28 w-full" />
        ) : editable ? (
          <div className="space-y-3.5">
            <label className="block">
              <span className="mb-1.5 flex items-center gap-1.5 text-[12px] font-medium text-ink-2">
                <Server className="size-3.5 text-ink-3" />
                KARMAX daemon URL
              </span>
              <Input value={karmaxUrl} onChange={(e) => setKarmaxUrl(e.target.value)} placeholder="http://127.0.0.1:9091" spellCheck={false} className="font-[family-name:var(--font-mono)] text-[12.5px]" />
            </label>
            <label className="block">
              <span className="mb-1.5 flex items-center gap-1.5 text-[12px] font-medium text-ink-2">
                <Smartphone className="size-3.5 text-ink-3" />
                wacli URL
              </span>
              <Input value={wacliUrl} onChange={(e) => setWacliUrl(e.target.value)} placeholder="http://127.0.0.1:8765" spellCheck={false} className="font-[family-name:var(--font-mono)] text-[12.5px]" />
            </label>
            <label className="block">
              <span className="mb-1.5 flex items-center gap-1.5 text-[12px] font-medium text-ink-2">
                <KeyRound className="size-3.5 text-ink-3" />
                API token
                <span className="ml-1 font-normal text-ink-3">{conn.hasToken ? '(one is stored, leave blank to keep it)' : '(none stored)'}</span>
              </span>
              <div className="relative">
                <Input type={showToken ? 'text' : 'password'} value={token} onChange={(e) => setToken(e.target.value)} placeholder={conn.hasToken ? '••••••••••••' : 'KARMAX_API_TOKEN'} autoComplete="off" spellCheck={false} className="pr-9 font-[family-name:var(--font-mono)] text-[12.5px]" />
                <button type="button" aria-label={showToken ? 'Hide token' : 'Show token'} onClick={() => setShowToken((v) => !v)} className="app-no-drag absolute right-2 top-1/2 grid size-6 -translate-y-1/2 place-items-center rounded text-ink-3 hover:text-ink">
                  {showToken ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
                </button>
              </div>
            </label>
            <div className="flex items-center justify-between gap-3 pt-1">
              <p className="text-[11.5px] leading-snug text-ink-3">Stored in this browser only (localStorage). The desktop app keeps the token in the OS keychain instead.</p>
              <Button variant="primary" icon={<Save className="size-3.5" />} loading={saving} onClick={save}>
                Save
              </Button>
            </div>
          </div>
        ) : (
          <>
            <dl className="divide-y divide-line">
              <KV k="KARMAX daemon URL">
                <span className="font-[family-name:var(--font-mono)] text-[12px]">{conn.karmaxUrl}</span>
              </KV>
              <KV k="wacli URL">
                <span className="font-[family-name:var(--font-mono)] text-[12px]">{conn.wacliUrl}</span>
              </KV>
              <KV k="API token">
                {conn.hasToken ? (
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="size-3.5 text-good" />
                    Stored in the OS keychain
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-ink-3">
                    <CircleAlert className="size-3.5" />
                    None (auth disabled?)
                  </span>
                )}
              </KV>
            </dl>
            <p className="mt-3 text-[11.5px] leading-snug text-ink-3">Read-only here: the desktop app talks to both services from its main process, so this window never holds the token.</p>
          </>
        )}
      </Panel>

      <Panel
        className="mt-4"
        icon={<Check className="size-3.5" />}
        title="Test connection"
        hint="Pings the daemon, checks the token and asks wacli for its status"
        right={
          <Button variant="subtle" loading={testing} onClick={test}>
            Test connection
          </Button>
        }
      >
        {!probes ? (
          <p className="text-[12.5px] text-ink-3">Nothing tested yet.</p>
        ) : (
          <ul className="divide-y divide-line" aria-label="Connection test results">
            {probes.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-4 py-2.5">
                <div className="flex min-w-0 items-center gap-3">
                  {p.ok ? <StatusPill tone="good" label="OK" /> : <StatusPill tone="crit" label="Failed" />}
                  <span className="text-[13px] font-medium text-ink">{p.label}</span>
                </div>
                <div className="flex min-w-0 items-center gap-3 text-[12px] text-ink-3">
                  <span className="selectable min-w-0 truncate" title={p.detail}>
                    {p.detail}
                  </span>
                  {p.ms != null && <span className="tnum shrink-0 font-[family-name:var(--font-mono)] text-[11px]">{p.ms} ms</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  )
}
