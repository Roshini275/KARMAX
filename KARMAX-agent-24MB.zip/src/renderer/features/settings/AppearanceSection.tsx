import { Monitor, Moon, Palette, Sun } from 'lucide-react'
import { Segmented } from '@/design/primitives'
import { resolveTheme, useUi, type ThemePref } from '@/lib/stores'
import { Panel } from '@/features/whatsapp/ui/Bits'
import { Row, SectionHead } from './parts'

const SWATCHES: { name: string; v: string }[] = [
  { name: 'Page', v: 'var(--page)' },
  { name: 'Panel', v: 'var(--panel)' },
  { name: 'Surface', v: 'var(--surface-2)' },
  { name: 'Accent', v: 'var(--accent)' },
  { name: 'Good', v: 'var(--good)' },
  { name: 'Warn', v: 'var(--warn)' },
  { name: 'Serious', v: 'var(--serious)' },
  { name: 'Critical', v: 'var(--crit-mark)' }
]

export function AppearanceSection() {
  const theme = useUi((s) => s.theme)
  const setTheme = useUi((s) => s.setTheme)
  const active = resolveTheme(theme)
  return (
    <div>
      <SectionHead title="Appearance" description="Dark is the default. System follows your Windows setting and switches live." />
      <Panel icon={<Palette className="size-3.5" />} title="Theme">
        <Row label="Colour theme" hint={theme === 'system' ? `Following the system: currently ${active}.` : `Always ${theme}.`}>
          <Segmented<ThemePref>
            value={theme}
            onChange={setTheme}
            options={[
              { value: 'dark', label: (<><Moon className="size-3.5" />Dark</>) },
              { value: 'light', label: (<><Sun className="size-3.5" />Light</>) },
              { value: 'system', label: (<><Monitor className="size-3.5" />System</>) }
            ]}
          />
        </Row>
        <div className="mt-2 border-t border-line pt-4">
          <div className="label-micro mb-2.5">Palette in use ({active})</div>
          <ul className="flex flex-wrap gap-3" aria-label="Palette">
            {SWATCHES.map((s) => (
              <li key={s.name} className="flex items-center gap-2 text-[11.5px] text-ink-3">
                <span className="size-5 rounded-md ring-1 ring-line-strong" style={{ background: s.v }} aria-hidden />
                {s.name}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11.5px] leading-snug text-ink-3">Status colours (good, warn, serious, critical) are reserved for state and always appear with an icon and a label.</p>
        </div>
      </Panel>
    </div>
  )
}
