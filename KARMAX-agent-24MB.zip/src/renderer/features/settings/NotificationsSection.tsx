import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Bell, BellOff, CheckCheck, Circle, Info, ListTodo, ShieldCheck, TriangleAlert } from 'lucide-react'
import { Button, EmptyState, ErrorNote, Skeleton } from '@/design/primitives'
import { cn } from '@/design/cn'
import { api } from '@/lib/api/client'
import type { Notification } from '@/lib/api/schemas'
import { qk } from '@/lib/api/hooks'
import { timeAgo } from '@/lib/format'
import { Panel } from '@/features/whatsapp/ui/Bits'
import { SectionHead } from './parts'

type Data = Awaited<ReturnType<typeof api.notifications.list>>

const kindIcon = (k: string) => {
  const s = k.toLowerCase()
  if (s.includes('task')) return <ListTodo className="size-3.5" />
  if (s.includes('approv') || s.includes('proposal')) return <ShieldCheck className="size-3.5" />
  if (s.includes('warn') || s.includes('alert') || s.includes('error') || s.includes('crit')) return <TriangleAlert className="size-3.5" />
  return <Info className="size-3.5" />
}

function Item({ n, onRead, pending }: { n: Notification; onRead: () => void; pending: boolean }) {
  return (
    <li className={cn('flex items-start gap-3.5 py-3', !n.read && 'relative')}>
      <span className={cn('mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg ring-1', n.read ? 'bg-surface-2 text-ink-3 ring-line' : 'bg-accent-soft text-accent ring-[color-mix(in_oklab,var(--accent)_35%,transparent)]')}>{kindIcon(n.kind)}</span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className={cn('truncate text-[13px]', n.read ? 'font-medium text-ink-2' : 'font-semibold text-ink')}>{n.title || n.kind || 'Notification'}</span>
          {!n.read && (
            <span className="inline-flex items-center gap-1 rounded-full bg-accent-soft px-1.5 py-px text-[10px] font-bold uppercase tracking-wide text-accent">
              <Circle className="size-1.5 fill-current" />
              New
            </span>
          )}
        </div>
        {n.body && <p className="selectable mt-0.5 text-[12.5px] leading-snug text-ink-3">{n.body}</p>}
        <div className="mt-1 text-[11px] text-ink-3">{timeAgo(n.created_at)}</div>
      </div>
      {!n.read && (
        <Button size="sm" variant="ghost" disabled={pending} onClick={onRead}>
          Mark read
        </Button>
      )}
    </li>
  )
}

export function NotificationsSection({ toast }: { toast: (kind: 'ok' | 'error', text: string) => void }) {
  const qc = useQueryClient()
  const q = useQuery({ queryKey: qk.notifications, queryFn: () => api.notifications.list(50), refetchInterval: 15_000, retry: false })

  const patch = (fn: (d: Data) => Data) => {
    const prev = qc.getQueryData<Data>(qk.notifications)
    if (prev) qc.setQueryData<Data>(qk.notifications, fn(prev))
    return prev
  }
  const one = useMutation({
    mutationFn: (id: string) => api.notifications.read(id),
    onMutate: async (id) => {
      await qc.cancelQueries({ queryKey: qk.notifications })
      return { prev: patch((d) => ({ ...d, notifications: d.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)), unread: Math.max(0, d.unread - 1) })) }
    },
    onError: (e, _id, ctx) => {
      if (ctx?.prev) qc.setQueryData(qk.notifications, ctx.prev)
      toast('error', `Could not mark it read: ${e instanceof Error ? e.message : String(e)}`)
    },
    onSettled: () => void qc.invalidateQueries({ queryKey: qk.notifications })
  })
  const all = useMutation({
    mutationFn: () => api.notifications.readAll(),
    onMutate: async () => {
      await qc.cancelQueries({ queryKey: qk.notifications })
      return { prev: patch((d) => ({ ...d, notifications: d.notifications.map((n) => ({ ...n, read: true })), unread: 0 })) }
    },
    onError: (e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(qk.notifications, ctx.prev)
      toast('error', `Could not mark all read: ${e instanceof Error ? e.message : String(e)}`)
    },
    onSettled: () => void qc.invalidateQueries({ queryKey: qk.notifications })
  })

  const d = q.data
  return (
    <div>
      <SectionHead
        title="Notifications"
        description="Things the daemon wanted you to know: blocked tasks, approvals, alerts."
        right={
          <Button icon={<CheckCheck className="size-3.5" />} disabled={!d || d.unread === 0} loading={all.isPending} onClick={() => all.mutate()}>
            Mark all read
          </Button>
        }
      />
      <Panel icon={<Bell className="size-3.5" />} title="Inbox" hint={d ? (d.unread ? `${d.unread} unread` : 'All caught up') : undefined}>
        {q.isError ? (
          <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
        ) : !d ? (
          <div className="space-y-3">
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        ) : d.notifications.length === 0 ? (
          <EmptyState icon={<BellOff className="size-5" />} title="No notifications" body="Nothing has needed your attention yet." />
        ) : (
          <ul className="divide-y divide-line" aria-label="Notifications">
            {d.notifications.map((n) => (
              <Item key={n.id} n={n} pending={one.isPending && one.variables === n.id} onRead={() => one.mutate(n.id)} />
            ))}
          </ul>
        )}
      </Panel>
    </div>
  )
}
