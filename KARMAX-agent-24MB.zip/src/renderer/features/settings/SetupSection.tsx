import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, CircleAlert, CircleDashed, LoaderCircle, MinusCircle, RotateCcw } from 'lucide-react'
import type { SetupStep, SetupStepId, StepStatus } from '@shared/ipc'
import { Button, Skeleton } from '@/design/primitives'
import { StatusPill, type Tone } from '@/design/status'
import { useSetupState } from '@/lib/api/hooks'
import { getBridge } from '@/lib/bridge'
import { KV, Panel, Reveal } from '@/features/whatsapp/ui/Bits'
import { ConfirmDialog } from '@/features/whatsapp/ui/ConfirmDialog'
import { maskPhone, revealPhone } from '@/features/whatsapp/logic'
import { SectionHead } from './parts'

const STEP: Record<SetupStepId, { title: string; body: string }> = {
  prereqs: { title: 'Prerequisites', body: 'Claude CLI present and signed in, Windows version, ports free' },
  model: { title: 'Model key', body: 'Anthropic API key saved, API token and webhook secret generated' },
  binaries: { title: 'Binaries', body: 'karmax and wacli downloaded and checksum-verified' },
  config: { title: 'Configuration', body: 'karmax.yaml written with your operator number and the wacli path' },
  whatsapp: { title: 'WhatsApp pairing', body: 'This device linked to the KARMAX WhatsApp number' },
  services: { title: 'Services', body: 'The KARMAX daemon and wacli are running and healthy' },
  operator: { title: 'Operator webhook', body: 'wacli forwards only your operator chat to KARMAX' },
  lockdown: { title: 'Lockdown', body: 'Every other chat locked, automation armed' },
  verify: { title: 'Verification', body: 'A test message round trip' }
}

const STATUS: Record<StepStatus, { tone: Tone; label: string; icon: React.ReactNode }> = {
  done: { tone: 'good', label: 'Done', icon: <Check className="size-3" strokeWidth={3} /> },
  active: { tone: 'accent', label: 'In progress', icon: <LoaderCircle className="size-3 animate-[km-spin_1s_linear_infinite]" strokeWidth={2.5} /> },
  todo: { tone: 'muted', label: 'To do', icon: <CircleDashed className="size-3" strokeWidth={2.5} /> },
  error: { tone: 'crit', label: 'Failed', icon: <CircleAlert className="size-3" strokeWidth={2.5} /> },
  skipped: { tone: 'muted', label: 'Skipped', icon: <MinusCircle className="size-3" strokeWidth={2.5} /> }
}

function StepRow({ s, n }: { s: SetupStep; n: number }) {
  const meta = STEP[s.id]
  const st = STATUS[s.status]
  return (
    <li className="flex items-start gap-3.5 py-3">
      <span className="tnum mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-surface-2 text-[11px] font-semibold text-ink-3 ring-1 ring-line">{n}</span>
      <div className="min-w-0 flex-1">
        <div className="text-[13px] font-medium text-ink">{meta?.title ?? s.id}</div>
        <div className="text-[12px] leading-snug text-ink-3">{meta?.body}</div>
        {s.detail && <div className="selectable mt-1 text-[11.5px] text-ink-2">{s.detail}</div>}
        {s.error && <div className="selectable mt-1 text-[11.5px] text-crit">{s.error}</div>}
      </div>
      {s.status === 'done' ? (
        <span className="inline-flex shrink-0 items-center gap-1.5 text-[11.5px] font-semibold text-good">
          {st.icon}
          {st.label}
        </span>
      ) : (
        <StatusPill tone={st.tone} label={st.label} icon={st.icon} className="shrink-0" />
      )}
    </li>
  )
}

export function SetupSection({ toast }: { toast: (kind: 'ok' | 'error', text: string) => void }) {
  const setup = useSetupState()
  const nav = useNavigate()
  const [confirm, setConfirm] = useState(false)
  const [busy, setBusy] = useState(false)
  const done = setup?.steps.filter((s) => s.status === 'done').length ?? 0

  const reset = async () => {
    setBusy(true)
    try {
      await getBridge().setup.reset()
      setConfirm(false)
      nav('/setup')
    } catch (e) {
      setConfirm(false)
      toast('error', `Could not reopen setup: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <SectionHead title="Setup" description="The first-run wizard installs and wires everything together. You can check its steps here and run it again if something has drifted." />
      {!setup ? (
        <Skeleton className="h-96 w-full" />
      ) : (
        <div className="space-y-4">
          <Panel
            title="Steps"
            hint={setup.completed ? 'Setup is complete' : `${done} of ${setup.steps.length} done`}
            right={<StatusPill tone={setup.completed ? 'good' : 'warn'} label={setup.completed ? 'Complete' : 'Incomplete'} />}
          >
            <ol className="divide-y divide-line" aria-label="Setup steps">
              {setup.steps.map((s, i) => (
                <StepRow key={s.id} s={s} n={i + 1} />
              ))}
            </ol>
          </Panel>

          <Panel title="What setup configured">
            <dl className="divide-y divide-line">
              <KV k="Model access">{setup.modelAuth === 'claude-code' ? 'Claude Code sign-in (no API key)' : setup.hasApiKey ? 'Anthropic API key saved (never shown)' : 'Not set'}</KV>
              <KV k="Operator number">{setup.operatorNumber ? <Reveal masked={maskPhone(setup.operatorNumber)} revealed={revealPhone(setup.operatorNumber)} /> : 'Not set'}</KV>
              <KV k="WhatsApp number">{setup.waMode === 'dedicated' ? 'Dedicated to KARMAX' : setup.waMode === 'own' ? 'Your own number' : 'Not chosen'}</KV>
            </dl>
          </Panel>

          <Panel title="Run setup again" hint="Reopens the wizard from the first step">
            <p className="text-[12.5px] leading-relaxed text-ink-2">
              Use this if a step failed, you changed the operator number, or you want to repair the configuration. It <b className="font-semibold text-ink">never deletes your WhatsApp session or any KARMAX data</b> (memory, tasks, loops, conversations).
            </p>
            <div className="mt-4">
              <Button icon={<RotateCcw className="size-3.5" />} onClick={() => setConfirm(true)}>
                Run setup again
              </Button>
            </div>
          </Panel>
        </div>
      )}

      <ConfirmDialog open={confirm} tone="warn" icon={<RotateCcw className="size-4" />} title="Run setup again?" confirmLabel="Reopen setup" loading={busy} onCancel={() => setConfirm(false)} onConfirm={reset}>
        <p>The wizard reopens from the first step and the app leaves this screen until it finishes.</p>
        <p className="text-ink-3">Your WhatsApp session and all KARMAX data stay exactly as they are. Steps that apply a change, such as the operator lockdown, will re-apply it when you reach them.</p>
      </ConfirmDialog>
    </div>
  )
}
