import { useEffect, useRef, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { MotionConfig, AnimatePresence, motion } from 'framer-motion'
import { Bell, Cpu, Info, ListChecks, Palette, PlugZap, Power, Sparkles, type LucideIcon } from 'lucide-react'
import { Page } from '@/design/primitives'
import { cn } from '@/design/cn'
import { base } from '@/design/motion'
import { api } from '@/lib/api/client'
import { qk } from '@/lib/api/hooks'
import { useToasts } from '@/features/whatsapp/ui/Toast'
import { AboutSection } from './AboutSection'
import { AppearanceSection } from './AppearanceSection'
import { ConnectionSection } from './ConnectionSection'
import { ModelsSection } from './ModelsSection'
import { NotificationsSection } from './NotificationsSection'
import { ProcessesSection } from './ProcessesSection'
import { SetupSection } from './SetupSection'
import { StartupSection } from './StartupSection'

type Id = 'connection' | 'processes' | 'appearance' | 'startup' | 'setup' | 'models' | 'notifications' | 'about'
const NAV: { id: Id; label: string; icon: LucideIcon }[] = [
  { id: 'connection', label: 'Connection', icon: PlugZap },
  { id: 'processes', label: 'Processes', icon: Cpu },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'startup', label: 'Startup', icon: Power },
  { id: 'setup', label: 'Setup', icon: ListChecks },
  { id: 'models', label: 'Models', icon: Sparkles },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'about', label: 'About', icon: Info }
]
const isId = (s: string | null): s is Id => !!s && NAV.some((n) => n.id === s)

export default function SettingsPage() {
  const [params, setParams] = useSearchParams()
  const raw = params.get('section')
  const section: Id = isId(raw) ? raw : 'connection'
  const { push, node: toasts } = useToasts()
  const body = useRef<HTMLDivElement>(null)
  const unread = useQuery({ queryKey: qk.notifications, queryFn: () => api.notifications.list(50), refetchInterval: 15_000, retry: false }).data?.unread ?? 0

  useEffect(() => {
    body.current?.scrollTo({ top: 0 })
  }, [section])

  const go = (id: Id) => setParams({ section: id }, { replace: true })
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return
    e.preventDefault()
    const i = NAV.findIndex((n) => n.id === section)
    const d = e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : -1
    const next = NAV[(i + d + NAV.length) % NAV.length]
    go(next.id)
    requestAnimationFrame(() => document.getElementById(`settings-tab-${next.id}`)?.focus())
  }

  const panes: Record<Id, ReactNode> = {
    connection: <ConnectionSection toast={push} />,
    processes: <ProcessesSection toast={push} />,
    appearance: <AppearanceSection />,
    startup: <StartupSection toast={push} />,
    setup: <SetupSection toast={push} />,
    models: <ModelsSection />,
    notifications: <NotificationsSection toast={push} />,
    about: <AboutSection />
  }

  return (
    <MotionConfig reducedMotion="user">
      <Page title="Settings" subtitle="Connection, processes, appearance and housekeeping" flush>
        <div className="@container/page h-full min-h-0 px-7">
        <div className="flex h-full min-h-0 flex-col @2xl/page:flex-row @2xl/page:gap-8">
          <nav aria-label="Settings sections" className="shrink-0 @2xl/page:w-[196px]">
            <div role="tablist" aria-orientation="vertical" onKeyDown={onKey} className="scroll-thin -mx-1 flex gap-1 overflow-x-auto px-1 pb-3 @2xl/page:flex-col @2xl/page:overflow-visible @2xl/page:pb-0">
              {NAV.map((n) => {
                const on = n.id === section
                const Icon = n.icon
                return (
                  <button
                    key={n.id}
                    id={`settings-tab-${n.id}`}
                    role="tab"
                    aria-selected={on}
                    aria-controls="settings-pane"
                    tabIndex={on ? 0 : -1}
                    onClick={() => go(n.id)}
                    className={cn(
                      'app-no-drag group relative flex h-9 shrink-0 items-center gap-2.5 whitespace-nowrap rounded-lg px-3 text-[13px] font-medium transition-colors',
                      on ? 'bg-accent-soft text-ink' : 'text-ink-2 hover:bg-surface-2 hover:text-ink'
                    )}
                  >
                    {on && <span className="absolute -left-1 top-2 hidden h-5 w-[3px] rounded-r-full bg-accent shadow-[0_0_12px_var(--accent)] @2xl/page:block" />}
                    <Icon className={cn('size-[16px] shrink-0', on ? 'text-accent' : 'text-ink-3 group-hover:text-ink-2')} />
                    {n.label}
                    {n.id === 'notifications' && unread > 0 && <span className="ml-auto grid min-w-[18px] place-items-center rounded-full bg-accent px-1.5 text-[10.5px] font-bold leading-[18px] text-white">{unread}</span>}
                  </button>
                )
              })}
            </div>
          </nav>

          <div ref={body} id="settings-pane" role="tabpanel" aria-labelledby={`settings-tab-${section}`} className="scroll-thin min-h-0 min-w-0 flex-1 overflow-auto pb-10 @2xl/page:pr-1">
            <div className="max-w-[820px]">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div key={section} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0, transition: base }} exit={{ opacity: 0, transition: { duration: 0.08 } }}>
                  {panes[section]}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
        </div>
        {toasts}
      </Page>
    </MotionConfig>
  )
}
