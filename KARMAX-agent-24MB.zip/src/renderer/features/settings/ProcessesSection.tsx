import { useEffect, useState, type ReactNode } from 'react'
import { AlertTriangle, Cpu, Play, RotateCw, Smartphone, Square } from 'lucide-react'
import type { ProcName, ProcState, ProcStatus } from '@shared/ipc'
import { Button, EmptyState, Skeleton } from '@/design/primitives'
import { StatusDot, StatusPill, type Tone } from '@/design/status'
import { timeAgo } from '@/lib/format'
import { useSupervisor } from '@/lib/api/hooks'
import { getBridge } from '@/lib/bridge'
import { KV, Panel } from '@/features/whatsapp/ui/Bits'
import { ConfirmDialog } from '@/features/whatsapp/ui/ConfirmDialog'
import { cn } from '@/design/cn'
import { warnText } from '@/features/whatsapp/ui/tone'
import { SectionHead, formatUptime, useNow } from './parts'

const STATE: Record<ProcState, { tone: Tone; label: string }> = {
  running: { tone: 'good', label: 'Running' },
  external: { tone: 'good', label: 'Running (external)' },
  starting: { tone: 'accent', label: 'Starting' },
  backoff: { tone: 'warn', label: 'Waiting to restart' },
  crashed: { tone: 'crit', label: 'Crashed' },
  stopped: { tone: 'muted', label: 'Stopped' },
  missing: { tone: 'serious', label: 'Not installed' }
}

const META: Record<ProcName, { title: string; blurb: string; icon: ReactNode }> = {
  karmax: { title: 'KARMAX daemon', blurb: 'Orchestrator, loops and API on :9091', icon: <Cpu className="size-3.5" /> },
  wacli: { title: 'wacli', blurb: 'WhatsApp session and API on :8765', icon: <Smartphone className="size-3.5" /> }
}

const CONSEQUENCE: Record<ProcName, { stop: string; restart: string }> = {
  karmax: {
    stop: 'The daemon stops. Loops, running tasks and WhatsApp handling pause, and this app goes read-only until you start it again.',
    restart: 'The daemon restarts, which takes a few seconds. Loop runs and chat streams in progress are interrupted.'
  },
  wacli: {
    stop: 'WhatsApp disconnects: no messages arrive or leave until wacli is started again. Your session is kept, so you do not need to pair again.',
    restart: 'WhatsApp disconnects for a few seconds while wacli restarts. Messages sent to your operator number meanwhile are usually delivered when it reconnects.'
  }
}

type Action = 'start' | 'stop' | 'restart'

function ProcCard({ p, onAct, busy }: { p: ProcStatus; onAct: (a: Action) => void; busy?: Action }) {
  const now = useNow(1000)
  const meta = META[p.name]
  const st = STATE[p.state]
  const live = p.state === 'running' || p.state === 'starting' || p.state === 'external'
  const attached = p.state === 'external'
  const canStart = p.state === 'stopped' || p.state === 'crashed' || p.state === 'backoff'
  const uptime = p.startedAt && (p.state === 'running' || p.state === 'starting') ? formatUptime(now - Date.parse(p.startedAt)) : '—'
  const nextIn = p.nextRestartAt ? Math.max(0, Math.round((Date.parse(p.nextRestartAt) - now) / 1000)) : undefined

  return (
    <Panel
      icon={meta.icon}
      title={meta.title}
      hint={meta.blurb}
      right={<StatusPill tone={st.tone} label={st.label} />}
      className="h-full"
    >
      <dl className="divide-y divide-line">
        <KV k="Health">
          <span className="inline-flex items-center gap-2">
            <StatusDot tone={p.healthy ? 'good' : live ? 'warn' : 'muted'} size={7} pulse={p.healthy && p.state === 'running'} />
            {p.healthy ? 'Healthy' : live ? 'Not answering yet' : 'Not running'}
          </span>
        </KV>
        <KV k="Process ID">{p.pid ?? '—'}</KV>
        <KV k="Uptime">{uptime}</KV>
        <KV k="Restarts">{p.restarts}</KV>
        <KV k="Last exit">
          {p.lastExit ? (
            <span className="inline-flex items-center gap-1.5">
              {p.lastExit.code !== 0 && <AlertTriangle className={cn('size-3.5', warnText)} />}
              {p.lastExit.signal ? `signal ${p.lastExit.signal}` : `code ${p.lastExit.code ?? '?'}`}
              <span className="text-ink-3">· {timeAgo(p.lastExit.at)}</span>
            </span>
          ) : (
            '—'
          )}
        </KV>
        {nextIn != null && <KV k="Next restart">{`in ${nextIn}s`}</KV>}
        <KV k="Binary">
          <span className="block max-w-[260px] truncate font-[family-name:var(--font-mono)] text-[11.5px]" title={p.binaryPath}>
            {p.binaryPath ?? '—'}
          </span>
        </KV>
      </dl>

      {attached && <p className="mt-3 text-[11.5px] leading-snug text-ink-3">Something else already answers on this port, so KARMAX Desktop is only watching it. It will not stop or restart a process it did not start.</p>}
      {p.state === 'missing' && <p className="mt-3 text-[11.5px] leading-snug text-ink-3">The binary is not installed yet. Run setup to download and verify it.</p>}

      <div className="mt-4 flex flex-wrap gap-2">
        {canStart || p.state === 'missing' ? (
          <Button variant="primary" icon={<Play className="size-3.5" />} loading={busy === 'start'} disabled={p.state === 'missing'} onClick={() => onAct('start')}>
            Start
          </Button>
        ) : (
          <Button icon={<Square className="size-3.5" />} loading={busy === 'stop'} disabled={attached || !live} onClick={() => onAct('stop')}>
            Stop
          </Button>
        )}
        <Button icon={<RotateCw className="size-3.5" />} loading={busy === 'restart'} disabled={attached || !live || p.state === 'starting'} onClick={() => onAct('restart')}>
          Restart
        </Button>
      </div>
    </Panel>
  )
}

export function ProcessesSection({ toast }: { toast: (kind: 'ok' | 'error', text: string) => void }) {
  const polled = useSupervisor()
  const [fresh, setFresh] = useState<ProcStatus[]>()
  // A poll result supersedes whatever we fetched right after an action.
  useEffect(() => setFresh(undefined), [polled])
  const procs = fresh ?? polled
  const [confirm, setConfirm] = useState<{ name: ProcName; action: 'stop' | 'restart' } | null>(null)
  const [busy, setBusy] = useState<Partial<Record<ProcName, Action>>>({})

  const run = async (name: ProcName, action: Action) => {
    setBusy((b) => ({ ...b, [name]: action }))
    try {
      await getBridge().supervisor[action](name)
      void getBridge().supervisor.status().then(setFresh).catch(() => undefined)
      toast('ok', `${META[name].title}: ${action === 'start' ? 'starting' : action === 'stop' ? 'stopped' : 'restarting'}.`)
    } catch (e) {
      toast('error', `Could not ${action} ${META[name].title}: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy((b) => ({ ...b, [name]: undefined }))
    }
  }

  const onAct = (name: ProcName) => (a: Action) => (a === 'start' ? void run(name, a) : setConfirm({ name, action: a }))

  return (
    <div>
      <SectionHead title="Processes" description="KARMAX Desktop supervises the KARMAX daemon and wacli: it starts them, watches their health and restarts them with backoff if they crash." />
      {procs.length === 0 ? (
        <div className="grid gap-4 @5xl/page:grid-cols-2">
          <Skeleton className="h-72 w-full" />
          <Skeleton className="h-72 w-full" />
        </div>
      ) : (
        <div className="grid gap-4 @5xl/page:grid-cols-2">
          {(['karmax', 'wacli'] as ProcName[]).map((n) => {
            const p = procs.find((x) => x.name === n)
            return p ? <ProcCard key={n} p={p} busy={busy[n]} onAct={onAct(n)} /> : <EmptyState key={n} title={`${n} is not reported`} body="The supervisor did not return a status for it." />
          })}
        </div>
      )}

      <ConfirmDialog
        open={!!confirm}
        tone="warn"
        confirmVariant={confirm?.action === 'stop' ? 'danger' : 'primary'}
        icon={confirm?.action === 'stop' ? <Square className="size-4" /> : <RotateCw className="size-4" />}
        title={confirm ? `${confirm.action === 'stop' ? 'Stop' : 'Restart'} ${META[confirm.name].title}?` : ''}
        confirmLabel={confirm?.action === 'stop' ? 'Stop' : 'Restart'}
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          const c = confirm
          setConfirm(null)
          if (c) void run(c.name, c.action)
        }}
      >
        <p>{confirm ? CONSEQUENCE[confirm.name][confirm.action] : ''}</p>
      </ConfirmDialog>
    </div>
  )
}
