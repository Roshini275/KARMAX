import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Power } from 'lucide-react'
import type { StartupPrefs } from '@shared/ipc'
import { ErrorNote, Skeleton, Switch } from '@/design/primitives'
import { getBridge } from '@/lib/bridge'
import { useConnection } from '@/lib/api/hooks'
import { Panel } from '@/features/whatsapp/ui/Bits'
import { Row, SectionHead } from './parts'

const KEY = ['settings', 'startup'] as const

export function StartupSection({ toast }: { toast: (kind: 'ok' | 'error', text: string) => void }) {
  const qc = useQueryClient()
  const conn = useConnection()
  const q = useQuery({ queryKey: KEY, queryFn: () => getBridge().startup.get(), retry: false })
  const m = useMutation({
    mutationFn: (patch: Partial<StartupPrefs>) => getBridge().startup.set(patch),
    onMutate: async (patch) => {
      await qc.cancelQueries({ queryKey: KEY })
      const prev = qc.getQueryData<StartupPrefs>(KEY)
      if (prev) qc.setQueryData<StartupPrefs>(KEY, { ...prev, ...patch })
      return { prev }
    },
    onError: (e, _p, ctx) => {
      if (ctx?.prev) qc.setQueryData(KEY, ctx.prev)
      toast('error', `Could not change the setting: ${e instanceof Error ? e.message : String(e)}. Reverted.`)
    },
    onSuccess: (prefs) => qc.setQueryData(KEY, prefs)
  })

  return (
    <div>
      <SectionHead title="Startup" description="Because KARMAX Desktop supervises the daemons, whether it is running decides whether your operator can reach KARMAX." />
      <Panel icon={<Power className="size-3.5" />} title="Windows" hint={conn?.mode === 'web' ? 'Browser preview: not persisted' : undefined}>
        {q.isError ? (
          <ErrorNote error={q.error} onRetry={() => void q.refetch()} />
        ) : !q.data ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <div className="divide-y divide-line">
            <Row label="Open at login" hint="Start KARMAX Desktop, and with it the KARMAX daemon and wacli, when you sign in to Windows.">
              <Switch checked={q.data.openAtLogin} label="Open at login" onChange={(v) => m.mutate({ openAtLogin: v })} />
            </Row>
            <Row label="Minimise to tray" hint="Closing the window hides it to the tray and keeps the daemons running. Quit from the tray menu.">
              <Switch checked={q.data.minimizeToTray} label="Minimise to tray" onChange={(v) => m.mutate({ minimizeToTray: v })} />
            </Row>
          </div>
        )}
      </Panel>
    </div>
  )
}
