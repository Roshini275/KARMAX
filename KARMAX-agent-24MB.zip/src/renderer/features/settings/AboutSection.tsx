import { useEffect, useState } from 'react'
import { ExternalLink, GitBranch, Info } from 'lucide-react'
import { Button } from '@/design/primitives'
import { Logo } from '@/shell/Logo'
import { useConnection } from '@/lib/api/hooks'
import { getBridge } from '@/lib/bridge'
import { KV, Panel } from '@/features/whatsapp/ui/Bits'
import { SectionHead } from './parts'

const REPOS = [
  { name: 'KARMAX', url: 'https://github.com/MelloB1989/KARMAX', blurb: 'The always-on Go orchestrator this app is a cockpit for.' },
  { name: 'karmax-loops', url: 'https://github.com/MelloB1989/karmax-loops', blurb: 'The registry of recurring automations (recipes and signed workflows).' },
  { name: 'wacli', url: 'https://github.com/MelloB1989/wacli', blurb: 'The WhatsApp daemon behind the operator channel.' }
]

export function AboutSection() {
  const conn = useConnection()
  const [version, setVersion] = useState<string>()
  useEffect(() => {
    let alive = true
    void getBridge().app.version().then((v) => alive && setVersion(v))
    return () => {
      alive = false
    }
  }, [])
  const bridge = getBridge()
  return (
    <div>
      <SectionHead title="About" />
      <Panel bodyClassName="px-5 pb-5 pt-1">
        <div className="flex items-center gap-4">
          <Logo size={44} />
          <div>
            <div className="font-[family-name:var(--font-display)] text-[18px] font-semibold tracking-[0.12em]">KARMAX</div>
            <div className="text-[12.5px] text-ink-3">Desktop cockpit for KARMAX and karmax-loops</div>
          </div>
        </div>
        <dl className="mt-4 divide-y divide-line">
          <KV k="App version">{version ?? '…'}</KV>
          <KV k="Runtime">{conn ? (conn.mode === 'electron' ? 'Electron (desktop app)' : 'Browser preview') : '…'}</KV>
          <KV k="Platform">{bridge.app.platform}</KV>
          <KV k="Daemon">{conn?.reachable ? `KARMAX v${(conn.version ?? '?').replace(/^v/, '')}${conn.agent ? ` · agent ${conn.agent}` : ''}` : 'Not reachable'}</KV>
        </dl>
      </Panel>

      <Panel className="mt-4" icon={<GitBranch className="size-3.5" />} title="Source" hint="Opens in your default browser">
        <ul className="divide-y divide-line" aria-label="Repositories">
          {REPOS.map((r) => (
            <li key={r.name} className="flex items-center justify-between gap-4 py-3">
              <div className="min-w-0">
                <div className="text-[13px] font-medium text-ink">{r.name}</div>
                <div className="text-[12px] text-ink-3">{r.blurb}</div>
              </div>
              <Button size="sm" icon={<ExternalLink className="size-3.5" />} onClick={() => void getBridge().app.openExternal(r.url)} aria-label={`Open ${r.name} on GitHub`}>
                GitHub
              </Button>
            </li>
          ))}
        </ul>
      </Panel>
      <p className="mt-4 flex items-start gap-2 text-[11.5px] leading-snug text-ink-3">
        <Info className="mt-px size-3.5 shrink-0" />
        The app talks to the daemons only over their public local APIs. It never holds your API token or Anthropic key in the window.
      </p>
    </div>
  )
}
