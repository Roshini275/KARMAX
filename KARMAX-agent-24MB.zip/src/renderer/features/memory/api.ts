/**
 * Memory endpoints, verified against KARMAX/internal/api/{server.go,cleanup.go} and the Expo client (app/src/lib/api.ts):
 *   GET    /api/memory/entries?q=&limit=   -> { namespace, entries: [{id, role, content, tags, created_at}] }  (q => memory search, else most recent)
 *   DELETE /api/memory/entries/{id}        -> { deleted }   ids may be GitLoom repo paths ("people/aarav.md"), so they are URL-encoded
 *   GET    /api/memory/tree                -> { namespace, tree: TreeNode | null }   (null on a fresh namespace)
 *   GET    /api/memory/cleanup/question    -> { done: true } | { memory_id, memory, question, options }   runs an LLM call (up to 90s)
 *   POST   /api/memory/cleanup/answer      {memory_id, memory, question, answer} -> { action: 'delete'|'update', memory_id, content? }  also an LLM call
 * The graph endpoints are intentionally not used.
 */
import { z } from 'zod'
import { daemonCall, req } from '../whatsapp/http'

const arr = <T extends z.ZodType>(t: T) =>
  z
    .array(t)
    .nullish()
    .transform((v) => v ?? [])

export const EntrySchema = z.looseObject({
  id: z.string(),
  role: z.string().default(''),
  content: z.string().default(''),
  tags: arr(z.string()),
  created_at: z.string().optional()
})
export type MemoryEntry = z.infer<typeof EntrySchema>

export interface TreeNode {
  node_id: string
  title: string
  summary?: string
  content?: string
  children: TreeNode[]
}

const TreeNodeSchema: z.ZodType<TreeNode, unknown> = z.lazy(() =>
  z.looseObject({
    node_id: z.string().default(''),
    title: z.string().default(''),
    summary: z.string().optional(),
    content: z.string().optional(),
    children: arr(TreeNodeSchema)
  })
)

const K = (method: string, path: string, extra = {}) => req('karmax', method, path, extra)

export const memoryApi = {
  entries: (q: string, limit = 100) =>
    daemonCall(z.looseObject({ namespace: z.string().optional(), entries: arr(EntrySchema) }), K('GET', '/api/memory/entries', { query: { q: q || undefined, limit } })).then((r) => r.entries),

  forget: (id: string) => daemonCall(z.looseObject({ deleted: z.string().optional() }), K('DELETE', `/api/memory/entries/${encodeURIComponent(id)}`)),

  tree: () => daemonCall(z.looseObject({ namespace: z.string().optional(), tree: TreeNodeSchema.nullish() }), K('GET', '/api/memory/tree')).then((r) => r.tree ?? null),

  cleanupQuestion: () =>
    daemonCall(
      z.looseObject({ done: z.boolean().optional(), memory_id: z.string().optional(), memory: z.string().optional(), question: z.string().optional(), options: arr(z.string()) }),
      K('GET', '/api/memory/cleanup/question')
    ),

  cleanupAnswer: (b: { memory_id: string; memory: string; question: string; answer: string }) =>
    daemonCall(z.looseObject({ action: z.string().optional(), memory_id: z.string().optional(), content: z.string().optional() }), K('POST', '/api/memory/cleanup/answer', { body: b }))
}
export type CleanupQuestion = Awaited<ReturnType<typeof memoryApi.cleanupQuestion>>
