import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Brain, ChevronRight, Network, Search, Sparkles, Trash2, X } from 'lucide-react'
import { Badge, Button, Card, EmptyState, ErrorNote, Input, Page, Segmented, Skeleton, Spinner, Textarea } from '@/design/primitives'
import { cn } from '@/design/cn'
import { timeAgo } from '@/lib/format'
import { memoryApi, type CleanupQuestion, type MemoryEntry, type TreeNode } from './api'

type Tab = 'entries' | 'tree' | 'cleanup'

const keys = { entries: (q: string) => ['memory', 'entries', q] as const, tree: ['memory', 'tree'] as const }

function useDebounced<T>(value: T, ms: number) {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms)
    return () => clearTimeout(t)
  }, [value, ms])
  return v
}

export default function MemoryPage() {
  const [tab, setTab] = useState<Tab>('entries')
  return (
    <Page
      title="Memory"
      subtitle="What KARMAX remembers about you, your people and your projects"
      actions={
        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { value: 'entries', label: 'Entries' },
            { value: 'tree', label: 'Tree' },
            { value: 'cleanup', label: 'Cleanup' }
          ]}
        />
      }
    >
      {tab === 'entries' && <Entries />}
      {tab === 'tree' && <Tree />}
      {tab === 'cleanup' && <Cleanup />}
    </Page>
  )
}

/* ── Entries ────────────────────────────────────────────────────────────── */

function Entries() {
  const [text, setText] = useState('')
  const q = useDebounced(text.trim(), 250)
  const qc = useQueryClient()
  const list = useQuery({ queryKey: keys.entries(q), queryFn: () => memoryApi.entries(q), retry: false })
  const forget = useMutation({
    mutationFn: (id: string) => memoryApi.forget(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['memory'] })
  })
  const [confirming, setConfirming] = useState<string | null>(null)

  return (
    <div className="mx-auto max-w-3xl">
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-3" />
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Search memory (people, projects, preferences)" className="pl-9" aria-label="Search memory" />
        {text && (
          <button aria-label="Clear search" onClick={() => setText('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-ink-3 hover:text-ink">
            <X className="size-3.5" />
          </button>
        )}
      </div>

      {list.isError && <ErrorNote error={list.error} onRetry={() => list.refetch()} />}
      {forget.isError && <div className="mb-3"><ErrorNote error={forget.error} /></div>}
      {list.isPending && (
        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
      )}
      {list.data && list.data.length === 0 && (
        <EmptyState
          icon={<Brain className="size-5" />}
          title={q ? 'Nothing matches that search' : 'No memories yet'}
          body={q ? 'Try a different word, or clear the search.' : 'KARMAX saves facts here as it learns them from your chats and tasks.'}
        />
      )}
      {list.data && list.data.length > 0 && (
        <>
          <p className="mb-2 text-[12px] text-ink-3">{list.data.length} {list.data.length === 1 ? 'entry' : 'entries'}{q ? ` matching “${q}”` : ', most recent first'}</p>
          <ul className="space-y-3">
            {list.data.map((e) => (
              <EntryCard
                key={e.id}
                entry={e}
                confirming={confirming === e.id}
                busy={forget.isPending && forget.variables === e.id}
                onAsk={() => setConfirming(e.id)}
                onCancel={() => setConfirming(null)}
                onForget={() => forget.mutate(e.id, { onSettled: () => setConfirming(null) })}
              />
            ))}
          </ul>
        </>
      )}
    </div>
  )
}

function EntryCard({ entry, confirming, busy, onAsk, onCancel, onForget }: { entry: MemoryEntry; confirming: boolean; busy: boolean; onAsk: () => void; onCancel: () => void; onForget: () => void }) {
  return (
    <li>
      <Card className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            <code className="truncate font-[family-name:var(--font-mono)] text-[11.5px] text-ink-3">{entry.id}</code>
            {entry.role && <Badge>{entry.role}</Badge>}
          </div>
          <span className="shrink-0 text-[11.5px] text-ink-3">{entry.created_at ? timeAgo(entry.created_at) : ''}</span>
        </div>
        <p className="selectable mt-2 text-[13.5px] leading-relaxed text-ink">{entry.content}</p>
        <div className="mt-3 flex items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5">
            {entry.tags.map((t) => <Badge key={t}>#{t}</Badge>)}
          </div>
          {confirming ? (
            <div className="flex shrink-0 items-center gap-1.5">
              <span className="text-[12px] text-ink-3">Forget this?</span>
              <Button size="sm" variant="danger" loading={busy} onClick={onForget}>Forget</Button>
              <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
            </div>
          ) : (
            <Button size="sm" variant="ghost" icon={<Trash2 className="size-3.5" />} onClick={onAsk}>Forget</Button>
          )}
        </div>
      </Card>
    </li>
  )
}

/* ── Tree ───────────────────────────────────────────────────────────────── */

function countLeaves(n: TreeNode): number {
  return n.children.length ? n.children.reduce((a, c) => a + countLeaves(c), 0) : 1
}

function Tree() {
  const tree = useQuery({ queryKey: keys.tree, queryFn: memoryApi.tree, retry: false })
  const [selected, setSelected] = useState<TreeNode | null>(null)

  if (tree.isPending) return <Skeleton className="h-72 rounded-xl" />
  if (tree.isError) return <ErrorNote error={tree.error} onRetry={() => tree.refetch()} />
  if (!tree.data) return <EmptyState icon={<Network className="size-5" />} title="The memory tree is empty" body="It fills in once KARMAX has organised a few memories." />

  return (
    <div className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <Card className="p-2">
        <TreeRow node={tree.data} depth={0} selected={selected?.node_id} onSelect={setSelected} defaultOpen />
      </Card>
      <Card className="h-fit p-4 md:sticky md:top-0">
        {selected ? (
          <>
            <div className="flex items-center gap-2">
              <h2 className="text-[15px] font-semibold text-ink">{selected.title || selected.node_id}</h2>
              <Badge>{countLeaves(selected)} {countLeaves(selected) === 1 ? 'note' : 'notes'}</Badge>
            </div>
            <code className="mt-1 block font-[family-name:var(--font-mono)] text-[11.5px] text-ink-3">{selected.node_id}</code>
            {selected.summary && <p className="mt-3 text-[13px] text-ink-2">{selected.summary}</p>}
            {selected.content && <p className="selectable mt-3 rounded-lg bg-surface-2 p-3 text-[13px] leading-relaxed text-ink">{selected.content}</p>}
            {!selected.summary && !selected.content && <p className="mt-3 text-[12.5px] text-ink-3">No details stored on this node.</p>}
          </>
        ) : (
          <p className="text-[12.5px] text-ink-3">Select a node to see its summary and details.</p>
        )}
      </Card>
    </div>
  )
}

function TreeRow({ node, depth, selected, onSelect, defaultOpen }: { node: TreeNode; depth: number; selected?: string; onSelect: (n: TreeNode) => void; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(!!defaultOpen)
  const has = node.children.length > 0
  const active = selected === node.node_id
  return (
    <div>
      <div
        className={cn('flex items-center gap-1 rounded-lg py-1.5 pr-2 text-[13px] transition-colors', active ? 'bg-accent-soft text-ink' : 'text-ink-2 hover:bg-surface-2 hover:text-ink')}
        style={{ paddingLeft: 6 + depth * 16 }}
      >
        <button
          aria-label={open ? 'Collapse' : 'Expand'}
          aria-expanded={has ? open : undefined}
          disabled={!has}
          onClick={() => setOpen((o) => !o)}
          className="grid size-5 shrink-0 place-items-center rounded text-ink-3 hover:text-ink disabled:opacity-0"
        >
          <ChevronRight className={cn('size-3.5 transition-transform', open && 'rotate-90')} />
        </button>
        <button onClick={() => onSelect(node)} className="min-w-0 flex-1 truncate text-left">
          {node.title || node.node_id}
          {has && <span className="ml-2 text-[11px] text-ink-3">{node.children.length}</span>}
        </button>
      </div>
      {has && open && node.children.map((c) => <TreeRow key={c.node_id} node={c} depth={depth + 1} selected={selected} onSelect={onSelect} />)}
    </div>
  )
}

/* ── Cleanup ────────────────────────────────────────────────────────────── */

function Cleanup() {
  const qc = useQueryClient()
  const [q, setQ] = useState<CleanupQuestion | null>(null)
  const [answer, setAnswer] = useState('')
  const [result, setResult] = useState<string | null>(null)

  const next = useMutation({
    mutationFn: memoryApi.cleanupQuestion,
    onSuccess: (r) => {
      setQ(r)
      setAnswer('')
    }
  })
  const send = useMutation({
    mutationFn: memoryApi.cleanupAnswer,
    onSuccess: (r) => {
      setResult(r.action === 'delete' ? 'Forgotten. That memory was removed.' : 'Updated. KARMAX refined that memory with your answer.')
      setQ(null)
      qc.invalidateQueries({ queryKey: ['memory'] })
    }
  })

  const asking = q && !q.done && q.memory_id
  const submit = (a: string) => {
    if (!q?.memory_id || !a.trim()) return
    send.mutate({ memory_id: q.memory_id, memory: q.memory ?? '', question: q.question ?? '', answer: a.trim() })
  }

  return (
    <div className="mx-auto max-w-2xl">
      <Card className="p-5">
        <div className="flex items-start gap-3">
          <div className="grid size-9 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent"><Sparkles className="size-4" /></div>
          <div>
            <h2 className="text-[15px] font-semibold text-ink">Keep memory fresh</h2>
            <p className="mt-0.5 text-[12.5px] text-ink-3">KARMAX picks one memory it is unsure about and asks you. Your answer updates or removes it. Each question uses an AI call, so it can take a few seconds.</p>
          </div>
        </div>

        {result && !asking && <p className="mt-4 rounded-lg bg-surface-2 px-3 py-2 text-[12.5px] text-ink-2" role="status">{result}</p>}
        {q?.done && <p className="mt-4 rounded-lg bg-surface-2 px-3 py-2 text-[12.5px] text-ink-2" role="status">All clear. Nothing needs checking right now.</p>}
        {next.isError && <div className="mt-4"><ErrorNote error={next.error} onRetry={() => next.mutate()} /></div>}
        {send.isError && <div className="mt-4"><ErrorNote error={send.error} /></div>}

        {asking && (
          <div className="mt-5 space-y-4">
            <blockquote className="selectable rounded-lg border-l-2 border-accent bg-surface-2 px-3 py-2 text-[13px] text-ink-2">{q.memory}</blockquote>
            <p className="text-[14px] font-medium text-ink">{q.question}</p>
            <div className="flex flex-wrap gap-2">
              {q.options.map((o) => <Button key={o} disabled={send.isPending} onClick={() => submit(o)}>{o}</Button>)}
            </div>
            <div className="flex items-end gap-2">
              <Textarea rows={2} value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Or answer in your own words" className="py-2" aria-label="Your answer" />
              <Button variant="primary" loading={send.isPending} disabled={!answer.trim()} onClick={() => submit(answer)}>Send</Button>
            </div>
          </div>
        )}

        {!asking && (
          <div className="mt-5">
            <Button variant="primary" loading={next.isPending} icon={next.isPending ? undefined : <Sparkles className="size-3.5" />} onClick={() => { setResult(null); next.mutate() }}>
              {q?.done || result ? 'Check another' : 'Start cleanup'}
            </Button>
            {next.isPending && <span className="ml-3 inline-flex items-center gap-2 text-[12px] text-ink-3"><Spinner />Finding something to ask…</span>}
          </div>
        )}
      </Card>
    </div>
  )
}
