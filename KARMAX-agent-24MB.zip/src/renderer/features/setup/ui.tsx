import { forwardRef, useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { Check, CircleAlert, Copy, Info, TriangleAlert } from 'lucide-react'
import { Card, Input } from '@/design/primitives'
import { cn } from '@/design/cn'
import { formatClock } from '@/lib/format'
import type { SetupStepId } from '@shared/ipc'
import { useActivity } from './activity'
import { countryOf, normalizePhone, validatePhone } from './phone'
import { STEP_META, STEP_ORDER } from './wizard'

/* ── errors from the bridge ─────────────────────────────────────────────── */

/** Electron wraps main-process errors as "Error invoking remote method 'setup:invoke': SetupError: <message>". */
export function cleanError(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e)
  return m.replace(/^Error invoking remote method '[^']+':\s*/, '').replace(/^(?:Setup)?Error:\s*/, '')
}

export function useAction<A extends unknown[]>(fn: (...args: A) => Promise<unknown>) {
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string>()
  const alive = useRef(true)
  useEffect(() => {
    alive.current = true
    return () => {
      alive.current = false
    }
  }, [])
  const run = useCallback(
    async (...args: A) => {
      setPending(true)
      setError(undefined)
      try {
        await fn(...args)
        return true
      } catch (e) {
        if (alive.current) setError(cleanError(e))
        return false
      } finally {
        if (alive.current) setPending(false)
      }
    },
    [fn]
  )
  return { run, pending, error, clearError: () => setError(undefined) }
}

/* ── motion ─────────────────────────────────────────────────────────────── */

export function useMotionSafe() {
  const reduce = useReducedMotion()
  return {
    reduce: !!reduce,
    tr: <T extends object>(t: T): T | { duration: number } => (reduce ? { duration: 0 } : t)
  }
}

/* ── panel scaffold ─────────────────────────────────────────────────────── */

export function PanelFrame({
  step,
  title,
  lead,
  children,
  footer,
  icon
}: {
  step: SetupStepId
  title: string
  lead?: ReactNode
  children?: ReactNode
  footer?: ReactNode
  icon?: ReactNode
}) {
  const { reduce } = useMotionSafe()
  const idx = STEP_ORDER.indexOf(step) + 1
  const headRef = useRef<HTMLHeadingElement>(null)
  const secRef = useRef<HTMLElement>(null)
  // Move focus to the heading so screen readers announce the new panel, unless the panel already took focus (an autoFocus input).
  useEffect(() => {
    if (!secRef.current?.contains(document.activeElement)) headRef.current?.focus({ preventScroll: true })
  }, [step])
  return (
    <motion.section
      ref={secRef}
      aria-labelledby={`setup-h-${step}`}
      initial={reduce ? false : { opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0, transition: reduce ? { duration: 0 } : { duration: 0.32, ease: [0.22, 1, 0.36, 1] } }}
      exit={{ opacity: 0, y: -6, transition: { duration: reduce ? 0 : 0.12 } }}
    >
      <Card className="overflow-clip">
        <div className="relative px-7 pb-2 pt-7">
          <div aria-hidden className="pointer-events-none absolute -right-16 -top-24 size-64 rounded-full opacity-60 blur-3xl" style={{ background: 'radial-gradient(closest-side, color-mix(in oklab, var(--accent) 22%, transparent), transparent)' }} />
          <div className="relative flex items-start gap-4">
            {icon && <div className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent ring-1 ring-[color-mix(in_oklab,var(--accent)_28%,transparent)]">{icon}</div>}
            <div className="min-w-0">
              <div className="label-micro">
                Step {idx} of {STEP_ORDER.length}
              </div>
              <h2 id={`setup-h-${step}`} ref={headRef} tabIndex={-1} style={{ outline: 'none' }} className="mt-1 font-[family-name:var(--font-display)] text-[24px] font-semibold leading-tight tracking-tight">
                {title}
              </h2>
              {lead && <p className="mt-1.5 max-w-[56ch] text-[13.5px] leading-relaxed text-ink-2">{lead}</p>}
            </div>
          </div>
        </div>
        {children && <div className="px-7 pb-2 pt-4">{children}</div>}
        {footer && <div className="sticky bottom-0 z-10 mt-3 flex items-center justify-between gap-3 border-t border-line bg-[color-mix(in_oklab,var(--surface-2)_88%,var(--page))] px-7 py-4 backdrop-blur-md">{footer}</div>}
      </Card>
    </motion.section>
  )
}

/* ── callouts ───────────────────────────────────────────────────────────── */

const calloutTone = {
  info: { c: 'var(--accent)', icon: <Info className="size-4" />, label: 'Note' },
  warn: { c: 'var(--warn)', icon: <TriangleAlert className="size-4" />, label: 'Heads up' },
  crit: { c: 'var(--crit)', icon: <CircleAlert className="size-4" />, label: 'Problem' },
  good: { c: 'var(--good)', icon: <Check className="size-4" strokeWidth={3} />, label: 'Done' }
} as const

export function Callout({ tone = 'info', title, children, className, role }: { tone?: keyof typeof calloutTone; title?: string; children?: ReactNode; className?: string; role?: 'alert' | 'status' }) {
  const t = calloutTone[tone]
  return (
    <div
      role={role}
      className={cn('flex gap-3 rounded-xl px-4 py-3 text-[12.5px] leading-relaxed ring-1', className)}
      style={{ background: `color-mix(in oklab, ${t.c} 9%, transparent)`, ['--tw-ring-color' as string]: `color-mix(in oklab, ${t.c} 28%, transparent)` }}
    >
      <span className="mt-0.5 shrink-0" style={{ color: t.c }}>
        {t.icon}
      </span>
      <div className="min-w-0 text-ink-2">
        {title && <div className="mb-0.5 font-semibold text-ink">{title}</div>}
        {children}
      </div>
    </div>
  )
}

export function ErrorCallout({ message, title = 'That did not work' }: { message?: string; title?: string }) {
  if (!message) return null
  return (
    <Callout tone="crit" title={title} role="alert" className="selectable">
      <span className="whitespace-pre-line">{message}</span>
    </Callout>
  )
}

/* ── copy ───────────────────────────────────────────────────────────────── */

export function useCopy() {
  const [copied, setCopied] = useState(false)
  const t = useRef<number>(0)
  const copy = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      ta.remove()
    }
    setCopied(true)
    window.clearTimeout(t.current)
    t.current = window.setTimeout(() => setCopied(false), 1600)
  }, [])
  return { copied, copy }
}

export function CopyChip({ text, label = 'Copy' }: { text: string; label?: string }) {
  const { copied, copy } = useCopy()
  return (
    <button
      type="button"
      onClick={() => copy(text)}
      className="app-no-drag inline-flex h-7 items-center gap-1.5 rounded-md border border-line bg-surface-2 px-2.5 text-[12px] font-medium text-ink-2 transition-colors hover:bg-surface-3 hover:text-ink"
    >
      {copied ? <Check className="size-3.5 text-good" strokeWidth={3} /> : <Copy className="size-3.5" />}
      <span aria-live="polite">{copied ? 'Copied' : label}</span>
    </button>
  )
}

/* ── phone field ────────────────────────────────────────────────────────── */

export const PhoneField = forwardRef<
  HTMLInputElement,
  { id: string; label: string; value: string; onChange: (v: string) => void; hint?: ReactNode; disabled?: boolean; autoFocus?: boolean; onEnter?: () => void }
>(function PhoneField({ id, label, value, onChange, hint, disabled, autoFocus, onEnter }, ref) {
  const digits = normalizePhone(value)
  const check = validatePhone(value)
  const country = countryOf(digits)
  const [touched, setTouched] = useState(false)
  const showError = touched && !check.ok && digits.length > 0
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-[12.5px] font-medium text-ink">
        {label}
      </label>
      <div className="relative">
        <span aria-hidden className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 font-mono text-[13px] text-ink-3">
          +
        </span>
        <Input
          id={id}
          ref={ref}
          inputMode="numeric"
          autoComplete="off"
          spellCheck={false}
          autoFocus={autoFocus}
          disabled={disabled}
          placeholder="91 98765 43210"
          value={value}
          aria-invalid={showError || undefined}
          aria-describedby={`${id}-hint`}
          onChange={(e) => onChange(e.target.value.replace(/[^\d\s()-]/g, ''))}
          onBlur={() => setTouched(true)}
          onKeyDown={(e) => e.key === 'Enter' && check.ok && onEnter?.()}
          className={cn('h-11 pl-7 pr-40 font-mono text-[15px] tracking-wide tnum', showError && 'border-[color-mix(in_oklab,var(--crit)_60%,transparent)]')}
        />
        <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">
          {country ? (
            <motion.span key={country.code} initial={{ opacity: 0, x: 4 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.18 }} className="inline-flex items-center gap-1.5 rounded-md bg-surface-3 px-2 py-0.5 text-[11.5px] font-medium text-ink-2">
              <span className="font-mono text-accent">+{country.code}</span>
              {country.name}
            </motion.span>
          ) : digits.length > 0 ? (
            <span className="text-[11.5px] text-ink-3">Country code?</span>
          ) : null}
        </div>
      </div>
      <p id={`${id}-hint`} className={cn('mt-1.5 min-h-[18px] text-[12px]', showError ? 'text-crit' : 'text-ink-3')} role={showError ? 'alert' : undefined}>
        {showError ? check.reason : hint}
      </p>
      {digits.length === 10 && (
        <div className="mt-2 flex flex-wrap items-center gap-2 rounded-lg border border-[color-mix(in_oklab,var(--warn)_40%,transparent)] bg-[color-mix(in_oklab,var(--warn)_10%,transparent)] px-3 py-2 text-[12px] text-ink-2" role="status">
          <span>
            That is 10 digits. WhatsApp needs the country code in front, or the pairing code never reaches the phone.
          </span>
          {localDialCode && (
            <button type="button" disabled={disabled} onClick={() => onChange(`${localDialCode}${digits}`)} className="app-no-drag rounded-md bg-surface-3 px-2 py-1 font-medium text-ink hover:bg-surface-2">
              Use +{localDialCode} {digits}
            </button>
          )}
        </div>
      )}
    </div>
  )
})

const DIAL_BY_REGION: Record<string, string> = { IN: '91', US: '1', CA: '1', GB: '44', AU: '61', AE: '971', SG: '65' }
const localDialCode: string | undefined = (() => {
  try {
    const region = new Intl.Locale(navigator.language).maximize().region
    return region ? DIAL_BY_REGION[region] : undefined
  } catch {
    return undefined
  }
})()

/* ── activity log ───────────────────────────────────────────────────────── */

/** `exclude`: a message already shown in an error callout, so the log does not repeat it. */
export function ActivityLog({ step, running, max = 5, exclude }: { step: SetupStepId; running?: boolean; max?: number; exclude?: string }) {
  const entries = useActivity(step)
  const shown = entries.filter((e) => !exclude || e.text !== exclude).slice(-max)
  return (
    <div className="mt-4 rounded-2xl border border-line bg-[color-mix(in_oklab,var(--surface)_60%,transparent)] px-4 py-3">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="label-micro">Activity</span>
          {running && (
            <span className="relative inline-grid size-2 place-items-center" aria-hidden>
              <span className="absolute inset-0 rounded-full bg-accent" style={{ animation: 'km-pulse-ring 1.8s ease-out infinite' }} />
              <span className="relative size-2 rounded-full bg-accent" />
            </span>
          )}
        </div>
        <span className="text-[11px] text-ink-3">{STEP_META[step].title}</span>
      </div>
      <div className="selectable space-y-1 font-mono text-[11.5px] leading-[1.55]" role="log" aria-live="off" aria-label={`${STEP_META[step].title} activity`}>
        {shown.length === 0 ? (
          <div className="text-ink-3">{running ? 'Listening…' : 'Nothing has happened yet.'}</div>
        ) : (
          shown.map((e, i) => {
            const fade = 0.45 + (0.55 * (i + 1)) / shown.length
            return (
              <motion.div key={`${e.ts}-${e.text}`} initial={{ opacity: 0, y: 4 }} animate={{ opacity: fade, y: 0 }} className="flex gap-3">
                <span className="shrink-0 text-ink-3 tnum">{formatClock(e.ts)}</span>
                <span className={cn('min-w-0 break-words', e.level === 'error' ? 'text-crit' : e.level === 'warn' ? 'text-warn' : 'text-ink-2')}>{e.text}</span>
              </motion.div>
            )
          })
        )}
      </div>
    </div>
  )
}

/* ── small pieces ───────────────────────────────────────────────────────── */

export function KeyValue({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-6 border-b border-line py-2.5 last:border-b-0">
      <dt className="text-[12.5px] text-ink-3">{label}</dt>
      <dd className="selectable min-w-0 text-right text-[13px] text-ink">{children}</dd>
    </div>
  )
}
