import { Suspense, useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { Monitor, Moon, Sun } from 'lucide-react'
import type { SetupState, SetupStepId } from '@shared/ipc'
import { IconButton, Skeleton } from '@/design/primitives'
import { useSetupState } from '@/lib/api/hooks'
import { isElectron } from '@/lib/bridge'
import { resolveTheme, useUi, type ThemePref } from '@/lib/stores'
import { Logo } from '@/shell/Logo'
import { useActivityFeed } from './activity'
import { Stepper } from './Stepper'
import { firstOpenStep, hasStarted, progressCount, STEP_ORDER, type View } from './wizard'
import { Binaries } from './panels/Binaries'
import { Config } from './panels/Config'
import { Finish } from './panels/Finish'
import { Lockdown } from './panels/Lockdown'
import { Model } from './panels/Model'
import { Operator } from './panels/Operator'
import { Prereqs } from './panels/Prereqs'
import { Services } from './panels/Services'
import { Verify } from './panels/Verify'
import { Welcome } from './panels/Welcome'
import { WhatsApp } from './panels/WhatsApp'
import type { PanelProps } from './panels/types'

const nextTheme: Record<ThemePref, ThemePref> = { dark: 'light', light: 'system', system: 'dark' }

const PANELS: Record<SetupStepId, (p: PanelProps) => React.JSX.Element> = {
  prereqs: Prereqs,
  model: Model,
  binaries: Binaries,
  config: Config,
  whatsapp: WhatsApp,
  services: Services,
  operator: Operator,
  lockdown: Lockdown,
  verify: Verify
}

/** The steps a person may open: everything up to and including the first one that has not passed. */
function reachableIndex(state: SetupState): number {
  const i = state.steps.findIndex((s) => s.status !== 'done' && s.status !== 'skipped')
  return i < 0 ? STEP_ORDER.length - 1 : i
}

function initialView(state: SetupState): View {
  if (state.completed) return 'finish'
  return 'welcome'
}

export default function SetupPage() {
  const state = useSetupState()
  useActivityFeed(state)
  const navigate = useNavigate()
  const theme = useUi((s) => s.theme)
  const setTheme = useUi((s) => s.setTheme)
  const [view, setView] = useState<View>()

  // The first snapshot decides where we land. After that only the person (or a panel's Continue) moves the view, so a
  // finished step stays on screen with its "Continue" button instead of being whisked away.
  useEffect(() => {
    if (state && !view) setView(initialView(state))
  }, [state, view])

  // The backend can change under us (reset from elsewhere, a step invalidated). Never sit on a panel that is now unreachable.
  useEffect(() => {
    if (!state || !view) return
    if (view === 'finish' && !state.completed && state.steps.every((s) => s.status === 'todo')) setView('welcome')
    else if (view !== 'welcome' && view !== 'finish' && STEP_ORDER.indexOf(view) > reachableIndex(state)) setView(firstOpenStep(state) ?? 'finish')
  }, [state, view])

  const next = useCallback(() => {
    if (!view || view === 'welcome' || view === 'finish') return
    const i = STEP_ORDER.indexOf(view)
    setView(i >= STEP_ORDER.length - 1 ? 'finish' : STEP_ORDER[i + 1])
  }, [view])

  const ThemeIcon = theme === 'dark' ? Moon : theme === 'light' ? Sun : Monitor

  const body = () => {
    if (!state || !view) {
      return (
        <div className="space-y-3 pt-6" aria-busy="true" aria-label="Loading setup">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-64 w-full" />
        </div>
      )
    }
    if (view === 'welcome') {
      return <Welcome key="welcome" resume={hasStarted(state) && !state.completed} done={progressCount(state)} onStart={() => setView(firstOpenStep(state) ?? 'finish')} />
    }
    if (view === 'finish') return <Finish key="finish" state={state} onOpen={() => navigate('/chat')} />
    const Panel = PANELS[view]
    const step = state.steps.find((s) => s.id === view)
    if (!step) return null
    return <Panel key={view} state={state} step={step} onNext={next} />
  }

  return (
    <div className="ambient relative flex h-full flex-col">
      <header className="app-drag relative z-20 flex h-10 shrink-0 items-center justify-between border-b border-line bg-panel/60 pl-4 backdrop-blur-xl" style={{ paddingRight: isElectron() ? 148 : 12 }}>
        <div className="flex items-center gap-2.5">
          <Logo size={20} />
          <span className="font-[family-name:var(--font-display)] text-[13px] font-semibold tracking-[0.16em]">KARMAX</span>
          <span className="ml-1 hidden text-[12px] text-ink-3 sm:inline">First-run setup</span>
        </div>
        <IconButton label={`Theme: ${theme} (click for ${nextTheme[theme]})`} onClick={() => setTheme(nextTheme[theme])} className="size-7">
          <ThemeIcon className="size-[15px]" />
        </IconButton>
      </header>
      <div className="relative z-10 grid min-h-0 flex-1 grid-cols-[280px_minmax(0,1fr)] gap-5 p-5 max-[900px]:grid-cols-1 max-[900px]:overflow-auto">
        {state && view ? (
          <Stepper
            state={state}
            view={view}
            onSelect={(id) => {
              setView(id)
            }}
          />
        ) : (
          <Skeleton className="h-full w-full rounded-2xl" />
        )}
        <main className="scroll-thin -mt-3 min-h-0 overflow-y-auto px-3 pt-3" aria-live="off">
          <div className="mx-auto max-w-[760px] pb-6">
            <Suspense fallback={null}>
              <AnimatePresence mode="wait" initial={false}>
                {body()}
              </AnimatePresence>
            </Suspense>
          </div>
        </main>
      </div>
    </div>
  )
}
