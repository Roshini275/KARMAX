// Screenshot driver for the first-run wizard (browser build + lib/webSetup.ts simulation).
//   node src/renderer/features/setup/dev/shots.mjs                       -> every scenario, dark, 1440x900
//   THEME=light W=1100 H=700 node .../shots.mjs flow                     -> just the main walkthrough
//   ONLY=fail-binaries,qr node .../shots.mjs                             -> named scenarios
// Env: REDUCED=1 emulates prefers-reduced-motion. BASE (default http://127.0.0.1:5173), OUT (default shots/a2), THEME, W, H, SPEED (simulation speed multiplier, default 0.35)
// Scenarios: flow, revisit, keyboard, claude-missing, claude-unauth, fail-binaries, fail-whatsapp, fail-operator, qr, own, resume, finish
// Needs the Vite dev server (`npx vite --config vite.web.config.ts`) and a Chromium under /opt/pw-browsers.
import { chromium } from 'playwright'
import { existsSync, mkdirSync, readdirSync } from 'node:fs'

const BASE = process.env.BASE || 'http://127.0.0.1:5173'
const OUT = process.env.OUT || 'shots/a2'
const THEME = process.env.THEME || 'dark'
const W = Number(process.env.W || 1440)
const H = Number(process.env.H || 900)
const SPEED = process.env.SPEED || '0.35'
const only = (process.env.ONLY || process.argv.slice(2).join(',')).split(',').filter(Boolean)
const tag = `${THEME}${W < 1200 ? `-${W}x${H}` : ''}`

function chromePath() {
  const root = '/opt/pw-browsers'
  if (!existsSync(root)) return undefined
  const dir = readdirSync(root).find((d) => /^chromium-\d+$/.test(d))
  return dir ? `${root}/${dir}/chrome-linux/chrome` : undefined
}

mkdirSync(OUT, { recursive: true })
const browser = await chromium.launch({ executablePath: chromePath(), args: ['--no-sandbox'] })
const errors = []

async function open(query) {
  const ctx = await browser.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1, colorScheme: THEME === 'light' ? 'light' : 'dark', reducedMotion: process.env.REDUCED ? 'reduce' : 'no-preference' })
  await ctx.addInitScript((t) => {
    try {
      localStorage.setItem('km.theme', t)
    } catch {}
  }, THEME)
  const page = await ctx.newPage()
  page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`))
  page.on('console', (m) => m.type() === 'error' && errors.push(`console.error: ${m.text()}`))
  await page.goto(`${BASE}/?setup=1&simspeed=${SPEED}&${query}#/setup`, { waitUntil: 'networkidle' })
  await page.waitForTimeout(700)
  return { page, ctx }
}

const shot = (page, scenario) => async (name, settle = 650) => {
  await page.waitForTimeout(settle)
  const file = `${OUT}/${scenario}-${name}-${tag}.png`
  await page.screenshot({ path: file })
  console.log('saved', file)
}
const btn = (page, name) => page.getByRole('button', { name })
const click = async (page, name, opts = {}) => {
  const b = btn(page, name).first()
  await b.waitFor({ state: 'visible', timeout: opts.timeout ?? 20000 })
  await b.waitFor({ state: 'attached' })
  await page.waitForFunction((el) => !el.disabled, await b.elementHandle(), { timeout: opts.timeout ?? 20000 })
  await b.click()
}
const KEY = 'sk-ant-api03-Zk3mQ8vR1nT6yH2pLdW9aXcE5uJ7bF4gS0tNoM1kPqA'

/* ── reusable step walkers ─────────────────────────────────────────────── */
const steps = {
  async prereqs(page, s) {
    await s('prereqs-checking', 300)
    await btn(page, /^Continue/).first().waitFor({ timeout: 15000 })
    await s('prereqs-done')
    await click(page, /^Continue/)
  },
  async model(page, s, { snaps = true } = {}) {
    await page.getByLabel('Anthropic API key').waitFor()
    if (snaps) await s('model-empty')
    await page.getByLabel('Anthropic API key').fill('abc123')
    await page.getByLabel('Anthropic API key').blur()
    if (snaps) await s('model-invalid', 200)
    await page.getByLabel('Anthropic API key').fill(KEY)
    await page.getByRole('button', { name: 'Show key' }).click()
    if (snaps) await s('model-typed', 200)
    await click(page, /Save key/)
    if (snaps) await s('model-saving', 250)
  },
  async binaries(page, s) {
    await btn(page, /Install and verify/).waitFor()
    await s('binaries-todo')
    await click(page, /Install and verify/)
    await s('binaries-installing', 1100)
    await btn(page, /^Continue/).first().waitFor({ timeout: 20000 })
    await s('binaries-done')
    await click(page, /^Continue/)
  },
  async config(page, s, { mode } = {}) {
    await page.getByLabel(/Your WhatsApp number/).waitFor()
    await s('config-empty')
    await page.getByLabel(/Your WhatsApp number/).fill('98765 43210')
    await s('config-short', 300)
    await page.getByLabel(/Your WhatsApp number/).fill('91 98765 43210')
    await s('config-dedicated', 300)
    if (mode === 'own') {
      await page.getByRole('radio', { name: /My own number/ }).click()
      await s('config-own', 300)
    }
    await click(page, /Save and continue/)
    await s('config-saving', 700)
  },
  async whatsapp(page, s, { qr = false, own = false } = {}) {
    await page.getByRole('heading', { name: /Link WhatsApp/ }).waitFor()
    if (qr) {
      await page.getByRole('tab', { name: /QR code/ }).click()
      await s('whatsapp-qr-form', 300)
      await click(page, /Show QR code/)
      await page.getByAltText('WhatsApp QR code').waitFor({ timeout: 10000 })
      await s('whatsapp-qr', 500)
    } else {
      if (!own) {
        await page.getByLabel(/Phone number of the KARMAX WhatsApp/).fill('91 98765 43210')
        await s('whatsapp-same-number', 300)
        await page.getByLabel(/Phone number of the KARMAX WhatsApp/).fill('1 555 123 0000')
      } else await s('whatsapp-own-form', 200)
      await s('whatsapp-form', 200)
      await click(page, /Get pairing code/)
      await s('whatsapp-requesting', 150)
      await page.getByRole('img', { name: /Pairing code/ }).waitFor({ timeout: 10000 })
      await s('whatsapp-code', 900)
    }
    await btn(page, /^Continue/).first().waitFor({ timeout: 25000 })
    await s('whatsapp-done')
    await click(page, /^Continue/)
  },
  async services(page, s) {
    await btn(page, /^Start services$/).waitFor()
    await s('services-todo')
    await click(page, /^Start services$/)
    await s('services-starting', 800)
    await btn(page, /^Continue/).first().waitFor({ timeout: 20000 })
    await s('services-done')
    await click(page, /^Continue/)
  },
  async operator(page, s, { fail = false } = {}) {
    await page.getByRole('heading', { name: /Say hi to KARMAX|KARMAX heard you/ }).waitFor()
    await s('operator-waiting', 900)
    if (fail) {
      await btn(page, /^Retry/).waitFor({ timeout: 20000 })
      await s('operator-failed')
      await click(page, /^Retry/)
      await s('operator-retry', 600)
    }
    await btn(page, /^Continue/).first().waitFor({ timeout: 25000 })
    await s('operator-done')
    await click(page, /^Continue/)
  },
  async lockdown(page, s) {
    await btn(page, /Lock everything except me/).waitFor()
    await s('lockdown-todo')
    await click(page, /Lock everything except me/)
    await s('lockdown-running', 900)
    await btn(page, /^Continue/).first().waitFor({ timeout: 20000 })
    await s('lockdown-done')
    await click(page, /^Continue/)
  },
  async verify(page, s) {
    await btn(page, /Send test message/).waitFor()
    await s('verify-todo')
    await click(page, /Send test message/)
    await s('verify-sending', 500)
    await page.getByRole('heading', { name: 'KARMAX is online' }).waitFor({ timeout: 15000 })
    await s('finish', 1400)
  }
}

const scenarios = {
  async flow() {
    const { page, ctx } = await open('')
    const s = shot(page, 'flow')
    await s('welcome', 900)
    await click(page, /Get started/)
    await steps.prereqs(page, s)
    await steps.model(page, s)
    await steps.binaries(page, s)
    await steps.config(page, s)
    await steps.whatsapp(page, s)
    await steps.services(page, s)
    await steps.operator(page, s)
    await steps.lockdown(page, s)
    await steps.verify(page, s)
    await ctx.close()
  },
  async 'claude-missing'() {
    const { page, ctx } = await open('claude=missing')
    const s = shot(page, 'claude-missing')
    await click(page, /Get started/)
    await btn(page, /^Continue/).first().waitFor({ timeout: 15000 })
    await s('prereqs')
    await ctx.close()
  },
  async 'claude-unauth'() {
    const { page, ctx } = await open('claude=unauth')
    const s = shot(page, 'claude-unauth')
    await click(page, /Get started/)
    await btn(page, /^Continue/).first().waitFor({ timeout: 15000 })
    await s('prereqs')
    await ctx.close()
  },
  async 'fail-binaries'() {
    const { page, ctx } = await open('setupat=binaries&setupfail=binaries')
    const s = shot(page, 'fail-binaries')
    await click(page, /Continue setup/)
    await click(page, /Install and verify/)
    await btn(page, /Try again/).waitFor({ timeout: 20000 })
    await s('error')
    await ctx.close()
  },
  async 'fail-whatsapp'() {
    const { page, ctx } = await open('setupat=whatsapp&setupfail=whatsapp')
    const s = shot(page, 'fail-whatsapp')
    await click(page, /Continue setup/)
    await page.getByLabel(/Phone number of the KARMAX WhatsApp/).fill('1 555 123 0000')
    await click(page, /Get pairing code/)
    await btn(page, /Start again/).waitFor({ timeout: 25000 })
    await s('error', 900)
    await ctx.close()
  },
  async 'fail-operator'() {
    const { page, ctx } = await open('setupat=services&setupfail=operator')
    const s = shot(page, 'fail-operator')
    await click(page, /Continue setup/)
    await steps.services(page, s)
    await steps.operator(page, s, { fail: true })
    await ctx.close()
  },
  async qr() {
    const { page, ctx } = await open('setupat=whatsapp')
    const s = shot(page, 'qr')
    await click(page, /Continue setup/)
    await steps.whatsapp(page, s, { qr: true })
    await ctx.close()
  },
  async own() {
    const { page, ctx } = await open('setupat=config')
    const s = shot(page, 'own')
    await click(page, /Continue setup/)
    await steps.config(page, s, { mode: 'own' })
    await steps.whatsapp(page, s, { own: true })
    await steps.services(page, s)
    await s('operator-own', 900)
    await ctx.close()
  },
  async resume() {
    const { page, ctx } = await open('setupat=whatsapp')
    const s = shot(page, 'resume')
    await s('welcome-back', 900)
    await ctx.close()
  },
  async revisit() {
    const { page, ctx } = await open('setupat=whatsapp')
    const s = shot(page, 'revisit')
    await click(page, /Continue setup/)
    await page.getByRole('heading', { name: /Link WhatsApp/ }).waitFor()
    await page.getByRole('button', { name: /^Model access/ }).click()
    await s('model-done', 700)
    await page.getByRole('button', { name: /^Operator number/ }).click()
    await s('config-done', 700)
    // A step that is not reachable yet must be disabled.
    const locked = await page.getByRole('button', { name: /Lock down chats/ }).isDisabled()
    console.log('lockdown step disabled while earlier steps are open:', locked)
    await ctx.close()
  },
  async keyboard() {
    const { page, ctx } = await open('setupat=model')
    const s = shot(page, 'keyboard')
    await page.keyboard.press('Tab')
    await page.keyboard.press('Tab')
    await s('focus-stepper', 300)
    await page.getByRole('button', { name: /Continue setup/ }).focus()
    await page.keyboard.press('Enter')
    await page.getByLabel('Anthropic API key').waitFor()
    await page.keyboard.type(KEY)
    await page.keyboard.press('Enter') // submits the form
    await page.getByRole('button', { name: /Install and verify/ }).waitFor({ timeout: 10000 })
    console.log('keyboard-only: key saved and moved on to Install')
    await s('after-enter', 400)
    await ctx.close()
  },
  async finish() {
    const { page, ctx } = await open('setupat=finish')
    const s = shot(page, 'finish')
    await s('done', 1400)
    await ctx.close()
  }
}

for (const [name, fn] of Object.entries(scenarios)) {
  if (only.length && !only.includes(name)) continue
  try {
    await fn()
  } catch (e) {
    console.log(`SCENARIO FAILED ${name}: ${e.message.split('\n')[0]}`)
  }
}
if (errors.length) {
  console.log('\nBROWSER ERRORS:')
  for (const e of [...new Set(errors)]) console.log(' -', e)
}
await browser.close()
