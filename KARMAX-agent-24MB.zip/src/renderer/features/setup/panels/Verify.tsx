import { ArrowRight, CheckCheck, Send } from 'lucide-react'
import { Button } from '@/design/primitives'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, ErrorCallout, PanelFrame, useAction } from '../ui'
import { formatPhone } from '../phone'
import type { PanelProps } from './types'

export function Verify({ state, step, onNext }: PanelProps) {
  const send = useAction(() => getBridge().setup.sendTestMessage())
  const active = step.status === 'active' || send.pending
  const done = step.status === 'done'
  const number = state.operatorNumber ? formatPhone(state.operatorNumber) : 'your phone'
  const go = async () => {
    if (await send.run()) onNext()
  }
  return (
    <PanelFrame
      step="verify"
      icon={<Send className="size-5" />}
      title="One last thing: a real message"
      lead={`KARMAX will send a test message to ${number} through the whole chain: daemon, tool call, wacli, WhatsApp.`}
      footer={
        <>
          <span className="text-[12px] text-ink-3">{done ? step.detail : 'Check your phone after sending.'}</span>
          {done ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              Finish
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={active} onClick={() => void go()} icon={!active ? <Send className="size-4" /> : undefined}>
              {active ? 'Sending…' : step.status === 'error' ? 'Send again' : 'Send test message'}
            </Button>
          )}
        </>
      }
    >
      <div className="rounded-2xl border border-line bg-[color-mix(in_oklab,var(--page)_45%,var(--surface))] p-5">
        <div className="mb-3 flex items-center gap-2 text-[11.5px] text-ink-3">
          <span className="grid size-6 place-items-center rounded-full bg-accent-soft text-[10px] font-semibold text-accent">K</span>
          Preview of what arrives on WhatsApp
        </div>
        <div className="max-w-[420px] rounded-2xl rounded-tl-md bg-surface-3 px-4 py-2.5 text-[13.5px] leading-relaxed shadow-sm">
          KARMAX is online. This is the setup test message. Reply here any time to give me a task.
          <span className="mt-1 flex items-center justify-end gap-1 text-[10.5px] text-ink-3">
            now
            <CheckCheck className="size-3.5 text-accent" />
          </span>
        </div>
      </div>
      <div aria-live="polite" className="sr-only">
        {step.detail}
      </div>
      <div className="mt-3">
        <ErrorCallout message={send.error ?? (step.status === 'error' ? step.error : undefined)} title="The test message did not go out" />
      </div>
      {(active || step.status === 'error' || !!send.error) && <ActivityLog step="verify" running={active} exclude={send.error ?? step.error} />}
    </PanelFrame>
  )
}
