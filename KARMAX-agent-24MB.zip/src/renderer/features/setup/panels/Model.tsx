import { useState } from 'react'
import { ArrowRight, Check, ExternalLink, Eye, EyeOff, KeyRound, Lock, TerminalSquare } from 'lucide-react'
import { Button, Input } from '@/design/primitives'
import { cn } from '@/design/cn'
import { getBridge } from '@/lib/bridge'
import { Callout, ErrorCallout, PanelFrame, useAction } from '../ui'
import { ANTHROPIC_KEYS_URL, type PanelProps } from './types'

/** Same shape check as electron/main/setup/env.ts validateApiKey: a sanity check, the real verdict comes from Anthropic. */
function checkKey(raw: string): { ok: boolean; reason?: string } {
  const k = raw.trim()
  if (!k) return { ok: false }
  if (/\s/.test(k)) return { ok: false, reason: 'Keys never contain spaces. Paste just the key.' }
  if (!k.startsWith('sk-ant-')) return { ok: false, reason: 'Anthropic API keys start with "sk-ant-".' }
  if (k.length < 24) return { ok: false, reason: 'That looks too short to be a full key.' }
  return { ok: true }
}

type Mode = 'claude' | 'key'

function Choice({ active, onClick, icon, title, body }: { active: boolean; onClick: () => void; icon: React.ReactNode; title: string; body: string }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      className={cn(
        'app-no-drag flex flex-1 items-start gap-3 rounded-xl border px-4 py-3 text-left transition-colors',
        active ? 'border-accent bg-accent-soft' : 'border-line bg-surface-2/40 hover:border-line-strong'
      )}
    >
      <span className={cn('mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg', active ? 'bg-accent text-white' : 'bg-surface-3 text-ink-2')}>{icon}</span>
      <span className="min-w-0">
        <span className="block text-[13px] font-semibold text-ink">{title}</span>
        <span className="mt-0.5 block text-[12px] leading-relaxed text-ink-3">{body}</span>
      </span>
    </button>
  )
}

export function Model({ state, step, onNext }: PanelProps) {
  const saved = step.status === 'done'
  const [replacing, setReplacing] = useState(false)
  const [mode, setMode] = useState<Mode>(state.modelAuth === 'api-key' ? 'key' : 'claude')
  const [key, setKey] = useState('')
  const [show, setShow] = useState(false)
  const [touched, setTouched] = useState(false)
  const saveKey = useAction(async (k: string) => {
    await getBridge().setup.saveModelKey(k)
    setKey('')
    setReplacing(false)
  })
  const saveClaude = useAction(async () => {
    await getBridge().setup.saveModelClaudeCode()
    setReplacing(false)
  })
  const check = checkKey(key)
  const showEntry = !saved || replacing
  const busy = saveKey.pending || saveClaude.pending || step.status === 'active'
  const error = saveKey.error ?? saveClaude.error ?? (step.status === 'error' ? step.error : undefined)

  const submitKey = async () => {
    if (!check.ok || busy) return
    if (await saveKey.run(key.trim())) onNext()
  }
  const submitClaude = async () => {
    if (busy) return
    if (await saveClaude.run()) onNext()
  }

  return (
    <PanelFrame
      step="model"
      icon={mode === 'claude' && showEntry ? <TerminalSquare className="size-5" /> : <KeyRound className="size-5" />}
      title="Give KARMAX a model to think with"
      lead="KARMAX's brain is Claude. Use the Claude Code you are already signed in to, or bring your own Anthropic API key. There is no KARMAX account."
      footer={
        showEntry ? (
          <>
            {saved ? (
              <Button variant="ghost" onClick={() => setReplacing(false)}>
                Keep current setting
              </Button>
            ) : mode === 'key' ? (
              <Button variant="ghost" onClick={() => void getBridge().app.openExternal(ANTHROPIC_KEYS_URL)} icon={<ExternalLink className="size-3.5" />}>
                Get a key
              </Button>
            ) : null}
            {mode === 'claude' ? (
              <Button variant="primary" size="lg" loading={busy} onClick={() => void submitClaude()}>
                {busy ? 'Saving…' : 'Use Claude Code'}
                {!busy && <ArrowRight className="size-4" />}
              </Button>
            ) : (
              <Button variant="primary" size="lg" disabled={!check.ok} loading={busy} onClick={() => void submitKey()}>
                {busy ? 'Checking key…' : 'Save key'}
                {!busy && <ArrowRight className="size-4" />}
              </Button>
            )}
          </>
        ) : (
          <>
            <Button variant="ghost" onClick={() => setReplacing(true)}>
              Change
            </Button>
            <Button variant="primary" size="lg" onClick={onNext}>
              Continue
              <ArrowRight className="size-4" />
            </Button>
          </>
        )
      }
    >
      {showEntry ? (
        <>
          <div role="radiogroup" aria-label="How KARMAX reaches Claude" className="mb-4 flex flex-col gap-2 sm:flex-row">
            <Choice active={mode === 'claude'} onClick={() => setMode('claude')} icon={<TerminalSquare className="size-4" />} title="Claude Code login (no API key)" body="Uses the claude CLI you are signed in to. Runs on your Claude plan." />
            <Choice active={mode === 'key'} onClick={() => setMode('key')} icon={<KeyRound className="size-4" />} title="Anthropic API key" body="Pay Anthropic per use. Also powers memory search and summaries." />
          </div>

          {mode === 'claude' ? (
            <div className="space-y-3">
              <Callout tone="info">
                KARMAX will run every chat and task through the <span className="font-mono">claude</span> command on this PC, using your existing sign-in. Nothing is stored except a local API token and webhook secret.
              </Callout>
              <p className="text-[12px] leading-relaxed text-ink-3">
                Heavy use draws on your Claude plan limits, and KARMAX steps down to a cheaper model when it has used its share. Features that need a separate API key, such as memory search summaries, may be limited.
              </p>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault()
                void submitKey()
              }}
            >
              <label htmlFor="setup-key" className="mb-1.5 block text-[12.5px] font-medium">
                Anthropic API key
              </label>
              <div className="relative">
                <Input
                  id="setup-key"
                  type={show ? 'text' : 'password'}
                  autoComplete="off"
                  spellCheck={false}
                  disabled={busy}
                  placeholder="sk-ant-api03-…"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  onBlur={() => setTouched(true)}
                  aria-invalid={(touched && !!check.reason) || undefined}
                  aria-describedby="setup-key-hint"
                  className={cn('h-11 pr-11 font-mono text-[13.5px]', touched && check.reason && 'border-[color-mix(in_oklab,var(--crit)_60%,transparent)]')}
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  aria-label={show ? 'Hide key' : 'Show key'}
                  aria-pressed={show}
                  className="app-no-drag absolute right-1.5 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-md text-ink-3 transition-colors hover:bg-surface-3 hover:text-ink"
                >
                  {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              <p id="setup-key-hint" className={cn('mt-1.5 min-h-[18px] text-[12px]', touched && check.reason ? 'text-crit' : 'text-ink-3')} role={touched && check.reason ? 'alert' : undefined}>
                {touched && check.reason ? check.reason : check.ok ? 'Looks like a valid key. KARMAX checks it with Anthropic before saving.' : 'Create one in the Anthropic Console under Settings, then API keys.'}
              </p>
              <div className="mt-4 flex items-start gap-3 rounded-xl border border-line bg-surface-2/40 px-4 py-3">
                <Lock className="mt-0.5 size-4 shrink-0 text-ink-3" />
                <p className="text-[12.5px] leading-relaxed text-ink-2">
                  Stored locally in <span className="font-mono text-ink">~/.karmax/.env</span> on this PC and sent only to Anthropic. It is never shown again, logged, or uploaded anywhere else.
                </p>
              </div>
              <input type="submit" hidden />
            </form>
          )}
        </>
      ) : (
        <div className="flex items-center gap-4 rounded-xl border border-line bg-surface-2/40 px-4 py-4">
          <div className="grid size-10 shrink-0 place-items-center rounded-full text-white" style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))' }}>
            <Check className="size-5" strokeWidth={3} />
          </div>
          <div className="min-w-0">
            <div className="text-[13.5px] font-semibold">Model ready</div>
            <div className="selectable text-[12.5px] text-ink-3">{step.detail ?? 'Stored in ~/.karmax/.env.'}</div>
          </div>
        </div>
      )}
      {showEntry && step.status === 'active' && !saveKey.pending && !saveClaude.pending && <Callout tone="info" className="mt-3">Working on it. {step.detail}</Callout>}
      <div className="mt-3">
        <ErrorCallout message={error} title="Could not save that" />
      </div>
    </PanelFrame>
  )
}
