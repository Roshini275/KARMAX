import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Check, MessageSquareText, Smartphone, UserRound } from 'lucide-react'
import type { WaMode } from '@shared/ipc'
import { Button } from '@/design/primitives'
import { cn } from '@/design/cn'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, Callout, ErrorCallout, PanelFrame, PhoneField, useAction, useMotionSafe } from '../ui'
import { formatPhone, normalizePhone, validatePhone } from '../phone'
import { useWizardStore } from '../wizard'
import type { PanelProps } from './types'

const MODES: { id: WaMode; title: string; tag: string; icon: typeof Smartphone; body: string; points: string[] }[] = [
  {
    id: 'dedicated',
    title: 'Dedicated number',
    tag: 'Recommended',
    icon: Smartphone,
    body: 'A separate WhatsApp number that belongs to KARMAX (a spare SIM or a business line). You chat with it like with a colleague.',
    points: ['Two-way: you message it, it replies', 'Your own WhatsApp is never automated']
  },
  {
    id: 'own',
    title: 'My own number',
    tag: 'Advanced',
    icon: UserRound,
    body: 'Link KARMAX to your personal WhatsApp account and use "Message yourself" as the channel.',
    points: ['KARMAX can message you, but cannot read what you type to yourself', 'Puts your personal account at risk']
  }
]

export function Config({ state, step, onNext }: PanelProps) {
  const store = useWizardStore()
  const seeded = useRef(false)
  // Resume: put back what the backend already stored so the form never looks blank after a restart.
  useEffect(() => {
    if (seeded.current) return
    seeded.current = true
    if (state.operatorNumber && !store.operatorInput) store.setOperatorInput(state.operatorNumber)
    if (state.waMode) store.setWaMode(state.waMode)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const { reduce } = useMotionSafe()
  const mode = store.waMode
  const digits = normalizePhone(store.operatorInput)
  const check = validatePhone(store.operatorInput)
  const done = step.status === 'done'
  const unchanged = done && state.operatorNumber === digits && state.waMode === mode
  const save = useAction(async () => {
    await getBridge().setup.writeConfig({ operatorNumber: digits, waMode: mode })
  })
  const active = step.status === 'active' || save.pending
  const go = async () => {
    if (!check.ok || active) return
    if (unchanged) return onNext()
    if (await save.run()) onNext()
  }

  return (
    <PanelFrame
      step="config"
      icon={<MessageSquareText className="size-5" />}
      title="Who is allowed to give orders?"
      lead="KARMAX will only ever obey one WhatsApp number: yours. Every other chat is locked out later in setup."
      footer={
        <>
          <span className="text-[12px] text-ink-3">{digits ? <>Operator: <span className="font-mono text-ink-2">{formatPhone(digits)}</span></> : 'Enter your number to continue.'}</span>
          <Button variant="primary" size="lg" disabled={!check.ok} loading={active} onClick={() => void go()}>
            {active ? 'Writing config…' : unchanged ? 'Continue' : done ? 'Update and continue' : 'Save and continue'}
            {!active && <ArrowRight className="size-4" />}
          </Button>
        </>
      }
    >
      <PhoneField
        id="setup-operator"
        label="Your WhatsApp number (the operator)"
        value={store.operatorInput}
        onChange={store.setOperatorInput}
        hint="Country code first, no leading 0 or +. For example 91 for India, 1 for the US or Canada."
        disabled={active}
        autoFocus
        onEnter={() => void go()}
      />
      <div role="radiogroup" aria-label="How KARMAX reaches WhatsApp" className="mt-3 grid grid-cols-2 gap-3">
        {MODES.map((m) => {
          const on = mode === m.id
          const Icon = m.icon
          return (
            <motion.button
              key={m.id}
              type="button"
              role="radio"
              aria-checked={on}
              disabled={active}
              onClick={() => store.setWaMode(m.id)}
              whileTap={reduce ? undefined : { scale: 0.99 }}
              className={cn(
                'app-no-drag relative rounded-xl border p-4 text-left transition-colors disabled:opacity-60',
                on ? 'border-accent bg-accent-soft' : 'border-line bg-surface-2/40 hover:border-line-strong hover:bg-surface-2/70'
              )}
              style={on ? { boxShadow: '0 0 0 1px var(--accent), 0 8px 28px -14px var(--accent)' } : undefined}
            >
              <div className="flex items-center gap-2.5">
                <span className={cn('grid size-8 shrink-0 place-items-center rounded-lg', on ? 'bg-accent text-white' : 'bg-surface-3 text-ink-2')}>
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[13.5px] font-semibold leading-tight">{m.title}</span>
                  <span className={cn('block text-[11px] font-semibold uppercase tracking-[0.08em]', m.id === 'dedicated' ? 'text-accent' : 'text-ink-3')}>{m.tag}</span>
                </span>
                <span className={cn('grid size-[18px] shrink-0 place-items-center rounded-full border', on ? 'border-accent bg-accent text-white' : 'border-line-strong')} aria-hidden>
                  {on && <Check className="size-3" strokeWidth={3.4} />}
                </span>
              </div>
              <p className="mt-2.5 text-[12.5px] leading-relaxed text-ink-2">{m.body}</p>
              <ul className="mt-2 space-y-1">
                {m.points.map((p) => (
                  <li key={p} className="flex gap-2 text-[12px] leading-snug text-ink-3">
                    <span aria-hidden className="mt-[7px] size-1 shrink-0 rounded-full bg-ink-3" />
                    {p}
                  </li>
                ))}
              </ul>
            </motion.button>
          )
        })}
      </div>
      {mode === 'own' && (
        <Callout tone="warn" className="mt-3" title="WhatsApp can ban automated personal accounts">
          Linking software to your personal WhatsApp can get that number banned, and you could lose the account. Use it only if you accept that risk. A dedicated number is the safe choice.
        </Callout>
      )}
      {mode === 'dedicated' && (
        <Callout tone="info" className="mt-3">
          Automating any WhatsApp account is against WhatsApp's terms and can get a number banned. Use a number you can afford to lose, never your personal one.
        </Callout>
      )}
      <div className="mt-3">
        <ErrorCallout message={save.error ?? (step.status === 'error' ? step.error : undefined)} title="Could not write the config" />
      </div>
      {(active || save.error) && <ActivityLog step="config" running={active} exclude={save.error ?? step.error} />}
    </PanelFrame>
  )
}
