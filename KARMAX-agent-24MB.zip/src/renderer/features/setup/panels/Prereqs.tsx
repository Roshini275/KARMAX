import { useEffect, useRef, useState, type ReactNode } from 'react'
import { ArrowRight, ExternalLink, Monitor, Network, RefreshCw, Terminal } from 'lucide-react'
import type { PrereqReport } from '@shared/ipc'
import { Button } from '@/design/primitives'
import { StatusPill, type Tone } from '@/design/status'
import { getBridge } from '@/lib/bridge'
import { CopyChip, ErrorCallout, PanelFrame, useAction, Callout } from '../ui'
import { CLAUDE_DOCS_URL, type PanelProps } from './types'

function CheckRow({ icon, title, value, pill, children }: { icon: ReactNode; title: string; value: ReactNode; pill: ReactNode; children?: ReactNode }) {
  return (
    <div className="rounded-xl border border-line bg-surface-2/40 px-4 py-3">
      <div className="flex items-center gap-3.5">
        <div className="grid size-9 shrink-0 place-items-center rounded-lg bg-surface-3 text-ink-2">{icon}</div>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-semibold">{title}</div>
          <div className="selectable truncate text-[12.5px] text-ink-3">{value}</div>
        </div>
        {pill}
      </div>
      {children && <div className="mt-3 border-t border-line pt-3">{children}</div>}
    </div>
  )
}

export function Prereqs({ step, onNext }: PanelProps) {
  const setup = getBridge().setup
  const [report, setReport] = useState<PrereqReport>()
  const check = useAction(async () => setReport(await setup.checkPrereqs()))
  const started = useRef(false)
  useEffect(() => {
    if (started.current) return
    started.current = true
    void check.run()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const checking = check.pending || !report
  const claude = report?.claudeCli
  const claudeTone: Tone = !claude ? 'muted' : !claude.found ? 'warn' : claude.loggedIn === false ? 'warn' : 'good'
  const claudeLabel = !claude ? 'Checking' : !claude.found ? 'Not found' : claude.loggedIn === false ? 'Not signed in' : claude.loggedIn === undefined ? 'Found' : 'Ready'
  const portsOk = report?.ports.free !== false
  const clean = !!report && report.ok && claude?.loggedIn !== false

  return (
    <PanelFrame
      step="prereqs"
      icon={<Monitor className="size-5" />}
      title="Let's check this PC"
      lead="KARMAX hands real coding work to the Claude Code CLI and listens on three local ports. Nothing is installed in this step."
      footer={
        <>
          <Button variant="ghost" onClick={() => void check.run()} loading={check.pending} icon={<RefreshCw className="size-3.5" />}>
            Re-check
          </Button>
          {report && portsOk ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              {clean ? 'Continue' : 'Continue anyway'}
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={check.pending} onClick={() => void check.run()}>
              {report ? 'Re-check ports' : 'Checking…'}
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-2.5" aria-live="polite" aria-busy={checking}>
        <CheckRow icon={<Monitor className="size-4" />} title="Operating system" value={report?.os ?? 'Detecting…'} pill={report ? <StatusPill tone="good" label="Supported" /> : <StatusPill tone="accent" label="Checking" />} />
        <CheckRow
          icon={<Terminal className="size-4" />}
          title="Claude Code CLI"
          value={!claude ? 'Looking for it…' : claude.found ? `Version ${claude.version ?? 'unknown'}` : 'Not installed'}
          pill={<StatusPill tone={claude ? claudeTone : 'accent'} label={claudeLabel} />}
        >
          {claude && (!claude.found || claude.loggedIn !== true) && claude.hint && (
            <div className="space-y-2.5">
              <p className="text-[12.5px] leading-relaxed text-ink-2">{claude.hint}</p>
              <div className="flex flex-wrap items-center gap-2">
                {!claude.found && (
                  <Button size="sm" onClick={() => void getBridge().app.openExternal(CLAUDE_DOCS_URL)} icon={<ExternalLink className="size-3.5" />}>
                    Install guide
                  </Button>
                )}
                <CopyChip text="claude" label="Copy: claude" />
                <span className="text-[12px] text-ink-3">then sign in once. You can also continue and fix this later.</span>
              </div>
            </div>
          )}
        </CheckRow>
        <CheckRow
          icon={<Network className="size-4" />}
          title="Local ports"
          value={
            <span className="font-mono">
              {report?.ports.karmax ?? 9091} API · {report?.ports.wacli ?? 8765} wacli · {report?.ports.webhooks ?? 9090} webhook
            </span>
          }
          pill={<StatusPill tone={!report ? 'accent' : report.ports.free ? 'good' : 'crit'} label={!report ? 'Checking' : report.ports.free ? (report.ports.busyBy ? 'Adopting' : 'Free') : 'In use'} />}
        >
          {report?.ports.busyBy && <p className="text-[12.5px] leading-relaxed text-ink-2">{report.ports.busyBy}.{!report.ports.free && ' Close that program, then re-check.'}</p>}
        </CheckRow>
      </div>
      {report && claude && !claude.found && (
        <Callout tone="warn" className="mt-3" title="Coding tasks will not run without Claude Code">
          You can finish setup now and install it later. KARMAX will chat and use WhatsApp, but delegated tasks will fail until it is installed and signed in.
        </Callout>
      )}
      <ErrorCallout message={check.error ?? (step.status === 'error' && !report ? step.error : undefined)} />
    </PanelFrame>
  )
}
