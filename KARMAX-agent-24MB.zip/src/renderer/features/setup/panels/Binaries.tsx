import { ArrowRight, Check, CircleDashed, Download, FolderOpen, PackageCheck, ShieldCheck } from 'lucide-react'
import { Button } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { cn } from '@/design/cn'
import { getBridge } from '@/lib/bridge'
import { useActivity } from '../activity'
import { ActivityLog, ErrorCallout, PanelFrame, useAction } from '../ui'
import type { PanelProps } from './types'

function Row({ name, role, state, note }: { name: string; role: string; state: 'todo' | 'active' | 'done'; note: string }) {
  return (
    <div className="flex items-center gap-3.5 rounded-xl border border-line bg-surface-2/40 px-4 py-3">
      <div className={cn('grid size-9 shrink-0 place-items-center rounded-lg', state === 'done' ? 'bg-[color-mix(in_oklab,var(--good)_16%,transparent)] text-good' : 'bg-surface-3 text-ink-2')}>
        {state === 'done' ? <Check className="size-4" strokeWidth={3} /> : state === 'active' ? <Download className="size-4" /> : <CircleDashed className="size-4" />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span className="font-mono text-[13px] font-semibold">{name}</span>
          <span className="text-[12px] text-ink-3">{role}</span>
        </div>
        <div className="truncate text-[12px] text-ink-3">{note}</div>
      </div>
      <StatusPill tone={state === 'done' ? 'good' : state === 'active' ? 'accent' : 'muted'} label={state === 'done' ? 'Verified' : state === 'active' ? 'Installing' : 'Waiting'} />
    </div>
  )
}

export function Binaries({ step, onNext }: PanelProps) {
  const install = useAction(() => getBridge().setup.installBinaries())
  const active = step.status === 'active' || install.pending
  const done = step.status === 'done'
  const error = install.error ?? (step.status === 'error' ? step.error : undefined)
  const seen = useActivity('binaries')
  const d = (step.detail ?? '').toLowerCase() + ' ' + seen.slice(-6).map((e) => e.text.toLowerCase()).join(' ')
  const kState: 'todo' | 'active' | 'done' = done || d.includes('wacli') ? 'done' : active ? 'active' : 'todo'
  const wState: 'todo' | 'active' | 'done' = done ? 'done' : active && d.includes('wacli') ? 'active' : 'todo'

  return (
    <PanelFrame
      step="binaries"
      icon={<PackageCheck className="size-5" />}
      title="Install KARMAX and wacli"
      lead="Two small programs do the work: karmax runs the agent and wacli talks to WhatsApp. Each is checked against a SHA-256 hash before it is used."
      footer={
        <>
          <span className="flex items-center gap-2 text-[12px] text-ink-3">
            <ShieldCheck className="size-3.5" />
            Nothing runs until its hash matches.
          </span>
          {done ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              Continue
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={active} onClick={() => void install.run()}>
              {active ? 'Installing…' : step.status === 'error' ? 'Try again' : 'Install and verify'}
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-2.5">
        <Row name="karmax" role="agent daemon" state={kState} note={done ? 'Hash verified' : 'Go daemon: agents, tools, memory'} />
        <Row name="wacli" role="WhatsApp bridge" state={wState} note={done ? 'Hash verified' : 'Sends and receives WhatsApp messages'} />
      </div>
      <div className="mt-3 flex items-center gap-2 text-[12px] text-ink-3">
        <FolderOpen className="size-3.5 shrink-0" />
        <span>
          Installed for your account only, into <span className="font-mono text-ink-2">%LOCALAPPDATA%\KARMAX</span>. No administrator rights needed.
        </span>
      </div>
      <div aria-live="polite" className="sr-only">
        {step.detail}
      </div>
      <div className="mt-3">
        <ErrorCallout message={error} title="Could not install" />
      </div>
      {(active || done || error) && <ActivityLog step="binaries" running={active} exclude={error} />}
    </PanelFrame>
  )
}
