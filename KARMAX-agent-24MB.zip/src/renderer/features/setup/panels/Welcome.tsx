import { motion } from 'framer-motion'
import { ArrowRight, HardDrive, RotateCw, ShieldCheck } from 'lucide-react'
import { Button } from '@/design/primitives'
import { Logo } from '@/shell/Logo'
import { useMotionSafe } from '../ui'
import { STEP_ORDER } from '../wizard'

const points = [
  { icon: <ShieldCheck className="size-4" />, title: 'Only you give orders', body: 'Every WhatsApp chat except yours gets locked.' },
  { icon: <HardDrive className="size-4" />, title: 'Everything stays here', body: 'Your key and data live in ~/.karmax on this PC.' },
  { icon: <RotateCw className="size-4" />, title: 'Pick up any time', body: 'Progress is saved after every step.' }
]

export function Welcome({ resume, done, onStart }: { resume: boolean; done?: number; onStart: () => void }) {
  const { reduce } = useMotionSafe()
  return (
    <motion.section aria-labelledby="setup-welcome" initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: reduce ? 0 : 0.4, ease: [0.22, 1, 0.36, 1] }} className="mx-auto flex max-w-[640px] flex-col items-center pt-10 text-center">
      <div className="relative mb-7 grid size-28 place-items-center">
        <motion.div
          aria-hidden
          className="absolute inset-0 rounded-full opacity-80 blur-2xl"
          style={{ background: 'conic-gradient(from 0deg, var(--accent), var(--accent-2), var(--accent))' }}
          animate={reduce ? undefined : { rotate: 360 }}
          transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
        />
        <div aria-hidden className="absolute inset-3 rounded-full ring-1 ring-line-strong" />
        <motion.div aria-hidden className="absolute inset-0" animate={reduce ? undefined : { rotate: 360 }} transition={{ duration: 9, repeat: Infinity, ease: 'linear' }}>
          <span className="absolute left-1/2 top-0 size-2 -translate-x-1/2 rounded-full bg-accent" style={{ boxShadow: '0 0 12px 2px var(--accent)' }} />
        </motion.div>
        <div className="relative rounded-[26px] bg-page/70 p-3 shadow-pop ring-1 ring-line-strong backdrop-blur">
          <Logo size={56} />
        </div>
      </div>
      <div className="label-micro">{resume ? 'Welcome back' : 'First-run setup'}</div>
      <h2 id="setup-welcome" className="mt-2 font-[family-name:var(--font-display)] text-[36px] font-semibold leading-[1.1] tracking-tight">
        {resume ? 'Pick up where you left off' : "Let's bring KARMAX online"}
      </h2>
      <p className="mt-3 max-w-[50ch] text-[14.5px] leading-relaxed text-ink-2">
        {resume && done
          ? `${done} of ${STEP_ORDER.length} steps are done and saved. Everything you already finished is kept, so this picks up at the next step.`
          : `${STEP_ORDER.length} short steps: check this PC, add your Anthropic key, install KARMAX, link WhatsApp, and lock everything down except you. You will need your phone for two of them.`}
      </p>
      <div className="mt-7 grid w-full grid-cols-3 gap-3 text-left">
        {points.map((p, i) => (
          <motion.div key={p.title} initial={reduce ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: reduce ? 0 : 0.15 + i * 0.07 }} className="glass rounded-2xl p-4">
            <div className="mb-2.5 grid size-8 place-items-center rounded-lg bg-accent-soft text-accent">{p.icon}</div>
            <div className="text-[13px] font-semibold">{p.title}</div>
            <div className="mt-0.5 text-[12px] leading-snug text-ink-3">{p.body}</div>
          </motion.div>
        ))}
      </div>
      <Button variant="primary" size="lg" className="mt-8 min-w-[200px]" onClick={onStart} icon={undefined} autoFocus>
        {resume ? 'Continue setup' : 'Get started'}
        <ArrowRight className="size-4" />
      </Button>
      <p className="mt-3 text-[12px] text-ink-3">About five minutes.</p>
    </motion.section>
  )
}
