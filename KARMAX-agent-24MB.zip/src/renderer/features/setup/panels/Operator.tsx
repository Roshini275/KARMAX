import type { ReactNode } from 'react'
import { ArrowRight, Ear, RefreshCw, Send, UserRound } from 'lucide-react'
import { motion } from 'framer-motion'
import { Button } from '@/design/primitives'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, Callout, ErrorCallout, PanelFrame, useAction, useMotionSafe } from '../ui'
import { formatPhone } from '../phone'
import { useWizardStore } from '../wizard'
import type { PanelProps } from './types'

function Node({ icon, title, sub }: { icon: ReactNode; title: string; sub: string }) {
  return (
    <div className="flex min-w-0 flex-col items-center gap-2 text-center">
      <div className="grid size-14 place-items-center rounded-2xl bg-surface-3 text-ink ring-1 ring-line-strong">{icon}</div>
      <div>
        <div className="text-[13px] font-semibold">{title}</div>
        <div className="max-w-[170px] truncate font-mono text-[11.5px] text-ink-3">{sub}</div>
      </div>
    </div>
  )
}

function Flow({ waiting, from, to }: { waiting: boolean; from: string; to: string }) {
  const { reduce } = useMotionSafe()
  return (
    <div className="grid grid-cols-[1fr_minmax(80px,1.2fr)_1fr] items-center gap-2 rounded-2xl border border-line bg-surface-2/40 px-6 py-6">
      <Node icon={<UserRound className="size-6" />} title="You" sub={from} />
      <div className="relative h-8" aria-hidden>
        <div className="absolute inset-x-0 top-1/2 h-px bg-line-strong" />
        {waiting && !reduce && [0, 1, 2].map((i) => (
          <motion.span key={i} className="absolute top-1/2 size-2 -translate-y-1/2 rounded-full bg-accent" style={{ boxShadow: '0 0 10px var(--accent)' }} initial={{ left: '0%', opacity: 0 }} animate={{ left: ['0%', '96%'], opacity: [0, 1, 1, 0] }} transition={{ duration: 2.4, repeat: Infinity, delay: i * 0.8, ease: 'easeInOut' }} />
        ))}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-line-strong bg-surface px-2.5 py-0.5 font-mono text-[11.5px] text-ink-2">"hi"</div>
      </div>
      <Node icon={<Ear className="size-6" />} title="KARMAX" sub={to} />
    </div>
  )
}

export function Operator({ state, step, onNext }: PanelProps) {
  const retry = useAction(() => getBridge().setup.startServices())
  const storeMode = useWizardStore((s) => s.waMode)
  const mode = state.waMode ?? storeMode
  const own = mode === 'own'
  const number = state.operatorNumber ? formatPhone(state.operatorNumber) : 'your number'
  const done = step.status === 'done'
  const waiting = step.status === 'active'
  const failed = step.status === 'error' || !!retry.error

  return (
    <PanelFrame
      step="operator"
      icon={<Ear className="size-5" />}
      title={done ? 'KARMAX heard you' : 'Say hi to KARMAX'}
      lead="WhatsApp only tells KARMAX about a chat once a message has arrived in it. Send one message and KARMAX will scope its webhook to that chat and nothing else."
      footer={
        <>
          <span className="text-[12px] text-ink-3">{waiting ? 'This step waits up to 10 minutes.' : done ? 'The operator chat is registered.' : failed ? 'Send the message first, then retry.' : 'Nothing is watched until you press Start listening.'}</span>
          {done ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              Continue
              <ArrowRight className="size-4" />
            </Button>
          ) : waiting ? (
            <Button variant="primary" size="lg" disabled loading>
              Waiting for your message…
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={retry.pending} onClick={() => void retry.run()} icon={!retry.pending ? failed ? <RefreshCw className="size-4" /> : <Send className="size-4" /> : undefined}>
              {failed ? 'Retry' : 'Start listening'}
            </Button>
          )}
        </>
      }
    >
      <Flow waiting={waiting} from={number} to={own ? 'Message yourself' : 'the KARMAX number'} />
      {waiting && step.detail && (
        <div className="selectable mt-3 rounded-xl border border-line bg-surface-2/40 px-4 py-3 text-[13px] leading-relaxed text-ink-2" role="status" aria-live="polite">
          {step.detail}
        </div>
      )}
      {!waiting && !done && !failed && (
        <p className="mt-3 text-[13px] leading-relaxed text-ink-2">
          {own ? 'When you are ready, press Start listening, then send "hi" to yourself in WhatsApp.' : `When you are ready, press Start listening, then send "hi" from ${number} to the KARMAX number.`}
        </p>
      )}
      {own && (
        <Callout tone="warn" className="mt-3" title="Own-number mode is receive-only for KARMAX">
          Messages you type to yourself arrive as "sent by you", which KARMAX ignores. KARMAX can message you, but tasks have to be started from this app. A dedicated number gives you real two-way chat.
        </Callout>
      )}
      <div className="mt-3">
        <ErrorCallout message={retry.error ?? (step.status === 'error' ? step.error : undefined)} title="No message yet" />
      </div>
      {(waiting || done || failed) && <ActivityLog step="operator" running={waiting} exclude={waiting ? step.detail : retry.error ?? step.error} />}
    </PanelFrame>
  )
}
