import type { SetupState, SetupStep } from '@shared/ipc'

export interface PanelProps {
  state: SetupState
  step: SetupStep
  /** Move the wizard to the next step's panel. */
  onNext: () => void
}

export const CLAUDE_DOCS_URL = 'https://docs.claude.com/en/docs/claude-code/setup'
export const ANTHROPIC_KEYS_URL = 'https://console.anthropic.com/settings/keys'
