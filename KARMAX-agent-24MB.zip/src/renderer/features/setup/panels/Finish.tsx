import { motion } from 'framer-motion'
import { ArrowRight, Check, Send } from 'lucide-react'
import { Button, Card } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { getBridge } from '@/lib/bridge'
import { ErrorCallout, KeyValue, useAction, useMotionSafe } from '../ui'
import { formatPhone } from '../phone'
import { STEP_META } from '../wizard'
import type { SetupState } from '@shared/ipc'

export function Finish({ state, onOpen }: { state: SetupState; onOpen: () => void }) {
  const { reduce } = useMotionSafe()
  const again = useAction(() => getBridge().setup.sendTestMessage())
  const warned = state.steps.filter((s) => s.status === 'skipped')
  const detail = (id: string) => state.steps.find((s) => s.id === id)?.detail
  const own = state.waMode === 'own'
  return (
    <motion.section aria-labelledby="setup-finish" initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: reduce ? 0 : 0.4, ease: [0.22, 1, 0.36, 1] }} className="mx-auto max-w-[640px]">
      <div className="flex flex-col items-center pb-6 pt-4 text-center">
        <div className="relative mb-6 grid size-24 place-items-center">
          <motion.span aria-hidden className="absolute inset-0 rounded-full" style={{ background: 'radial-gradient(closest-side, color-mix(in oklab, var(--good) 35%, transparent), transparent)' }} animate={reduce ? undefined : { scale: [1, 1.18, 1], opacity: [0.8, 0.4, 0.8] }} transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }} />
          <svg width="88" height="88" viewBox="0 0 88 88" className="relative -rotate-90" aria-hidden>
            <defs>
              <linearGradient id="km-finish-ring" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="var(--accent)" />
                <stop offset="1" stopColor="var(--accent-2)" />
              </linearGradient>
            </defs>
            <circle cx="44" cy="44" r="40" fill="color-mix(in oklab, var(--surface) 80%, transparent)" stroke="var(--line-strong)" strokeWidth="2" />
            <motion.circle cx="44" cy="44" r="40" fill="none" stroke="url(#km-finish-ring)" strokeWidth="4" strokeLinecap="round" strokeDasharray={251.3} initial={reduce ? false : { strokeDashoffset: 251.3 }} animate={{ strokeDashoffset: 0 }} transition={{ duration: reduce ? 0 : 0.9, ease: [0.22, 1, 0.36, 1] }} />
          </svg>
          <motion.span className="absolute text-accent" initial={reduce ? false : { scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: reduce ? 0 : 0.5, type: 'spring', stiffness: 380, damping: 20 }}>
            <Check className="size-10" strokeWidth={3} />
          </motion.span>
        </div>
        <div className="label-micro">Setup complete</div>
        <h2 id="setup-finish" tabIndex={-1} style={{ outline: 'none' }} className="mt-2 font-[family-name:var(--font-display)] text-[34px] font-semibold leading-tight tracking-tight">
          KARMAX is online
        </h2>
        <p className="mt-2.5 max-w-[46ch] text-[14px] leading-relaxed text-ink-2">
          {own ? 'Your number is linked and every other chat is locked out. KARMAX can message you on WhatsApp; start tasks from the chat page.' : 'Message the KARMAX number from your phone and it will answer. Every other chat is locked out.'}
        </p>
        <Button variant="primary" size="lg" className="mt-6 min-w-[200px]" onClick={onOpen} autoFocus>
          Open KARMAX
          <ArrowRight className="size-4" />
        </Button>
      </div>

      <Card className="px-6 py-2">
        <dl>
          <KeyValue label="Operator">{state.operatorNumber ? <span className="font-mono">{formatPhone(state.operatorNumber)}</span> : 'Not set'}</KeyValue>
          <KeyValue label="Channel">{own ? 'Own WhatsApp number (receive-only)' : 'Dedicated WhatsApp number'}</KeyValue>
          <KeyValue label="Model access">{state.modelAuth === 'claude-code' ? 'Claude Code sign-in (no API key)' : state.hasApiKey ? 'Anthropic key saved locally' : <StatusPill tone="warn" label="No key" />}</KeyValue>
          <KeyValue label="Programs">{detail('binaries') ?? 'Installed'}</KeyValue>
          <KeyValue label="Chat lockdown">{detail('lockdown') ?? 'Applied'}</KeyValue>
          <KeyValue label="Last test">{detail('verify') ?? 'Sent'}</KeyValue>
        </dl>
      </Card>
      {warned.length > 0 && (
        <p className="mt-3 text-center text-[12px] text-warn">
          Passed with a warning: {warned.map((w) => STEP_META[w.id].title).join(', ')}.
        </p>
      )}
      <div className="mt-4 flex flex-col items-center gap-2">
        <Button variant="ghost" size="sm" loading={again.pending} onClick={() => void again.run()} icon={!again.pending ? <Send className="size-3.5" /> : undefined}>
          Send another test message
        </Button>
        <ErrorCallout message={again.error} title="The test message did not go out" />
      </div>
    </motion.section>
  )
}
