import { ArrowRight, BellOff, Lock, ShieldCheck, UserCheck } from 'lucide-react'
import { Button } from '@/design/primitives'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, ErrorCallout, PanelFrame, useAction } from '../ui'
import { formatPhone } from '../phone'
import type { PanelProps } from './types'

export function Lockdown({ state, step, onNext }: PanelProps) {
  const lock = useAction(() => getBridge().setup.applyOperatorLockdown())
  const active = step.status === 'active' || lock.pending
  const done = step.status === 'done'
  const number = state.operatorNumber ? formatPhone(state.operatorNumber) : 'the operator'
  const effects = [
    { icon: <Lock className="size-4" />, title: 'Every other chat is locked', body: 'Friends, family and groups can never reach KARMAX or be read by it.' },
    { icon: <UserCheck className="size-4" />, title: `${number} stays open`, body: 'Your chat is the only one wacli will deliver and the only one KARMAX may answer.' },
    { icon: <BellOff className="size-4" />, title: 'Do Not Disturb turns on', body: 'wacli refuses to send anywhere except unlocked chats. It is checked again afterwards.' }
  ]
  return (
    <PanelFrame
      step="lockdown"
      icon={<ShieldCheck className="size-5" />}
      title="Lock everything except you"
      lead="This is the safety step. It changes wacli, not your phone: nothing is deleted and you can unlock a chat later from the WhatsApp page."
      footer={
        <>
          <span className="text-[12px] text-ink-3">{done ? 'Verified by reading the chat list back.' : 'It is re-read afterwards to prove it worked.'}</span>
          {done ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              Continue
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={active} onClick={() => void lock.run()} icon={!active ? <Lock className="size-4" /> : undefined}>
              {active ? 'Locking…' : step.status === 'error' ? 'Try again' : 'Lock everything except me'}
            </Button>
          )}
        </>
      }
    >
      <ul className="space-y-2.5">
        {effects.map((e) => (
          <li key={e.title} className="flex items-start gap-3.5 rounded-xl border border-line bg-surface-2/40 px-4 py-3">
            <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-accent-soft text-accent">{e.icon}</span>
            <div>
              <div className="text-[13px] font-semibold">{e.title}</div>
              <div className="text-[12.5px] leading-snug text-ink-3">{e.body}</div>
            </div>
          </li>
        ))}
      </ul>
      <div aria-live="polite" className="sr-only">
        {step.detail}
      </div>
      {done && step.detail && <p className="selectable mt-3 text-[12.5px] text-ink-2">{step.detail}</p>}
      <div className="mt-3">
        <ErrorCallout message={lock.error ?? (step.status === 'error' ? step.error : undefined)} title="Lockdown was not applied" />
      </div>
      {(active || (step.status === 'error' && !!step.error) || !!lock.error) && <ActivityLog step="lockdown" running={active} exclude={lock.error ?? step.error} />}
    </PanelFrame>
  )
}
