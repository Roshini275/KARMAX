import type { ReactNode } from 'react'
import { ArrowRight, Check, CircleDashed, MessageCircle, Play, Server, TriangleAlert } from 'lucide-react'
import { motion } from 'framer-motion'
import { Button, Spinner } from '@/design/primitives'
import { StatusPill } from '@/design/status'
import { cn } from '@/design/cn'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, ErrorCallout, PanelFrame, useAction } from '../ui'
import { useActivity } from '../activity'
import type { PanelProps } from './types'

type TileState = 'todo' | 'active' | 'done' | 'error'

function Tile({ icon, name, role, port, state }: { icon: ReactNode; name: string; role: string; port: string; state: TileState }) {
  const tone = state === 'done' ? 'good' : state === 'active' ? 'accent' : state === 'error' ? 'crit' : 'muted'
  const label = state === 'done' ? 'Healthy' : state === 'active' ? 'Starting' : state === 'error' ? 'Failed' : 'Stopped'
  return (
    <div className={cn('relative overflow-hidden rounded-xl border bg-surface-2/40 p-4 transition-colors', state === 'done' ? 'border-[color-mix(in_oklab,var(--good)_40%,var(--line))]' : state === 'error' ? 'border-[color-mix(in_oklab,var(--crit)_45%,var(--line))]' : 'border-line')}>
      <div className="flex items-start justify-between">
        <div className={cn('grid size-10 place-items-center rounded-xl', state === 'done' ? 'bg-[color-mix(in_oklab,var(--good)_16%,transparent)] text-good' : state === 'active' ? 'bg-accent-soft text-accent' : 'bg-surface-3 text-ink-2')}>{icon}</div>
        <StatusPill tone={tone} label={label} />
      </div>
      <div className="mt-3 flex items-center gap-2">
        <span className="font-mono text-[14px] font-semibold">{name}</span>
        {state === 'active' && <Spinner className="size-3.5 text-accent" />}
        {state === 'done' && <Check className="size-3.5 text-good" strokeWidth={3} />}
        {state === 'error' && <TriangleAlert className="size-3.5 text-crit" />}
        {state === 'todo' && <CircleDashed className="size-3.5 text-ink-3" />}
      </div>
      <div className="text-[12.5px] text-ink-3">{role}</div>
      <div className="mt-2 font-mono text-[11.5px] text-ink-3">127.0.0.1:{port}</div>
      {state === 'active' && (
        <motion.span aria-hidden className="absolute inset-x-0 bottom-0 h-[2px]" style={{ background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }} animate={{ x: ['-100%', '100%'] }} transition={{ duration: 1.6, repeat: Infinity, ease: 'linear' }} />
      )}
    </div>
  )
}

export function Services({ step, onNext }: PanelProps) {
  const start = useAction(() => getBridge().setup.startServices())
  const active = step.status === 'active' || start.pending
  const done = step.status === 'done'
  const failed = step.status === 'error' || !!start.error
  const seen = useActivity('services')
  const text = ((step.detail ?? '') + ' ' + seen.slice(-4).map((e) => e.text).join(' ')).toLowerCase()
  const waState: TileState = done || text.includes('starting karmax') || text.includes('wacli is healthy') || text.includes('karmax is healthy') ? 'done' : active ? 'active' : failed && !text.includes('karmax') ? 'error' : 'todo'
  const kxState: TileState = done ? 'done' : failed ? 'error' : active && waState === 'done' ? 'active' : 'todo'
  const go = async () => {
    await start.run()
  }

  return (
    <PanelFrame
      step="services"
      icon={<Server className="size-5" />}
      title="Start the engines"
      lead="KARMAX Desktop now launches wacli first (it owns the WhatsApp session), then the KARMAX daemon, and waits until both answer their health checks."
      footer={
        <>
          <span className="text-[12px] text-ink-3">Both run in the background and are restarted if they crash.</span>
          {done ? (
            <Button variant="primary" size="lg" onClick={onNext}>
              Continue
              <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button variant="primary" size="lg" loading={active} onClick={() => void go()} icon={!active ? <Play className="size-4" /> : undefined}>
              {active ? 'Starting…' : failed ? 'Try again' : 'Start services'}
            </Button>
          )}
        </>
      }
    >
      <div className="grid grid-cols-2 gap-3">
        <Tile icon={<MessageCircle className="size-5" />} name="wacli" role="WhatsApp bridge" port="8765" state={waState} />
        <Tile icon={<Server className="size-5" />} name="karmax" role="Agent daemon and API" port="9091" state={kxState} />
      </div>
      <div aria-live="polite" className="sr-only">
        {step.detail}
      </div>
      <div className="mt-3">
        <ErrorCallout message={start.error ?? (step.status === 'error' ? step.error : undefined)} title="Services did not start" />
      </div>
      {(active || done || failed) && <ActivityLog step="services" running={active} exclude={start.error ?? step.error} />}
    </PanelFrame>
  )
}
