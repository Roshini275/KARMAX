import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, Check, QrCode, Smartphone, X } from 'lucide-react'
import type { PairingState } from '@shared/ipc'
import { Button, Segmented, Spinner } from '@/design/primitives'
import { cn } from '@/design/cn'
import { getBridge } from '@/lib/bridge'
import { ActivityLog, Callout, CopyChip, ErrorCallout, PanelFrame, PhoneField, useAction, useMotionSafe } from '../ui'
import { formatPhone, normalizePhone, validatePhone } from '../phone'
import { useWizardStore } from '../wizard'
import type { PanelProps } from './types'

/** wacli prints 8 characters; WhatsApp shows them as two groups of four. */
function splitCode(code: string): [string, string] {
  const c = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase()
  return [c.slice(0, 4), c.slice(4, 8)]
}

function CodeTiles({ code }: { code: string }) {
  const { reduce } = useMotionSafe()
  const groups = splitCode(code)
  return (
    <div className="flex items-center justify-center gap-4" role="img" aria-label={`Pairing code: ${groups.join(' ').split('').join(' ')}`}>
      {groups.map((g, gi) => (
        <div key={gi} className="flex items-center gap-4">
          {gi === 1 && <span aria-hidden className="h-1 w-3.5 rounded-full bg-line-strong" />}
          <div className="flex gap-2">
            {g.split('').map((ch, i) => (
              <motion.span
                key={`${gi}${i}${ch}`}
                initial={reduce ? false : { opacity: 0, y: 10, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: reduce ? 0 : (gi * 4 + i) * 0.045, duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="selectable grid h-[68px] w-[50px] place-items-center rounded-xl border border-line-strong bg-[color-mix(in_oklab,var(--page)_55%,var(--surface))] font-mono text-[38px] font-semibold leading-none text-ink"
                style={{ boxShadow: 'inset 0 1px 0 color-mix(in oklab, var(--ink) 6%, transparent), 0 10px 26px -16px var(--accent)' }}
              >
                {ch}
              </motion.span>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

function Steps({ items, cols }: { items: string[]; cols?: boolean }) {
  return (
    <ol className={cols ? 'grid grid-cols-2 gap-x-6 gap-y-2.5' : 'space-y-2'}>
      {items.map((t, i) => (
        <li key={t} className="flex items-start gap-3 text-[13px] leading-snug text-ink-2">
          <span className="mt-px grid size-5 shrink-0 place-items-center rounded-full bg-surface-3 text-[11px] font-semibold text-ink tnum">{i + 1}</span>
          <span>{t}</span>
        </li>
      ))}
    </ol>
  )
}

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`

function useElapsed(running: boolean): number {
  const [s, setS] = useState(0)
  useEffect(() => {
    if (!running) return setS(0)
    const t0 = Date.now()
    const id = window.setInterval(() => setS(Math.floor((Date.now() - t0) / 1000)), 1000)
    return () => window.clearInterval(id)
  }, [running])
  return s
}

export function WhatsApp({ state, step, onNext }: PanelProps) {
  const store = useWizardStore()
  const setup = getBridge().setup
  const pairing: PairingState | undefined = state.pairing
  const mode = state.waMode ?? store.waMode
  const dedicated = mode !== 'own'
  const method = pairing?.running ? pairing.method : store.pairMethod
  const operator = state.operatorNumber ?? ''

  // In own-number mode the phone that gets linked IS the operator's phone, so we can pre-fill it.
  const seeded = useRef(false)
  useEffect(() => {
    if (seeded.current) return
    seeded.current = true
    if (!dedicated && !store.pairPhone && operator) store.setPairPhone(operator)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const digits = normalizePhone(store.pairPhone)
  const check = validatePhone(store.pairPhone)
  const sameAsOperator = dedicated && !!digits && digits === operator
  const needsPhone = method === 'code'
  const canStart = (!needsPhone || (check.ok && !sameAsOperator)) && !sameAsOperator

  const start = useAction(() => setup.startPairing({ method: store.pairMethod, ...(store.pairMethod === 'code' ? { phone: digits } : {}) }))
  const cancel = useAction(() => setup.cancelPairing())

  const done = step.status === 'done'
  const running = !!pairing?.running || (step.status === 'active' && !done)
  const linked = running && /linked|syncing/i.test(step.detail ?? '')
  const elapsed = useElapsed(running && !linked)
  const failure = start.error ?? cancel.error ?? pairing?.error ?? (step.status === 'error' ? step.error : undefined)

  const label = dedicated ? 'Phone number of the KARMAX WhatsApp' : 'Your own WhatsApp number'
  const hint = dedicated ? 'The dedicated number you are linking, not your operator number.' : 'The number of the phone you will scan or pair with.'

  const footer = done ? (
    <>
      <span className="flex items-center gap-2 text-[12.5px] text-good">
        <Check className="size-4" strokeWidth={3} />
        WhatsApp is linked
      </span>
      <Button variant="primary" size="lg" onClick={onNext}>
        Continue
        <ArrowRight className="size-4" />
      </Button>
    </>
  ) : running ? (
    <>
      <Button variant="ghost" loading={cancel.pending} onClick={() => void cancel.run()} icon={<X className="size-3.5" />}>
        Cancel
      </Button>
      <Button variant="primary" size="lg" disabled>
        {linked ? 'Syncing chats…' : 'Waiting for your phone…'}
      </Button>
    </>
  ) : (
    <>
      <span className="text-[12px] text-ink-3">{needsPhone ? 'Takes about a minute.' : 'You will scan a QR code with your phone.'}</span>
      <Button variant="primary" size="lg" disabled={!canStart} loading={start.pending} onClick={() => void start.run()} icon={!start.pending ? <Smartphone className="size-4" /> : undefined}>
        {failure ? 'Start again' : needsPhone ? 'Get pairing code' : 'Show QR code'}
      </Button>
    </>
  )

  return (
    <PanelFrame
      step="whatsapp"
      icon={<Smartphone className="size-5" />}
      title={done ? 'WhatsApp is linked' : 'Link WhatsApp'}
      lead={
        done
          ? step.detail ?? 'wacli is paired with the phone.'
          : dedicated
            ? 'Pair the KARMAX number with wacli, the same way you would link WhatsApp Web. Have that phone in your hand.'
            : 'Pair your own WhatsApp account with wacli, the same way you would link WhatsApp Web. Have your phone in your hand.'
      }
      footer={footer}
    >
      <AnimatePresence mode="wait" initial={false}>
        {!running && !done && (
          <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, transition: { duration: 0.1 } }}>
            <Segmented
              value={store.pairMethod}
              onChange={store.setPairMethod}
              className="mb-4"
              options={[
                { value: 'code', label: <>Pairing code</> },
                { value: 'qr', label: <><QrCode className="size-3.5" />QR code</> }
              ]}
            />
            {needsPhone ? (
              <PhoneField id="setup-pair-phone" label={label} value={store.pairPhone} onChange={store.setPairPhone} hint={hint} autoFocus onEnter={() => canStart && void start.run()} />
            ) : (
              <Callout tone="info">
                A QR code appears here in a few seconds. It refreshes about every 20 seconds, so scan the one on screen.
              </Callout>
            )}
            {sameAsOperator && (
              <Callout tone="warn" className="mt-1" title="That is your operator number">
                In dedicated mode KARMAX gets its own number. Enter the second number here, or go back one step and choose "My own number".
              </Callout>
            )}
          </motion.div>
        )}

        {running && (
          <motion.div key="pairing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, transition: { duration: 0.1 } }} className="space-y-4">
            {pairing?.method === 'qr' || method === 'qr' ? (
              <div className="grid grid-cols-[auto_1fr] items-center gap-6 rounded-2xl border border-line bg-surface-2/40 p-5 max-[900px]:grid-cols-1">
                <div className="grid size-[208px] place-items-center rounded-xl bg-white p-2.5 shadow-pop">
                  {pairing?.qrDataUri ? <img src={pairing.qrDataUri} alt="WhatsApp QR code" className="size-full [image-rendering:pixelated]" /> : <Spinner className="size-6 text-neutral-400" />}
                </div>
                <div>
                  <div className="label-micro mb-2">Scan with your phone</div>
                  <Steps items={['Open WhatsApp on the phone', 'Settings, then Linked devices, then Link a device', 'Point the camera at this code']} />
                  {!pairing?.qrDataUri && elapsed > 8 && (
                    <Callout tone="warn" className="mt-3">
                      No QR yet. Give it a few more seconds. If it never appears, cancel and try again, or use a pairing code.
                    </Callout>
                  )}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-line bg-surface-2/40 px-5 pb-4 pt-3.5">
                <div className="mb-3 flex items-center justify-between">
                  <span className="label-micro">Your pairing code</span>
                  {pairing?.code && <CopyChip text={pairing.code} label="Copy code" />}
                </div>
                {pairing?.code ? (
                  <CodeTiles code={pairing.code} />
                ) : (
                  <div className="flex h-[68px] items-center justify-center gap-3 text-[13px] text-ink-3" role="status">
                    <Spinner />
                    Requesting a code from WhatsApp…
                  </div>
                )}
                <div className="mt-4 border-t border-line pt-3.5">
                  <Steps
                    cols
                    items={[
                      `Open WhatsApp on the phone${digits ? ` with ${formatPhone(digits)}` : ''}`,
                      'Settings, then Linked devices, then Link a device',
                      'Tap "Link with phone number instead" at the bottom',
                      'Type the code above'
                    ]}
                  />
                </div>
              </div>
            )}
            <div className="flex items-center gap-3 rounded-xl border border-line px-4 py-2 text-[12.5px]" role="status" aria-live="polite">
              {linked ? <Check className="size-4 text-good" strokeWidth={3} /> : <Spinner className="text-accent" />}
              <span className="text-ink-2">{linked ? 'Linked. Syncing your chats so KARMAX knows who is who…' : pairing?.code || pairing?.qrDataUri ? 'Waiting for you to finish on the phone…' : 'Getting ready…'}</span>
              {!linked && elapsed > 0 && <span className="ml-auto font-mono text-ink-3 tnum">{mmss(elapsed)}</span>}
            </div>
          </motion.div>
        )}

        {done && (
          <motion.div key="done" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-4 rounded-xl border border-line bg-surface-2/40 px-4 py-4">
            <div className={cn('grid size-10 shrink-0 place-items-center rounded-full text-white')} style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))' }}>
              <Check className="size-5" strokeWidth={3} />
            </div>
            <div className="min-w-0">
              <div className="text-[13.5px] font-semibold">Paired</div>
              <div className="selectable text-[12.5px] text-ink-3">Chats are synced. You can unlink KARMAX any time from WhatsApp, Linked devices.</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="mt-3">
        <ErrorCallout message={failure} title="Pairing did not finish" />
      </div>
      {(running || failure) && <ActivityLog step="whatsapp" running={running} max={running ? 3 : 5} exclude={failure} />}
    </PanelFrame>
  )
}
