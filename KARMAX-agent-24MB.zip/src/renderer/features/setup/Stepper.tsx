import { motion } from 'framer-motion'
import { Check, LoaderCircle, Minus, TriangleAlert } from 'lucide-react'
import type { SetupState, SetupStep, SetupStepId } from '@shared/ipc'
import { cn } from '@/design/cn'
import { truncate } from '@/lib/format'
import { useMotionSafe } from './ui'
import { progressCount, STEP_META, STEP_ORDER, type View } from './wizard'

export function ProgressRing({ value, total, size = 60 }: { value: number; total: number; size?: number }) {
  const { reduce } = useMotionSafe()
  const stroke = 5
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} role="img" aria-label={`${value} of ${total} steps complete`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90 overflow-visible">
        <defs>
          <linearGradient id="km-setup-ring" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="var(--accent)" />
            <stop offset="1" stopColor="var(--accent-2)" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="url(#km-setup-ring)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          initial={false}
          animate={{ strokeDashoffset: c * (1 - value / total) }}
          transition={reduce ? { duration: 0 } : { type: 'spring', stiffness: 90, damping: 20 }}
          style={{ filter: 'drop-shadow(0 0 5px color-mix(in oklab, var(--accent) 55%, transparent))' }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center font-[family-name:var(--font-display)] text-[15px] font-semibold tnum">
        {value}
        <span className="-ml-1 mt-0.5 self-center text-[10.5px] font-medium text-ink-3">/{total}</span>
      </div>
    </div>
  )
}

function Node({ status, index }: { status: SetupStep['status']; index: number }) {
  const base = 'relative z-10 grid size-7 shrink-0 place-items-center rounded-full text-[11.5px] font-semibold transition-colors'
  if (status === 'done')
    return (
      <span className={cn(base, 'text-white')} style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))', boxShadow: '0 0 14px -2px color-mix(in oklab, var(--accent) 55%, transparent)' }}>
        <Check className="size-3.5" strokeWidth={3.2} />
      </span>
    )
  if (status === 'active')
    return (
      <span className={cn(base, 'bg-accent-soft text-accent ring-2 ring-accent')} style={{ boxShadow: 'var(--glow-accent)' }}>
        <LoaderCircle className="size-3.5 animate-[km-spin_0.9s_linear_infinite]" strokeWidth={2.6} />
      </span>
    )
  if (status === 'error')
    return (
      <span className={cn(base, 'text-crit ring-2')} style={{ background: 'color-mix(in oklab, var(--crit) 14%, transparent)', ['--tw-ring-color' as string]: 'color-mix(in oklab, var(--crit) 55%, transparent)' }}>
        <TriangleAlert className="size-3.5" strokeWidth={2.6} />
      </span>
    )
  if (status === 'skipped')
    return (
      <span className={cn(base, 'text-warn ring-2')} style={{ background: 'color-mix(in oklab, var(--warn) 14%, transparent)', ['--tw-ring-color' as string]: 'color-mix(in oklab, var(--warn) 45%, transparent)' }}>
        <Minus className="size-3.5" strokeWidth={3} />
      </span>
    )
  return <span className={cn(base, 'bg-surface-2 text-ink-3 ring-1 ring-line-strong tnum')}>{index + 1}</span>
}

const STATUS_LABEL: Record<SetupStep['status'], string> = { todo: '', active: 'In progress', done: 'Done', error: 'Needs attention', skipped: 'Passed with a warning' }

export function Stepper({ state, view, onSelect }: { state: SetupState; view: View; onSelect: (id: SetupStepId) => void }) {
  const { reduce } = useMotionSafe()
  const done = progressCount(state)
  const firstOpen = state.steps.findIndex((s) => s.status !== 'done' && s.status !== 'skipped')
  const reachable = firstOpen < 0 ? STEP_ORDER.length - 1 : firstOpen

  return (
    <aside className="glass flex min-h-0 flex-col rounded-2xl p-4" aria-label="Setup progress">
      <div className="mb-3 flex items-center gap-3.5 px-1 pt-1">
        <ProgressRing value={done} total={STEP_ORDER.length} />
        <div className="min-w-0">
          <div className="font-[family-name:var(--font-display)] text-[15px] font-semibold leading-tight">First-run setup</div>
          <div className="mt-0.5 text-[12px] text-ink-3">{state.completed ? 'All done' : done === 0 ? 'Not started' : `${STEP_ORDER.length - done} to go`}</div>
        </div>
      </div>
      <ol className="scroll-thin -mx-1 min-h-0 flex-1 overflow-auto px-1">
        {state.steps.map((s, i) => {
          const meta = STEP_META[s.id]
          const selected = view === s.id
          const canOpen = i <= reachable
          const sub = s.status === 'error' ? STATUS_LABEL.error : s.status === 'todo' ? meta.blurb : s.detail ? truncate(s.detail, 64) : STATUS_LABEL[s.status]
          return (
            <li key={s.id} className="relative">
              {i < state.steps.length - 1 && (
                <span aria-hidden className="absolute left-[13.5px] top-[36px] h-[calc(100%-30px)] w-[2px] overflow-hidden rounded-full bg-line-strong">
                  <motion.span
                    className="block h-full w-full origin-top"
                    style={{ background: 'linear-gradient(var(--accent), var(--accent-2))' }}
                    initial={false}
                    animate={{ scaleY: s.status === 'done' || s.status === 'skipped' ? 1 : 0 }}
                    transition={reduce ? { duration: 0 } : { duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  />
                </span>
              )}
              <button
                type="button"
                disabled={!canOpen}
                aria-current={selected ? 'step' : undefined}
                onClick={() => onSelect(s.id)}
                className={cn(
                  'app-no-drag relative flex w-full items-start gap-3 rounded-xl px-2 py-2 text-left transition-colors',
                  canOpen ? 'hover:bg-surface-2/70' : 'cursor-default opacity-60',
                  selected && 'hover:bg-transparent'
                )}
              >
                {selected && (
                  <motion.span
                    layoutId="setup-stepper-active"
                    className="absolute inset-0 rounded-xl bg-surface-2 ring-1 ring-line-strong"
                    transition={reduce ? { duration: 0 } : { type: 'spring', stiffness: 420, damping: 36 }}
                  />
                )}
                <Node status={s.status} index={i} />
                <span className="relative min-w-0 flex-1 pt-px">
                  <span className={cn('block text-[13px] font-medium leading-tight', s.status === 'todo' && !selected ? 'text-ink-2' : 'text-ink')}>{meta.title}</span>
                  <span className={cn('mt-0.5 block truncate text-[11.5px] leading-tight', s.status === 'error' ? 'font-medium text-crit' : s.status === 'skipped' ? 'text-warn' : 'text-ink-3')}>{sub}</span>
                </span>
                <span className="sr-only">{STATUS_LABEL[s.status]}</span>
              </button>
            </li>
          )
        })}
      </ol>
    </aside>
  )
}
