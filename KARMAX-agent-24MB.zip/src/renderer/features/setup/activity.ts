import { useEffect } from 'react'
import { create } from 'zustand'
import type { SetupState, SetupStepId } from '@shared/ipc'
import { getBridge } from '@/lib/bridge'

export interface ActivityEntry {
  ts: number
  text: string
  level: 'info' | 'warn' | 'error'
}

interface ActivityStore {
  byStep: Partial<Record<SetupStepId, ActivityEntry[]>>
  push(id: SetupStepId, text: string, level?: ActivityEntry['level']): void
  clear(): void
}

export const useActivityStore = create<ActivityStore>((set) => ({
  byStep: {},
  push: (id, text, level = 'info') =>
    set((s) => {
      const list = s.byStep[id] ?? []
      // The same fact arrives as a step detail, a pairing line and an app log line, so skip anything seen just before.
      // Errors are only collapsed when they repeat back to back, so a retry that fails again is still shown.
      const recent = level === 'error' ? list.slice(-1) : list.slice(-8)
      if (recent.some((e) => e.text === text)) return s
      return { byStep: { ...s.byStep, [id]: [...list, { ts: Date.now(), text, level }].slice(-60) } }
    }),
  clear: () => set({ byStep: {} })
}))

/** Wizard-scoped: turns step-detail changes, pairing output and `[setup:<step>]` app log lines into a per-step feed. */
export function useActivityFeed(state: SetupState | undefined): void {
  const push = useActivityStore((s) => s.push)

  useEffect(() => {
    // Real backend: every step logs "[setup:<id>] message" through LogSink.app, which reaches the renderer via logs.onLine.
    return getBridge().logs.onLine((l) => {
      if (l.source !== 'app') return
      const m = /^\[setup:(\w+)\]\s*(.*)$/.exec(l.message)
      if (m && m[2]) push(m[1] as SetupStepId, m[2], l.level === 'error' ? 'error' : l.level === 'warn' ? 'warn' : 'info')
    })
  }, [push])

  useEffect(() => {
    if (!state) return
    for (const s of state.steps) {
      if (s.detail && s.status !== 'todo') push(s.id, s.detail)
      if (s.error) push(s.id, s.error, 'error')
    }
    const lines = state.pairing?.lines ?? []
    // Pairing output is streamed line by line; the store de-duplicates consecutive repeats.
    for (const l of lines.slice(-6)) push('whatsapp', l.replace(/([A-Z0-9]{4})-([A-Z0-9]{4})/, '••••-••••'))
  }, [state, push])
}

export function useActivity(id: SetupStepId): ActivityEntry[] {
  return useActivityStore((s) => s.byStep[id]) ?? EMPTY
}
const EMPTY: ActivityEntry[] = []
