import { create } from 'zustand'
import type { SetupState, SetupStepId, WaMode } from '@shared/ipc'

export const STEP_ORDER: SetupStepId[] = ['prereqs', 'model', 'binaries', 'config', 'whatsapp', 'services', 'operator', 'lockdown', 'verify']

export interface StepMeta {
  id: SetupStepId
  title: string
  /** One-line static description shown in the stepper while the step has not run. */
  blurb: string
}

export const STEP_META: Record<SetupStepId, StepMeta> = {
  prereqs: { id: 'prereqs', title: 'Check this PC', blurb: 'Claude Code and free ports' },
  model: { id: 'model', title: 'Model access', blurb: 'Your Anthropic API key' },
  binaries: { id: 'binaries', title: 'Install KARMAX', blurb: 'Verified karmax and wacli' },
  config: { id: 'config', title: 'Operator number', blurb: 'Who is allowed to give orders' },
  whatsapp: { id: 'whatsapp', title: 'Link WhatsApp', blurb: 'Pair the KARMAX number' },
  services: { id: 'services', title: 'Start services', blurb: 'Bring wacli and KARMAX up' },
  operator: { id: 'operator', title: 'Connect operator', blurb: 'Your first message opens the channel' },
  lockdown: { id: 'lockdown', title: 'Lock down chats', blurb: 'Every chat except yours' },
  verify: { id: 'verify', title: 'Test message', blurb: 'A round trip to your phone' }
}

export type View = 'welcome' | SetupStepId | 'finish'

const passed = (s: { status: string }) => s.status === 'done' || s.status === 'skipped'

/** First step that has not passed yet (the "current" step), or undefined when every step has. */
export function firstOpenStep(state: SetupState | undefined): SetupStepId | undefined {
  if (!state) return undefined
  return state.steps.find((s) => !passed(s))?.id
}

export function progressCount(state: SetupState | undefined): number {
  return state ? state.steps.filter(passed).length : 0
}

export function hasStarted(state: SetupState | undefined): boolean {
  return !!state && state.steps.some((s) => s.status !== 'todo')
}

/** Ephemeral inputs that must survive moving between panels (never persisted, never secrets). */
interface WizardStore {
  waMode: WaMode
  operatorInput: string
  pairPhone: string
  pairMethod: 'code' | 'qr'
  setWaMode(m: WaMode): void
  setOperatorInput(v: string): void
  setPairPhone(v: string): void
  setPairMethod(m: 'code' | 'qr'): void
}

export const useWizardStore = create<WizardStore>((set) => ({
  waMode: 'dedicated',
  operatorInput: '',
  pairPhone: '',
  pairMethod: 'code',
  setWaMode: (waMode) => set({ waMode }),
  setOperatorInput: (operatorInput) => set({ operatorInput }),
  setPairPhone: (pairPhone) => set({ pairPhone }),
  setPairMethod: (pairMethod) => set({ pairMethod })
}))
