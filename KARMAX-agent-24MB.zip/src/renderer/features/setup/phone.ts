/**
 * Renderer-side phone helpers. Mirrors electron/main/setup/phone.ts (which is authoritative: the backend re-validates
 * everything); duplicated here because the renderer must not import main-process modules. Keep the two in sync.
 */

export interface PhoneCheck {
  ok: boolean
  digits: string
  reason?: string
}

export function normalizePhone(input: string): string {
  let d = String(input ?? '').replace(/[^\d]/g, '')
  if (d.startsWith('00')) d = d.slice(2)
  return d
}

export function validatePhone(input: string): PhoneCheck {
  const digits = normalizePhone(input)
  if (!digits) return { ok: false, digits, reason: 'Enter a phone number.' }
  if (digits.startsWith('0')) return { ok: false, digits, reason: 'Start with the country code, without a leading 0 or +.' }
  if (digits.length < 8) return { ok: false, digits, reason: `${digits.length} digits so far. A number has 8 to 15 digits including the country code.` }
  if (digits.length > 15) return { ok: false, digits, reason: 'Too long: 8 to 15 digits including the country code.' }
  return { ok: true, digits }
}

/** Common dial codes (longest prefix wins). Purely a convenience hint next to the field, never used for validation. */
const DIAL: Record<string, string> = {
  '1': 'US / Canada', '7': 'Russia / Kazakhstan', '20': 'Egypt', '27': 'South Africa', '30': 'Greece', '31': 'Netherlands', '32': 'Belgium',
  '33': 'France', '34': 'Spain', '39': 'Italy', '40': 'Romania', '41': 'Switzerland', '43': 'Austria', '44': 'United Kingdom', '45': 'Denmark',
  '46': 'Sweden', '47': 'Norway', '48': 'Poland', '49': 'Germany', '52': 'Mexico', '54': 'Argentina', '55': 'Brazil', '56': 'Chile',
  '57': 'Colombia', '60': 'Malaysia', '61': 'Australia', '62': 'Indonesia', '63': 'Philippines', '64': 'New Zealand', '65': 'Singapore',
  '66': 'Thailand', '81': 'Japan', '82': 'South Korea', '84': 'Vietnam', '86': 'China', '90': 'Turkey', '91': 'India', '92': 'Pakistan',
  '94': 'Sri Lanka', '98': 'Iran', '212': 'Morocco', '234': 'Nigeria', '254': 'Kenya', '351': 'Portugal', '353': 'Ireland', '358': 'Finland',
  '380': 'Ukraine', '420': 'Czechia', '852': 'Hong Kong', '880': 'Bangladesh', '966': 'Saudi Arabia', '971': 'United Arab Emirates', '972': 'Israel', '974': 'Qatar'
}

export function countryOf(digits: string): { code: string; name: string } | undefined {
  for (const len of [3, 2, 1]) {
    const code = digits.slice(0, len)
    if (code.length === len && DIAL[code]) return { code, name: DIAL[code] }
  }
  return undefined
}

/** "919876543210" -> "+91 98765 43210" (country code, then groups of 5/4/3). Falls back to "+digits". */
export function formatPhone(digits: string): string {
  if (!digits) return ''
  const c = countryOf(digits)
  const cc = c?.code ?? ''
  const rest = digits.slice(cc.length)
  const groups: string[] = []
  let i = 0
  const size = rest.length > 9 ? 5 : 4
  while (i < rest.length) {
    groups.push(rest.slice(i, i + size))
    i += size
  }
  return `+${[cc, ...groups].filter(Boolean).join(' ')}`
}
