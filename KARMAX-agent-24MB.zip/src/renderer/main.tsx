import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './design/styles.css'
import App from './App'
import { resolveTheme, useUi } from './lib/stores'

document.documentElement.dataset.theme = resolveTheme(useUi.getState().theme)

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
)
